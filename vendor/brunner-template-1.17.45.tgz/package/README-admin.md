# Brunner Template 관리자 가이드

이 문서는 `brunner-template` 저장소에 실제로 존재하는 화면, API, 스크립트만 기준으로 작성합니다.

## 플랫폼구성

**개발환경**

**Railway**

**DB (PostgreSQL)**

**개발**

- 환경변수
- 초기생성
- 이관
- 테이블 별 용량 관리
  - `/mainPages/adminDbUsage`에서 테이블별 크기와 행수를 확인
  - 맨 위 볼륨 게이지는 `DB_CAPACITY_BYTES` 기준입니다.
  - 테이블 카드의 비율은 현재 테이블 합계 대비 비중입니다.
  - 각 테이블 카드에서 보관주기 정책을 설정할 수 있습니다.
- 테이블 별 보관주기
  - `lib/tableRetentionCron.js`가 `TB_COR_TABLE_RETENTION_POLICY` 정책을 기준으로 오래된 행을 삭제
  - 실행 시각은 관리자 화면의 Daily cleanup schedule에서 설정
  - 설정은 `TB_COR_TABLE_RETENTION_CONFIG`에 저장
  - 다중 인스턴스에서는 DB lease를 잡은 1개 인스턴스가 실행하는 방식
  - 끄기: `DB_RETENTION_ENABLED=false`
- 백업
  - `lib/dbBackupCron.js`가 `pg_dump` 결과를 매일 정해진 시각에 현재 테넌트 데이터를 떠서 gzip으로 압축해 Cloudflare R2에 저장
  - 관리자 메뉴의 **DB설정관리** 화면 맨 아래 "DB 백업" 패널에서 설정
  - 저장하면 재배포 없이 다음 회차부터 백업 수행

| 항목      | 내용                                                                                                       |
| --------- | ---------------------------------------------------------------------------------------------------------- |
| 대상      | **이 배포의 `SYSTEM_CODE` 데이터만.**한 스키마를 세 서비스가 나눠 쓰므로 테넌트 경계를 백업에서도 지킵니다 |
| 시각·주기 | 관리자 화면에서 설정합니다(기본 매일 04시 KST). 설정은 `TB_COR_DB_BACKUP_CONFIG`에 테넌트별로 저장됩니다   |
| 방식      | `pg_dump`가 있으면 그것으로, 없으면 `pg` 드라이버로 직접 뜹니다                                            |
| 저장      | `backups/{서비스명}-db-dow{0~6}.sql.gz` — 요일 로테이션 7일 롤링                                           |
| 이력      | `TB_COR_DB_BACKUP_HIST`에 성공·실패를 남깁니다. 화면 조회는 최근 7일, 행 보관은 보존정책으로 30일          |

| 할 수 있는 일   | 설명                                                                  |
| --------------- | --------------------------------------------------------------------- |
| 자동 백업 켬/끔 | 끄면 예약을 잡지 않습니다. 다시 켤 때까지 자동 백업은 돌지 않습니다   |
| 시작 시각       | 브라우저 시간대로 입력하고, 저장할 때 그 시간대와 함께 기록됩니다     |
| 주기            | 하루 1회(기본)부터 1시간까지. 시작 시각을 기준으로 그 간격마다 돕니다 |
| 지금 백업       | 예약과 무관하게 한 번 바로 뜹니다                                     |
| 백업 이력       | 최근 7일의 성공·실패, 크기, 행 수, 실행 주체(예약 실행 / 즉시 실행)   |
| 내려받기        | 성공한 백업 파일을 짧게 유효한 서명 주소로 받습니다                   |
| 복원            | 그 백업 시점으로 되돌립니다                                           |

     - 백업이 실제로 되고 있는지는 `/api/build-info`의 `backup` 항목과 관리자 화면의 백업 이력에서 확인

설정은 `TB_COR_DB_BACKUP_CONFIG`에 테넌트별로 저장됩니다. 인스턴스가 여러 개여도 같은
회차를 둘이 뜨지 않도록 테넌트 단위 락을 잡습니다 — 락은 그 테넌트에만 걸리므로 한 서비스의 백업이 다른 서비스를 막지 않음

    - 복원
      - 백업 파일로**해당 테넌트만**백업 시점으로 복원
      - 파일 헤더의 테넌트와 복원 대상이 다르면 거절합니다
        — `02` 백업을 `01`에 넣을 수 없습니다.
      - 지우는 범위는 백업 파일에 실제로 들어 있는 테이블로 한정하고, `system_code`로 한 번 더 좁힙니다.
      - 전부 한 트랜잭션입니다. 중간에 실패하면 지운 것도 되살아나므로 "지워졌는데 못 채운" 상태는 생기지 않습니다.
      - 복원 후 시퀀스를 현재 최대값 뒤로 밉니다. 이걸 빠뜨리면 복원 직후 첫 글쓰기가 중복키로 깨집니다.
      -**백업 이후에 쌓인 데이터는 사라집니다.
        - 병합이 아니라 시점 복구임
        - 화면에서 복원할 때는 되돌릴 수 없는 조작이므로 두 단계를 거칩니다.
         "먼저 점검"은 파일에 들어있는 테이블 수와 행 수만 확인하고 아무것도 바꾸지 않습니다.
         실제 복원은 백업 파일 이름을 그대로 입력해야 버튼이 열립니다.
         이력에 남아 있는 성공한 백업만 대상이 됩니다.
        - 되돌리지 않는 것: 테이블 정의(DDL). 구조의 정본은 저장소의 `scripts/create_*.sql`입니다.
    - 백업 성능
      - 일반 조회로 읽으므로 백업이 쓰기를 막지는 않음.
      - 실측으로 10만 행에 약 10초이며 거의 선형으로 증가함
      - 복원은 `INSERT`를 한 줄씩 실행해 백업보다 오래 걸림
      - 데이터가 커지면 손볼 곳 두 군데입니다
        - 읽기가 `OFFSET` 페이징이라 뒤로 갈수록 느려짐
        - 복원이 한 트랜잭션이라 그동안 락과 WAL이 커짐
    - 용량 경보
      - `lib/dbCapacityMonitor.js`가 DB 크기를 주기적으로 확인
      - 기준: `DB_CAPACITY_BYTES`, `DB_ALERT_PERCENT`, `DB_ALERT_BYTES`
      - 알림: `DB_ALERT_EMAIL`
      - 끄기: `DB_CAPACITY_MONITOR_ENABLED=false`

**운영**

- 환경변수
  - ENCRYPTION 키 (데이터 암호화)
  - 푸시키 VAPID
  - 카카오 인증키 (로그인, 회원가입 인증)
  - TOSS 인증키 (결재)
  - DB_SCHEMA: PostgreSQL에서 어느 스키마의 테이블을 볼지 결정
  - SYSTEM_CODE: 같은 스키마 안에서 어느 서비스/테넌트 데이터를 볼지 결정
    - 운영 정책에 따라 한 스키마에 여러 서비스를 `SYSTEM_CODE`로 합칠 수도 있고, 서비스별로 `DB_SCHEMA`를 나눠 분리할 수도 있음
    - 복수개의 테넌트가 스키마를 공유하는 경우 스키마 변경은 여러 테넌트에 영향을 주므로 매우 유의해야 함
- 초기생성
- 이관
- 퍼지 및 백업
- Replicas 설정
  **AP**
- 개발
  - Github 배포설정
  - 환경변수 등록
  - 빌드및배포 현황 확인
- 운영
  - Github 배포설정
  - 환경변수 등록
  - Replicas 설정
  - Redis AP 동기화
  - 도메인URL 설정
  - 빌드및배포 현황 확인
  - 문서 작업
    - 문서 동기화
      `scripts/sync_repo_docs_to_edoc.cjs`가 저장소 문서를 eDoc 공용문서로 upsert
      - 사용자 공개 문서: `README.md`
      - 관리자 공개 믄사: `README-admin.md`, `PLAN.md`, `Offering.md`, `Contract.md`
        `SYNC_REPO_DOCS_ON_START=false`로 서버 시작 시 동기화를 끌 수 있습니다.

**Github**

- 브랜치 관리

**Claude**

- Claude Desktop

---

### 아키텍처

**DB**

- DB URL
- 스키마 명
- 시스템 코드
  - 테넌트로 데이터를 논리적으로 분리함

**AP**

- 도메인 URL
- DB 스키마 이름
- 시스템 코드
- 동적 쿼리
  - 서버코드 내 SQL작성은 금지하며 서버에서 수행하는 SQL은 모두 DB 테이블 (TB_COR_SQL_INFO)에 저장하고 관리함
  - DB SQL 스크립트는 서버 시작 전에 `scripts/run_sql.cjs`가 실행함
  - `VERIFY_DYNAMIC_SQL_ON_START=false`로 시작 시 검증을 끌 수 있음
- UI 요청 메시지의 응딥 메시지에 서버 처리 시간(durationMs) 항목 필수 포함

**Cloudflare (Object Storage)**

- 미디어 저장
  R2가 설정된 경우 바이너리는 DB가 아니라 R2에 저장
  | 자산 | R2 키 |
  | ------------------ | --------------------------------------- |
  | 채팅 첨부 | `chat/{roomId}/{uuid}.{ext}` |
  | 채팅 메시지 이미지 | `chat/{roomId}/img-{uuid}.{ext}` |
  | 프로필 사진 | `profile/{userId}.{ext}` |
  | 커스텀 이모지 | `emoji/{userId}/{uuid}.{ext}` |
  | DB 백업 | `backups/{서비스명}-db-dow{0-6}.sql.gz` |

  R2가 없으면 기존 DB 저장 경로로 폴백
  공개 자산은 `R2_PUBLIC_BASE_URL`을 설정하면 커스텀 도메인으로 서빙

- DB 백업
  - DB의 현재 테넌트 데이터를 gzip으로 압축해 Cloudflare R2에 관리자 설정에 따라 주기적으로 백업

### 화면

**관리자 화면**

관리자 화면은 관리자 전용 화면들이며 관리자 여부 판정은 사용자 마스터의 `admin_flag`를 기준으로 함

| 경로                               | 용도                                  |
| ---------------------------------- | ------------------------------------- |
| `/admin/hub`                       | 관리자 허브                           |
| `/admin/sql`                       | 관리자 SQL                            |
| `/admin/transactions`              | 트랜잭션 이력                         |
| `/mainPages/transactionHistory`    | 앱 내 트랜잭션 이력                   |
| `/mainPages/dynamicSql`            | 동적 SQL 관리                         |
| `/mainPages/userActivityDashboard` | 사용자 활동 대시보드                  |
| `/mainPages/adminDbUsage`          | DB설정관리: 테이블별 용량/보관주기/백업 설정 |
| `/mainPages/complaint`             | 문의사항 관리                         |

**일반 화면**

**결제/크레딧 운영**

- 크레딧은 템플릿의 공통 과금 단위
- 충전, 지급, 사용, 환불은 모두 공통 잔액 테이블과 원장 테이블에 기록
- 홈의 크레딧 영역에서 현재 잔액을 확인 -**충전**버튼은 `ChargeModal`을 열고 토스 결제창으로 이동
- 기본 충전 선택지는 1,000원/3,000원/5,000원/10,000원
- 화면에서는 10원당 1크레딧으로 표시 -**내역**버튼은**크레딧 내역**과**결제 내역**탭을 함께 표시
- 결제 내역 탭에서는 `APPROVED` 상태 결제만**결제 취소**버튼 표시

**푸시 알림**

Web Push는 VAPID 키가 필요합니다.

| 변수                           | 설명                          |
| ------------------------------ | ----------------------------- |
| `NEXT_PUBLIC_VAPID_PUBLIC_KEY` | 클라이언트 구독용 공개 키     |
| `VAPID_PUBLIC_KEY`             | 서버 공개 키                  |
| `VAPID_PRIVATE_KEY`            | 서버 개인 키                  |
| `VAPID_SUBJECT`                | VAPID subject                 |
| `MAIL_USER`                    | subject fallback 및 메일 계정 |

구독 만료(404/410)는 사용자가 알림을 껐다 켜면 새 구독으로 교체됩니다.

---

## 신규 설치 위저드와 동적 SQL

설치 위저드(관리자 → Railway 배포)는 **리포의 SQL 스크립트를 그대로 적용하고, 동적 SQL 은
지금 돌고 있는 이 배포의 등록분을 옮깁니다.** 덤프 파일(`scripts/schema_full.sql`)은 더 이상
설치에 쓰지 않습니다.

- 적용 순서는 `scripts/install_sql_files.json` 한 곳에 있고, 서버 기동 시 돌리는
  `run_sql.cjs` 도 같은 목록을 읽습니다. 목록이 한 벌이라 새 스크립트를 추가하면 기존
  배포와 신규 설치가 같이 따라옵니다.
- 예전에는 덤프가 기준이라 새 스크립트가 설치본에 반영되지 않았습니다. 실제로 게시판·결제이력·
  보존정책·전자문서 컴포넌트 템플릿 등 **테이블 11개와 동적 SQL 61건**이 빠진 채 설치됐고,
  그렇게 만든 시스템은 해당 기능이 바로 실패합니다.
- 적용할 때 스크립트의 스키마 이름을 입력한 `DB_SCHEMA` 로, 시드의 테넌트를 입력한
  `SYSTEM_CODE` 로 바꿉니다.
- 마지막에 이 배포의 `TB_COR_SQL_INFO` 를 대상 스키마로 upsert 합니다. 관리 화면에서 손본
  쿼리까지 새 시스템에 그대로 따라갑니다. 등록분을 하나도 못 찾으면 설치를 중단합니다 —
  쿼리가 반쪽만 들어간 시스템이 조용히 만들어지는 쪽이 더 위험합니다.
- 설치 목록은 템플릿 배포에만 둡니다. 파생 서비스(brunner-next·zicp)의 SQL 목록에는 일회성
  이관 스크립트가 섞여 있어 새 DB 에 돌리면 안 되므로, 위저드는 그 배포에서 실행하면
  목록을 못 찾고 멈춥니다.

## SQL_NAME 규칙은 빌드가 막습니다

`SQL_NAME` 은 `{동사}_{테이블}` 이고 스키마 토큰(`BRUNNER`)을 넣지 않습니다.
`alias_sql_names_without_brunner.sql` 이 매 배포마다 `%_BRUNNER_%` 이름을 지우므로, 그런 이름으로
등록하면 심자마자 사라지고 그 이름을 쓰는 화면만 조용히 실패합니다.

`npm run gate:sqlname` — 시드와 `getSQL` 호출부를 훑어 위반이 있으면 실패합니다. 검사 대상은 게이트가
놓인 곳이 아니라 **실행하는 앱**입니다(`BRUNNER_APP_DIR` 또는 실행 디렉터리). 파생 서비스가 패키지의
게이트를 그대로 돌려도 자기 시드·코드를 검사합니다. `prebuild` 에
걸려 있어 위반이 있으면 빌드가 진행되지 않습니다. 파생 서비스는 패키지를 다시 받으면 같은
게이트를 쓰게 됩니다.

## 멀티테넌트 경계

여러 서비스가 한 스키마를 `SYSTEM_CODE` 로 나눠 쓰므로, 서비스 경계는 쿼리에서 지켜진다.

- 동적 SQL 본문에 테넌트 값을 리터럴로 박지 않는다. 등록분이 다른 테넌트로 복제될 때 그대로
  따라가, 그 배포가 남의 서비스 데이터를 읽고 쓰게 된다. 테넌트는 파라미터로 받는다.
- 서버 크론(일정 미리 알림 등)은 자기 테넌트만 처리한다. 테넌트 조건이 없으면 한 서비스가
  다른 서비스의 알림을 대신 보내고 처리완료 표시까지 찍어, 정작 맞는 서비스에서는 알림이 안 뜬다.
- 초대 토큰 조회처럼 링크 하나로 들어오는 경로도 테넌트로 좁힌다.
- 푸시 구독은 서비스마다 따로 저장한다. 같은 아이디를 여러 서비스에서 쓰면, 경계가 없을 때
  한 서비스의 채팅 알림이 다른 서비스 앱에서도 울린다.

## 2026-08-24 변경 사항

### UI 리소스 DB화

- 화면 라벨/메시지를 `TB_COR_RESOURCE_TEXT`에서 읽도록 변경했습니다.
- 클라이언트는 `/api/resource-text`를 호출해 리소스 캐시를 구성합니다.
- 서버 시작 시에도 리소스 rows를 미리 적재해 공용 함수 캐시에 반영합니다.
- 리소스가 실제로 누락된 경우 `[리소스 없음:label:key:ko-KR]` 형태로 표시되며, 노란색/분홍색 경고 스타일로 눈에 띄게 표시됩니다.
- `languageCode`가 아직 준비되지 않은 초기 렌더에서는 누락 경고를 표시하지 않습니다.

### 리소스 테이블/시드

- `scripts/create_resource_text_table.sql`을 추가했습니다.
- `scripts/seed_resource_text_common.sql`에 공용 리소스 seed를 추가했습니다.
- `complaint` 메뉴 라벨이 누락되어 `label:complaint`를 `00/01/02`에 추가했습니다.
- 현재 운영 기준 `brunner.tb_cor_resource_text`는 `DB_SCHEMA=brunner`와 각 서비스의 `SYSTEM_CODE`로 조회합니다.

### Railway PostgreSQL SSL

- `SSL_MODE=require`일 때 `pg` Pool 설정을 `ssl: { rejectUnauthorized: false }`로 처리하도록 수정했습니다.
- 기존에는 `ssl: true`로 전달되어 Railway PostgreSQL에서 `SELF_SIGNED_CERT_IN_CHAIN`이 발생했고, `/api/resource-text`가 빈 배열을 반환했습니다.
- 운영 필수 env 예시는 다음과 같습니다.
  - `DATABASE_URL`
  - `DB_SCHEMA=brunner`
  - `SYSTEM_CODE=00` 또는 서비스별 코드
  - `SSL_MODE=require`

### 파생 서비스 배포 방식

- `brunner-next`, `zicp`는 private `brunner-template` GitHub repo를 Railway 빌드 중 직접 받지 않도록 변경했습니다.
- 각 서비스 repo에 `vendor/brunner-template-1.14.9.tgz`를 커밋하고, `package.json`에서 `brunner-template`을 `file:vendor/brunner-template-1.14.9.tgz`로 설치합니다.
- 이 방식은 Railway가 현재 서비스 repo만 checkout할 수 있으면 빌드 가능하며, 별도 GitHub SSH 권한이나 private dependency 인증이 필요 없습니다.
- `brunner-template` 변경을 파생 서비스에 반영하려면 다음 순서로 진행합니다.
  1. `brunner-template`에서 `npm pack`
  2. 생성된 `.tgz`를 각 서비스 repo의 `vendor/`에 복사
  3. 각 서비스 repo에서 `package-lock.json` 갱신
  4. 각 서비스 repo에 커밋/푸시

### Vendored Template Alias

- vendored `brunner-template` 내부의 `@/...` import가 서비스 repo에서 해석되도록 `next.config.js` alias를 정리했습니다.
- 클라이언트와 서비스별 override는 로컬 repo를 우선합니다.
  - `@/components/core/client` -> 로컬 `components/core/client`
  - `@/lib` -> 로컬 `lib`
- 서버 공용 모듈은 vendored template을 사용합니다.
  - `@/components/core/server` -> `node_modules/brunner-template/components/core/server`
  - `@/lib/serviceRunner` -> `node_modules/brunner-template/lib/serviceRunner.js`

### 햄버거/홈 메뉴 manifest

- 햄버거 메뉴와 템플릿 홈 카드 메뉴는 `lib/menuManifest.js`에서 관리합니다.
- manifest에는 메뉴 구조, 경로, 노출 여부만 두고 화면 라벨은 `key`를 통해 `TB_COR_RESOURCE_TEXT`에서 다국어로 조회합니다.
- `components/core/client/frames/dropdownMenuitem.js`는 manifest를 읽어 섹션과 항목으로 변환하고, 공용문서 메뉴는 기존처럼 DB 문서 목록에서 붙입니다.
- `components/core/client/contents/homeContent.js`는 `homeMenu`만 참조하므로 홈 노출 여부는 manifest 항목의 `home` 값으로 조정합니다.
- 파생 서비스는 로컬 `lib/menuManifest.js`를 두면 `next.config.js` alias 정책에 따라 npm 패키지의 manifest보다 로컬 manifest가 우선합니다.
- 서비스별 메뉴가 있는 경우 `zicpMenu`, `serviceMenuSections`처럼 서비스 repo에서 manifest 구조를 확장하고 dropdown 조립부는 변환 로직만 유지합니다.

### 설치 마법사에 넣는 토큰 세 가지

| 토큰 | 발급처 | 필요한 권한 |
|------|--------|-------------|
| Railway Account Token | `railway.com` → Account Settings → Tokens (Workspace 없이 발급) | 프로젝트 목록·생성, 워크스페이스·환경 조회 |
| Railway Workspace Token | 같은 화면에서 Workspace 를 지정해 발급 | 서비스·변수·배포. 화면 라벨은 Project Token 이지만 워크스페이스 토큰을 넣어도 동작합니다 |
| GitHub Token | `github.com/settings/personal-access-tokens/new` | Repository access 에서 대상 저장소 선택, Permissions → Contents 를 Read and write |

- GitHub 토큰은 대상 저장소에 초기 소스를 커밋할 때만 씁니다. Contents 권한을 주지 않으면
  GitHub 가 403 이 아니라 404 를 돌려주므로, 저장소가 없는 것처럼 보이는 오류가 납니다.
- 세 토큰 모두 화면에만 입력하며 서버나 DB 에 저장하지 않습니다. 새로고침하면 지워지므로
  다시 입력해야 합니다.
- 세 토큰과 대상 저장소 이름(`owner/repo`) 네 가지는 1단계 "사전 입력값" 화면에서 한 번에 입력합니다.
  네 줄을 통째로 붙여넣는 칸이 있어, `라벨: 값` 형식이면 라벨로 나누고 라벨이 없으면 값 모양으로
  나눠 담습니다. 저장소 주소를 통째로 붙여넣어도 `owner/repo` 로 정리합니다.
- 2단계부터는 같은 값을 다시 묻지 않습니다. 각 단계 위에 지금 쓰이는 네 값을 읽기 전용으로 보여주고,
  고쳐야 하면 "1단계에서 고치기" 로 돌아가 바꿉니다. NextJS 서비스 단계의 저장소·GitHub 토큰 칸도
  읽기 전용입니다.

### 신규 시스템 설치 마법사 DB 초기화

- 설치 마법사와 그 API(`/api/admin/railwayDeploy`)는 관리자 로그인 상태에서만 동작합니다. 세션이 없거나 `admin_flag`가 아니면 모든 단계가 거부됩니다.
- DB 스키마 적용 단계에서 `DB_SCHEMA`와 `SYSTEM_CODE`를 반드시 입력합니다.
- `SYSTEM_CODE`는 1~2자만 허용합니다. 핵심 테이블 13개의 `system_code` 컬럼이 `varchar(2)`라, 3자 이상이면 스키마 적용 직후 seed 적재가 실패합니다.
- 환경변수 카운터(`n/29`)는 값이 실제로 입력된 항목만 셉니다. 초록으로 바뀌지 않으면 빈 값이 남아 있다는 뜻입니다.
- API는 `scripts/install_sql_files.json` 의 스크립트를 순서대로 실행하며, 실행 전에 SQL 파일의 `brunner_template.`/`brunner.` 스키마 접두어를 입력한 `DB_SCHEMA`로 바꾸고 초기 동적 SQL/리소스 seed의 `SYSTEM_CODE`를 입력한 값으로 바꿉니다. `micoMES`처럼 대문자가 섞인 스키마명은 `"micoMES"` 형태의 PostgreSQL quoted identifier로 적용합니다. 마지막에 이 배포의 동적 SQL 등록분을 그대로 옮깁니다.
- 입력한 `DB_SCHEMA`가 없으면 `CREATE SCHEMA IF NOT EXISTS`로 먼저 생성합니다.
- AP 서비스 Railway 필수 환경변수는 29개입니다. `DB_SCHEMA`, `SYSTEM_CODE`는 마법사 입력값으로 덮어씁니다.
- 필수 목록: `APP_ENCRYPTION_KEY`, `CHAT_DB_POOL_MAX`, `DATABASE_URL`, `DB_CAPACITY_BYTES`, `DB_POOL_MAX`, `DB_SCHEMA`, `HOST`, `KAKAO_CLIENT_SECRET`, `KAKAO_REST_API_KEY`, `MAIL_USER`, `NEXT_PUBLIC_KAKAO_API_KEY`, `NEXT_PUBLIC_TOSS_CLIENT_KEY`, `NEXT_PUBLIC_VAPID_PUBLIC_KEY`, `NODE_ENV`, `PUSH_JOB_CONCURRENCY`, `PUSH_SEND_CONCURRENCY`, `R2_ACCESS_KEY_ID`, `R2_ACCOUNT_ID`, `R2_BUCKET_NAME`, `R2_SECRET_ACCESS_KEY`, `REDIS_URL`, `RESEND_API_KEY`, `RESEND_FROM`, `SSL_MODE`, `SYSTEM_CODE`, `TOSS_SECRET_KEY`, `TXN_HISTORY_EXCLUDED_USERS`, `VAPID_PRIVATE_KEY`, `VAPID_PUBLIC_KEY`.
- `TENANT_SYSTEM_CODE`, `NEXT_PUBLIC_SYSTEM_CODE`는 설치 마법사에서 등록하지 않습니다.

### 운영 확인

- 배포 반영 여부는 `/api/build-info`의 `commitSha`, `startedAt`, `version`으로 확인합니다.
- 리소스 정상 적재 여부는 `/api/resource-text`의 `rows.length`와 특정 키 조회로 확인합니다.
- `brunner-template` 운영에서 `SYSTEM_CODE=00` 리소스 조회가 정상인 것을 확인했습니다.
