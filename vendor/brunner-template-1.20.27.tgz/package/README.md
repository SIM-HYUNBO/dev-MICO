# Brunner Template

## 최근 반영

- 문서 디자이너에서 저장한 문서는 문서 열기 목록에서 다시 불러와 이어서 편집할 수 있습니다.

Brunner Template은 Next.js 기반 업무/커뮤니케이션 템플릿입니다. 현재 저장소에 포함된 실제 화면과 API를 기준으로 이 문서를 유지합니다.

## 주요 기능

| 영역 | 포함 기능 |
|------|-----------|
| 계정 | 회원가입, 로그인, 카카오 로그인, 비밀번호 재설정, 계정 정보 관리 |
| 채팅 | 1:1 채팅, 단체 채팅, 오픈채팅, 파일/이미지/영상 첨부, 읽음/미읽음, 반응, 검색 |
| 친구 | 친구 목록, 친구 요청, 1:1 채팅 연결 |
| 일정 | 일정 등록/수정/삭제, 반복 일정, 음력 반복, 참가자, 알림 |
| 문서 | eDoc 문서 디자이너, 공용문서, Markdown 가져오기/내보내기, AI 문서 초안 생성 |
| 결제/크레딧 | 토스페이먼츠 충전, 크레딧 잔액/원장, 결제 이력, 전액 취소 |
| 운영 | 트랜잭션 이력, 동적 SQL, 사용자 활동 대시보드, DB 적재량/보관주기 관리 |
| 기타 | 계산기, 문의사항, PWA 설치, Web Push |

## 화면 경로

| 경로 | 설명 |
|------|------|
| `/` | 홈 |
| `/mainPages/signin` | 로그인 |
| `/mainPages/signup` | 회원가입 |
| `/mainPages/resetPassword` | 비밀번호 재설정 |
| `/mainPages/userAccount` | 계정 정보 |
| `/mainPages/chatRoom` | 채팅방 |
| `/mainPages/openChat` | 오픈채팅 |
| `/mainPages/userFriendManagement` | 친구 관리 |
| `/mainPages/schedule` | 일정 |
| `/mainPages/eDocDesigner` | 문서 디자이너 |
| `/mainPages/calculator` | 계산기 |
| `/mainPages/complaint` | 문의사항 |
| `/mainPages/settings` | 설정 |
| `/mainPages/transactionHistory` | 트랜잭션 이력 |
| `/mainPages/userActivityDashboard` | 사용자 활동 대시보드 |
| `/mainPages/adminDbUsage` | DB설정관리 |
| `/mainPages/dynamicSql` | 동적 SQL |
| `/mainPages/userManual` | 사용자 매뉴얼 |
| `/admin/hub` | 관리자 허브 |
| `/admin/sql` | 관리자 SQL |
| `/admin/transactions` | 관리자 트랜잭션 이력 |

## 채팅

- Socket.IO 기반 실시간 채팅을 사용합니다.
- 1:1, 단체, 오픈채팅 방을 지원합니다.
- 이미지/파일/영상 첨부를 지원합니다.
- 메시지 반응, 검색, 읽음/미읽음 집계, 초대 알림을 제공합니다.
- R2가 설정된 경우 채팅 첨부와 이미지를 R2에 저장하고 DB에는 키만 남깁니다.
- 비밀방은 방 키와 메시지 암호화를 사용합니다.

## 문서

- eDoc 문서 디자이너에서 텍스트, 이미지, 테이블, 입력, 체크리스트, 버튼, 링크, 카드, 동영상, Lottie 컴포넌트를 배치할 수 있습니다.
- 문서를 공용문서로 공개하면 햄버거 메뉴 자료실에 표시됩니다.
- `README.md`, `README-admin.md`, `PLAN.md`, `Offering.md`, `Contract.md`는 서버 시작 시 eDoc 공용문서로 동기화할 수 있습니다.
- AI 문서 초안 생성은 공통 텍스트 provider를 사용합니다. 사용자는 내 AI API 키를 선택할 수 있고, 비용과 차감 여부는 크레딧 설정을 따릅니다.

## 결제와 크레딧

- 충전은 토스페이먼츠 결제창으로 진행합니다.
- 기본 환산은 `CREDIT_WON_PER_CREDIT=10` 기준, 10원당 1크레딧입니다.
- 잔액은 `TB_COR_CREDIT_MST`, 변동 이력은 `TB_COR_CREDIT_LEDGER`에 저장합니다.
- 결제 이력은 `TB_COR_PAYMENT_HIST`에 저장합니다.
- 사용자는 크레딧 내역 모달에서 결제 이력을 보고 승인 결제를 전액 취소할 수 있습니다.
- 결제 취소는 지급된 크레딧을 먼저 회수하고 토스 취소를 호출합니다. 이미 크레딧을 사용해 잔액이 부족하면 취소가 거절됩니다.

## 관리자 기능

- 트랜잭션 이력 조회
- 동적 SQL 조회/관리
- 사용자 활동 대시보드
- DB설정관리
  - 테이블별 용량 조회
  - 테이블 보관주기 정책 관리와 즉시 정리
- 문의사항 전체 관리
- 결제 이력 전체 조회와 결제 취소

## 주요 환경변수

| 변수 | 설명 |
|------|------|
| `DATABASE_URL` | PostgreSQL 연결 문자열 |
| `DB_SCHEMA` | PostgreSQL 스키마 이름 |
| `SYSTEM_CODE` | 서비스/테넌트 코드 |
| `TOSS_SECRET_KEY` | 토스페이먼츠 서버 키 |
| `NEXT_PUBLIC_TOSS_CLIENT_KEY` | 토스페이먼츠 클라이언트 키 |
| `CREDIT_WON_PER_CREDIT` | 원화-크레딧 환산 단위 |
| `CREDIT_STARTER` | 신규/최초 조회 사용자 스타터 크레딧 |
| `R2_ACCOUNT_ID` | Cloudflare R2 계정 ID |
| `R2_ACCESS_KEY_ID` | R2 Access Key |
| `R2_SECRET_ACCESS_KEY` | R2 Secret Key |
| `R2_BUCKET_NAME` | R2 버킷 |
| `R2_PUBLIC_BASE_URL` | 공개 자산용 R2 커스텀 도메인 |
| `REDIS_URL` | Socket.IO Redis Adapter |
| `VAPID_PUBLIC_KEY` | Web Push 공개 키 |
| `VAPID_PRIVATE_KEY` | Web Push 개인 키 |
| `MAIL_USER` | 메일 발송 계정 또는 VAPID subject fallback |

## 로컬 실행

```bash
npm install
npm run dev
```

운영 시작은 DB SQL 등록 후 서버를 실행하는 흐름입니다.

```bash
npm run db:sql
npm start
```
