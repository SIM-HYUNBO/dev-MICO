// scripts/run_sql.cjs
// DB table migration and dynamic SQL registration runner.
// last updated: 2026-06-18 R2 migration

const { Client } = require("pg");
const fs = require("fs");
const crypto = require("crypto");
const path = require("path");

// 파생 서비스에서는 이 파일이 node_modules 안에 있다. .env 는 패키지가 아니라
// 실행하는 앱 루트에 있으므로 그쪽을 먼저 본다.
const appDir = process.env.BRUNNER_APP_DIR || process.cwd();
require("dotenv").config({ path: path.join(appDir, ".env") });
require("dotenv").config({ path: path.join(__dirname, "../.env") });

// 스키마 DDL 은 한 곳만 책임진다.
//
// 세 서비스(brunner-next / brunner-template / zicp)는 brunner 스키마 하나를 공유하고
// SYSTEM_CODE 로만 갈린다. 옛 brunner_template · zicp 스키마는 이관 뒤 없어졌다.
// 여기 SQL 파일들은 스키마 이름을 그대로 박고 있고 TB_COR_SQL_INFO 를 DELETE 하는
// 것도 있어, 두 배포가 같은 스키마에 각자 DDL 을 돌리면 서로의 등록분을 지운다.
// 그래서 스키마를 소유한 배포(SCHEMA_OWNER)만 DDL 을 적용하고, 나머지는 건너뛴다.
// 소유자가 심을 때 그 스키마 안의 모든 테넌트(00·01·02)분을 함께 등록한다.
const SCHEMA_OWNER = "brunner";
// 소문자로 접는다. PostgreSQL 이 따옴표 없는 식별자를 그렇게 다루므로, 대소문자를
// 살리면 참조하는 모든 자리에서 따옴표를 씌워야 하고 한 군데만 빠져도 무너진다.
const DB_SCHEMA = (process.env.DB_SCHEMA || "").trim().toLowerCase() || "brunner_template";

if (!/^[a-z_][a-z0-9_]*$/.test(DB_SCHEMA)) {
  console.error(`[run_sql] DB_SCHEMA 형식이 올바르지 않다: ${DB_SCHEMA}`);
  process.exit(1);
}

const quoteIdentifier = (identifier) => `"${String(identifier).replace(/"/g, '""')}"`;
const DB_SCHEMA_SQL = quoteIdentifier(DB_SCHEMA);

// 이 리포는 남의 스키마에 얹혀 사는 테넌트라 기본값이 false 다. 하지만 설치
// 마법사로 만든 시스템은 자기 스키마의 주인이므로 스스로 DDL 을 적용해야 한다.
// 하드코딩해 두면 파생 시스템이 DB 를 영원히 초기화하지 못한다.
// 파생 서비스는 자기 SQL 을 따로 갖는다(예: 그 서비스 전용 리소스 시드). 목록을
// 앱 저장소에 두게 해야 패키지의 run_sql 을 그대로 쓰면서도 자기 것을 돌릴 수 있다.
// 스키마 소유자가 아니면 공용 DDL 은 건너뛰고 이 목록만 돌린다 — 남의 스키마에
// DDL 을 적용하지 않으면서 자기 데이터는 넣기 위해서다.
const readServiceSqlFiles = () => {
  const file = path.join(appDir, "scripts", "service_sql_files.json");
  if (!fs.existsSync(file)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    const list = Array.isArray(parsed) ? parsed : parsed.files || [];
    return list.map((entry) => String(entry).trim()).filter(Boolean);
  } catch (error) {
    console.error(`[run_sql] service_sql_files.json 을 읽지 못했다: ${error.message}`);
    process.exit(1);
  }
};

const readAppPackage = () => {
  const packageFile = path.join(appDir, "package.json");
  if (!fs.existsSync(packageFile)) return {};
  try {
    return JSON.parse(fs.readFileSync(packageFile, "utf8"));
  } catch {
    return {};
  }
};

const appPackage = readAppPackage();
const schemaOwnedEnv = String(process.env.DB_SCHEMA_OWNED || "").trim().toLowerCase();
const DB_SYSTEM_CODE = String(process.env.SYSTEM_CODE || "").trim() || "00";
const isTemplateSystemOwner =
  appPackage.name === "brunner-template" && DB_SYSTEM_CODE === "00";
const OWNS_SCHEMA =
  schemaOwnedEnv === "true" || (schemaOwnedEnv !== "false" && isTemplateSystemOwner);

if (OWNS_SCHEMA && schemaOwnedEnv !== "true") {
  console.log("[run_sql] brunner-template SYSTEM_CODE=00 deploy owns the shared schema by default.");
}


// 비소유 배포가 돌릴 목록. 소유자면 null 이다.
//
// 예전에는 이 값을 process.env.SQL_FILES 에 밀어 넣어 아래 계산에 태웠다. 지금은
// 환경변수가 목록을 대체하지 않고 더하므로, 그렇게 두면 비소유 배포가 공용 DDL 까지
// 남의 스키마에 돌리게 된다. 목록을 따로 들고 간다.
let SERVICE_ONLY_FILES = null;

// 동적 SQL 등록 파일은 소유자가 아니어도 돌린다.
//
// 왜
//   등록이 없으면 그 이름을 부르는 화면이 "Database operation failed." 로 죽는다.
//   그런데 등록을 심을 수 있는 것은 소유 배포뿐이라, 소유 배포가 옛 판을 쓰고
//   있거나 아무도 소유자가 아니면 등록이 영영 안 된다. 실제로 그 상태였다 —
//   어느 배포에도 DB_SCHEMA_OWNED 가 없어 공용 등록이 통째로 멈춰 있었고,
//   화면 두 개가 조용히 죽어 있었는데 아무도 몰랐다.
//
//   이 파일들은 TB_COR_SQL_INFO 에 upsert 만 한다. 테이블을 만들지도 지우지도
//   않으므로 남의 스키마를 망가뜨릴 수 없고, 여러 번 돌려도 결과가 같다.
//   반면 create_/alter_/delete_/rename_ 은 그대로 소유 배포에만 맡긴다.
const isDynamicSqlRegistration = (file) => /^insert_dynamic_sql_[\w.-]+\.sql$/.test(file);



// 적용 순서를 담은 단일 목록.
//
// 왜 파일로 빼나
//   신규 설치 위저드도 같은 목록을 그대로 적용해야 한다. 목록이 두 벌이면 한쪽에만 새
//   스크립트가 등록돼, 새로 설치한 시스템에만 테이블·쿼리가 빠진다(실제로 설치본에
//   테이블 11개와 동적 SQL 61건이 빠져 있었다).
const readInstallSqlFiles = () => {
  // 패키지로 설치된 앱은 이 스크립트를 node_modules 안에서 실행하고 cwd 는
  // 앱 루트다. appDir 만 보면 목록 파일을 못 찾아 기동이 통째로 죽는다.
  // SQL 본문과 같은 규칙으로, 앱이 자기 목록을 두면 그것을 먼저 쓰고
  // 없으면 패키지에 들어 있는 것을 쓴다.
  const candidates = [
    path.join(appDir, "scripts", "install_sql_files.json"),
    path.join(__dirname, "install_sql_files.json"),
  ];
  const file = candidates.find((candidate) => fs.existsSync(candidate));
  if (!file) {
    throw new Error(`install_sql_files.json not found: ${candidates.join(", ")}`);
  }
  const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
  const list = Array.isArray(parsed) ? parsed : parsed.files || [];
  // 항목은 파일명 문자열이거나 { file, why } 다. why 에는 그 자리에 있어야 하는 이유를 적는다
  // (예: rename 은 create 보다 앞이어야 한다). 순서 제약은 목록을 옮길 때 제일 먼저 잃는다.
  return list
    .map((entry) => String(typeof entry === "string" ? entry : entry?.file || "").trim())
    .filter(Boolean);
};

const DEFAULT_SQL_FILES = readInstallSqlFiles();

if (!OWNS_SCHEMA) {
  // 소유자가 아니어도 이 서비스 전용 SQL 과 동적 SQL 등록은 돌려야 한다.
  const serviceOnly = readServiceSqlFiles();
  const registrations = readInstallSqlFiles().filter(isDynamicSqlRegistration);
  const files = [...registrations, ...serviceOnly].filter(
    (file, index, all) => all.indexOf(file) === index,
  );

  if (files.length) {
    console.log(
      `[run_sql] 스키마 소유자가 아니다 — 테이블 DDL 은 건너뛴다. ` +
        `동적 SQL 등록 ${registrations.length} 건, 서비스 전용 ${serviceOnly.length} 건만 적용한다.`,
    );
    SERVICE_ONLY_FILES = files;
  } else {
    console.log(
    `[run_sql] 이 배포는 스키마 소유자가 아니다(DB_SCHEMA=${DB_SCHEMA}). DB_SCHEMA_OWNED 가 true 가 아니다. ` +
      `적용할 등록 파일도 없다 — 건너뛴다.`
    );
    process.exit(0);
  }
}

const sqlFilesFromEnv = (process.env.SQL_FILES || "")
  .split(",")
  .map((file) => file.trim())
  .filter(Boolean);

const serviceSqlFiles = readServiceSqlFiles();

// SQL_FILES 는 목록을 대체하지 않고 더한다.
//
// 왜
//   예전에는 환경변수가 있으면 install_sql_files.json 을 통째로 무시했다. 그래서
//   자기 SQL 을 환경변수로 넘기던 배포에서는, 템플릿에 새 SQL 파일이 생겨도 사람이
//   그 환경변수를 손으로 고치기 전까지 영영 적용되지 않았다. 코드는 새 이름을
//   부르는데 등록이 없어 그 화면만 "Database operation failed." 로 죽는다.
//   실제로 시스템 리소스 관리 화면이 그렇게 죽었고, 원인을 찾는 데 배포 로그를
//   세 군데 뒤져야 했다.
//
//   목록은 파일이 정본이고 환경변수는 그 배포에만 필요한 것을 덧붙이는 자리다.
//   이름이 겹치면 먼저 나온 순서를 지킨다 — 적용 순서가 결과를 바꾸기 때문이다.
const sqlFiles = (SERVICE_ONLY_FILES
  ? SERVICE_ONLY_FILES
  : [...DEFAULT_SQL_FILES, ...serviceSqlFiles, ...sqlFilesFromEnv]
).filter((file, index, all) => all.indexOf(file) === index);

if (!SERVICE_ONLY_FILES && sqlFilesFromEnv.length > 0) {
  const extra = sqlFilesFromEnv.filter((file) => !DEFAULT_SQL_FILES.includes(file));
  console.log(
    `[run_sql] SQL_FILES 환경변수 ${sqlFilesFromEnv.length} 건 중 목록에 없던 ${extra.length} 건을 뒤에 덧붙인다.`,
  );
}

const getSslConfig = () => {
  const mode = (process.env.SSL_MODE || "").trim().toLowerCase();
  if (mode === "disable" || mode === "false" || mode === "0") return false;
  if (mode === "require" || process.env.RAILWAY_ENVIRONMENT || process.env.NODE_ENV === "production") {
    return { rejectUnauthorized: false };
  }
  return false;
};

// 이 리포가 소유한 스키마 이름. SQL 본문에 리터럴로 박혀 있다.
const OWN_SCHEMA = "brunner_template";
const RETARGETABLE_SCHEMAS = ["brunner_template", "brunner", "zicp"];

// 소유 스키마 이름을 이 배포가 실제로 보는 스키마로 바꾼다. 안 바꾸면
// DB_SCHEMA=brunner 로 뜬 설치본이 DDL 을 brunner_template 에 적용해,
// 앱이 보는 스키마와 DDL 이 적용되는 스키마가 영구히 갈린다.
const retargetSchema = (sql) => {
  let retargeted = sql;
  for (const schema of RETARGETABLE_SCHEMAS) {
    if (schema === DB_SCHEMA) continue;
    const schemaPrefix = new RegExp(
      `(?:"${schema}"|\\b${schema})(?:\\s*\\.\\s*)(?=(?:"?(?:TB_|tb_|IDX_|idx_|UQ_|uq_))|(?:[A-Za-z0-9_]+_pkey)|%I)`,
      "g",
    );
    retargeted = retargeted.replace(schemaPrefix, `${DB_SCHEMA_SQL}.`);

    // 따옴표 안의 스키마 이름도 바꾼다.
    //
    // 왜
    //   information_schema.columns 나 to_regclass 로 무언가를 확인하는 마이그레이션은
    //   스키마를 문자열로 적는다 — table_schema = 'brunner_template',
    //   connamespace = 'brunner_template'::regnamespace 처럼. 위의 접두어 치환은
    //   점이 붙은 형태만 보므로 이 문자열은 그대로 남는다. 그러면 다른 스키마로 뜬
    //   배포에서 조건이 영영 안 맞고, 마이그레이션은 오류 없이 아무것도 하지 않는다.
    //
    //   파생 서비스들이 이것 때문에 같은 파일을 복사해 스키마 이름만 고쳐 들고 있었다.
    //   사본은 그 순간부터 템플릿 수정을 못 받으므로, 우회책을 없애고 여기서 바꾼다.
    retargeted = retargeted.replace(new RegExp(`'${schema}'`, "g"), `'${DB_SCHEMA}'`);
  }
  return retargeted;
};

// 앱이 자기 SQL 을 두면 그것을 먼저 쓰고, 없으면 패키지에 들어 있는 것을 쓴다.
const readSqlFile = (fileName) => {
  const candidates = [path.join(appDir, "scripts", fileName), path.join(__dirname, fileName)];
  const fullPath = candidates.find((candidate) => fs.existsSync(candidate));
  if (!fullPath) {
    throw new Error(`SQL file not found: ${fileName}`);
  }
  return retargetSchema(fs.readFileSync(fullPath, "utf8").trim());
};

// DB 재시작/복구 중처럼 잠시 뒤 사라지는 일시적 오류. 이 경우 즉시 실패시키지 않고 재시도한다.
// (recovery mode 한 번에 배포 전체가 막혀 사이트가 다운되는 것을 방지)
const TRANSIENT_DB_ERROR =
  /recovery mode|starting up|the database system is|ECONNREFUSED|ECONNRESET|Connection terminated|connection refused|could not connect|ETIMEDOUT|timeout expired/i;

// 시드 내용 전체의 지문. 이게 그대로면 적용해봐야 결과가 같으므로 건너뛴다.
//
// 배포마다 무조건 다시 적용하면 두 가지가 걸린다. 관리 화면(/mainPages/dynamicSql)
// 에서 손본 쿼리가 다음 배포에 시드 값으로 되돌아가고, 앱 기동이 마이그레이션
// 성공에 묶여 DB 가 잠깐 흔들리면 아예 뜨지 못한다. 시드가 바뀐 배포에서만
// 돌게 해서 둘 다 피한다.
const seedFingerprint = () =>
  crypto
    .createHash("sha256")
    .update(sqlFiles.map((f) => `${f}\n${readSqlFile(f)}`).join("\n--\n"))
    .digest("hex");

const FINGERPRINT_DDL = `
  CREATE TABLE IF NOT EXISTS ${DB_SCHEMA_SQL}.TB_COR_SEED_STATE (
    ID          VARCHAR(20) PRIMARY KEY,
    FINGERPRINT VARCHAR(64) NOT NULL,
    APPLIED_AT  TIMESTAMP   DEFAULT NOW()
  )`;

const findStaleDynamicSqlRefs = async (client) => {
  const badSchemas = RETARGETABLE_SCHEMAS.filter((schema) => schema !== DB_SCHEMA);
  if (badSchemas.length === 0) return [];
  const clauses = badSchemas
    .map((schema, index) => `sql_content ~ $${index + 2}`)
    .join(" OR ");
  const result = await client.query(
    `SELECT sql_name, sql_seq
       FROM ${DB_SCHEMA_SQL}.TB_COR_SQL_INFO
      WHERE system_code = $1
        AND (${clauses})
      ORDER BY sql_name, sql_seq
      LIMIT 20`,
    [DB_SYSTEM_CODE, ...badSchemas.map((schema) => `(\"${schema}\"|\\m${schema})[[:space:]]*\\.[[:space:]]*(\"?(TB_|tb_|IDX_|idx_|UQ_|uq_)|[A-Za-z0-9_]+_pkey|%I)`)],
  );
  return result.rows;
};

const applyAll = async () => {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: getSslConfig(),
  });
  await client.connect();
  try {
    const fingerprint = seedFingerprint();
    if (process.env.RUN_SQL_FORCE !== "true") {
      try {
        await client.query(`CREATE SCHEMA IF NOT EXISTS ${DB_SCHEMA_SQL}`);
        await client.query(FINGERPRINT_DDL);
        const prev = await client.query(
          `SELECT fingerprint FROM ${DB_SCHEMA_SQL}.TB_COR_SEED_STATE WHERE id = 'seed'`,
        );
        if (prev.rows[0]?.fingerprint === fingerprint) {
          const staleRows = await findStaleDynamicSqlRefs(client);
          if (staleRows.length) {
            console.warn(
              `[run_sql] DB(${DB_SCHEMA}) 동적 SQL에 다른 스키마 참조가 남아 있어 시드를 다시 적용합니다: ` +
                staleRows.map((row) => `${row.sql_name}#${row.sql_seq}`).join(", "),
            );
          } else {
            console.log("[run_sql] 시드가 지난 적용과 같습니다 — 건너뜁니다. (RUN_SQL_FORCE=true 로 강제 실행)");
            return;
          }
        }
      } catch (e) {
        // 지문 확인에 실패하면 판단할 근거가 없으니 그냥 적용한다.
        console.warn(`[run_sql] 시드 지문 확인 실패, 그대로 적용합니다: ${e.message}`);
      }
    }

    console.log(`[run_sql] Applying ${sqlFiles.length} SQL file(s) to schema ${DB_SCHEMA}.`);
    await client.query(`CREATE SCHEMA IF NOT EXISTS ${DB_SCHEMA_SQL}`);
    await client.query(FINGERPRINT_DDL);
    // 공용 스크립트 하나가 파생 서비스를 통째로 죽이지 못하게 한다.
    //
    // 왜
    //   이 목록은 두 출처가 섞여 있다 — 템플릿이 모두에게 주는 것, 그리고 그 서비스가
    //   자기 것으로 넣은 것. 앞의 것은 그 서비스가 요청한 적이 없는데도 실패하면
    //   기동을 막았다. 실제로 템플릿 목록을 합치자마자 운영 사이트가 502 로 죽었고,
    //   원인 파일을 알아내려고 배포 로그를 뒤져야 했다.
    //
    //   자기 목록의 SQL 은 그대로 필수다 — 그 서비스가 자기 기능을 위해 넣은 것이라,
    //   실패했는데 그냥 뜨면 기능이 조용히 죽는다. 남의 것이 실패하면 경고만 남기고
    //   계속 간다. 무엇이 실패했는지는 로그에 파일명으로 남는다.
    // 자기 것의 기준은 앱이 둔 service_sql_files.json 이다. 비소유 경로에서는
    // 템플릿의 등록 파일도 함께 돌지만 그건 여전히 남의 것이다.
    const ownFiles = new Set(serviceSqlFiles);
    const failedShared = [];

    for (const fileName of sqlFiles) {
      const sql = readSqlFile(fileName);
      if (!sql) {
        console.log(`[run_sql] Skip empty file: ${fileName}`);
        continue;
      }
      console.log(`[run_sql] ${fileName}`);
      try {
        await client.query(sql);
      } catch (error) {
        if (TRANSIENT_DB_ERROR.test(error && error.message)) throw error;
        if (ownFiles.has(fileName)) throw error;
        failedShared.push(fileName);
        console.warn(`[run_sql] 공용 스크립트 실패 — 계속 진행: ${fileName}: ${error.message}`);
      }
    }

    if (failedShared.length) {
      console.warn(`[run_sql] 실패한 공용 스크립트 ${failedShared.length}건: ${failedShared.join(", ")}`);
    }
    // 하나라도 실패했으면 지문을 남기지 않는다. 남기면 다음 배포가 '지난 적용과
    // 같다' 며 통째로 건너뛰어, 실패한 스크립트가 영영 다시 돌지 않는다.
    if (failedShared.length === 0) {
      await client.query(
        `INSERT INTO ${DB_SCHEMA_SQL}.TB_COR_SEED_STATE (id, fingerprint, applied_at)
           VALUES ('seed', $1, NOW())
         ON CONFLICT (id) DO UPDATE SET fingerprint = EXCLUDED.fingerprint, applied_at = NOW()`,
        [fingerprint],
      );
    } else {
      console.warn("[run_sql] 실패가 있어 적용 지문을 남기지 않는다 — 다음 배포에서 다시 시도한다.");
    }
  } finally {
    await client.end().catch(() => {});
  }
};

async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is required.");
  }
  const maxAttempts = parseInt(process.env.RUN_SQL_MAX_ATTEMPTS || "10", 10);
  for (let attempt = 1; ; attempt++) {
    try {
      await applyAll();
      break;
    } catch (err) {
      const transient = TRANSIENT_DB_ERROR.test(err && err.message);
      if (transient && attempt < maxAttempts) {
        const wait = Math.min(30000, 3000 * attempt); // 3s,6s,9s...최대 30s
        console.warn(`[run_sql] transient DB error (attempt ${attempt}/${maxAttempts}): ${err.message} — retry in ${wait}ms`);
        await new Promise((r) => setTimeout(r, wait));
        continue;
      }
      throw err;
    }
  }
  console.log("[run_sql] SQL scripts applied.");
}

main().catch((err) => {
  console.error("[run_sql] Failed:", err.message);
  process.exit(1);
});
