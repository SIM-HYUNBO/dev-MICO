const { Client } = require("pg");
const fs = require("fs");
const path = require("path");

const appDir = process.env.BRUNNER_APP_DIR || process.cwd();
require("dotenv").config({ path: path.join(appDir, ".env") });
require("dotenv").config({ path: path.join(__dirname, "../.env") });

// 소문자로 접는다 — lib/dbSchema.js 와 같은 규칙.
const schema = (process.env.DB_SCHEMA || "brunner_template").trim().toLowerCase();

if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(schema)) {
  console.error(`[resource_seed] DB_SCHEMA 형식이 올바르지 않다: ${schema}`);
  process.exit(1);
}

const quoteIdent = (name) => `"${String(name).replace(/"/g, '""')}"`;

const getSslConfig = () => {
  const url = String(process.env.DATABASE_URL || "");
  const mode = (process.env.SSL_MODE || "").trim().toLowerCase();
  if (mode === "disable" || mode === "false" || mode === "0") return false;
  if (/sslmode=require/i.test(url) || mode === "require" || mode === "true" || process.env.RAILWAY_ENVIRONMENT || process.env.NODE_ENV === "production") {
    return { rejectUnauthorized: false };
  }
  return false;
};

const stripPgSslParams = (connectionString) => {
  const value = String(connectionString || "");
  try {
    const parsed = new URL(value);
    parsed.searchParams.delete("sslmode");
    return parsed.toString();
  } catch {
    return value.replace(/([?&])sslmode=[^&]*&?/i, "$1").replace(/[?&]$/, "");
  }
};

const readSql = (fileName) => {
  const fullPath = path.join(__dirname, fileName);
  return fs
    .readFileSync(fullPath, "utf8")
    .replaceAll("brunner_template.", `${quoteIdent(schema)}.`)
    .replaceAll("brunner_template.tb_cor_resource_text", `${schema}.tb_cor_resource_text`);
};

async function main() {
  if (!process.env.DATABASE_URL) {
    console.log("[resource_seed] DATABASE_URL 없음 — 건너뜀");
    return;
  }

  const client = new Client({
    connectionString: stripPgSslParams(process.env.DATABASE_URL),
    ssl: getSslConfig(),
  });

  client.on("notice", (notice) => {
    if (notice?.message) console.log(`[resource_seed:${notice.severity || "NOTICE"}] ${notice.message}`);
  });

  await client.connect();
  try {
    await client.query(`CREATE SCHEMA IF NOT EXISTS ${quoteIdent(schema)}`);
    await client.query(readSql("create_resource_text_table.sql"));
    await client.query(readSql("seed_resource_text_common.sql"));

    const result = await client.query(
      `SELECT SYSTEM_CODE, COUNT(*)::int AS ROWS
         FROM ${quoteIdent(schema)}.TB_COR_RESOURCE_TEXT
        GROUP BY SYSTEM_CODE
        ORDER BY SYSTEM_CODE`,
    );
    console.log(`[resource_seed] ${schema}.TB_COR_RESOURCE_TEXT rows: ${JSON.stringify(result.rows)}`);
  } finally {
    await client.end().catch(() => {});
  }
}

main().catch((error) => {
  console.error("[resource_seed] Failed:", error.message);
  process.exit(1);
});
