import fsNode from "fs";
import pathNode from "path";
import { fileURLToPath, pathToFileURL } from "url";
import * as dotenv from "dotenv";

// lib 모듈은 앱의 것을 먼저 쓴다.
//
// 왜
//   이 파일은 두 자리에서 실행된다 — 이 저장소 자신, 그리고 파생 서비스의
//   node_modules/brunner-template. 상대경로로 import 하면 언제나 패키지의 lib 를
//   읽으므로, 파생 서비스는 자기 constants·크론을 쓰려면 server.js 를 통째로
//   복사할 수밖에 없었다. 그 사본은 만든 순간부터 템플릿 수정을 못 받는다.
//
//   앱 루트에 같은 이름의 lib 파일이 있으면 그것을 쓰고, 없으면 패키지 것을 쓴다.
//   SQL 파일과 같은 규칙이다. 이 저장소에서 실행하면 두 경로가 같으므로
//   동작이 달라지지 않는다.
const packageRoot = pathNode.dirname(fileURLToPath(import.meta.url));
const appDir = process.env.BRUNNER_APP_DIR || process.cwd();
dotenv.config({ path: pathNode.join(appDir, ".env") });
dotenv.config({ path: pathNode.join(packageRoot, ".env") });
const libUrl = (name) => {
  const local = pathNode.join(appDir, "lib", name);
  const target = fsNode.existsSync(local) ? local : pathNode.join(packageRoot, "lib", name);
  return pathToFileURL(target).href;
};

const constants = await import(libUrl("constants.js"));
const { deploymentSystemCode } = await import(libUrl("tenantResolver.js"));
import { createServer } from "http";
import { parse } from "url";
import next from "next";
import { Server } from "socket.io";
import { createAdapter } from "@socket.io/redis-adapter";
import { createClient } from "redis";
import pkg from "pg";
const { Pool } = pkg;

// DB 없이는 아무것도 못 하므로 이것만 필수로 둔다.
// 나머지는 해당 기능을 쓸 때만 필요하다 — 없다고 서버를 죽이면 템플릿을
// 그냥 띄워보는 것조차 못 한다(원본은 메일·AI 키까지 필수라 즉시 종료했다).
const REQUIRED_ENV = ["DATABASE_URL", "DB_SCHEMA"];
const OPTIONAL_ENV = {
  MAIL_USER: "관리자 알림 수신",
  MAIL_FROM: "메일 발신 주소",
  RESEND_API_KEY: "메일 발송",
  OPENAI_API_KEY: "채팅 AI 이모지",
  TOSS_SECRET_KEY: "결제 승인",
  NEXT_PUBLIC_TOSS_CLIENT_KEY: "결제창 호출",
  REDIS_URL: "다중 인스턴스 소켓 동기화",
};

const missingEnv = REQUIRED_ENV.filter((k) => !process.env[k]);
if (missingEnv.length > 0) {
  console.error(`[startup] 필수 환경변수 누락: ${missingEnv.join(", ")}`);
  process.exit(1);
}

const missingOptional = Object.keys(OPTIONAL_ENV).filter((k) => !process.env[k]);
if (missingOptional.length > 0) {
  console.warn(
    `[startup] 다음 기능이 비활성화됩니다 — ${missingOptional
      .map((k) => `${k}(${OPTIONAL_ENV[k]})`)
      .join(", ")}`,
  );
}

const dev = process.env.NODE_ENV !== "production";
const app = next({ dev });
const handle = app.getRequestHandler();

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || "0.0.0.0";
const INSTANCE_ID =
  process.env.INSTANCE_ID ||
  process.env.RAILWAY_REPLICA_ID ||
  process.env.RAILWAY_DEPLOYMENT_ID ||
  "local";
const SYSTEM_CODE = deploymentSystemCode();

console.log(`[startup] DB_SCHEMA=${process.env.DB_SCHEMA || "(unset)"}, SYSTEM_CODE=${process.env.SYSTEM_CODE || "(unset)"}`);

const parsePositiveInt = (value, fallback) => {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
};

/**
 * roomId별 최근 메시지 캐시 (인메모리)
 */
const roomMessages = {};
let globalMessageId = 1;
const MAX_MESSAGES_PER_ROOM = 1000;
const INITIAL_MESSAGES = 20;

// 읽음 추적: { [roomId]: { [messageId]: Set<userId> } }
const roomReadReceipts = {};

// Redis Adapter 활성 여부 — 다중 서버 환경에서 DB-first 모드 전환에 사용
let redisActive = false;

// 타이핑 추적: { [roomId]: { [userId]: { userName, timer } } }
const roomTyping = {};

const setupSocketRedisAdapter = async (ioServer) => {
  const redisUrl = process.env.REDIS_URL;
  if (!redisUrl) {
    console.log(`[socket.io:${INSTANCE_ID}] Redis adapter disabled: REDIS_URL is not set`);
    return null;
  }

  try {
    const pubClient = createClient({ url: redisUrl });
    const subClient = pubClient.duplicate();

    pubClient.on("error", (err) => console.error(`[redis:${INSTANCE_ID}] pub client error:`, err.message));
    subClient.on("error", (err) => console.error(`[redis:${INSTANCE_ID}] sub client error:`, err.message));

    await Promise.all([pubClient.connect(), subClient.connect()]);
    ioServer.adapter(createAdapter(pubClient, subClient));
    redisActive = true;
    globalThis.__brunnerRedisActive = true;
    console.log(`[socket.io:${INSTANCE_ID}] Redis adapter enabled`);

    return { pubClient, subClient };
  } catch (e) {
    console.error(`[socket.io:${INSTANCE_ID}] Redis adapter disabled:`, e.message);
    return null;
  }
};

/* -------------------------------------------------------
 * 멤버십 직접 DB 체크 (HTTP 내부 루프 없이)
 * ------------------------------------------------------- */
let dbPool = null;
const getDbPool = () => {
  if (!dbPool) {
    const ssl = process.env.SSL_MODE
      ? (() => { try { const p = JSON.parse(process.env.SSL_MODE); return typeof p === "object" ? p : { rejectUnauthorized: false }; } catch { return { rejectUnauthorized: false }; } })()
      : { rejectUnauthorized: false };
    dbPool = new Pool({
      connectionString: process.env.DATABASE_URL,
      max: parsePositiveInt(process.env.CHAT_DB_POOL_MAX, 3),
      ssl,
    });
  }
  return dbPool;
};

const checkRoomMembership = async (systemCode, roomId, userId) => {
  try {
    // 동적 SQL 경유 — 예전에는 여기에 SQL 문자열을 직접 들고 있었고 스키마가
    // 'BRUNNER' 로 박혀 있어, 스키마 이름이 다른 리포에서는 매번 오류가 났다.
    // 아래 catch 가 오류 시 입장을 허용하므로 권한 검사가 통째로 무력화돼 있었다.
    const { getSQL, executeSQL } = await import(libUrl("serverSql.js"));

    const memberSql = await getSQL(systemCode, "select_TB_COR_CHATROOM_MEMBERSHIP", 1);
    const result = await executeSQL(memberSql, [systemCode, roomId, userId]);
    if (result.rows.length > 0) {
      return true;
    }

    const ownerSql = await getSQL(systemCode, "select_TB_COR_CHATROOM_OWNER", 1);
    const ownerResult = await executeSQL(ownerSql, [systemCode, roomId, userId]);

    if (ownerResult.rows.length === 0) {
      return false;
    }

    const joinSql = await getSQL(systemCode, "insert_TB_COR_CHATROOM_USERS", 1);
    await executeSQL(joinSql, [systemCode, roomId, userId]);
    console.warn(`[checkRoomMembership] restored missing creator membership: room=${roomId} user=${userId}`);
    return true;
  } catch (e) {
    // DB 조회 실패 시 접근 허용 (transient 오류로 거부하지 않음)
    console.error("[checkRoomMembership] DB error, allowing join:", e.message);
    return true;
  }
};

/* -------------------------------------------------------
 * 내부 API 호출 헬퍼 (dynamic SQL 시스템 경유)
 * ------------------------------------------------------- */
const callChatroomAPI = async (commandName, params) => {
  try {
    const res = await fetch(`http://localhost:${PORT}/api/backendServer`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        commandName,
        systemCode: SYSTEM_CODE,
        userId: "system",
        ...params,
      }),
    });
    return await res.json();
  } catch (e) {
    console.error(`callChatroomAPI error [${commandName}]:`, e.message);
    return null;
  }
};

const saveChatMessage = (roomId, chatUserId, userName, message, replyTo) => {
  return callChatroomAPI("chatroom.saveMessage", {
    roomId,
    chatUserId,
    userName,
    message,
    replyTo: replyTo || null,
  });
};

// 이미지 base64를 플레이스홀더로 대체하여 WebSocket 페이로드 크기 축소
// R2 로 옮긴 이미지는 본문에 "r2img:{key}" 참조만 있다. base64 든 참조든 화면에는
// 똑같이 [img:{msgId}] 마커로 나가고, 클라이언트는 /api/chat/image?msgId= 로 읽는다.
const isImageMessage = (message) =>
  typeof message === "string" &&
  (message.startsWith("data:image/") || message.startsWith("r2img:"));

const stripImages = (msgs) =>
  msgs.map((m) => {
    if (!isImageMessage(m.message)) return m;
    const stripped = { ...m, message: `[img:${m.id}]` };
    if (isImageMessage(stripped.replyTo?.message)) {
      stripped.replyTo = { ...stripped.replyTo, message: `[img:${stripped.replyTo.id ?? ""}]` };
    }
    return stripped;
  });

const loadChatHistory = async (roomId) => {
  const res = await callChatroomAPI("chatroom.loadHistory", { roomId });
  return res?.data || [];
};

const loadMoreHistory = async (roomId, beforeId) => {
  const res = await callChatroomAPI(constants.commands.CHATROOM_LOAD_MORE_HISTORY, { roomId, beforeId });
  return res?.data || [];
};

const saveReadReceiptsToDB = (roomId, userId, messageIds) => {
  callChatroomAPI("chatroom.saveReadReceipts", {
    systemCode: SYSTEM_CODE,
    roomId,
    userId,
    messageIds,
  });
};

const loadReadReceiptsFromDB = async (roomId) => {
  const res = await callChatroomAPI("chatroom.loadReadReceipts", {
    systemCode: SYSTEM_CODE,
    roomId,
  });
  return res?.data || [];
};

const trimChatHistory = (roomId) => {
  callChatroomAPI("chatroom.trimHistory", { roomId });
};

app.prepare().then(async () => {
  const httpServer = createServer((req, res) => {
    const parsedUrl = parse(req.url, true);
    handle(req, res, parsedUrl);
  });

  const ioServer = new Server(httpServer, {
    cors: { origin: "*" },
    pingInterval: 25000,
    pingTimeout: 60000,
    maxHttpBufferSize: 100 * 1024 * 1024, // 100MB (base64 오버헤드 포함 최대 대응)
  });
  const redisAdapterClients = await setupSocketRedisAdapter(ioServer);

  ioServer.on(constants.websocketMessageType.connection, (socket) => {
    console.log(`[socket:${INSTANCE_ID}] connected:`, socket.id);

    /**
     * heartbeat
     */
    socket.on("ping", (t) => {
      socket.emit("pong", t);
    });

    /**
     * userId 등록 — 방 입장 전에도 대상 소켓 탐색 가능하도록
     */
    socket.on("identify", ({ userId }) => {
      if (userId) socket.data.userId = userId;
    });

    /**
     * 포그라운드/백그라운드 상태 — 앱이 백그라운드로 내려가면 소켓은 방에 남아 있어도
     * 실시간으로 메시지를 못 보므로, 푸시 대상 계산(onlineUserIds)에서 제외하기 위해 표시한다.
     */
    socket.on("visibility", ({ visible } = {}) => {
      socket.data.hidden = visible === false;
    });

    /**
     * 방 입장
     */
    socket.on(
      constants.websocketMessageType.join,
      async ({ roomId, userId, userName, lastMessageId, suppressMessage }) => {
        const canJoinRoom = await checkRoomMembership(deploymentSystemCode(), roomId, userId);
        if (!canJoinRoom) {
          // 조용히 거부 — HTTP CHATROOM_ENTER 실패가 클라이언트 접근거부 UX를 담당
          // systemMessage로 보내면 onReconnect 타이밍 경쟁 시 채팅창에 오류 문구가 노출됨
          return;
        }

        socket.data.userId = userId;
        if (userName) socket.data.userName = userName;
        socket.join(roomId);
        console.log(`[socket:${INSTANCE_ID}] join room=${roomId} user=${userId}`);

        // Redis 활성(다중 서버) → DB-first: 항상 DB에서 로드해 인스턴스 간 캐시 불일치 방지
        // Redis 비활성(단일 서버) → 인메모리 캐시 우선, 없을 때만 DB 로드
        if (!roomMessages[roomId] || redisActive) {
          const [history, receipts] = await Promise.all([
            loadChatHistory(roomId),
            loadReadReceiptsFromDB(roomId),
          ]);
          if (history.length > 0) {
            roomMessages[roomId] = history;
            const maxId = history[history.length - 1].id;
            if (maxId >= globalMessageId) globalMessageId = maxId + 1;
          }
          if (receipts.length > 0) {
            roomReadReceipts[roomId] = {};
            for (const { messageId, userIds } of receipts) {
              roomReadReceipts[roomId][messageId] = new Set(userIds);
            }
          } else if (redisActive) {
            roomReadReceipts[roomId] = roomReadReceipts[roomId] || {};
          }
        }

        const msgs = roomMessages[roomId] || [];

        if (lastMessageId > 0) {
          // 재접속: 누락 메시지만 동기화
          const missed = msgs.filter((m) => m.id > lastMessageId);
          if (missed.length > 0) {
            socket.emit(constants.websocketMessageType.syncMessages, stripImages(missed));
          }
        } else {
          // 최초 입장: 최신 INITIAL_MESSAGES개만 전송
          const initial = msgs.slice(-INITIAL_MESSAGES);
          socket.emit(constants.websocketMessageType.history, stripImages(initial));
          socket.emit("historyMeta", { hasMore: msgs.length >= INITIAL_MESSAGES });
          // 히스토리 메시지의 현재 readCount를 함께 전송
          const receipts = roomReadReceipts[roomId] || {};
          const snapshot = initial
            .filter((m) => m.id && receipts[m.id])
            .map((m) => ({ messageId: m.id, readCount: receipts[m.id].size }));
          if (snapshot.length > 0) {
            socket.emit(constants.websocketMessageType.readReceiptUpdate, snapshot);
          }
        }

        if (!suppressMessage) {
          ioServer.to(roomId).emit(constants.websocketMessageType.join, {
            roomId,
            userId,
            userName,
          });
        }
      },
    );

    /**
     * 이전 메시지 더 불러오기
     * { roomId, beforeId } → "olderMessages" 이벤트로 응답
     * in-memory 대신 DB에서 직접 페이지네이션 조회
     */
    socket.on("loadMore", async ({ roomId, beforeId }) => {
      const older = await loadMoreHistory(roomId, beforeId);
      socket.emit("olderMessages", { messages: stripImages(older), hasMore: older.length >= INITIAL_MESSAGES });
    });

    /**
     * 채팅 메시지
     */
    socket.on(constants.websocketMessageType.chat, async (msg) => {
      console.log(`[socket:${INSTANCE_ID}] chat room=${msg?.roomId} user=${msg?.userId}`);
      const pendingMessage = {
        ...msg,
        id: globalMessageId++,
        ts: Date.now(),
      };
      let message = pendingMessage;
      try {
        const saveResult = await saveChatMessage(msg.roomId, msg.userId, msg.userName, msg.message, msg.replyTo);
        const dbMsgId = saveResult?.msgId;
        if (dbMsgId) {
          message = {
            ...pendingMessage,
            id: dbMsgId,
          };
          if (message.id >= globalMessageId) {
            globalMessageId = message.id + 1;
          }
        }
      } catch (e) {
        console.error("[chat] save failed, broadcasting pending message:", e.message);
      }

      if (!roomMessages[msg.roomId]) {
        roomMessages[msg.roomId] = [];
      }
      roomMessages[msg.roomId].push(message);

      // 인메모리는 최대 1000개 유지 (메모리 관리용), DB는 전체 보관
      if (roomMessages[msg.roomId].length > MAX_MESSAGES_PER_ROOM) {
        roomMessages[msg.roomId].shift();
      }

      // 발신자는 자동으로 읽음 처리 + 초기 readCount 브로드캐스트
      if (!roomReadReceipts[msg.roomId]) roomReadReceipts[msg.roomId] = {};
      roomReadReceipts[msg.roomId][message.id] = new Set([msg.userId]);

      // 즉시 broadcast 후 푸시 알림 전에는 DB 저장을 보장
      ioServer
        .to(msg.roomId)
        .emit(constants.websocketMessageType.chat, message);
      ioServer
        .to(msg.roomId)
        .emit(constants.websocketMessageType.readReceiptUpdate, [
          { messageId: message.id, readCount: 1 },
        ]);
      saveReadReceiptsToDB(msg.roomId, msg.userId, [message.id]);

      // 채팅방 밖에 있는 멤버에게 푸시 알림
      const roomSocketIds = await ioServer.in(msg.roomId).allSockets();
      // 방에 join돼 있어도 백그라운드(hidden) 소켓은 실시간 수신을 못 하므로 온라인에서 제외 → 푸시 대상에 포함
      const onlineUserIds = [];
      for (const sid of roomSocketIds) {
        const s = ioServer.sockets.sockets.get(sid);
        if (s?.data?.userId && !s.data.hidden) onlineUserIds.push(s.data.userId);
      }

      // 오프라인 사용자별 미읽은 메시지 수 계산 (인메모리 기준)
      const roomMsgs = roomMessages[msg.roomId] || [];
      const receipts = roomReadReceipts[msg.roomId] || {};
      const onlineSet = new Set(onlineUserIds);
      const unreadCountByUser = {};
      for (const m of roomMsgs) {
        if (!m.id) continue;
        const readers = receipts[m.id] || new Set();
        // 이 메시지를 읽지 않은 오프라인 사용자별로 카운트
        for (const [sid2] of ioServer.sockets.sockets) {
          // 오프라인 사용자는 소켓 목록에 없으므로 불필요 — DB에서 처리
          void sid2;
        }
      }
      // 실제 오프라인 사용자 목록은 chatroom.js에서 DB 조회 후 계산하므로
      // 전체 방 메시지 수와 각 userId별 읽음 Set을 직렬화하여 전달
      const readReceiptSnapshot = {};
      for (const [msgId, readerSet] of Object.entries(receipts)) {
        readReceiptSnapshot[msgId] = [...readerSet];
      }

      callChatroomAPI(constants.commands.CHATROOM_SEND_PUSH_TO_OFFLINE, {
        roomId: msg.roomId,
        senderId: msg.userId,
        senderName: msg.userName,
        message: msg.message,
        onlineUserIds,
        totalMessageCount: roomMsgs.length,
        readReceiptSnapshot,
        asyncDispatch: true,
      });
    });

    /**
     * 멤버 변경 알림 (초대 등) → 방 전체에 브로드캐스트
     */
    socket.on(constants.websocketMessageType.memberUpdate, ({ roomId }) => {
      ioServer
        .to(roomId)
        .emit(constants.websocketMessageType.memberUpdate, { roomId });
    });

    /**
     * 시스템 메시지 → 방 전체에 브로드캐스트
     */
    socket.on(
      constants.websocketMessageType.systemMessage,
      ({ roomId, message }) => {
        ioServer
          .to(roomId)
          .emit(constants.websocketMessageType.systemMessage, {
            roomId,
            message,
          });
      },
    );

    /**
     * 강퇴: 방장이 특정 유저를 방에서 내보냄
     */
    socket.on(
      constants.websocketMessageType.kick,
      async ({ roomId, targetUserId, targetUserName }) => {
        const roomSocketIds = await ioServer.in(roomId).allSockets();
        for (const sid of roomSocketIds) {
          const s = ioServer.sockets.sockets.get(sid);
          if (s?.data?.userId === targetUserId) {
            s.emit(constants.websocketMessageType.kicked, { roomId });
            s.leave(roomId);
            break;
          }
        }
        // 방 전체에 시스템 메시지 + 참여자 목록 갱신 (leave 대신 사용)
        ioServer.to(roomId).emit(constants.websocketMessageType.systemMessage, {
          roomId,
          message: `${targetUserName}님을 내보냈습니다.`,
        });
        ioServer
          .to(roomId)
          .emit(constants.websocketMessageType.memberUpdate, { roomId });
      },
    );

    /**
     * 읽음 확인: 클라이언트가 메시지를 수신했을 때 전송
     * { roomId, userId, messageIds: number[] }
     */
    socket.on(
      constants.websocketMessageType.readReceipt,
      async ({ roomId, userId, messageIds }) => {
        if (!roomReadReceipts[roomId]) roomReadReceipts[roomId] = {};
        const updated = [];
        for (const msgId of messageIds) {
          if (!roomReadReceipts[roomId][msgId]) {
            roomReadReceipts[roomId][msgId] = new Set();
          }
          const before = roomReadReceipts[roomId][msgId].size;
          roomReadReceipts[roomId][msgId].add(userId);
          if (roomReadReceipts[roomId][msgId].size !== before) {
            updated.push({ messageId: msgId, readCount: roomReadReceipts[roomId][msgId].size });
          }
        }
        if (updated.length > 0) {
          ioServer.to(roomId).emit(constants.websocketMessageType.readReceiptUpdate, updated);
          saveReadReceiptsToDB(roomId, userId, updated.map((u) => u.messageId));
        }
      },
    );

    /**
     * 메시지 수정
     */
    socket.on(
      constants.websocketMessageType.messageEdit,
      ({ roomId, messageId, newMessage, userId, systemCode }) => {
        const msgs = roomMessages[roomId];
        if (!msgs) return;
        const idx = msgs.findIndex((m) => m.id === messageId && m.userId === userId);
        if (idx === -1) return;
        msgs[idx] = { ...msgs[idx], message: newMessage, edited: true };
        ioServer.to(roomId).emit(constants.websocketMessageType.messageEdited, {
          roomId,
          messageId,
          newMessage,
        });
        callChatroomAPI(constants.commands.CHATROOM_UPDATE_MESSAGE, {
          systemCode: systemCode || SYSTEM_CODE,
          roomId,
          messageId,
          userId,
          newMessage,
        });
      },
    );

    /**
     * 메시지 삭제
     */
    socket.on(
      constants.websocketMessageType.messageDelete,
      ({ roomId, messageId, userId, systemCode }) => {
        const msgs = roomMessages[roomId];
        if (!msgs) return;
        const idx = msgs.findIndex((m) => m.id === messageId && m.userId === userId);
        if (idx === -1) return;
        msgs[idx] = { ...msgs[idx], message: null, deleted: true };
        ioServer.to(roomId).emit(constants.websocketMessageType.messageDeleted, {
          roomId,
          messageId,
        });
        callChatroomAPI(constants.commands.CHATROOM_DELETE_MESSAGE, {
          systemCode: systemCode || SYSTEM_CODE,
          roomId,
          messageId,
          userId,
        });
      },
    );

    /**
     * 방 나가기
     */
    socket.on(
      constants.websocketMessageType.leave,
      async ({ roomId, userId, userName }) => {
        socket.leave(roomId);

        ioServer.to(roomId).emit(constants.websocketMessageType.leave, {
          roomId,
          userId,
          userName,
        });

        // 방에 소켓이 없으면 인메모리 캐시 제거
        const roomSockets = await ioServer.in(roomId).allSockets();
        if (roomSockets.size === 0) {
          delete roomMessages[roomId];
          delete roomReadReceipts[roomId];
        }
      },
    );

    /**
     * 초대 알림: 초대한 쪽 소켓 → 초대받은 유저의 소켓으로 newRoomInvite 전달
     */
    socket.on(constants.websocketMessageType.notifyInvited, ({ targetUserId, roomId, roomName, inviterName, inviteId }) => {
      for (const [, s] of ioServer.sockets.sockets) {
        if (s.data?.userId === targetUserId) {
          s.emit(constants.websocketMessageType.newRoomInvite, { roomId, roomName, inviterName, inviteId });
        }
      }
    });

    /**
     * 비밀방 룸키 요청: 키를 가진 다른 멤버에게 브로드캐스트
     */
    socket.on("roomKeyRequest", ({ roomId, requesterId, deviceId, publicKey }) => {
      if (!roomId || !requesterId || !deviceId || !publicKey) return;
      socket.to(roomId).emit("roomKeyRequest", { roomId, requesterId, deviceId, publicKey });
    });

    socket.on("stickerEffect", ({ roomId, style }) => {
      if (!roomId || !style) return;
      socket.to(roomId).emit("stickerEffect", { style });
    });

    /**
     * 타이핑 인디케이터
     */
    const broadcastTyping = (roomId) => {
      const typingMap = roomTyping[roomId] || {};
      const typing = Object.entries(typingMap).map(([uid, { userName }]) => ({ userId: uid, userName }));
      ioServer.to(roomId).emit(constants.websocketMessageType.typingUpdate, { roomId, typing });
    };

    socket.on(constants.websocketMessageType.typing, ({ roomId }) => {
      const userId = socket.data.userId;
      const userName = socket.data.userName || userId;
      if (!roomId || !userId) return;
      // 소켓이 실제로 해당 방에 입장해 있는지 확인
      if (!socket.rooms.has(roomId)) return;
      if (!roomTyping[roomId]) roomTyping[roomId] = {};
      if (roomTyping[roomId][userId]?.timer) clearTimeout(roomTyping[roomId][userId].timer);
      roomTyping[roomId][userId] = {
        userName,
        timer: setTimeout(() => {
          if (roomTyping[roomId]) {
            delete roomTyping[roomId][userId];
            broadcastTyping(roomId);
          }
        }, 3000),
      };
      broadcastTyping(roomId);
    });

    /**
     * 리액션 추가/삭제 → DB + 브로드캐스트
     */
    socket.on(constants.websocketMessageType.addReaction, async ({ roomId, messageId, emoji }) => {
      const userId = socket.data.userId;
      if (!roomId || !messageId || !userId || !emoji) return;
      if (!socket.rooms.has(roomId)) return;
      const result = await callChatroomAPI(constants.commands.CHATROOM_ADD_REACTION, {
        systemCode: SYSTEM_CODE, roomId, messageId, userId, emoji,
      });
      if (result?.error_code !== constants.errorCode.Success) return;
      ioServer.to(roomId).emit(constants.websocketMessageType.reactionUpdate, { messageId, userId, emoji, action: "add" });
    });

    socket.on(constants.websocketMessageType.removeReaction, async ({ roomId, messageId, emoji }) => {
      const userId = socket.data.userId;
      if (!roomId || !messageId || !userId || !emoji) return;
      if (!socket.rooms.has(roomId)) return;
      const result = await callChatroomAPI(constants.commands.CHATROOM_REMOVE_REACTION, {
        systemCode: SYSTEM_CODE, roomId, messageId, userId, emoji,
      });
      if (result?.error_code !== constants.errorCode.Success) return;
      ioServer.to(roomId).emit(constants.websocketMessageType.reactionUpdate, { messageId, userId, emoji, action: "remove" });
    });

    socket.on("disconnect", (reason) => {
      console.log(`[socket:${INSTANCE_ID}] disconnected:`, socket.id, reason);
    });
  });

  // 그 서비스에만 있는 기동 작업을 앱이 끼워 넣는 자리.
  //
  // 왜
  //   파생 서비스는 자기 크론(주식·자동매매·뉴스 수집 같은 것)을 띄우려고 server.js
  //   를 통째로 복사해 왔다. 763줄 중 다른 곳은 40줄뿐인데 나머지 723줄까지 같이
  //   들고 가느라, 템플릿이 서버를 고쳐도 받지 못했다. 그 40줄만 여기로 뺀다.
  //
  //   서버가 뜬 뒤에 부른다. 여기서 실패해도 사이트는 살아 있어야 한다 — 크론 하나
  //   때문에 서비스를 내리는 것은 맞지 않는다. 실패는 로그로 남긴다.
  const startAppSpecific = async () => {
    const entry = pathNode.join(appDir, "lib", "appStartup.js");
    if (!fsNode.existsSync(entry)) return;
    try {
      const mod = await import(pathToFileURL(entry).href);
      const start = mod.default || mod.start;
      if (typeof start !== "function") {
        console.warn("[startup] lib/appStartup.js 에 start 함수가 없다 — 건너뛴다.");
        return;
      }
      await start({ systemCode: deploymentSystemCode(), instanceId: INSTANCE_ID });
      console.log(`[startup:${INSTANCE_ID}] 앱 기동 작업 완료`);
    } catch (e) {
      console.error("[startup] 앱 기동 작업 실패:", e?.message || e);
    }
  };

  httpServer.listen(PORT, HOST, () => {
    // HOST 는 바인딩 주소다. 0.0.0.0 을 그대로 안내하면 브라우저에서
    // ERR_ADDRESS_INVALID 가 나므로, 접속용 주소로 바꿔 보여준다.
    const openHost = HOST === "0.0.0.0" || HOST === "::" ? "localhost" : HOST;
    console.log(
      `Server running — 접속: http://${openHost}:${PORT}  (bind=${HOST}, instance=${INSTANCE_ID})`,
    );
    startAppSpecific();
  });

  const shutdown = async (signal) => {
    console.log(`[startup:${INSTANCE_ID}] ${signal} received, shutting down`);
    await new Promise((resolve) => {
      httpServer.close(() => {
        console.log(`[startup:${INSTANCE_ID}] HTTP server closed`);
        resolve();
      });
    });
    if (redisAdapterClients) {
      await Promise.allSettled([
        redisAdapterClients.pubClient.quit(),
        redisAdapterClients.subClient.quit(),
      ]);
      console.log(`[startup:${INSTANCE_ID}] Redis adapter clients closed`);
    }
    process.exit(0);
  };
  // 처리되지 않은 거부 하나로 서버 전체가 죽으면, 돌고 있던 생성이 흔적 없이 사라진다.
  // (오래 걸리는 작업의 약속을 나중에 기다리는 구조라 이런 누수가 생기기 쉽다.)
  process.on("unhandledRejection", (reason) => {
    console.error(`[unhandledRejection] ${reason?.stack || reason}`);
  });
  process.on("uncaughtException", (err) => {
    console.error(`[uncaughtException] ${err?.stack || err}`);
  });
  process.once("SIGTERM", () => shutdown("SIGTERM"));
  process.once("SIGINT", () => shutdown("SIGINT"));

  // 일정 미리 알림 cron (1분 interval)
  try {
    const { startReminderCron } = await import(libUrl("scheduleCron.js"));
    const { getSQL, executeSQL } = await import(libUrl("serverSql.js"));
    const { sendPush } = await import(libUrl("webPush.js"));
    startReminderCron(getSQL, executeSQL, null, sendPush);
  } catch (e) {
    console.error("[scheduleCron] init failed:", e.message);
  }

  // 관리자 퍼지정책 기반 테이블 보관기간 정리 — 작은 배치로 락 시간을 짧게 유지
  try {
    const { startTableRetentionCron } = await import(libUrl("tableRetentionCron.js"));
    const { getSQL, executeSQL } = await import(libUrl("serverSql.js"));
    startTableRetentionCron(getSQL, executeSQL);
  } catch (e) {
    console.error("[tableRetention] init failed:", e.message);
  }

  // 볼륨 용량 자동 경보(조용한 디스크 풀 방지) — 임계 초과 시 로그+관리자 메일
  try {
    const { startDbCapacityMonitor } = await import(libUrl("dbCapacityMonitor.js"));
    const { getSQL, executeSQL } = await import(libUrl("serverSql.js"));
    startDbCapacityMonitor(getSQL, executeSQL);
  } catch (e) {
    console.error("[dbCapacity] init failed:", e.message);
  }

  // Postgres 자동 백업 → R2(데이터 전멸 방지) — 매일 pg_dump→gzip 업로드, 7일 롤링
  try {
    const { startDbBackupCron } = await import(libUrl("dbBackupCron.js"));
    startDbBackupCron();
  } catch (e) {
    console.error("[dbBackup] init failed:", e.message);
  }

  // DB에 남은 미디어(프로필 data URL, 이모지 BYTEA) → R2 이관. 작은 배치로 돌다가
  // 옮길 게 없어지면 스스로 멈춘다.
  try {
    const { startMediaMigrationCron } = await import(libUrl("mediaMigrationCron.js"));
    const { getSQL, executeSQL } = await import(libUrl("serverSql.js"));
    startMediaMigrationCron(getSQL, executeSQL);
  } catch (e) {
    console.error("[mediaMigration] init failed:", e.message);
  }
});
