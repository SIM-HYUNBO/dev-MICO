"use client";

import React, { useState, useEffect, useRef } from "react";
import { useRouter } from "next/router";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import { RequestServer } from "@/components/core/client/requestServer";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import Loading from "@/components/core/client/loading";
import Button from "@/components/core/client/ui/Button";
import Input from "@/components/core/client/ui/Input";
import Card from "@/components/core/client/ui/Card";
import BrunnerWordmark from "@/components/core/client/ui/BrunnerWordmark";

// 외부에서 import 가능하도록 export

export default function SigninContent() {
  const [loading, setLoading] = useState(false);
  const { BrunnerMessageBox, openOkCancelModal, openOkModal, openInputModal } =
    useModal();
  const router = useRouter();

  const userIdRef = useRef();

  const [userId, setUserId] = useState(constants.emptyString);
  const [password, setPassword] = useState(constants.emptyString);
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);
  const [expiredUserId, setExpiredUserId] = useState(null);
  const [expiredUserEmail, setExpiredUserEmail] = useState(null);
  const [rememberMe, setRememberMe] = useState(false);

  const tl = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.label,
      currentLanguageCode,
    );
  const tm = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.message,
      currentLanguageCode,
    );
  const [currentLoginedUserId, setCurrentLoggedUserId] = useState(null);

  // 초기 focus
  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
    setCurrentLoggedUserId(userInfo.getLoginUserId());
    if (userIdRef.current) userIdRef.current.focus();
  }, []);

  const changeUserIdValue = (e) => setUserId(e.target.value);
  const changePasswordValue = (e) => setPassword(e.target.value);

  const requestSignIn = async () => {
    try {
      const jRequest = {
        commandName: constants.commands.SECURITY_SIGNIN,
                userId,
        languageCode: currentLanguageCode,
        password,
      };

      setLoading(true);
      const jResponse = await RequestServer(jRequest);
      setLoading(false);

      if (jResponse.error_code === constants.errorCode.Success) {
        setExpiredUserId(null);
        setExpiredUserEmail(null);

        // 사용자 기본정보 저장. 메뉴는 저장하지 않는다 — 로그인 직후 미리 만들면 아직
        // 로그인 정보가 반영되기 전이라 '비로그인 메뉴'가 저장돼 서비스 메뉴가 사라진다.
        // 메뉴는 화면에서 항상 현재 코드·로그인 상태 기준으로 생성한다.
        const userInfo = jResponse;
        delete userInfo.menuItems;
        localStorage.setItem("userInfo", JSON.stringify(userInfo));
        window.dispatchEvent(
          new CustomEvent("userChanged", {
            detail: { userId: userInfo.userId },
          }),
        );

        const inviteToken = router.query.inviteToken;
        if (inviteToken) {
          window.location.assign(`/invite/${inviteToken}`);
        } else {
          // 읽던 화면에서 로그인하러 온 경우 그 화면으로 되돌린다(외부 주소는 허용하지 않는다).
          const back = String(router.query.redirect || "");
          const safeBack = back.startsWith("/") && !back.startsWith("//") ? back : "/";
          window.location.assign(safeBack);
        }
      } else if (jResponse.error_code === constants.errorCode.AccountExpired) {
        setExpiredUserId(jResponse.userId || userId);
        setExpiredUserEmail(jResponse.emailId || null);
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      } else {
        setExpiredUserId(null);
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") requestSignIn();
  };

  return (
    <>
      <BrunnerMessageBox />
      {loading && <Loading />}

      <div className="min-h-[calc(100dvh-5rem)] bg-[var(--bg)] text-[var(--text)] md:grid md:grid-cols-[0.42fr_0.58fr]">
        <section className="relative overflow-hidden bg-[image:var(--brand-gradient)] px-6 py-8 text-white md:flex md:flex-col md:justify-between md:p-10">
          <div className="w-fit" style={{ filter: "brightness(0) invert(1)" }}><BrunnerWordmark className="text-2xl font-extrabold md:text-[26px]" /></div>
          <div className="relative mt-10 md:mt-0">
            <h1 className="text-3xl font-extrabold leading-tight md:text-[32px]">{tl("authWelcomeBackTitle")}</h1>
            <p className="mt-4 max-w-sm text-sm leading-6 text-white/90">{tl("authWelcomeBackDesc")}</p>
          </div>
          <div className="mt-8 hidden text-xs text-white/70 md:block">v2026.05</div>
          <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-white/10" />
          <div className="absolute -bottom-28 -left-16 h-64 w-64 rounded-full bg-white/10" />
        </section>

        <section className="flex items-center justify-center px-5 py-8 md:p-10">
          <Card className="w-full max-w-[420px] border-0 bg-transparent p-0 shadow-none md:bg-[var(--surface)] md:p-7 md:shadow-[var(--shadow-card)]">
            <h2 className="text-3xl font-bold text-[var(--text)]">{tl("signIn")}</h2>
            <p className="mt-2 text-sm text-[var(--text-muted)]">{tl("authSigninDesc")}</p>

            <div className="mt-7 space-y-4">
              {/* 카카오 로그인 — 가장 빠른 경로를 맨 위에 우선 노출 */}
              <button
                type="button"
                onClick={() => {
                  const state = router.query.inviteToken
                    ? `chatInvite:${router.query.inviteToken}`
                    : router.query.inviteCode
                      ? `friendInvite:${router.query.inviteCode}`
                      : "login";
                  window.location.href = `/api/auth/kakao-start?state=${encodeURIComponent(state)}`;
                }}
                className="flex w-full items-center justify-center gap-2 rounded-[var(--radius-md)] px-4 py-3 text-sm font-bold text-[#191919] transition hover:opacity-90"
                style={{ backgroundColor: "#FEE500" }}
              >
                <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-[#191919] text-xs font-extrabold text-[#FEE500]">K</span>
                {tl("authStartWithKakao")}
              </button>

              <div className="flex items-center gap-3 py-1">
                <div className="h-px flex-1 bg-[var(--border)]" />
                <span className="text-[11px] font-semibold uppercase tracking-[0.05em] text-[var(--text-subtle)]">{tl("signinManualDivider")}</span>
                <div className="h-px flex-1 bg-[var(--border)]" />
              </div>
<div>
                <label htmlFor="id" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("loginId")}</label>
                <Input
                  ref={userIdRef}
                  type="text"
                  id="id"
                  name="Id"
                  value={userId}
                  onChange={changeUserIdValue}
                  aria-label={tl("loginId")}
                  placeholder={currentLoginedUserId || "brunner_id"}
                />
              </div>

              <div>
                <label htmlFor="password" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("password")}</label>
                <Input
                  type="password"
                  id="password"
                  name="password"
                  value={password}
                  onChange={changePasswordValue}
                  onKeyDown={handleKeyPress}
                  aria-label={tl("password")}
                  placeholder="********"
                />
              </div>

              <div className="flex items-center justify-between text-xs">
                <label htmlFor="rememberMe" className="flex items-center gap-2 text-[var(--text-muted)]">
                  <input id="rememberMe" type="checkbox" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} className="h-4 w-4 accent-[var(--brand-blue)]" />
                  {tl("authRememberMe")}
                </label>
                <button type="button" className="font-semibold text-[var(--brand-blue)]" onClick={() => router.push("/mainPages/resetPassword")}>
                  {tl("resetPassword")}
                </button>
              </div>

              <Button className="w-full py-3 text-[15px]" onClick={requestSignIn}>{tl("signIn")}</Button>
            </div>

            <div className="mt-6 text-center text-sm text-[var(--text-muted)]">
              {tl("authNoAccount")}{" "}
              <button type="button" className="font-semibold text-[var(--brand-blue)]" onClick={() => router.push("/mainPages/signup")}>
                {tl("signUp")}
              </button>
            </div>

          </Card>
        </section>
      </div>
    </>
  );
}
