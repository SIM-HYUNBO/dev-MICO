"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import {
  RequestServer,
} from "@/components/core/client/requestServer";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import Loading from "@/components/core/client/loading";
import Button from "@/components/core/client/ui/Button";
import Input from "@/components/core/client/ui/Input";
import Card from "@/components/core/client/ui/Card";
import Chip from "@/components/core/client/ui/Chip";
import BrunnerWordmark from "@/components/core/client/ui/BrunnerWordmark";

// 검증 함수는 메시지 "키"를 반환하고, 렌더 시 현재 언어로 해석한다(로직 truthiness 동일, 표시만 다국어).
const vmsg = (key) =>
  key ? commonFunctions.getResourceByLanguage(key, constants.resourceType.message, userInfo.getCurrentLanguageCode()) : key;

// ── 유효성 검사 헬퍼 ──────────────────────────────────────
function validateUserId(v) {
  if (!v) return null;
  if (v.length < 5)  return "SIGNUP_ID_MIN";
  if (v.length > 10) return "SIGNUP_ID_MAX";
  if (!/^[a-zA-Z0-9_]+$/.test(v)) return "SIGNUP_ID_CHARS";
  return "";
}

function validatePassword(v) {
  if (!v) return null;
  if (v.length < 8) return "SIGNUP_PW_MIN";
  return "";
}

function passwordStrength(v) {
  if (!v || v.length < 4) return 0;
  let score = 0;
  if (v.length >= 8)  score++;
  if (/[0-9]/.test(v) && /[a-zA-Z]/.test(v)) score++;
  if (/[^a-zA-Z0-9]/.test(v)) score++;
  if (v.length >= 12) score++;
  return score; // 0~3
}

function validateEmail(v) {
  if (!v) return null;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return "SIGNUP_EMAIL_FMT";
  return "";
}

// 생년월일(YYMMDD 6자리) — 연령 확인용 필수
function validateBirth(v) {
  if (!v) return null;
  if (!/^\d{6}$/.test(v)) return "SIGNUP_BIRTH_FMT";
  return "";
}

// ── 서브 컴포넌트 ──────────────────────────────────────────
function FieldHint({ text }) {
  return <p className="mt-1 text-xs text-gray-400 dark:text-gray-500 leading-snug">{text}</p>;
}

function FieldError({ text }) {
  if (!text) return null;
  return <p className="mt-1 text-xs text-red-500 flex items-center gap-1">⚠ {vmsg(text)}</p>;
}

function FieldOk({ show }) {
  if (!show) return null;
  return <p className="mt-1 text-xs text-green-500 flex items-center gap-1">✓ {vmsg("SIGNUP_AVAILABLE")}</p>;
}

// ── 메인 컴포넌트 ──────────────────────────────────────────
export default function SignupContent() {
  const [loading, setLoading] = useState(false);
  const { BrunnerMessageBox, openOkModal } = useModal();
  const router = useRouter();

  const [userId,       setUserId]       = useState("");
  const [password,     setPassword]     = useState("");
  const [userName,     setUserName]     = useState("");
  const [email,        setEmail]        = useState("");
  const [registerNo,   setRegisterNo]   = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);
  const [step, setStep] = useState(0);
  const [termsAgreed, setTermsAgreed] = useState(false);

  // 터치 여부 추적 (처음 포커스 후에만 에러 표시)
  const [touched, setTouched] = useState({});
  const touch = (field) => setTouched((p) => ({ ...p, [field]: true }));

  const inviteToken = router.query.inviteToken || null;

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  const showMessage = async (message, category) => {
    try { return await openOkModal(message, category); }
    catch { return true; }
  };

  const requestSignup = async () => {
    try {
      const jRequest = {
        commandName: constants.commands.SECURITY_SIGNUP,
                userId, languageCode: currentLanguageCode,
        password, userName, email, registerNo,
        // 가입 간소화 — 전화/주소는 선택. 생년월일(registerNo)은 연령 확인용 필수
        phoneNumber: "", address: "",
        userType: constants.userType.Personal, registerName: "",
      };
      setLoading(true);
      const jResponse = await RequestServer(jRequest);
      setLoading(false);
      if (jResponse.error_code === constants.errorCode.Success) {
        await showMessage(
          commonFunctions.getResourceByLanguage("SUCCESS_SIGNUP", constants.resourceType.message, currentLanguageCode),
          constants.messageCategory.Info,
        );
        if (inviteToken) {
          router.push(`/mainPages/signin?inviteToken=${inviteToken}`);
        } else {
          router.push("/mainPages/signin");
        }
      } else {
        await showMessage(jResponse.error_message, constants.messageCategory.Error);
      }
    } catch (e) {
      setLoading(false);
      await showMessage(e.message, constants.messageCategory.Exception);
    }
  };

  const idErr    = validateUserId(userId);
  const pwErr    = validatePassword(password);
  const pwScore  = passwordStrength(password);
  const emailErr = validateEmail(email);
  const birthErr = validateBirth(registerNo);

  const tl = (k) => commonFunctions.getResourceByLanguage(k, constants.resourceType.label, currentLanguageCode);
  const tm = (k) => commonFunctions.getResourceByLanguage(k, constants.resourceType.message, currentLanguageCode);
  const pwColors = ["bg-[var(--surface-alt)]", "bg-[var(--danger)]", "bg-[var(--warn)]", "bg-[var(--brand-emerald)]", "bg-[var(--brand-emerald)]"];
  const pwLabels = ["", tl("passwordWeak"), tl("passwordMedium"), tl("passwordStrong"), tl("passwordStrong")];

  const steps = [tl("signupStepBasic"), tl("signupStepTerms")];

  const canGoNext = () => {
    if (step === 0) return idErr === "" && pwErr === "" && userName.trim() && emailErr === "" && birthErr === "";
    return termsAgreed;
  };

  const goNext = async () => {
    setTouched((prev) => ({ ...prev, userId: true, password: true, email: true, registerNo: true }));
    if (!canGoNext()) return;
    if (step < 1) setStep((prev) => prev + 1);
    else await requestSignup();
  };

  return (
    <>
      <BrunnerMessageBox />
      {loading && <Loading />}

      <div className="min-h-[calc(100dvh-5rem)] bg-[var(--bg)] px-5 py-8 text-[var(--text)]">
        <div className="mx-auto max-w-2xl">
          <div className="mb-7 flex items-center gap-3">
            <BrunnerWordmark className="text-xl font-extrabold" />
          </div>

          <h1 className="text-3xl font-extrabold">{tl("signupWelcomeTitle")}</h1>
          <p className="mt-2 text-sm leading-6 text-[var(--text-muted)]">{tl("signupWelcomeDesc")}</p>

          {/* 카카오 가입 — 가장 마찰 없는 경로를 맨 위에 노출 */}
          <button
            type="button"
            onClick={() => {
              const state = inviteToken ? `chatInvite:${inviteToken}` : "signup";
              window.location.href = `/api/auth/kakao-start?state=${encodeURIComponent(state)}`;
            }}
            className="mt-6 flex w-full items-center justify-center gap-2 rounded-[var(--radius-md)] px-4 py-3 text-sm font-bold text-[#191919] transition hover:opacity-90"
            style={{ backgroundColor: "#FEE500" }}
          >
            <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-[#191919] text-xs font-extrabold text-[#FEE500]">K</span>
            {tl("authSignupWithKakao")}
          </button>

          <div className="mt-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-[var(--border)]" />
            <span className="text-[11px] font-semibold uppercase tracking-[0.05em] text-[var(--text-subtle)]">{tl("signupManualDivider")}</span>
            <div className="h-px flex-1 bg-[var(--border)]" />
          </div>

          <div className="my-7 flex items-center gap-2">
            {steps.map((label, index) => (
              <div key={label} className="flex flex-1 items-center gap-2">
                <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${index <= step ? "bg-[image:var(--brand-gradient)] text-white" : "bg-[var(--surface-alt)] text-[var(--text-muted)]"}`}>{index + 1}</span>
                <span className={`hidden text-xs font-semibold sm:inline ${index === step ? "text-[var(--text)]" : "text-[var(--text-muted)]"}`}>{label}</span>
                {index < steps.length - 1 && <span className="h-px flex-1 bg-[var(--border)]" />}
              </div>
            ))}
          </div>

          <Card className="overflow-hidden p-0">
            <div className="p-5 md:p-6">
              {step === 0 && (
                <div className="grid gap-5 md:grid-cols-2">
                  <div>
                    <label htmlFor="id" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("loginId")}</label>
                    <Input id="id" name="Id" value={userId} onChange={(e) => setUserId(e.target.value)} onBlur={() => touch("userId")} maxLength={10} placeholder="brunner_01" error={touched.userId && !!idErr} />
                    <div className="mt-2">{touched.userId && idErr === "" ? <Chip tone="brand">{tl("available")}</Chip> : touched.userId && idErr ? <Chip tone="danger">{tl("unavailable")}</Chip> : null}</div>
                    {touched.userId && idErr && <FieldError text={idErr} />}
                  </div>

                  <div>
                    <label htmlFor="password" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("password")}</label>
                    <Input type="password" id="password" name="password" value={password} onChange={(e) => setPassword(e.target.value)} onBlur={() => touch("password")} placeholder="********" error={touched.password && !!pwErr} />
                    {password && (
                      <div className="mt-2 flex items-center gap-1.5">
                        {[1, 2, 3, 4].map((i) => (
                          <span key={i} className={`h-1.5 flex-1 rounded-full ${pwScore >= i ? pwColors[pwScore] : "bg-[var(--surface-alt)]"}`} />
                        ))}
                        <span className="ml-1 text-xs text-[var(--text-subtle)]">{pwLabels[pwScore]}</span>
                      </div>
                    )}
                    {touched.password && pwErr && <FieldError text={pwErr} />}
                  </div>

                  <div>
                    <label htmlFor="name" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("name")}</label>
                    <Input id="name" name="Name" value={userName} onChange={(e) => setUserName(e.target.value)} placeholder={tl("name")} />
                  </div>

                  <div>
                    <label htmlFor="email" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("email")}</label>
                    <Input type="email" id="email" name="Email" value={email} onChange={(e) => setEmail(e.target.value)} onBlur={() => touch("email")} placeholder="name@example.com" error={touched.email && !!emailErr} />
                    {touched.email && emailErr && <FieldError text={emailErr} />}
                  </div>

                  <div>
                    <label htmlFor="registerNo" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("birthDate")}</label>
                    <Input id="registerNo" name="RegisterNo" value={registerNo} maxLength={6} inputMode="numeric" onChange={(e) => setRegisterNo(e.target.value.replace(/\D/g, ""))} onBlur={() => touch("registerNo")} placeholder="901231" error={touched.registerNo && !!birthErr} />
                    {touched.registerNo && birthErr && <FieldError text={birthErr} />}
                    <FieldHint text={tl("birthDateHint")} />
                  </div>
                </div>
              )}

              {step === 1 && (
                <div className="space-y-5">
                  <div className="rounded-[var(--radius-md)] bg-[var(--surface-alt)] p-4">
                    <div className="text-sm font-bold text-[var(--text)]">{tl("signupFreeTitle")}</div>
                    <p className="mt-2 text-sm leading-6 text-[var(--text-muted)]">{tl("signupFreeDesc")}</p>
                  </div>
                  <label htmlFor="termsAgreed" className="flex items-start gap-3 text-sm text-[var(--text-muted)]">
                    <input id="termsAgreed" type="checkbox" checked={termsAgreed} onChange={(e) => setTermsAgreed(e.target.checked)} className="mt-1 h-4 w-4 accent-[var(--brand-blue)]" />
                    {tl("signupTermsAgree")}
                  </label>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between border-t border-[var(--border)] p-4">
              <Button variant="ghost" onClick={() => setStep((prev) => Math.max(0, prev - 1))} disabled={step === 0}>{tl("signupPrev")}</Button>
              <Button onClick={goNext}>{step === 1 ? tl("signupComplete") : tl("signupNext")}</Button>
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
