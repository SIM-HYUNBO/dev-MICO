import * as constants from "@/lib/constants";
import * as userInfo from "@/components/core/client/frames/userInfo";
import * as commonFunctions from "@/lib/commonFunctions";
import { adminMenu, serviceMenu } from "@/lib/menuManifest";

// AI Studio 로 만든 연재물 문서는 공용문서 메뉴에 섞지 않는다.
// (zicp/brunner-template 에는 AI Studio 가 없어 항상 false 지만, 아래 filter 가
//  이 함수를 부르므로 정의가 없으면 로그인 직후 메뉴 조립이 통째로 예외로 죽는다.)
const isAiContentDocument = (doc) => {
  const runtimeData = doc?.runtime_data || {};
  return (
    runtimeData.source === "AI_STUDIO" ||
    runtimeData.aiContent === true ||
    Boolean(runtimeData.aiContentEpisodeId) ||
    Boolean(runtimeData.aiContentSpaceId)
  );
};

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

/**
 * 좌측 드롭다운 메뉴 구성.
 *
 * 템플릿에는 범용 기능만 남겼다. 프로젝트 고유 메뉴는 아래 SERVICE_MENU /
 * ADMIN_MENU 에 항목을 추가하면 된다. 공용문서 섹션은 eDoc 으로 만든 문서를
 * DB 에서 읽어 자동으로 붙이므로 코드 수정 없이 늘어난다.
 */

const toItems = (defs, parent) =>
  defs.map(({ key, href }) => ({ label: L(key), href, type: "item", parent }));

// 메뉴 전체 구성 반환 함수
export async function getDropdownMenuItems() {
  // 로고 클릭으로 홈 이동 가능 — 별도 Home 메뉴 항목 불필요
  let items = [];

  if (userInfo.getLoginUserId()) {
    const serviceSectionLabel = L("publicMenuSection");
    items.push({ label: serviceSectionLabel, type: "section" });
    items.push(...toItems(serviceMenu, serviceSectionLabel));
  }

  var documentList;

  // 공용문서 섹션 (시스템별)
  if (userInfo.getCurrentSystemCode()) {
    const publicDocumentSectionLabel = commonFunctions.getResourceByLanguage(
      "publicDocumentSection",
      constants.resourceType.label,
      userInfo.getCurrentLanguageCode(),
    );
    items.push({ label: publicDocumentSectionLabel, type: "section" });

    // 문서 섹션에서 나는 오류가 메뉴 전체를 지우지 않게 여기서 막는다.
    // 예전에는 이 구간에서 예외가 나면 getDropdownMenuItems 가 통째로 reject 되어
    // 이미 담아둔 서비스·관리자 메뉴까지 사라졌다. 실제로 정의가 빠진 함수를
    // 부르는 바람에 "로그인하면 햄버거 메뉴가 텅 빈다"로 나타났다.
    try {
      documentList = await commonFunctions.getAdminDocumentList(
        userInfo.getCurrentSystemCode(),
      );
    } catch (e) {
      console.warn("[menu] 공용문서 목록을 불러오지 못했어요:", e?.message || e);
      documentList = null;
    }

    if (documentList) {
      try {
      // 무엇을 보여줄지만 정한다. 무엇을 내줄지는 서버가 정한다.
      //
      // 예전에는 여기서 runtime_data.adminOnly 로 관리자 문서를 걸러냈는데, 그건
      // 동기화 스크립트가 심어 넣은 값이라 전자문서의 범용 속성이 아니었고, 무엇보다
      // 브라우저에서 거르는 것이라 API 를 직접 부르면 그대로 뚫렸다(실제로 로그인 없이
      // 계약 문서가 통째로 조회됐다). 지금은 서버가 isPublic·소유자·관리자 기준으로
      // 목록과 단건 조회를 모두 거르므로, 여기 목록에는 이미 볼 수 있는 문서만 온다.
      const helpDocs = documentList.filter((d) => !isAiContentDocument(d));

      // 같은 문서의 관리자판은 menu_path 의 -admin 접미사로 짝지어져 있다(테이블에 있는 값).
      // 관리자에게는 관리자판을 열어주되, 목록에서는 한 줄로 보이게 한다.
      const pathOf = (d) => d.runtime_data?.menu_path || d.menu_path || "";
      const adminVersions = new Map(
        helpDocs.filter((d) => pathOf(d).endsWith("-admin"))
                .map((d) => [pathOf(d).replace(/-admin$/, ""), d]),
      );

      helpDocs.forEach((doc) => {
        const path = pathOf(doc);
        if (path.endsWith("-admin") && adminVersions.has(path.replace(/-admin$/, ""))) {
          // 일반판이 함께 있으면 그쪽 줄에서 대신 열린다. 두 줄로 나오지 않게 건너뛴다.
          const hasNormal = helpDocs.some((x) => pathOf(x) === path.replace(/-admin$/, ""));
          if (hasNormal) return;
        }
        const target = adminVersions.get(path) || doc;
        items.push({
          label: doc.runtime_data?.title || L("menuUntitledDocument"),
          href: `/${target.id}`,
          type: "item",
          parent: publicDocumentSectionLabel,
        });
      });
      } catch (e) {
        console.warn("[menu] 공용문서 항목을 구성하지 못했어요:", e?.message || e);
      }
    }
  }


  // 관리자 전용 메뉴 섹션
  if (userInfo.isAdminUser()) {
    const adminMenuSectionLabel = L("adminMenuSection");
    items.push({ label: adminMenuSectionLabel, type: "section" });
    items.push(...toItems(adminMenu, adminMenuSectionLabel));
  }

  return items;
}
