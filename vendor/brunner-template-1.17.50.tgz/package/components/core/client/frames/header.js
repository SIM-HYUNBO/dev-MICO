import Link from "next/link";
import DropdownMenu from "@/components/core/client/frames/dropdownMenu";
import BrunnerWordmark from "@/components/core/client/ui/BrunnerWordmark";
import BackNavigationButton, { ForwardNavigationButton } from "@/components/core/client/frames/backNavigationButton";
import { usePathname, useRouter } from "next/navigation";
import { useRouter as usePagesRouter } from "next/router";
import { refreshIfOutdatedBuild } from "@/lib/clientBuildRefresh";

export default function Header() {
  const pathname = usePathname();
  const router = useRouter();
  // 쿼리만 바뀌는 이동(주식 탭 등)도 감지해야 뒤로/앞으로 버튼 표시가 갱신된다.
  const navKey = usePagesRouter().asPath;

  const handleLogoClick = async (e) => {
    e.preventDefault();
    const refreshing = await refreshIfOutdatedBuild({ targetUrl: "/", force: true });
    if (refreshing) return;

    if (pathname === "/") {
      router.refresh();
      return;
    }
    router.push("/");
  };

  return (
    <header className="header">
      <div className="mx-auto w-full max-w-5xl px-4">
        <div className="flex items-center justify-between px-4 md:px-6">
          <div className="flex min-w-0 items-center gap-2">
            <Link href="/" onClick={handleLogoClick} className="inline-flex min-w-0 items-center" aria-label="BRUNNER">
              <BrunnerWordmark className="text-[28px] font-extrabold sm:text-[36px]" />
            </Link>
          </div>
          <div className="relative z-50 flex items-center gap-2">
            <BackNavigationButton variant="header" locationKey={navKey} />
            <ForwardNavigationButton locationKey={navKey} />
            <DropdownMenu />
          </div>
        </div>
      </div>
    </header>
  );
}
