#!/usr/bin/env node
/**
 * 품질 게이트 자동 검증 (객관 항목만)
 * - 게이트1: 브라우저 기본 대화상자(alert/confirm/prompt) 사용 = 0 목표
 * - 게이트2(참고): dark: 없는 라이트 전용 색 (테마 미대응 후보)
 * - 게이트3: labels/messages 다국어(ko/en/ja) 누락 = 0 목표
 * - 게이트4(참고): JSX 하드코딩 한국어 후보 (라벨 미등록 후보)
 * - 게이트5: 주요 화면의 바깥/컨텐츠 영역 라이트·다크 대비 토큰 누락 = 0 목표
 *
 * 사용:
 *   node scripts/quality_gate.cjs          # 리포트만 (exit 0)
 *   node scripts/quality_gate.cjs --strict # 게이트1/3/5 위반 있으면 exit 1 (CI/배포 게이트용)
 *
 * 게이트2/4는 오탐(주석·게임 캔버스·데이터 문자열)이 있어 참고 수치로만 본다.
 */
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");
const { pathToFileURL } = require("url");

const SCAN = "components/core/client pages";
const strict = process.argv.includes("--strict");
const REQUIRED_LANGS = ["en-US", "ko-KR", "ja-JP"];
const ALLOW_EMPTY_I18N = new Set(["lib/messages.js:EMPTY_STRING"]);

// rg 실행 → 매칭 라인 배열. 매칭 없으면 [].
const rg = (args) => {
  try {
    return execSync(`rg ${args}`, { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] })
      .split("\n").filter(Boolean);
  } catch {
    return []; // rg는 매칭 0건이면 exit 1
  }
};

// 파일별 건수 집계 (rg -c 형식 "path:count")
const perFile = (lines) => lines
  .map((l) => { const i = l.lastIndexOf(":"); return [l.slice(0, i), Number(l.slice(i + 1))]; })
  .sort((a, b) => b[1] - a[1]);

const printSection = (title, lines) => {
  const files = perFile(lines);
  const total = files.reduce((s, [, n]) => s + n, 0);
  console.log(`\n${title} — 총 ${total}건, ${files.length}파일`);
  files.slice(0, 15).forEach(([f, n]) => console.log(`  ${String(n).padStart(3)}  ${f}`));
  if (files.length > 15) console.log(`  … 외 ${files.length - 15}파일`);
  return total;
};

const printDetailSection = (title, findings) => {
  const byFile = {};
  findings.forEach((item) => { byFile[item.file] = (byFile[item.file] || 0) + 1; });
  const files = Object.entries(byFile).sort((a, b) => b[1] - a[1]);
  console.log(`\n${title} — 총 ${findings.length}건, ${files.length}파일`);
  files.slice(0, 15).forEach(([f, n]) => console.log(`  ${String(n).padStart(3)}  ${f}`));
  findings.slice(0, 20).forEach((item) => console.log(`       - ${item.file}:${item.key} ${item.message}`));
  if (findings.length > 20) console.log(`       … 외 ${findings.length - 20}건`);
  return findings.length;
};

const validateI18nObject = (file, dict) => {
  const findings = [];
  Object.entries(dict || {}).forEach(([key, value]) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      findings.push({ file, key, message: "값이 언어별 객체가 아님" });
      return;
    }
    REQUIRED_LANGS.forEach((lang) => {
      if (!(lang in value)) {
        findings.push({ file, key, message: `${lang} 누락` });
        return;
      }
      if (!ALLOW_EMPTY_I18N.has(`${file}:${key}`) && (typeof value[lang] !== "string" || !value[lang].trim())) {
        findings.push({ file, key, message: `${lang} 빈값` });
      }
    });
  });
  return findings;
};

// 게이트5 는 화면 영역 대비의 전체 기준이지만, 자동검증은 대표 화면 하나를 본다.
// 그 대표 화면이 이 리포에 없으면(브랜치마다 기능 구성이 다르다) 예외로 죽지 않고
// 건너뛴다. 예전에는 파일이 없으면 readFileSync 가 던져 게이트 전체가 중단됐고,
// 그 뒤 게이트들(6·7·8)까지 한 번도 실행되지 않았다.
const APP_SURFACE_TARGET = "components/core/client/contents/aiStudioContent.js";

const validateAppSurfaceContrast = (root) => {
  const file = APP_SURFACE_TARGET;
  const fullPath = path.join(root, file);
  if (!fs.existsSync(fullPath)) {
    console.log(
      `\n🎨 게이트5 화면 영역 대비 토큰 — 건너뜀: 대표 화면(${file})이 이 리포에 없습니다.` +
        `\n   이 리포의 대표 화면을 정해 APP_SURFACE_TARGET 과 규칙을 맞추면 검증이 다시 켜집니다.`,
    );
    return null;
  }
  const src = fs.readFileSync(fullPath, "utf8");
  const findings = [];
  const rules = [
    ["aiStudioOuterLight", /min-h-\[calc\(100dvh-4rem\)\][^"`]*bg-\[#eef3f8\]/, "AI Studio 바깥 영역 라이트 배경 토큰 누락"],
    ["aiStudioOuterDark", /min-h-\[calc\(100dvh-4rem\)\][^"`]*dark:bg-\[#0b1220\]/, "AI Studio 바깥 영역 다크 배경 토큰 누락"],
    ["aiStudioContentLight", /rounded-2xl[^"`]*bg-\[#ffffff\]/, "AI Studio 컨텐츠 영역 라이트 배경 토큰 누락"],
    ["aiStudioContentDark", /rounded-2xl[^"`]*dark:bg-\[#111827\]/, "AI Studio 컨텐츠 영역 다크 배경 토큰 누락"],
  ];
  rules.forEach(([key, pattern, message]) => {
    if (!pattern.test(src)) findings.push({ file, key, message });
  });
  if (/bg-\[#eef3f8\][^"`]*bg-\[#eef3f8\]/.test(src)) {
    findings.push({ file, key: "aiStudioSameLightSurface", message: "AI Studio 라이트 모드 바깥/컨텐츠 배경이 같음" });
  }
  if (/dark:bg-\[#0b1220\][^"`]*dark:bg-\[#0b1220\]/.test(src)) {
    findings.push({ file, key: "aiStudioSameDarkSurface", message: "AI Studio 다크 모드 바깥/컨텐츠 배경이 같음" });
  }
  return findings;
};

const listJsFiles = (dir) => {
  const files = [];
  if (!fs.existsSync(dir)) return files;
  fs.readdirSync(dir, { withFileTypes: true }).forEach((entry) => {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...listJsFiles(full));
    else if (/\.(js|jsx|tsx?)$/.test(entry.name)) files.push(full);
  });
  return files;
};

const validateThemeContrastCandidates = (root) => {
  const dirs = ["components/core/client", "pages"];
  const colorClassRe = /\b(?:bg|text|border)-(?:white|black|slate|gray|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)(?:-\d{2,3})?(?:\/\d{1,3})?\b/g;
  const findings = [];
  dirs.flatMap((dir) => listJsFiles(path.join(root, dir))).forEach((abs) => {
    const rel = path.relative(root, abs).replace(/\\/g, "/");
    const lines = fs.readFileSync(abs, "utf8").split(/\r?\n/);
    lines.forEach((line, index) => {
      if (!/(className|className=|className:|className`|className\s*=|className\s*:|className\s*\{|className\s*\()/i.test(line)) return;
      if (/dark:|var\(--|bg-\[var|text-\[var|border-\[var|brand-gradient|brand-blue|brand-emerald|danger|warn/.test(line)) return;
      const matches = [...new Set(line.match(colorClassRe) || [])]
        .filter((token) => !/^(text-white|text-black|bg-transparent|border-transparent)$/.test(token));
      if (!matches.length) return;
      findings.push({
        file: `${rel}:${index + 1}`,
        key: matches.slice(0, 5).join(","),
        message: "고정 색상 클래스에 dark:/테마 변수 병기 없음",
      });
    });
  });
  return findings;
};

// 게이트8(참고): 인라인 텍스트 color 오버라이드.
// style={{ color: ... }}는 테마 클래스(--general-text-color)를 무조건 이기므로,
// 값이 테마 변수(var(--...))가 아니면 반대 모드에서 글씨가 배경과 같아져 사라질 수 있다.
// (예: 문서에 저장된 fontColor를 리더가 그대로 인라인으로 찍어 다크모드에서 본문이 안 보이던 버그)
// 배경/그라데이션 오버라이드는 대개 의도적이라 제외하고, 텍스트 color만 잡는다.
const validateInlineTextColorOverride = (root) => {
  const dirs = ["components/core/client", "pages"];
  const safeRe = /tetris|breakout|galaga|calculator|motionDetect|gameBgm|cafeSounds|[Cc]hart|[Cc]anvas|Avatar|lottie/;
  const styleRe = /style=\{\{([\s\S]{0,240}?)\}\}/g;
  const findings = [];
  dirs.flatMap((dir) => listJsFiles(path.join(root, dir))).forEach((abs) => {
    if (safeRe.test(abs)) return;
    const rel = path.relative(root, abs).replace(/\\/g, "/");
    const src = fs.readFileSync(abs, "utf8");
    let m;
    while ((m = styleRe.exec(src)) !== null) {
      const km = m[1].match(/(?<![a-zA-Z])color\s*:\s*([^,}]+)/); // backgroundColor 제외
      if (!km) continue;
      const val = km[1].trim();
      if (/var\(--|transparent|inherit|currentColor|["'`]none["'`]/.test(val)) continue;
      const line = src.slice(0, m.index).split("\n").length;
      findings.push({ file: `${rel}:${line}`, key: "inline-color", message: `인라인 텍스트 color 오버라이드(테마 안 따름): ${val.slice(0, 40)}` });
    }
  });
  return findings;
};

// 게이트6(참고): 가로 버튼 행에서 라벨이 단어 중간에 깨지는 후보.
// 형제 버튼이 있는(=한 행) 라벨 버튼인데 whitespace-nowrap 이 없는 경우만 잡아 노이즈를 줄인다.
const validateButtonNowrap = (root) => {
  const findings = [];
  listJsFiles(path.join(root, "components/core/client")).forEach((abs) => {
    const rel = path.relative(root, abs).replace(/\\/g, "/");
    const lines = fs.readFileSync(abs, "utf8").split(/\r?\n/);
    lines.forEach((line, i) => {
      if (!/<button\b/.test(line)) return;
      const block = lines.slice(i, i + 6).join("\n");
      if (!/className/.test(block)) return;
      // 안전 패턴(줄바꿈 무해/아이콘/전폭 버튼)은 제외
      if (/whitespace-nowrap|w-full|justify-center|rounded-full|inline-flex h-|aria-label|title=/.test(block)) return;
      // 텍스트 라벨이 있는 버튼만
      if (!/L\(|[가-힣]/.test(block)) return;
      // 형제 버튼이 있는 가로 행만(단독 버튼은 줄바꿈이 덜 치명적이라 제외)
      const near = lines.slice(Math.max(0, i - 4), i + 6).join("\n");
      if ((near.match(/<button\b/g) || []).length < 2) return;
      findings.push({ file: `${rel}:${i + 1}`, key: "nowrap", message: "가로 버튼 행 라벨 whitespace-nowrap 누락 후보" });
    });
  });
  return findings;
};

// 게이트7: 다크모드 설정 무결성.
// next-themes는 `.dark` 클래스로 테마를 바꾸므로 Tailwind darkMode도 `.dark` 클래스 셀렉터여야 한다.
// 잘못되면(예: ["class","class"], "media") 모든 dark: 유틸리티가 죽어 다크모드에서 배경만 흰색으로 남는다.
const validateDarkModeConfig = (root) => {
  const findings = [];
  const cfgPath = ["tailwind.config.js", "tailwind.config.cjs", "tailwind.config.ts"]
    .map((f) => path.join(root, f)).find((p) => fs.existsSync(p));
  if (!cfgPath) return findings;
  const rel = path.relative(root, cfgPath).replace(/\\/g, "/");
  const src = fs.readFileSync(cfgPath, "utf8");
  const m = src.match(/darkMode\s*:\s*(\[[^\]]*\]|"[^"]*"|'[^']*')/);
  if (!m) {
    findings.push({ file: rel, key: "darkMode", message: "darkMode 설정이 없음 — next-themes(.dark)와 어긋나면 dark: 유틸리티가 안 먹음" });
    return findings;
  }
  const val = m[1];
  // 허용: "class" | ['class'] | ['class', '.dark'] 처럼 커스텀 셀렉터가 '.'로 시작하거나 '['로 시작하는 속성 셀렉터
  const okString = /^["']class["']$/.test(val);
  const arr = val.startsWith("[") ? val.slice(1, -1).split(",").map((s) => s.trim().replace(/^["']|["']$/g, "")) : null;
  const okArray = arr && arr[0] === "class" && (arr.length === 1 || /^[.\[]/.test(arr[1]));
  if (!okString && !okArray) {
    findings.push({ file: rel, key: "darkMode", message: `darkMode: ${val} — .dark 클래스 셀렉터가 아니라 모든 dark: 유틸리티가 죽음(권장: ["class", ".dark"])` });
  }
  return findings;
};

const main = async () => {
  // 게이트1: 브라우저 기본 대화상자 (openOk*/openInput* 브랜드 모달, 주석, .alert 제외)
  const alertLines = rg(`--pcre2 -n '(?<![.\\w])(window\\.)?(alert|confirm|prompt)\\s*\\(' ${SCAN} --glob '*.js'`)
    .filter((l) => !/openOk|openInput|openConfirm|\/\//.test(l));
  const alertByFile = {};
  alertLines.forEach((l) => { const f = l.split(":")[0]; alertByFile[f] = (alertByFile[f] || 0) + 1; });
  const alertTotal = printSection("🚨 게이트1 시스템 기본 대화상자(목표 0)",
    Object.entries(alertByFile).map(([f, n]) => `${f}:${n}`));

  // 이 스크립트는 파생 저장소의 node_modules 안에서도 실행된다. 자기 위치를
  // 앱 루트로 단정하면 그 저장소의 파일이 아니라 패키지 안을 검사하게 된다.
  const root = process.env.BRUNNER_APP_DIR || process.cwd();

  // 게이트2(참고): 전체 화면 고정 색상/다크 미대응 후보
  const themeContrastFindings = validateThemeContrastCandidates(root);
  printDetailSection("🎨 게이트2(참고) 라이트/다크 대비 후보", themeContrastFindings);

  // 게이트3: labels/messages 다국어 완성도
  const [{ labels }, { messages }] = await Promise.all([
    import(pathToFileURL(path.join(root, "lib", "labels.js")).href),
    import(pathToFileURL(path.join(root, "lib", "messages.js")).href),
  ]);
  const i18nFindings = [
    ...validateI18nObject("lib/labels.js", labels),
    ...validateI18nObject("lib/messages.js", messages),
  ];
  const i18nTotal = printDetailSection("🌐 게이트3 다국어 라벨/메시지 누락(목표 0)", i18nFindings);

  // 게이트4(참고): JSX 하드코딩 한국어 후보 (라벨 정의/주석 대략 제외)
  const koLines = rg(`-c '\\p{Hangul}' ${SCAN} --glob '*.js'`)
    .filter((l) => l && !/labels\.js|messages\.js|mediumTheme|constants\.js/.test(l));
  printSection("🌐 게이트4(참고) 한국어 포함 파일(주석·라벨 다수 오탐 있음)", koLines);

  // 게이트5: 주요 화면의 작업면과 바깥 배경이 라이트/다크 양쪽에서 분리되어야 한다.
  // null 이면 대표 화면이 없어 건너뛴 것 — 위반 0 으로 본다(사유는 함수가 출력).
  const appSurfaceFindings = validateAppSurfaceContrast(root);
  const appSurfaceTotal = appSurfaceFindings
    ? printDetailSection("🎨 게이트5 화면 영역 대비 토큰(목표 0)", appSurfaceFindings)
    : 0;

  // 게이트6(참고): 가로 버튼 행 라벨 줄바꿈 방지 누락 후보
  const buttonNowrapFindings = validateButtonNowrap(root);
  printDetailSection("🔘 게이트6(참고) 버튼 라벨 줄바꿈 방지 누락 후보", buttonNowrapFindings);

  // 게이트7: 다크모드 설정 무결성(Tailwind darkMode ↔ next-themes .dark)
  const darkModeFindings = validateDarkModeConfig(root);
  const darkModeTotal = printDetailSection("🌓 게이트7 다크모드 설정 무결성(목표 0)", darkModeFindings);

  // 게이트8(참고): 인라인 텍스트 color 오버라이드(테마 미준수) 후보
  const inlineColorFindings = validateInlineTextColorOverride(root);
  printDetailSection("🎨 게이트8(참고) 인라인 텍스트 color 오버라이드", inlineColorFindings);

  console.log("\n" + "=".repeat(50));
  console.log(`게이트1(대화상자) 위반: ${alertTotal}건 — 목표 0`);
  console.log(`게이트3(다국어 누락) 위반: ${i18nTotal}건 — 목표 0`);
  console.log(`게이트5(화면 영역 대비) 위반: ${appSurfaceTotal}건 — 목표 0`);
  console.log(`게이트7(다크모드 설정) 위반: ${darkModeTotal}건 — 목표 0`);
  if (strict && (alertTotal > 0 || i18nTotal > 0 || appSurfaceTotal > 0 || darkModeTotal > 0)) {
    console.log("❌ --strict: 게이트1/3/5/7 위반으로 실패(exit 1)");
    process.exit(1);
  }
  console.log("✅ 리포트 완료");
};

main().catch((err) => {
  console.error("품질 게이트 실행 실패:", err);
  process.exit(1);
});
