-- 저장소 문서의 공개 여부를 배포마다 강제한다.
--
-- 왜 별도로 두나
--   공개 여부는 sync_repo_docs_to_edoc 이 문서를 통째로 다시 쓰면서 함께 넣는다.
--   그런데 시작 명령이 "(npm run repo:docs:sync || true)" 라 그 동기화는 실패해도
--   배포가 그대로 성공한다. 코드(메뉴에서 관리자 문서를 숨기던 필터 제거)는 배포
--   즉시 반영되는데 데이터(isPublic=false)는 반영이 안 되는 틈이 생기고, 그 사이
--   관리자 문서가 일반 사용자에게 그대로 열린다. 실제로 그렇게 됐다.
--
--   이 스크립트는 run_sql 단계에서 돈다. run_sql 은 실패하면 서버 기동을 막으므로
--   조용히 넘어가지 않는다. 마크다운 변환과 무관하게 공개 여부만 손대므로
--   동기화가 실패한 배포에서도 가시성은 항상 의도대로 남는다.
--
--   문서 ID 는 고정 키에서 만드는 결정적 UUID 라 환경이 달라도 같다. 다만 컬럼
--   타입은 varchar 이므로 비교는 text 로 맞춘다 — uuid 로 비교하면 새 스키마에서
--   operator does not exist 로 기동이 막힌다.
--   스키마 안의 모든 테넌트(00·01·02)에 함께 적용한다.
DO $vis$
DECLARE
  d record;
BEGIN
  IF to_regclass('brunner_template.tb_cor_edoc_document') IS NULL THEN
    RETURN;
  END IF;

  FOR d IN
    SELECT * FROM (VALUES
      ('d0fcc113-371c-4c99-8cf5-a01de8b4a989'::uuid, true),   -- README : 사용자 매뉴얼
      ('1bc8abcc-a303-41a6-81b7-f8187548fde2'::uuid, false),  -- README (관리자)
      ('e5cccc10-001a-4c2a-86a8-590d99a06970'::uuid, false),  -- PLAN
      ('914684df-86f0-444d-9385-ae7fde82bd32'::uuid, false),  -- Offering
      ('75d921e1-cd9d-44c7-b691-3f3ed5bb39dc'::uuid, false)   -- Contract
    ) AS v(doc_id, is_public)
  LOOP
    UPDATE brunner_template.tb_cor_edoc_document
       SET runtime_data = jsonb_set(
             COALESCE(runtime_data, '{}'::jsonb), '{isPublic}', to_jsonb(d.is_public))
     WHERE id::text = d.doc_id::text
       AND COALESCE((runtime_data->>'isPublic')::boolean, NOT d.is_public) IS DISTINCT FROM d.is_public;
  END LOOP;
END
$vis$;
