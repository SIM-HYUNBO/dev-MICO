-- 채팅방별 안읽은 메시지 수 조회 (사용자 기준)
-- 실행 전: migrate_room_id_to_uuid.sql 먼저 실행 필요 (room_id uuid 타입 통일)
-- 실행 후: 서버 재시작 필요

INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'select_TB_COR_CHAT_UNREAD_COUNT_BY_USER',
  1,
  'SELECT u.room_id, COUNT(msg.msg_id)::integer AS unread_count FROM brunner_template.TB_COR_CHATROOM_USERS u INNER JOIN brunner_template.TB_COR_CHAT_MSG msg ON msg.system_code = $1 AND msg.room_id = u.room_id AND msg.user_id != $2 AND msg.message IS NOT NULL LEFT JOIN brunner_template.TB_COR_CHAT_READ_RECEIPT rr ON rr.system_code = $1 AND rr.room_id = u.room_id AND rr.message_id = msg.msg_id AND rr.user_id = $2 WHERE u.system_code = $1 AND u.user_id = $2 AND rr.message_id IS NULL GROUP BY u.room_id',
  'SYSTEM',
  NOW()
) ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE
  SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
