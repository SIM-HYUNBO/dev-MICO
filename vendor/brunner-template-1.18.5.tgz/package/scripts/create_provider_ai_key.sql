-- 사용자 제공 AI provider API 키(BYOK) 저장소.
--
-- eDoc AI 생성은 템플릿 공통 기능이고, AI Studio도 같은 계정별 키를 쓴다.
-- 그래서 AIC 영역이 아니라 COR 영역에 둔다. 다만 provider 일반 설정이 아니라
-- "사용자 제공 AI API 키"라서 이름은 TB_COR_PROVIDER_AI_KEY 로 명확히 둔다.
DO $rename_provider_ai_key$
BEGIN
  IF to_regclass('brunner_template.tb_cor_provider_ai_key') IS NULL THEN
    IF to_regclass('brunner_template.tb_aic_provider_key') IS NOT NULL THEN
      ALTER TABLE brunner_template.tb_aic_provider_key RENAME TO tb_cor_provider_ai_key;
      ALTER INDEX IF EXISTS brunner_template.tb_aic_provider_key_pkey
        RENAME TO tb_cor_provider_ai_key_pkey;
      ALTER INDEX IF EXISTS brunner_template.idx_tb_aic_provider_key_user
        RENAME TO idx_tb_cor_provider_ai_key_user;
      RAISE NOTICE 'tb_aic_provider_key -> tb_cor_provider_ai_key';
    ELSIF to_regclass('brunner_template.tb_cor_provider_key') IS NOT NULL THEN
      ALTER TABLE brunner_template.tb_cor_provider_key RENAME TO tb_cor_provider_ai_key;
      ALTER INDEX IF EXISTS brunner_template.tb_cor_provider_key_pkey
        RENAME TO tb_cor_provider_ai_key_pkey;
      ALTER INDEX IF EXISTS brunner_template.idx_tb_cor_provider_key_user
        RENAME TO idx_tb_cor_provider_ai_key_user;
      RAISE NOTICE 'tb_cor_provider_key -> tb_cor_provider_ai_key';
    END IF;
  END IF;
END
$rename_provider_ai_key$;

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_PROVIDER_AI_KEY (
  SYSTEM_CODE    VARCHAR(2)   NOT NULL,
  USER_ID        VARCHAR(100) NOT NULL,
  PROVIDER       VARCHAR(20)  NOT NULL,
  KEY_CIPHERTEXT TEXT         NOT NULL,
  CREATED_AT     TIMESTAMP    DEFAULT NOW(),
  UPDATED_AT     TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, USER_ID, PROVIDER)
);

CREATE INDEX IF NOT EXISTS IDX_TB_COR_PROVIDER_AI_KEY_USER
  ON brunner_template.TB_COR_PROVIDER_AI_KEY(SYSTEM_CODE, USER_ID);
