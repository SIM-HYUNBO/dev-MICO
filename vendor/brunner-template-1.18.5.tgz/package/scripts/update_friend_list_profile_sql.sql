-- select_TB_COR_USER_FRIEND seq=2 — friend profile_image_src 조회
-- friend.js에서 친구 목록 조회 후 프로필 이미지 병합에 사용
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES (
  '00',
  'select_TB_COR_USER_FRIEND',
  2,
  'SELECT f.friend_id, u.profile_image_src FROM brunner_template.TB_COR_USER_FRIEND f LEFT JOIN brunner_template.TB_COR_USER_MST u ON u.system_code = f.system_code AND u.user_id = f.friend_id WHERE f.system_code = $1 AND f.user_id = $2',
  'claude',
  NOW()
)
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET
  SQL_CONTENT = EXCLUDED.SQL_CONTENT,
  CREATE_TIME = NOW();
