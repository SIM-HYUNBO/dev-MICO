-- 채팅 파일(이미지/동영상) 저장 테이블
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHAT_FILE (
  system_code  VARCHAR(10)  NOT NULL,
  id           UUID         NOT NULL DEFAULT gen_random_uuid(),
  room_id      UUID         NOT NULL,
  sender_id    VARCHAR(50)  NOT NULL,
  file_name    VARCHAR(255),
  mime_type    VARCHAR(100) NOT NULL,
  file_size    BIGINT       NOT NULL,
  file_data    BYTEA        NOT NULL,
  created_at   TIMESTAMP    NOT NULL DEFAULT NOW(),
  PRIMARY KEY (system_code, id)
);
