--
-- brunner-template 스키마 일괄 생성 스크립트
--
-- scripts/run_sql.cjs 를 PostgreSQL 16 에 실행한 결과를 덤프한 것입니다.
-- Node 없이 psql·pgAdmin·Railway 콘솔 등 어디서든 그대로 실행할 수 있습니다.
--
--   psql "$DATABASE_URL" -f scripts/schema_full.sql
--
-- brunner-next 와 같은 DB 에 실행해도 안전합니다. 이 스크립트는 brunner_template
-- 스키마만 만들고, 원본 brunner 스키마의 테이블은 읽지도 쓰지도 않습니다.
--
-- 포함: 테이블 28개 + 동적 SQL 시드 132건 (전부 PREPARE 검증 통과)
--
-- 기능을 추가·수정할 때는 이 파일이 아니라 개별 스크립트를 고치고
-- npm run db:init 로 재생성하세요. 이 파일은 산출물입니다.
--

--
-- PostgreSQL database dump
--


-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: brunner_template; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA brunner_template;


--
-- Name: fn_table_usage(); Type: FUNCTION; Schema: brunner_template; Owner: -
--

CREATE FUNCTION brunner_template.fn_table_usage() RETURNS TABLE(table_name text, total_bytes bigint, total_size text, exact_rows bigint)
    LANGUAGE plpgsql
    AS $$
DECLARE
  r record;
  cnt bigint;
BEGIN
  FOR r IN
    SELECT c.relname AS relname, c.oid AS oid
    FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE lower(n.nspname) = 'brunner_template' AND c.relkind = 'r'
    ORDER BY pg_total_relation_size(c.oid) DESC
    LIMIT 80
  LOOP
    EXECUTE format('SELECT count(*) FROM brunner_template.%I', r.relname) INTO cnt;
    table_name := r.relname;
    total_bytes := pg_total_relation_size(r.oid);
    total_size := pg_size_pretty(pg_total_relation_size(r.oid));
    exact_rows := cnt;
    RETURN NEXT;
  END LOOP;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tb_cor_chat_custom_emoji; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chat_custom_emoji (
    system_code character varying(10) NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(50) NOT NULL,
    name character varying(50) NOT NULL,
    mime_type character varying(100) DEFAULT 'image/png'::character varying NOT NULL,
    file_data bytea NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: tb_cor_chat_reaction; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chat_reaction (
    system_code character varying(2) NOT NULL,
    message_id bigint NOT NULL,
    user_id character varying(100) NOT NULL,
    emoji character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_android_tester; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_android_tester (
    system_code character varying(10) NOT NULL,
    user_id character varying(100) NOT NULL,
    user_name character varying(200),
    email character varying(320) NOT NULL,
    status character varying(20) DEFAULT 'REQUESTED'::character varying NOT NULL,
    source character varying(40) DEFAULT 'home'::character varying NOT NULL,
    tester_link text,
    group_email character varying(320),
    group_result text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT tb_cor_android_tester_status_check CHECK (((status)::text = ANY ((ARRAY['REQUESTED'::character varying, 'GROUP_ADDED'::character varying, 'INVITED'::character varying, 'JOINED'::character varying, 'REJECTED'::character varying, 'FAILED'::character varying])::text[])))
);


--
-- Name: tb_cor_chat_file; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chat_file (
    system_code character varying(10) NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    room_id uuid NOT NULL,
    sender_id character varying(50) NOT NULL,
    file_name character varying(255),
    mime_type character varying(100) NOT NULL,
    file_size bigint NOT NULL,
    file_data bytea,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    r2_key character varying(500)
);


--
-- Name: tb_cor_chat_msg; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chat_msg (
    system_code character varying(2) NOT NULL,
    msg_id bigint NOT NULL,
    room_id uuid NOT NULL,
    user_id character varying(100) NOT NULL,
    user_name character varying(100),
    message text,
    reply_to bigint,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_chat_msg_msg_id_seq; Type: SEQUENCE; Schema: brunner_template; Owner: -
--

CREATE SEQUENCE brunner_template.tb_cor_chat_msg_msg_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tb_cor_chat_msg_msg_id_seq; Type: SEQUENCE OWNED BY; Schema: brunner_template; Owner: -
--

ALTER SEQUENCE brunner_template.tb_cor_chat_msg_msg_id_seq OWNED BY brunner_template.tb_cor_chat_msg.msg_id;


--
-- Name: tb_cor_chat_read_receipt; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chat_read_receipt (
    system_code character varying(2) NOT NULL,
    room_id uuid NOT NULL,
    message_id bigint NOT NULL,
    user_id character varying(100) NOT NULL,
    read_at timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_chatroom_invite; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chatroom_invite (
    invite_id bigint NOT NULL,
    system_code character varying(10) NOT NULL,
    room_id uuid NOT NULL,
    room_name character varying(200),
    inviter_id character varying(100) NOT NULL,
    inviter_name character varying(200),
    target_user_id character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    create_time timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT tb_cor_chatroom_invite_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'ACCEPTED'::character varying, 'REJECTED'::character varying])::text[])))
);


--
-- Name: tb_cor_chatroom_invite_invite_id_seq; Type: SEQUENCE; Schema: brunner_template; Owner: -
--

CREATE SEQUENCE brunner_template.tb_cor_chatroom_invite_invite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tb_cor_chatroom_invite_invite_id_seq; Type: SEQUENCE OWNED BY; Schema: brunner_template; Owner: -
--

ALTER SEQUENCE brunner_template.tb_cor_chatroom_invite_invite_id_seq OWNED BY brunner_template.tb_cor_chatroom_invite.invite_id;


--
-- Name: tb_cor_chatroom_member_device_key; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chatroom_member_device_key (
    system_code character varying(10) NOT NULL,
    room_id uuid NOT NULL,
    user_id character varying(50) NOT NULL,
    device_id character varying(120) NOT NULL,
    encrypted_key text NOT NULL,
    key_provider_id character varying(50) NOT NULL,
    key_provider_device_id character varying(120),
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: tb_cor_chatroom_member_key; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chatroom_member_key (
    system_code character varying(10) NOT NULL,
    room_id uuid NOT NULL,
    user_id character varying(50) NOT NULL,
    encrypted_key text NOT NULL,
    key_provider_id character varying(50) NOT NULL
);


--
-- Name: tb_cor_chatroom_mst; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chatroom_mst (
    system_code character varying(2) NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(200),
    created_by character varying(100),
    is_secret boolean DEFAULT false,
    room_type character varying(20) DEFAULT 'GROUP'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    category character varying(20),
    owner_id character varying(100),
    description character varying(200),
    max_members integer DEFAULT 100
);


--
-- Name: tb_cor_chatroom_room_key; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chatroom_room_key (
    system_code character varying(10) NOT NULL,
    room_id uuid NOT NULL,
    room_key_b64 text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: tb_cor_chatroom_room_key_history; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chatroom_room_key_history (
    system_code character varying(10) NOT NULL,
    room_id uuid NOT NULL,
    key_hash character varying(32) NOT NULL,
    room_key_b64 text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: tb_cor_chatroom_users; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_chatroom_users (
    system_code character varying(2) NOT NULL,
    room_id uuid NOT NULL,
    user_id character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_complaint; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_complaint (
    complaint_id bigint NOT NULL,
    system_code character varying(10) NOT NULL,
    user_id character varying(100) NOT NULL,
    user_name character varying(200),
    content text NOT NULL,
    images text,
    status character varying(20) DEFAULT 'RECEIVED'::character varying NOT NULL,
    resolution text,
    resolved_by character varying(100),
    resolved_time timestamp without time zone,
    approve_time timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT tb_cor_complaint_status_check CHECK (((status)::text = ANY ((ARRAY['RECEIVED'::character varying, 'IN_PROGRESS'::character varying, 'RESOLVED'::character varying, 'APPROVED'::character varying])::text[])))
);


--
-- Name: tb_cor_complaint_complaint_id_seq; Type: SEQUENCE; Schema: brunner_template; Owner: -
--

CREATE SEQUENCE brunner_template.tb_cor_complaint_complaint_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tb_cor_complaint_complaint_id_seq; Type: SEQUENCE OWNED BY; Schema: brunner_template; Owner: -
--

ALTER SEQUENCE brunner_template.tb_cor_complaint_complaint_id_seq OWNED BY brunner_template.tb_cor_complaint.complaint_id;


--
-- Name: tb_cor_friend_invite; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_friend_invite (
    invite_code character varying(36) NOT NULL,
    system_code character varying(10) NOT NULL,
    inviter_id character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    expire_at timestamp without time zone DEFAULT (now() + '7 days'::interval) NOT NULL,
    used_at timestamp without time zone,
    invitee_id character varying(50)
);


--
-- Name: tb_cor_push_subscription; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_push_subscription (
    system_code character varying(2) DEFAULT '00'::character varying NOT NULL,
    user_id character varying(100) NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_schedule; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_schedule (
    schedule_id bigint NOT NULL,
    system_code character varying(10) NOT NULL,
    user_id character varying(100) NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL,
    is_all_day character(1) DEFAULT 'N'::bpchar NOT NULL,
    color character varying(20) DEFAULT '#3b82f6'::character varying,
    reminder_minutes integer,
    notified_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    repeat_type character varying(10) DEFAULT NULL::character varying,
    repeat_until date,
    exceptions text,
    schedule_type character varying(20) DEFAULT NULL::character varying,
    repeat_lunar boolean DEFAULT false,
    CONSTRAINT tb_cor_schedule_is_all_day_check CHECK ((is_all_day = ANY (ARRAY['Y'::bpchar, 'N'::bpchar]))),
    CONSTRAINT tb_cor_schedule_repeat_type_check CHECK (((repeat_type)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'yearly'::character varying])::text[])))
);


--
-- Name: tb_cor_schedule_participant; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_schedule_participant (
    participant_id bigint NOT NULL,
    schedule_id bigint NOT NULL,
    system_code character varying(10) NOT NULL,
    user_id character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'ACCEPTED'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT tb_cor_schedule_participant_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'ACCEPTED'::character varying])::text[])))
);


--
-- Name: tb_cor_schedule_participant_participant_id_seq; Type: SEQUENCE; Schema: brunner_template; Owner: -
--

CREATE SEQUENCE brunner_template.tb_cor_schedule_participant_participant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tb_cor_schedule_participant_participant_id_seq; Type: SEQUENCE OWNED BY; Schema: brunner_template; Owner: -
--

ALTER SEQUENCE brunner_template.tb_cor_schedule_participant_participant_id_seq OWNED BY brunner_template.tb_cor_schedule_participant.participant_id;


--
-- Name: tb_cor_schedule_schedule_id_seq; Type: SEQUENCE; Schema: brunner_template; Owner: -
--

CREATE SEQUENCE brunner_template.tb_cor_schedule_schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tb_cor_schedule_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: brunner_template; Owner: -
--

ALTER SEQUENCE brunner_template.tb_cor_schedule_schedule_id_seq OWNED BY brunner_template.tb_cor_schedule.schedule_id;


--
-- Name: tb_cor_sql_info; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_sql_info (
    system_code character varying(2) NOT NULL,
    sql_name character varying(200) NOT NULL,
    sql_seq integer DEFAULT 1 NOT NULL,
    sql_content text NOT NULL,
    create_user_id character varying(100),
    create_time timestamp without time zone DEFAULT now(),
    update_user_id character varying(100),
    update_time timestamp without time zone
);


--
-- Name: tb_cor_txn_hist; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_txn_hist (
    system_code character varying(2) NOT NULL,
    transaction_id character varying(64) NOT NULL,
    request_ip character varying(100),
    request_message_content text,
    reply_message_content text,
    create_time timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_user_activity_log; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_user_activity_log (
    system_code character varying(10) NOT NULL,
    activity_date date DEFAULT ((now() AT TIME ZONE 'Asia/Seoul'::text))::date NOT NULL,
    user_id character varying(100) NOT NULL,
    activity_type character varying(80) NOT NULL,
    command_name character varying(160),
    first_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp without time zone DEFAULT now() NOT NULL,
    hit_count integer DEFAULT 1 NOT NULL
);


--
-- Name: tb_cor_user_e2ee_device_key; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_user_e2ee_device_key (
    system_code character varying(10) NOT NULL,
    user_id character varying(50) NOT NULL,
    device_id character varying(120) NOT NULL,
    public_key text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: tb_cor_user_friend; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_user_friend (
    system_code character varying(2) NOT NULL,
    user_id character varying(100) NOT NULL,
    friend_id character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'ACCEPTED'::character varying,
    create_time timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_user_mst; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_user_mst (
    system_code character varying(2) NOT NULL,
    user_id character varying(100) NOT NULL,
    password character varying(200),
    user_name character varying(100),
    address character varying(500),
    phone_number character varying(50),
    email_id character varying(200),
    use_flag character varying(1) DEFAULT 'Y'::character varying,
    admin_flag boolean DEFAULT false,
    register_no character varying(100),
    register_name character varying(100),
    user_type character varying(20),
    kakao_id character varying(100),
    profile_image_base64 text,
    public_key text,
    expire_time timestamp without time zone,
    create_time timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_user_session; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_user_session (
    system_code character varying(10) NOT NULL,
    session_token character varying(64) NOT NULL,
    user_id character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    expires_at timestamp without time zone DEFAULT (now() + '30 days'::interval) NOT NULL
);


--
-- Name: tb_cor_credit_mst; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_credit_mst (
    system_code character varying(2) NOT NULL,
    user_id character varying(100) NOT NULL,
    balance integer DEFAULT 0,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_credit_ledger; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_credit_ledger (
    system_code character varying(2) NOT NULL,
    ledger_id character varying(64) NOT NULL,
    user_id character varying(100) NOT NULL,
    delta integer NOT NULL,
    balance_after integer,
    reason character varying(40),
    ref character varying(100),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_edoc_document; Type: TABLE; Schema: brunner_template; Owner: -
--

CREATE TABLE brunner_template.tb_cor_edoc_document (
    system_code character varying(2) NOT NULL,
    id uuid NOT NULL,
    title character varying(300),
    description text,
    version integer DEFAULT 1,
    pages jsonb,
    runtime_data jsonb,
    menu_path character varying(200),
    created_by character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    updated_by character varying(100),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: tb_cor_chat_msg msg_id; Type: DEFAULT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chat_msg ALTER COLUMN msg_id SET DEFAULT nextval('brunner_template.tb_cor_chat_msg_msg_id_seq'::regclass);


--
-- Name: tb_cor_chatroom_invite invite_id; Type: DEFAULT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chatroom_invite ALTER COLUMN invite_id SET DEFAULT nextval('brunner_template.tb_cor_chatroom_invite_invite_id_seq'::regclass);


--
-- Name: tb_cor_complaint complaint_id; Type: DEFAULT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_complaint ALTER COLUMN complaint_id SET DEFAULT nextval('brunner_template.tb_cor_complaint_complaint_id_seq'::regclass);


--
-- Name: tb_cor_schedule schedule_id; Type: DEFAULT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_schedule ALTER COLUMN schedule_id SET DEFAULT nextval('brunner_template.tb_cor_schedule_schedule_id_seq'::regclass);


--
-- Name: tb_cor_schedule_participant participant_id; Type: DEFAULT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_schedule_participant ALTER COLUMN participant_id SET DEFAULT nextval('brunner_template.tb_cor_schedule_participant_participant_id_seq'::regclass);


--
-- Data for Name: tb_cor_chat_custom_emoji; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chat_custom_emoji (system_code, id, user_id, name, mime_type, file_data, created_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_chat_reaction; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chat_reaction (system_code, message_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_android_tester; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_android_tester (system_code, user_id, user_name, email, status, source, tester_link, group_email, group_result, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_chat_file; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chat_file (system_code, id, room_id, sender_id, file_name, mime_type, file_size, file_data, created_at, r2_key) FROM stdin;
\.


--
-- Data for Name: tb_cor_chat_msg; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chat_msg (system_code, msg_id, room_id, user_id, user_name, message, reply_to, created_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_chat_read_receipt; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chat_read_receipt (system_code, room_id, message_id, user_id, read_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_chatroom_invite; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chatroom_invite (invite_id, system_code, room_id, room_name, inviter_id, inviter_name, target_user_id, status, create_time) FROM stdin;
\.


--
-- Data for Name: tb_cor_chatroom_member_device_key; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chatroom_member_device_key (system_code, room_id, user_id, device_id, encrypted_key, key_provider_id, key_provider_device_id, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_chatroom_member_key; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chatroom_member_key (system_code, room_id, user_id, encrypted_key, key_provider_id) FROM stdin;
\.


--
-- Data for Name: tb_cor_chatroom_mst; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chatroom_mst (system_code, id, name, created_by, is_secret, room_type, created_at, category, owner_id, description, max_members) FROM stdin;
\.


--
-- Data for Name: tb_cor_chatroom_room_key; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chatroom_room_key (system_code, room_id, room_key_b64, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_chatroom_room_key_history; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chatroom_room_key_history (system_code, room_id, key_hash, room_key_b64, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_chatroom_users; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_chatroom_users (system_code, room_id, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_complaint; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_complaint (complaint_id, system_code, user_id, user_name, content, images, status, resolution, resolved_by, resolved_time, approve_time, created_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_friend_invite; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_friend_invite (invite_code, system_code, inviter_id, created_at, expire_at, used_at, invitee_id) FROM stdin;
\.


--
-- Data for Name: tb_cor_push_subscription; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_push_subscription (system_code, user_id, endpoint, p256dh, auth, created_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_schedule; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_schedule (schedule_id, system_code, user_id, title, description, start_time, end_time, is_all_day, color, reminder_minutes, notified_at, created_at, repeat_type, repeat_until, exceptions, schedule_type, repeat_lunar) FROM stdin;
\.


--
-- Data for Name: tb_cor_schedule_participant; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_schedule_participant (participant_id, schedule_id, system_code, user_id, status, created_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_sql_info; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_sql_info (system_code, sql_name, sql_seq, sql_content, create_user_id, create_time, update_user_id, update_time) FROM stdin;
00	select_TB_COR_EDOC_DOCUMENT	1	SELECT d.system_code, d.id, d.title, d.description, d.version, d.created_by, d.created_at, d.updated_at, d.updated_by, d.runtime_data, d.pages, d.menu_path FROM brunner_template.tb_cor_edoc_document d WHERE d.system_code = $1 AND d.id = $2	SYSTEM	2026-08-13 21:59:06.916756	\N	\N
00	select_TB_COR_EDOC_DOCUMENT	2	SELECT d.system_code, d.id, d.title, d.description, d.version, d.created_by, d.created_at, d.updated_at, d.updated_by, d.runtime_data, d.pages, d.menu_path FROM brunner_template.tb_cor_edoc_document d WHERE d.system_code = $1 AND d.created_by = $2 ORDER BY d.updated_at DESC, d.created_at DESC	SYSTEM	2026-08-13 21:59:06.916756	\N	\N
00	insert_TB_COR_EDOC_DOCUMENT	1	INSERT INTO brunner_template.TB_COR_EDOC_DOCUMENT (system_code, id, title, description, version, created_by, created_at, updated_by, updated_at, runtime_data, pages, menu_path) VALUES ($1, $2, $3, $4, $5, $6, NOW(), $6, NOW(), $7::jsonb, $8::jsonb, $9)	SYSTEM	2026-08-13 21:59:06.916756	\N	\N
00	update_TB_COR_EDOC_DOCUMENT	1	UPDATE brunner_template.TB_COR_EDOC_DOCUMENT SET title = $3, description = $4, updated_by = $5, updated_at = NOW(), version = COALESCE(version, 0) + 1, runtime_data = $6::jsonb, pages = $7::jsonb, menu_path = $8 WHERE system_code = $1 AND id = $2	SYSTEM	2026-08-13 21:59:06.916756	\N	\N
00	delete_TB_COR_EDOC_DOCUMENT	1	DELETE FROM brunner_template.TB_COR_EDOC_DOCUMENT WHERE system_code = $1 AND id = $2	SYSTEM	2026-08-13 21:59:06.916756	\N	\N
00	insert_TB_COR_COMPLAINT	1	INSERT INTO brunner_template.TB_COR_COMPLAINT (SYSTEM_CODE, USER_ID, USER_NAME, CONTENT, IMAGES) VALUES ($1, $2, $3, $4, $5) RETURNING COMPLAINT_ID, CREATED_AT	SYSTEM	2026-08-13 21:59:07.038743	\N	\N
00	select_TB_COR_USER_MST	4	SELECT user_id, user_name, address, phone_number, email_id, profile_image_base64, expire_time, register_no FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 LIMIT 1	claude	2026-08-13 21:59:07.019665	\N	\N
00	update_TB_COR_USER_MST	4	UPDATE brunner_template.TB_COR_USER_MST SET user_name = $3, address = $4, phone_number = $5, email_id = $6, profile_image_base64 = $7, register_no = COALESCE($8, register_no) WHERE system_code = $1 AND user_id = $2	claude	2026-08-13 21:59:07.019665	\N	\N
00	update_TB_COR_USER_MST	5	UPDATE brunner_template.TB_COR_USER_MST SET password = $3 WHERE system_code = $1 AND user_id = $2	claude	2026-08-13 21:59:07.019665	\N	\N
00	insert_TB_COR_USER_SESSION	1	INSERT INTO brunner_template.TB_COR_USER_SESSION (system_code, session_token, user_id) VALUES ($1, $2, $3)	claude	2026-08-13 21:59:07.020611	\N	\N
00	select_TB_COR_USER_SESSION	1	SELECT user_id FROM brunner_template.TB_COR_USER_SESSION WHERE system_code = $1 AND session_token = $2 AND user_id = $3 AND expires_at > NOW()	claude	2026-08-13 21:59:07.020611	\N	\N
00	delete_TB_COR_USER_SESSION	1	DELETE FROM brunner_template.TB_COR_USER_SESSION WHERE system_code = $1 AND session_token = $2	claude	2026-08-13 21:59:07.020611	\N	\N
00	delete_TB_COR_USER_SESSION_expired	1	DELETE FROM brunner_template.TB_COR_USER_SESSION WHERE system_code = $1 AND expires_at < NOW()	claude	2026-08-13 21:59:07.020611	\N	\N
00	select_TB_COR_USER_MST_BY_KAKAO	1	SELECT user_id, user_name, email_id, profile_image_base64, admin_flag, user_type, register_no, register_name FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND kakao_id = $2	claude	2026-08-13 21:59:07.021591	\N	\N
00	update_TB_COR_USER_MST_KAKAO_ID	1	UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = $3 WHERE system_code = $1 AND user_id = $2	claude	2026-08-13 21:59:07.021591	\N	\N
00	update_TB_COR_USER_MST_KAKAO_ID	2	UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = NULL WHERE system_code = $1 AND user_id = $2	codex	2026-08-13 21:59:07.021591	\N	\N
00	update_TB_COR_USER_MST_KAKAO_ID	3	WITH cleared AS (UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = NULL WHERE system_code = $1 AND user_id = $2 AND kakao_id = $4 RETURNING 1), linked AS (UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = $4 WHERE system_code = $1 AND user_id = $3 AND EXISTS (SELECT 1 FROM cleared) RETURNING user_id, user_name, email_id, profile_image_base64, admin_flag, user_type, register_no, register_name) SELECT user_id, user_name, email_id, profile_image_base64, admin_flag, user_type, register_no, register_name FROM linked	codex	2026-08-13 21:59:07.021591	\N	\N
00	select_TB_COR_EDOC_DOCUMENT	3	SELECT d.system_code, d.id, d.title, d.description, d."version", d.created_by, d.created_at, d.updated_at, d.updated_by, d.runtime_data, d.pages, d.menu_path FROM brunner_template.tb_cor_edoc_document d WHERE (d.runtime_data->>'isPublic')::boolean = true AND d.system_code = $1 ORDER BY d.updated_at DESC, d.created_at DESC	SYSTEM	2026-08-13 21:59:07.023698	\N	\N
00	insert_TB_COR_SCHEDULE	1	INSERT INTO brunner_template.TB_COR_SCHEDULE (SYSTEM_CODE, USER_ID, TITLE, DESCRIPTION, START_TIME, END_TIME, IS_ALL_DAY, COLOR, REMINDER_MINUTES, REPEAT_TYPE, REPEAT_UNTIL, SCHEDULE_TYPE) VALUES ($1, $2, $3, $4, $5::timestamp, $6::timestamp, $7, $8, $9, $10, $11::date, $12) RETURNING SCHEDULE_ID	claude	2026-08-13 21:59:07.037506	\N	\N
00	select_TB_COR_COMPLAINT	1	SELECT COMPLAINT_ID, USER_ID, USER_NAME, CONTENT, IMAGES, STATUS, RESOLUTION, RESOLVED_BY, RESOLVED_TIME, APPROVE_TIME, CREATED_AT FROM brunner_template.TB_COR_COMPLAINT WHERE SYSTEM_CODE = $1 AND USER_ID = $2 ORDER BY CREATED_AT DESC	SYSTEM	2026-08-13 21:59:07.038743	\N	\N
00	select_TB_COR_COMPLAINT	2	SELECT COMPLAINT_ID, USER_ID, USER_NAME, CONTENT, IMAGES, STATUS, RESOLUTION, RESOLVED_BY, RESOLVED_TIME, APPROVE_TIME, CREATED_AT FROM brunner_template.TB_COR_COMPLAINT WHERE SYSTEM_CODE = $1 ORDER BY CREATED_AT DESC	SYSTEM	2026-08-13 21:59:07.038743	\N	\N
00	update_TB_COR_USER_MST_KAKAO_ID	4	UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = $3 WHERE system_code = $1 AND user_id = $2 RETURNING user_id, user_name, email_id, profile_image_base64, admin_flag, user_type, register_no, register_name	codex	2026-08-13 21:59:07.021591	\N	\N
00	update_TB_COR_USER_MST_KAKAO_ID	5	UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = $3 WHERE system_code = $1 AND user_id = $2 AND kakao_id IS NULL RETURNING user_id, user_name, email_id, profile_image_base64, admin_flag, user_type, register_no, register_name	claude	2026-08-13 21:59:07.021591	\N	\N
00	insert_TB_COR_USER_MST_KAKAO	1	INSERT INTO brunner_template.TB_COR_USER_MST (system_code, user_id, password, user_name, address, phone_number, email_id, use_flag, register_no, user_type, register_name, expire_time, kakao_id) VALUES ($1, $2, $3, $4, $5, $6, $7, 'Y', $8, $9, $4, $10, $11) ON CONFLICT DO NOTHING	claude	2026-08-13 21:59:07.021591	\N	\N
00	insert_TB_COR_FRIEND_INVITE	1	INSERT INTO brunner_template.TB_COR_FRIEND_INVITE (invite_code, system_code, inviter_id) VALUES ($1, $2, $3)	claude	2026-08-13 21:59:07.021591	\N	\N
00	select_TB_COR_FRIEND_INVITE	1	SELECT fi.invite_code, fi.inviter_id, u.user_name as inviter_name, u.profile_image_base64 as inviter_image FROM brunner_template.TB_COR_FRIEND_INVITE fi JOIN brunner_template.TB_COR_USER_MST u ON fi.system_code = u.system_code AND fi.inviter_id = u.user_id WHERE fi.invite_code = $1 AND fi.system_code = $2 AND fi.expire_at > NOW() AND fi.used_at IS NULL	claude	2026-08-13 21:59:07.021591	\N	\N
00	select_TB_COR_USER_MST	6	SELECT user_id, user_name, email_id, profile_image_base64, admin_flag, user_type, register_no, register_name FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 LIMIT 1	codex	2026-08-13 21:59:07.021591	\N	\N
00	select_TB_COR_USER_MST	7	SELECT user_id, user_name, email_id, profile_image_base64, admin_flag, user_type, register_no, register_name FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND COALESCE(admin_flag, 'N') <> 'Y' AND LOWER(TRIM(email_id)) = LOWER(TRIM($2)) ORDER BY CASE WHEN user_id LIKE 'k%' THEN 1 ELSE 0 END, user_id LIMIT 1	codex	2026-08-13 21:59:07.021591	\N	\N
00	select_TB_COR_FRIEND_INVITE	2	SELECT fi.invite_code, fi.inviter_id, fi.invitee_id, fi.used_at, u.user_name as inviter_name, u.profile_image_base64 as inviter_image FROM brunner_template.TB_COR_FRIEND_INVITE fi JOIN brunner_template.TB_COR_USER_MST u ON fi.system_code = u.system_code AND fi.inviter_id = u.user_id WHERE fi.invite_code = $1 AND fi.system_code = $2 AND fi.expire_at > NOW() AND (fi.used_at IS NULL OR fi.invitee_id = $3)	codex	2026-08-13 21:59:07.021591	\N	\N
00	update_TB_COR_FRIEND_INVITE	1	UPDATE brunner_template.TB_COR_FRIEND_INVITE SET used_at = NOW(), invitee_id = $3 WHERE invite_code = $1 AND system_code = $2 AND used_at IS NULL	claude	2026-08-13 21:59:07.021591	\N	\N
00	select_TB_COR_FRIEND_INVITE_BY_INVITER	1	SELECT invite_code, invitee_id, used_at, expire_at, created_at FROM brunner_template.TB_COR_FRIEND_INVITE WHERE system_code = $1 AND inviter_id = $2 ORDER BY created_at DESC LIMIT 10	claude	2026-08-13 21:59:07.021591	\N	\N
00	upsert_TB_COR_USER_ACTIVITY_LOG	1	INSERT INTO brunner_template.TB_COR_USER_ACTIVITY_LOG (SYSTEM_CODE, ACTIVITY_DATE, USER_ID, ACTIVITY_TYPE, COMMAND_NAME, FIRST_SEEN_AT, LAST_SEEN_AT, HIT_COUNT) VALUES ($1, (NOW() AT TIME ZONE 'Asia/Seoul')::date, $2, $3, $4, NOW(), NOW(), 1) ON CONFLICT (SYSTEM_CODE, ACTIVITY_DATE, USER_ID, ACTIVITY_TYPE) DO UPDATE SET COMMAND_NAME = EXCLUDED.COMMAND_NAME, LAST_SEEN_AT = NOW(), HIT_COUNT = brunner_template.TB_COR_USER_ACTIVITY_LOG.HIT_COUNT + 1	codex	2026-08-13 21:59:07.022992	\N	\N
00	select_TB_COR_USER_ACTIVITY_DASHBOARD	1	WITH kst AS (SELECT (NOW() AT TIME ZONE 'Asia/Seoul')::date AS today), daily AS (SELECT ACTIVITY_DATE, COUNT(DISTINCT USER_ID)::int AS active_users, COALESCE(SUM(HIT_COUNT), 0)::int AS hits FROM brunner_template.TB_COR_USER_ACTIVITY_LOG, kst WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($2, '') IS NULL OR USER_ID <> ALL(string_to_array($2, ','))) AND ACTIVITY_DATE >= kst.today - INTERVAL '29 days' GROUP BY ACTIVITY_DATE), days AS (SELECT generate_series(kst.today - INTERVAL '29 days', kst.today, INTERVAL '1 day')::date AS activity_date FROM kst), by_type AS (SELECT ACTIVITY_TYPE, COUNT(DISTINCT USER_ID)::int AS active_users, COALESCE(SUM(HIT_COUNT), 0)::int AS hits FROM brunner_template.TB_COR_USER_ACTIVITY_LOG, kst WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($2, '') IS NULL OR USER_ID <> ALL(string_to_array($2, ','))) AND ACTIVITY_DATE >= kst.today - INTERVAL '29 days' GROUP BY ACTIVITY_TYPE ORDER BY active_users DESC, hits DESC), recent_users AS (SELECT USER_ID, MAX(LAST_SEEN_AT) AS last_seen_at, COUNT(DISTINCT ACTIVITY_DATE)::int AS active_days, COALESCE(SUM(HIT_COUNT), 0)::int AS hits FROM brunner_template.TB_COR_USER_ACTIVITY_LOG, kst WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($2, '') IS NULL OR USER_ID <> ALL(string_to_array($2, ','))) AND ACTIVITY_DATE >= kst.today - INTERVAL '29 days' GROUP BY USER_ID ORDER BY last_seen_at DESC LIMIT 20), top_commands AS (SELECT COALESCE(COMMAND_NAME, 'unknown') AS command_name, COUNT(DISTINCT USER_ID)::int AS active_users, COALESCE(SUM(HIT_COUNT), 0)::int AS hits FROM brunner_template.TB_COR_USER_ACTIVITY_LOG, kst WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($2, '') IS NULL OR USER_ID <> ALL(string_to_array($2, ','))) AND ACTIVITY_DATE >= kst.today - INTERVAL '6 days' GROUP BY COALESCE(COMMAND_NAME, 'unknown') ORDER BY hits DESC LIMIT 10) SELECT (SELECT COUNT(DISTINCT USER_ID)::int FROM brunner_template.TB_COR_USER_ACTIVITY_LOG, kst WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($2, '') IS NULL OR USER_ID <> ALL(string_to_array($2, ','))) AND ACTIVITY_DATE = kst.today) AS dau, (SELECT COUNT(DISTINCT USER_ID)::int FROM brunner_template.TB_COR_USER_ACTIVITY_LOG, kst WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($2, '') IS NULL OR USER_ID <> ALL(string_to_array($2, ','))) AND ACTIVITY_DATE >= kst.today - INTERVAL '6 days') AS wau, (SELECT COUNT(DISTINCT USER_ID)::int FROM brunner_template.TB_COR_USER_ACTIVITY_LOG, kst WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($2, '') IS NULL OR USER_ID <> ALL(string_to_array($2, ','))) AND ACTIVITY_DATE >= kst.today - INTERVAL '29 days') AS mau, (SELECT COALESCE(SUM(HIT_COUNT), 0)::int FROM brunner_template.TB_COR_USER_ACTIVITY_LOG, kst WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($2, '') IS NULL OR USER_ID <> ALL(string_to_array($2, ','))) AND ACTIVITY_DATE = kst.today) AS today_hits, (SELECT COALESCE(SUM(HIT_COUNT), 0)::int FROM brunner_template.TB_COR_USER_ACTIVITY_LOG, kst WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($2, '') IS NULL OR USER_ID <> ALL(string_to_array($2, ','))) AND ACTIVITY_DATE >= kst.today - INTERVAL '29 days') AS month_hits, (SELECT COALESCE(json_agg(json_build_object('activity_date', days.activity_date, 'active_users', COALESCE(daily.active_users, 0), 'hits', COALESCE(daily.hits, 0)) ORDER BY days.activity_date), '[]'::json) FROM days LEFT JOIN daily ON daily.activity_date = days.activity_date) AS daily_active, (SELECT COALESCE(json_agg(json_build_object('activity_type', ACTIVITY_TYPE, 'active_users', active_users, 'hits', hits)), '[]'::json) FROM by_type) AS activity_by_type, (SELECT COALESCE(json_agg(json_build_object('user_id', ru.USER_ID, 'user_name', COALESCE(NULLIF(TRIM(u.USER_NAME), ''), ru.USER_ID), 'is_registered', (u.USER_ID IS NOT NULL), 'last_seen_at', ru.last_seen_at, 'active_days', ru.active_days, 'hits', ru.hits) ORDER BY ru.last_seen_at DESC), '[]'::json) FROM recent_users ru LEFT JOIN brunner_template.TB_COR_USER_MST u ON u.SYSTEM_CODE = $1 AND u.USER_ID = ru.USER_ID) AS recent_users, (SELECT COALESCE(json_agg(json_build_object('command_name', command_name, 'active_users', active_users, 'hits', hits)), '[]'::json) FROM top_commands) AS top_commands	codex	2026-08-13 21:59:07.022992	\N	\N
00	select_TB_COR_USER_ACTIVITY_USER_LIST	1	WITH base AS (SELECT USER_ID, ACTIVITY_TYPE, COALESCE(SUM(HIT_COUNT), 0)::int AS hits, COUNT(DISTINCT ACTIVITY_DATE)::int AS active_days, MAX(LAST_SEEN_AT) AS last_seen_at FROM brunner_template.TB_COR_USER_ACTIVITY_LOG WHERE SYSTEM_CODE = $1 AND USER_ID <> 'system' AND ACTIVITY_TYPE <> 'admin' AND USER_ID NOT LIKE '\\_\\_%\\_\\_' ESCAPE '\\' AND (NULLIF($3, '') IS NULL OR USER_ID <> ALL(string_to_array($3, ','))) AND ACTIVITY_DATE >= (NOW() AT TIME ZONE 'Asia/Seoul')::date - ($2::int * '1 day'::interval) GROUP BY USER_ID, ACTIVITY_TYPE) SELECT b.USER_ID, COALESCE(NULLIF(TRIM(u.USER_NAME), ''), b.USER_ID) AS user_name, bool_or(u.USER_ID IS NOT NULL) AS is_registered, COALESCE(SUM(b.hits), 0)::int AS total_hits, MAX(b.active_days) AS active_days, MAX(b.last_seen_at) AS last_seen_at, json_agg(json_build_object('activity_type', b.ACTIVITY_TYPE, 'hits', b.hits) ORDER BY b.hits DESC) AS features FROM base b LEFT JOIN brunner_template.TB_COR_USER_MST u ON u.SYSTEM_CODE = $1 AND u.USER_ID = b.USER_ID GROUP BY b.USER_ID, u.USER_NAME ORDER BY last_seen_at DESC NULLS LAST, total_hits DESC	claude	2026-08-13 21:59:07.022992	\N	\N
00	select_TB_COR_OPENCHAT_LIST	1	SELECT r.id, r.name, r.category, r.owner_id, COALESCE(r.description, '') AS description, COALESCE(r.max_members, 100) AS max_members, (SELECT COUNT(*) FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id) AS member_count, (SELECT MAX(m.created_at) FROM brunner_template.TB_COR_CHAT_MSG m WHERE m.system_code = $1 AND m.room_id = r.id) AS last_message_at FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND r.room_type = 'OPEN' AND ($2 = 'ALL' OR r.category = $2) ORDER BY member_count DESC, last_message_at DESC NULLS LAST	claude	2026-08-13 21:59:07.024307	\N	\N
00	select_TB_COR_OPENCHAT_LIST	2	SELECT r.id, r.name, r.category, r.owner_id, COALESCE(r.description, '') AS description, COALESCE(r.max_members, 100) AS max_members, r.room_type, (SELECT COUNT(*) FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id) AS member_count FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND r.id = $2	claude	2026-08-13 21:59:07.024307	\N	\N
00	insert_TB_COR_OPENCHAT_MST	1	INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type, category, owner_id, description, max_members) VALUES ($1, $2, $3, $4::varchar, FALSE, 'OPEN', $5, $4::varchar, $6, $7) ON CONFLICT DO NOTHING	claude	2026-08-13 21:59:07.024307	\N	\N
00	update_TB_COR_OPENCHAT_OWNER	1	UPDATE brunner_template.TB_COR_CHATROOM_MST SET owner_id = $3 WHERE system_code = $1 AND id = $2	claude	2026-08-13 21:59:07.024307	\N	\N
00	insert_TB_COR_CHATROOM_MST	1	INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type) VALUES ($1, $2, $3, $4, FALSE, 'GROUP') ON CONFLICT DO NOTHING	codex	2026-08-13 21:59:07.024995	\N	\N
00	insert_TB_COR_CHATROOM_MST	3	INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type) VALUES ($1, $2, $3, $4, FALSE, 'DIRECT') ON CONFLICT DO NOTHING	codex	2026-08-13 21:59:07.024995	\N	\N
00	insert_TB_COR_CHATROOM_MST	4	INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type) VALUES ($1, $2, $3, $4, TRUE, 'DIRECT') ON CONFLICT DO NOTHING	codex	2026-08-13 21:59:07.024995	\N	\N
00	insert_TB_COR_CHATROOM_INVITE	1	INSERT INTO brunner_template.TB_COR_CHATROOM_INVITE (SYSTEM_CODE, ROOM_ID, ROOM_NAME, INVITER_ID, INVITER_NAME, TARGET_USER_ID) VALUES ($1, $2::uuid, $3, $4, $5, $6) ON CONFLICT (SYSTEM_CODE, ROOM_ID, TARGET_USER_ID) WHERE STATUS = 'PENDING' DO UPDATE SET ROOM_NAME = EXCLUDED.ROOM_NAME, INVITER_ID = EXCLUDED.INVITER_ID, INVITER_NAME = EXCLUDED.INVITER_NAME, CREATE_TIME = NOW() RETURNING INVITE_ID	claude	2026-08-13 21:59:07.025697	\N	\N
00	select_TB_COR_CHATROOM_INVITE	1	SELECT i.INVITE_ID, i.ROOM_ID, i.ROOM_NAME, i.INVITER_ID, i.INVITER_NAME, i.CREATE_TIME FROM brunner_template.TB_COR_CHATROOM_INVITE i WHERE i.SYSTEM_CODE = $1 AND i.TARGET_USER_ID = $2 AND i.STATUS = 'PENDING' AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_MST m WHERE m.id = i.ROOM_ID) ORDER BY i.CREATE_TIME ASC	claude	2026-08-13 21:59:07.025697	\N	\N
00	update_TB_COR_CHATROOM_INVITE	1	UPDATE brunner_template.TB_COR_CHATROOM_INVITE SET STATUS = $1 WHERE SYSTEM_CODE = $2 AND INVITE_ID = $3 AND TARGET_USER_ID = $4 RETURNING SYSTEM_CODE, ROOM_ID, ROOM_NAME, INVITER_ID	claude	2026-08-13 21:59:07.025697	\N	\N
00	delete_TB_COR_CHATROOM_INVITE	1	DELETE FROM brunner_template.TB_COR_CHATROOM_INVITE WHERE SYSTEM_CODE = $1 AND ROOM_ID = $2::uuid AND TARGET_USER_ID = $3	claude	2026-08-13 21:59:07.025697	\N	\N
00	select_TB_COR_DIRECT_CHAT_PARTICIPANT	1	SELECT DISTINCT p.user_id FROM (SELECT created_by AS user_id FROM brunner_template.TB_COR_CHATROOM_MST WHERE system_code = $1 AND id = $2 UNION SELECT user_id FROM brunner_template.TB_COR_CHATROOM_USERS WHERE system_code = $1 AND room_id = $2 UNION SELECT user_id FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND room_id = $2 AND user_id IS NOT NULL) p WHERE p.user_id IS NOT NULL AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND r.id = $2 AND COALESCE(r.room_type, 'GROUP') = 'DIRECT')	SYSTEM	2026-08-13 21:59:07.026545	\N	\N
00	insert_TB_COR_CHAT_FILE	1	INSERT INTO brunner_template.TB_COR_CHAT_FILE (system_code, id, room_id, sender_id, file_name, mime_type, file_size, file_data) VALUES ($1, $2::uuid, $3::uuid, $4, $5, $6, $7, $8)	claude	2026-08-13 21:59:07.027198	\N	\N
00	select_TB_COR_CHAT_FILE	1	SELECT mime_type, file_size, file_name, file_data FROM brunner_template.TB_COR_CHAT_FILE WHERE system_code = $1 AND id = $2::uuid	claude	2026-08-13 21:59:07.027198	\N	\N
00	insert_TB_COR_CHAT_FILE	2	INSERT INTO brunner_template.TB_COR_CHAT_FILE (system_code, id, room_id, sender_id, file_name, mime_type, file_size, r2_key) VALUES ($1, $2::uuid, $3::uuid, $4, $5, $6, $7, $8)	claude	2026-08-13 21:59:07.027816	\N	\N
00	select_TB_COR_CHAT_FILE	2	SELECT mime_type, file_size, file_name, file_data, r2_key FROM brunner_template.TB_COR_CHAT_FILE WHERE system_code = $1 AND id = $2::uuid	claude	2026-08-13 21:59:07.027816	\N	\N
00	upsert_TB_COR_CHAT_REACTION	1	INSERT INTO brunner_template.TB_COR_CHAT_REACTION (SYSTEM_CODE, MESSAGE_ID, USER_ID, EMOJI) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING	claude	2026-08-13 21:59:07.028871	\N	\N
00	delete_TB_COR_CHAT_REACTION	1	DELETE FROM brunner_template.TB_COR_CHAT_REACTION WHERE SYSTEM_CODE = $1 AND MESSAGE_ID = $2 AND USER_ID = $3 AND EMOJI = $4	claude	2026-08-13 21:59:07.028871	\N	\N
00	select_TB_COR_CHAT_REACTION_BY_MESSAGES	1	SELECT r.message_id, r.user_id, r.emoji FROM brunner_template.TB_COR_CHAT_REACTION r INNER JOIN brunner_template.TB_COR_CHAT_MSG m ON m.system_code = r.system_code AND m.msg_id = r.message_id AND m.room_id = $3::uuid WHERE r.system_code = $1 AND r.message_id = ANY($2::bigint[])	claude	2026-08-13 21:59:07.028871	\N	\N
00	select_TB_COR_CHAT_MSG_SEARCH	1	SELECT msg_id AS id, user_id, user_name, message, created_at FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND room_id = $2::uuid AND message IS NOT NULL ORDER BY msg_id DESC LIMIT 1000	claude	2026-08-13 21:59:07.028871	\N	\N
00	select_TB_COR_CHATROOM_MEMBERSHIP	1	SELECT 1 FROM brunner_template.TB_COR_CHATROOM_USERS WHERE SYSTEM_CODE=$1 AND ROOM_ID=$2::uuid AND USER_ID=$3 LIMIT 1	claude	2026-08-13 21:59:07.028871	\N	\N
00	select_TB_COR_CHAT_MSG_BY_ROOM	1	SELECT 1 FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code=$1 AND room_id=$2::uuid AND msg_id=$3 LIMIT 1	claude	2026-08-13 21:59:07.028871	\N	\N
00	insert_TB_COR_CHAT_CUSTOM_EMOJI	1	INSERT INTO brunner_template.TB_COR_CHAT_CUSTOM_EMOJI (system_code, user_id, name, mime_type, file_data) VALUES ($1, $2, $3, $4, $5) RETURNING id	claude	2026-08-13 21:59:07.029816	\N	\N
00	select_TB_COR_CHAT_CUSTOM_EMOJI_LIST	1	SELECT id, name, mime_type, created_at FROM brunner_template.TB_COR_CHAT_CUSTOM_EMOJI WHERE system_code = $1 AND user_id = $2 ORDER BY created_at DESC	claude	2026-08-13 21:59:07.029816	\N	\N
00	select_TB_COR_CHAT_CUSTOM_EMOJI	1	SELECT user_id, mime_type, file_data FROM brunner_template.TB_COR_CHAT_CUSTOM_EMOJI WHERE system_code = $1 AND id = $2::uuid	claude	2026-08-13 21:59:07.029816	\N	\N
00	delete_TB_COR_CHAT_CUSTOM_EMOJI	1	DELETE FROM brunner_template.TB_COR_CHAT_CUSTOM_EMOJI WHERE system_code = $1 AND id = $2::uuid AND user_id = $3	claude	2026-08-13 21:59:07.029816	\N	\N
00	update_TB_COR_CHAT_MSG	1	UPDATE brunner_template.TB_COR_CHAT_MSG SET message = $1 WHERE system_code = $2 AND room_id = $3 AND msg_id = $4 AND user_id = $5	SYSTEM	2026-08-13 21:59:07.030431	\N	\N
00	delete_TB_COR_CHAT_MSG	2	UPDATE brunner_template.TB_COR_CHAT_MSG SET message = NULL WHERE system_code = $1 AND room_id = $2 AND msg_id = $3 AND user_id = $4	SYSTEM	2026-08-13 21:59:07.030431	\N	\N
00	select_TB_COR_CHAT_MSG_BY_ID	1	SELECT msg_id AS id, message FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND msg_id = $2	SYSTEM	2026-08-13 21:59:07.030431	\N	\N
00	select_TB_COR_CHAT_UNREAD_COUNT_BY_USER	1	SELECT u.room_id, COUNT(msg.msg_id)::integer AS unread_count FROM brunner_template.TB_COR_CHATROOM_USERS u INNER JOIN brunner_template.TB_COR_CHAT_MSG msg ON msg.system_code = $1 AND msg.room_id = u.room_id AND msg.user_id != $2 AND msg.message IS NOT NULL LEFT JOIN brunner_template.TB_COR_CHAT_READ_RECEIPT rr ON rr.system_code = $1 AND rr.room_id = u.room_id AND rr.message_id = msg.msg_id AND rr.user_id = $2 WHERE u.system_code = $1 AND u.user_id = $2 AND rr.message_id IS NULL GROUP BY u.room_id	SYSTEM	2026-08-13 21:59:07.031254	\N	\N
00	insert_TB_COR_CHAT_READ_RECEIPT_ALL	1	INSERT INTO brunner_template.TB_COR_CHAT_READ_RECEIPT (system_code, room_id, message_id, user_id) SELECT msg.system_code, msg.room_id, msg.msg_id, $3 FROM brunner_template.TB_COR_CHAT_MSG msg LEFT JOIN brunner_template.TB_COR_CHAT_READ_RECEIPT rr ON rr.system_code = msg.system_code AND rr.room_id = msg.room_id AND rr.message_id = msg.msg_id AND rr.user_id = $3 WHERE msg.room_id = $2::uuid AND msg.system_code = $1 AND msg.user_id != $3 AND msg.message IS NOT NULL AND rr.message_id IS NULL ON CONFLICT DO NOTHING	SYSTEM	2026-08-13 21:59:07.031856	\N	\N
00	select_TB_COR_CHATROOM_USERS	3	SELECT r.id AS room_id, r.name AS room_name FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND COALESCE(r.is_secret, FALSE) = FALSE AND COALESCE(r.room_type, 'GROUP') = 'DIRECT' AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2) AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id AND u.user_id = $3) ORDER BY r.id LIMIT 1	claude	2026-08-13 21:59:07.032567	\N	\N
00	select_TB_COR_CHATROOM_MST	2	SELECT r.id, COALESCE(r.is_secret, FALSE) AS is_secret FROM brunner_template.TB_COR_CHATROOM_MST r INNER JOIN brunner_template.TB_COR_CHATROOM_USERS u ON u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2 WHERE r.system_code = $1	claude	2026-08-13 21:59:07.032567	\N	\N
00	upsert_TB_COR_USER_MST_pubkey	1	UPDATE brunner_template.TB_COR_USER_MST SET public_key = $1 WHERE system_code = $2 AND user_id = $3	claude	2026-08-13 21:59:07.032567	\N	\N
00	select_TB_COR_USER_MST_pubkey	1	SELECT public_key FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 LIMIT 1	claude	2026-08-13 21:59:07.032567	\N	\N
00	select_TB_COR_CHATROOM_USERS	4	SELECT r.id AS room_id, r.name AS room_name FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND COALESCE(r.is_secret, FALSE) = TRUE AND COALESCE(r.room_type, 'GROUP') = 'DIRECT' AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2) AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id AND u.user_id = $3) ORDER BY r.id LIMIT 1	claude	2026-08-13 21:59:07.032567	\N	\N
00	insert_TB_COR_CHATROOM_MST	2	INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type) VALUES ($1, $2, $3, $4, TRUE, 'GROUP') ON CONFLICT DO NOTHING	codex	2026-08-13 21:59:07.032567	\N	\N
00	upsert_TB_COR_CHATROOM_MEMBER_KEY	1	INSERT INTO brunner_template.TB_COR_CHATROOM_MEMBER_KEY (system_code, room_id, user_id, encrypted_key, key_provider_id) VALUES ($1, $2::uuid, $3, $4, $5) ON CONFLICT (system_code, room_id, user_id) DO UPDATE SET encrypted_key = EXCLUDED.encrypted_key, key_provider_id = EXCLUDED.key_provider_id	claude	2026-08-13 21:59:07.032567	\N	\N
00	select_TB_COR_CHATROOM_MEMBER_KEY	1	SELECT encrypted_key, key_provider_id FROM brunner_template.TB_COR_CHATROOM_MEMBER_KEY WHERE system_code = $1 AND room_id = $2::uuid AND user_id = $3 LIMIT 1	claude	2026-08-13 21:59:07.032567	\N	\N
00	upsert_TB_COR_USER_E2EE_DEVICE_KEY	1	INSERT INTO brunner_template.TB_COR_USER_E2EE_DEVICE_KEY (system_code, user_id, device_id, public_key, updated_at) VALUES ($1, $2, $3, $4, NOW()) ON CONFLICT (system_code, user_id, device_id) DO UPDATE SET public_key = EXCLUDED.public_key, updated_at = NOW()	codex	2026-08-13 21:59:07.032567	\N	\N
00	select_TB_COR_USER_E2EE_DEVICE_KEY	1	SELECT device_id, public_key FROM brunner_template.TB_COR_USER_E2EE_DEVICE_KEY WHERE system_code = $1 AND user_id = $2 AND ($3::varchar IS NULL OR device_id = $3) ORDER BY updated_at DESC	codex	2026-08-13 21:59:07.032567	\N	\N
00	upsert_TB_COR_CHATROOM_MEMBER_DEVICE_KEY	1	INSERT INTO brunner_template.TB_COR_CHATROOM_MEMBER_DEVICE_KEY (system_code, room_id, user_id, device_id, encrypted_key, key_provider_id, key_provider_device_id, updated_at) VALUES ($1, $2::uuid, $3, $4, $5, $6, $7, NOW()) ON CONFLICT (system_code, room_id, user_id, device_id) DO UPDATE SET encrypted_key = EXCLUDED.encrypted_key, key_provider_id = EXCLUDED.key_provider_id, key_provider_device_id = EXCLUDED.key_provider_device_id, updated_at = NOW()	codex	2026-08-13 21:59:07.032567	\N	\N
00	select_TB_COR_CHATROOM_MEMBER_DEVICE_KEY	1	SELECT encrypted_key, key_provider_id, key_provider_device_id FROM brunner_template.TB_COR_CHATROOM_MEMBER_DEVICE_KEY WHERE system_code = $1 AND room_id = $2::uuid AND user_id = $3 AND device_id = $4 LIMIT 1	codex	2026-08-13 21:59:07.032567	\N	\N
00	upsert_TB_COR_CHATROOM_ROOM_KEY	1	INSERT INTO brunner_template.TB_COR_CHATROOM_ROOM_KEY (system_code, room_id, room_key_b64, updated_at) VALUES ($1, $2::uuid, $3, NOW()) ON CONFLICT (system_code, room_id) DO UPDATE SET room_key_b64 = EXCLUDED.room_key_b64, updated_at = NOW()	claude	2026-08-13 21:59:07.032567	\N	\N
00	select_TB_COR_CHATROOM_ROOM_KEY	1	SELECT r.room_key_b64 FROM brunner_template.TB_COR_CHATROOM_ROOM_KEY r JOIN brunner_template.TB_COR_CHATROOM_USERS u ON r.system_code = u.system_code AND r.room_id = u.room_id WHERE r.system_code = $1 AND r.room_id = $2::uuid AND u.user_id = $3 LIMIT 1	claude	2026-08-13 21:59:07.032567	\N	\N
00	upsert_TB_COR_CHATROOM_ROOM_KEY_HISTORY	1	INSERT INTO brunner_template.TB_COR_CHATROOM_ROOM_KEY_HISTORY (system_code, room_id, key_hash, room_key_b64, updated_at) VALUES ($1, $2::uuid, md5($3), $3, NOW()) ON CONFLICT (system_code, room_id, key_hash) DO UPDATE SET updated_at = NOW()	codex	2026-08-13 21:59:07.032567	\N	\N
00	select_TB_COR_CHATROOM_ROOM_KEY_HISTORY	1	SELECT h.room_key_b64 FROM brunner_template.TB_COR_CHATROOM_ROOM_KEY_HISTORY h JOIN brunner_template.TB_COR_CHATROOM_USERS u ON h.system_code = u.system_code AND h.room_id = u.room_id WHERE h.system_code = $1 AND h.room_id = $2::uuid AND u.user_id = $3 ORDER BY h.updated_at DESC	codex	2026-08-13 21:59:07.032567	\N	\N
00	insert_TB_COR_PUSH_SUBSCRIPTION	1	WITH updated AS (UPDATE brunner_template.TB_COR_PUSH_SUBSCRIPTION SET system_code = $1, p256dh = $4, auth = $5, created_at = NOW() WHERE user_id = $2 AND endpoint = $3 RETURNING 1) INSERT INTO brunner_template.TB_COR_PUSH_SUBSCRIPTION (system_code, user_id, endpoint, p256dh, auth) SELECT $1, $2, $3, $4, $5 WHERE NOT EXISTS (SELECT 1 FROM updated)	codex	2026-08-13 21:59:07.033577	\N	\N
00	select_TB_COR_PUSH_SUBSCRIPTION	1	SELECT user_id, endpoint, p256dh, auth FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE system_code = $1 AND user_id = ANY($2::text[])	codex	2026-08-13 21:59:07.033577	\N	\N
00	select_TB_COR_PUSH_SUBSCRIPTION	2	SELECT user_id FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE endpoint = $1 LIMIT 1	claude	2026-08-13 21:59:07.033577	\N	\N
00	delete_TB_COR_PUSH_SUBSCRIPTION	3	DELETE FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE system_code = $1 AND user_id = $2 AND endpoint NOT IN (SELECT endpoint FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE system_code = $1 AND user_id = $2 ORDER BY created_at DESC LIMIT 5)	claude	2026-08-13 21:59:07.033577	\N	\N
00	select_TB_COR_PUSH_SUBSCRIPTION	3	SELECT endpoint, created_at FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE system_code = $1 AND user_id = $2 ORDER BY created_at DESC	claude	2026-08-13 21:59:07.033577	\N	\N
00	select_TB_COR_ADMIN_PUSH_SUBSCRIPTION	1	SELECT ps.endpoint, ps.p256dh, ps.auth FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION ps JOIN brunner_template.TB_COR_USER_MST u ON u.system_code = ps.system_code AND u.user_id = ps.user_id WHERE ps.system_code = $1 AND (u.admin_flag = true OR u.admin_flag::text = 'Y')	codex	2026-08-13 21:59:07.033577	\N	\N
00	delete_TB_COR_PUSH_SUBSCRIPTION	1	DELETE FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE user_id = $1 AND endpoint = $2	codex	2026-08-13 21:59:07.033577	\N	\N
00	delete_TB_COR_PUSH_SUBSCRIPTION	2	DELETE FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE endpoint = $1	codex	2026-08-13 21:59:07.033577	\N	\N
00	select_TB_COR_SCHEDULE	1	SELECT DISTINCT s.SCHEDULE_ID, s.USER_ID, s.TITLE, s.DESCRIPTION, s.START_TIME, s.END_TIME, s.IS_ALL_DAY, s.COLOR, s.REMINDER_MINUTES, s.REPEAT_TYPE, s.REPEAT_UNTIL, s.EXCEPTIONS, s.SCHEDULE_TYPE FROM brunner_template.TB_COR_SCHEDULE s LEFT JOIN brunner_template.TB_COR_SCHEDULE_PARTICIPANT p ON p.SCHEDULE_ID = s.SCHEDULE_ID WHERE s.SYSTEM_CODE = $1 AND (s.USER_ID = $2 OR p.USER_ID = $2) AND (s.REPEAT_TYPE IS NOT NULL OR (s.START_TIME < ($4::timestamp) AND s.END_TIME >= ($3::timestamp))) ORDER BY s.START_TIME	claude	2026-08-13 21:59:07.037506	\N	\N
00	select_TB_COR_SCHEDULE	2	SELECT SCHEDULE_ID, USER_ID, TITLE, DESCRIPTION, START_TIME, END_TIME, IS_ALL_DAY, COLOR, REMINDER_MINUTES, REPEAT_TYPE, REPEAT_UNTIL, EXCEPTIONS, SCHEDULE_TYPE FROM brunner_template.TB_COR_SCHEDULE WHERE SYSTEM_CODE = $1 AND SCHEDULE_ID = $2	claude	2026-08-13 21:59:07.037506	\N	\N
00	update_TB_COR_SCHEDULE_EXCEPTION	1	UPDATE brunner_template.TB_COR_SCHEDULE SET EXCEPTIONS = $3 WHERE SYSTEM_CODE = $1 AND SCHEDULE_ID = $2 AND USER_ID = $4	claude	2026-08-13 21:59:07.037506	\N	\N
00	update_TB_COR_SCHEDULE	1	UPDATE brunner_template.TB_COR_SCHEDULE SET TITLE=$3, DESCRIPTION=$4, START_TIME=$5::timestamp, END_TIME=$6::timestamp, IS_ALL_DAY=$7, COLOR=$8, REMINDER_MINUTES=$9, REPEAT_TYPE=$10, REPEAT_UNTIL=$11::date, SCHEDULE_TYPE=$12, NOTIFIED_AT=NULL WHERE SYSTEM_CODE=$1 AND SCHEDULE_ID=$2 AND USER_ID=$13	claude	2026-08-13 21:59:07.037506	\N	\N
00	delete_TB_COR_SCHEDULE_PARTICIPANT	1	DELETE FROM brunner_template.TB_COR_SCHEDULE_PARTICIPANT WHERE SCHEDULE_ID=$1	claude	2026-08-13 21:59:07.037506	\N	\N
00	delete_TB_COR_SCHEDULE	1	DELETE FROM brunner_template.TB_COR_SCHEDULE WHERE SYSTEM_CODE = $1 AND SCHEDULE_ID = $2 AND USER_ID = $3	claude	2026-08-13 21:59:07.037506	\N	\N
00	insert_TB_COR_SCHEDULE_PARTICIPANT	1	INSERT INTO brunner_template.TB_COR_SCHEDULE_PARTICIPANT (SCHEDULE_ID, SYSTEM_CODE, USER_ID) VALUES ($1, $2, $3) ON CONFLICT (SCHEDULE_ID, USER_ID) DO NOTHING	claude	2026-08-13 21:59:07.037506	\N	\N
00	select_TB_COR_SCHEDULE_PARTICIPANT	1	SELECT p.USER_ID, u.USER_NAME FROM brunner_template.TB_COR_SCHEDULE_PARTICIPANT p LEFT JOIN brunner_template.TB_COR_USER_MST u ON u.SYSTEM_CODE = p.SYSTEM_CODE AND u.USER_ID = p.USER_ID WHERE p.SYSTEM_CODE = $1 AND p.SCHEDULE_ID = $2	claude	2026-08-13 21:59:07.037506	\N	\N
00	select_TB_COR_SCHEDULE_REMINDER	1	SELECT s.SCHEDULE_ID, s.SYSTEM_CODE, s.USER_ID, s.TITLE, s.START_TIME, s.REMINDER_MINUTES, s.SCHEDULE_TYPE, ARRAY(SELECT p.USER_ID FROM brunner_template.TB_COR_SCHEDULE_PARTICIPANT p WHERE p.SYSTEM_CODE = s.SYSTEM_CODE AND p.SCHEDULE_ID = s.SCHEDULE_ID) AS participant_ids FROM brunner_template.TB_COR_SCHEDULE s WHERE s.SYSTEM_CODE = $1 AND s.REMINDER_MINUTES IS NOT NULL AND s.NOTIFIED_AT IS NULL AND s.START_TIME > NOW() AND s.START_TIME <= NOW() + make_interval(mins => s.REMINDER_MINUTES)	claude	2026-08-13 21:59:07.037506	\N	\N
00	update_TB_COR_SCHEDULE_NOTIFIED	1	UPDATE brunner_template.TB_COR_SCHEDULE SET NOTIFIED_AT = NOW() WHERE SYSTEM_CODE = $1 AND SCHEDULE_ID = $2	claude	2026-08-13 21:59:07.037506	\N	\N
00	update_TB_COR_COMPLAINT	1	UPDATE brunner_template.TB_COR_COMPLAINT SET STATUS = $1::text, RESOLUTION = COALESCE($2, RESOLUTION), RESOLVED_BY = $3, RESOLVED_TIME = CASE WHEN $1::text = 'RESOLVED' THEN NOW() ELSE RESOLVED_TIME END WHERE SYSTEM_CODE = $4 AND COMPLAINT_ID = $5 AND STATUS <> 'APPROVED' RETURNING COMPLAINT_ID, STATUS, USER_ID	claude	2026-08-13 21:59:07.038743	\N	\N
00	update_TB_COR_COMPLAINT	2	UPDATE brunner_template.TB_COR_COMPLAINT SET STATUS = 'APPROVED', APPROVE_TIME = NOW() WHERE SYSTEM_CODE = $1 AND COMPLAINT_ID = $2 AND USER_ID = $3 AND STATUS = 'RESOLVED' RETURNING COMPLAINT_ID	claude	2026-08-13 21:59:07.038743	\N	\N
00	select_TB_COR_CREDIT_MST	1	SELECT SYSTEM_CODE, USER_ID, BALANCE, UPDATED_AT FROM brunner_template.TB_COR_CREDIT_MST WHERE SYSTEM_CODE = $1 AND USER_ID = $2	claude	2026-08-13 21:59:07.039572	\N	\N
00	update_TB_COR_CREDIT_MST	1	INSERT INTO brunner_template.TB_COR_CREDIT_MST (SYSTEM_CODE, USER_ID, BALANCE, UPDATED_AT) VALUES ($1,$2,$3,NOW()) ON CONFLICT (SYSTEM_CODE, USER_ID) DO UPDATE SET BALANCE = TB_COR_CREDIT_MST.BALANCE + $3, UPDATED_AT = NOW() RETURNING BALANCE	claude	2026-08-13 21:59:07.039572	\N	\N
00	update_TB_COR_CREDIT_MST	2	UPDATE brunner_template.TB_COR_CREDIT_MST SET BALANCE = BALANCE - $3, UPDATED_AT = NOW() WHERE SYSTEM_CODE = $1 AND USER_ID = $2 AND BALANCE >= $3 RETURNING BALANCE	claude	2026-08-13 21:59:07.039572	\N	\N
00	insert_TB_COR_CREDIT_LEDGER	1	INSERT INTO brunner_template.TB_COR_CREDIT_LEDGER (SYSTEM_CODE, LEDGER_ID, USER_ID, DELTA, BALANCE_AFTER, REASON, REF) VALUES ($1,$2,$3,$4,$5,$6,$7)	claude	2026-08-13 21:59:07.039572	\N	\N
00	select_TB_COR_CREDIT_LEDGER	1	SELECT LEDGER_ID, DELTA, BALANCE_AFTER, REASON, REF, CREATED_AT FROM brunner_template.TB_COR_CREDIT_LEDGER WHERE SYSTEM_CODE = $1 AND USER_ID = $2 ORDER BY CREATED_AT DESC LIMIT 100	claude	2026-08-13 21:59:07.039572	\N	\N
00	select_TB_COR_CREDIT_LEDGER	2	SELECT LEDGER_ID FROM brunner_template.TB_COR_CREDIT_LEDGER WHERE SYSTEM_CODE = $1 AND REF = $2 AND REASON = $3 LIMIT 1	claude	2026-08-13 21:59:07.039572	\N	\N
00	select_TB_COR_CREDIT_MST_LIST	1	SELECT c.USER_ID AS user_id, c.BALANCE AS balance, c.UPDATED_AT AS updated_at, COALESCE(l.earned, 0) AS earned, COALESCE(l.spent, 0) AS spent FROM brunner_template.TB_COR_CREDIT_MST c LEFT JOIN (SELECT USER_ID, SUM(CASE WHEN DELTA > 0 THEN DELTA ELSE 0 END) AS earned, SUM(CASE WHEN DELTA < 0 THEN -DELTA ELSE 0 END) AS spent FROM brunner_template.TB_COR_CREDIT_LEDGER WHERE SYSTEM_CODE = $1 GROUP BY USER_ID) l ON l.USER_ID = c.USER_ID WHERE c.SYSTEM_CODE = $1 ORDER BY c.BALANCE DESC, c.UPDATED_AT DESC	claude	2026-08-13 21:59:07.039572	\N	\N
00	select_TB_COR_TXN_HIST	1	SELECT transaction_id, request_ip, request_message_content, reply_message_content, create_time FROM brunner_template.TB_COR_TXN_HIST WHERE system_code = $1 AND (coalesce(length($2::text), 0) = 0 OR CAST(request_message_content AS TEXT) ILIKE CONCAT('%', $2, '%') OR CAST(reply_message_content AS TEXT) ILIKE CONCAT('%', $2, '%') OR CAST(transaction_id AS TEXT) ILIKE CONCAT('%', $2, '%') OR request_ip ILIKE CONCAT('%', $2, '%')) ORDER BY create_time DESC LIMIT 500	claude	2026-08-13 21:59:07.040739	\N	\N
00	insert_TB_COR_TXN_HIST	1	INSERT INTO brunner_template.TB_COR_TXN_HIST (SYSTEM_CODE, TRANSACTION_ID, REQUEST_IP, REQUEST_MESSAGE_CONTENT, REPLY_MESSAGE_CONTENT) VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING	claude	2026-08-13 21:59:07.040739	\N	\N
00	upsert_TB_COR_ANDROID_TESTER	1	INSERT INTO brunner_template.TB_COR_ANDROID_TESTER (SYSTEM_CODE, USER_ID, USER_NAME, EMAIL, SOURCE, TESTER_LINK, USER_AGENT) VALUES ($1, $2, $3, LOWER(TRIM($4)), COALESCE(NULLIF($5, ''), 'home'), $6, $7) ON CONFLICT (SYSTEM_CODE, EMAIL) DO UPDATE SET USER_ID = EXCLUDED.USER_ID, USER_NAME = EXCLUDED.USER_NAME, SOURCE = EXCLUDED.SOURCE, TESTER_LINK = EXCLUDED.TESTER_LINK, USER_AGENT = EXCLUDED.USER_AGENT, UPDATED_AT = NOW(), STATUS = CASE WHEN brunner_template.TB_COR_ANDROID_TESTER.STATUS IN ('REJECTED', 'FAILED') THEN 'REQUESTED' ELSE brunner_template.TB_COR_ANDROID_TESTER.STATUS END RETURNING SYSTEM_CODE, USER_ID, USER_NAME, EMAIL, STATUS, TESTER_LINK, CREATED_AT, UPDATED_AT	codex	2026-08-13 21:59:07.041755	\N	\N
00	update_TB_COR_ANDROID_TESTER	1	UPDATE brunner_template.TB_COR_ANDROID_TESTER SET STATUS = $3, GROUP_EMAIL = $4, GROUP_RESULT = $5, UPDATED_AT = NOW() WHERE SYSTEM_CODE = $1 AND EMAIL = LOWER(TRIM($2)) RETURNING SYSTEM_CODE, USER_ID, USER_NAME, EMAIL, STATUS, TESTER_LINK, GROUP_EMAIL, GROUP_RESULT, CREATED_AT, UPDATED_AT	codex	2026-08-13 21:59:07.041755	\N	\N
00	select_TB_COR_ANDROID_TESTER	1	SELECT SYSTEM_CODE, USER_ID, USER_NAME, EMAIL, STATUS, TESTER_LINK, GROUP_EMAIL, GROUP_RESULT, CREATED_AT, UPDATED_AT FROM brunner_template.TB_COR_ANDROID_TESTER WHERE SYSTEM_CODE = $1 AND USER_ID = $2 ORDER BY UPDATED_AT DESC LIMIT 1	codex	2026-08-13 21:59:07.041755	\N	\N
00	select_TB_COR_ANDROID_TESTER	2	SELECT SYSTEM_CODE, USER_ID, USER_NAME, EMAIL, STATUS, SOURCE, TESTER_LINK, GROUP_EMAIL, GROUP_RESULT, CREATED_AT, UPDATED_AT FROM brunner_template.TB_COR_ANDROID_TESTER WHERE SYSTEM_CODE = $1 ORDER BY UPDATED_AT DESC	codex	2026-08-13 21:59:07.041755	\N	\N
00	select_TB_COR_ANDROID_TESTER	3	SELECT t.SYSTEM_CODE, t.USER_ID, t.USER_NAME, t.EMAIL, t.STATUS, t.TESTER_LINK, ps.endpoint, ps.p256dh, ps.auth FROM brunner_template.TB_COR_ANDROID_TESTER t JOIN brunner_template.TB_COR_PUSH_SUBSCRIPTION ps ON ps.system_code = t.SYSTEM_CODE AND ps.user_id = t.USER_ID WHERE t.SYSTEM_CODE = $1 AND t.STATUS NOT IN ('JOINED', 'REJECTED') ORDER BY t.UPDATED_AT DESC, ps.created_at DESC	codex	2026-08-13 21:59:07.041755	\N	\N
00	select_TB_COR_ANDROID_TESTER_USER	1	SELECT USER_ID, USER_NAME, EMAIL_ID, ADMIN_FLAG FROM brunner_template.TB_COR_USER_MST WHERE SYSTEM_CODE = $1 AND USER_ID = $2 LIMIT 1	codex	2026-08-13 21:59:07.041755	\N	\N
00	select_BRUNNER_DB_SIZE	1	SELECT pg_database_size(current_database()) AS bytes	claude	2026-08-13 21:59:07.0425	\N	\N
00	select_BRUNNER_TABLE_USAGE	1	SELECT table_name, total_bytes, total_size, exact_rows AS approx_rows FROM brunner_template.fn_table_usage() ORDER BY total_bytes DESC	claude	2026-08-13 21:59:07.04298	\N	\N
00	delete_TB_COR_CHAT_MSG	3	DELETE FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND room_id = $2	SYSTEM	2026-08-13 21:59:07.04411	\N	\N
00	delete_TB_COR_CHAT_READ_RECEIPT	1	DELETE FROM brunner_template.TB_COR_CHAT_READ_RECEIPT WHERE system_code = $1 AND room_id = $2	SYSTEM	2026-08-13 21:59:07.04411	\N	\N
00	select_TB_COR_CHAT_MSG	3	SELECT COUNT(*) AS cnt FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND room_id = $2 AND message IS NOT NULL AND user_id != $3	SYSTEM	2026-08-13 21:59:07.04411	\N	\N
00	delete_TB_COR_CHATROOM_USERS	2	DELETE FROM brunner_template.TB_COR_CHATROOM_USERS WHERE system_code = $1 AND room_id = $2	SYSTEM	2026-08-13 21:59:07.04411	\N	\N
00	delete_TB_COR_CHATROOM_MST	1	DELETE FROM brunner_template.TB_COR_CHATROOM_MST WHERE system_code = $1 AND id = $2	SYSTEM	2026-08-13 21:59:07.04411	\N	\N
00	select_TB_COR_CHAT_MSG	2	SELECT msg_id AS id, user_id AS "userId", user_name AS "userName", message, reply_to AS "replyTo", created_at AS ts FROM brunner_template.tb_cor_chat_msg WHERE system_code = $1 AND room_id = $2::uuid AND msg_id < $3 ORDER BY msg_id DESC LIMIT 20	SYSTEM	2026-08-13 21:59:07.045033	\N	\N
00	select_TB_COR_CHATROOM_USERS	2	SELECT cu.user_id, u.user_name, u.profile_image_base64 FROM brunner_template.TB_COR_CHATROOM_USERS cu LEFT JOIN brunner_template.TB_COR_USER_MST u ON u.system_code = cu.system_code AND u.user_id = cu.user_id WHERE cu.system_code = $1 AND cu.room_id = $2	claude	2026-08-13 21:59:07.046113	\N	\N
00	select_TB_COR_USER_FRIEND	2	SELECT f.friend_id, u.profile_image_base64 FROM brunner_template.TB_COR_USER_FRIEND f LEFT JOIN brunner_template.TB_COR_USER_MST u ON u.system_code = f.system_code AND u.user_id = f.friend_id WHERE f.system_code = $1 AND f.user_id = $2	claude	2026-08-13 21:59:07.046521	\N	\N
00	select_TB_COR_CHATROOM_MST	1	SELECT r.id, r.name, r.created_by, COALESCE(r.is_secret, FALSE) AS is_secret, (SELECT COUNT(*) FROM brunner_template.TB_COR_CHATROOM_USERS u2 WHERE u2.system_code = $1 AND u2.room_id = r.id) AS member_count FROM brunner_template.TB_COR_CHATROOM_MST r INNER JOIN brunner_template.TB_COR_CHATROOM_USERS u ON u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2 WHERE r.system_code = $1	codex	2026-08-13 21:59:07.046968	\N	\N
00	insert_TB_COR_CHATROOM_USERS	1	INSERT INTO brunner_template.TB_COR_CHATROOM_USERS (system_code, room_id, user_id) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING	claude	2026-08-13 21:59:07.046968	\N	\N
00	insert_TB_COR_CHATROOM_USERS	2	INSERT INTO brunner_template.TB_COR_CHATROOM_USERS (system_code, room_id, user_id) SELECT m.system_code, m.id, $2 FROM brunner_template.TB_COR_CHATROOM_MST m WHERE m.id = $1::uuid ON CONFLICT DO NOTHING	claude	2026-08-13 21:59:07.046968	\N	\N
\.


--
-- Data for Name: tb_cor_txn_hist; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_txn_hist (system_code, transaction_id, request_ip, request_message_content, reply_message_content, create_time) FROM stdin;
\.


--
-- Data for Name: tb_cor_user_activity_log; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_user_activity_log (system_code, activity_date, user_id, activity_type, command_name, first_seen_at, last_seen_at, hit_count) FROM stdin;
\.


--
-- Data for Name: tb_cor_user_e2ee_device_key; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_user_e2ee_device_key (system_code, user_id, device_id, public_key, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_user_friend; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_user_friend (system_code, user_id, friend_id, status, create_time) FROM stdin;
\.


--
-- Data for Name: tb_cor_user_mst; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_user_mst (system_code, user_id, password, user_name, address, phone_number, email_id, use_flag, admin_flag, register_no, register_name, user_type, kakao_id, profile_image_base64, public_key, expire_time, create_time) FROM stdin;
\.


--
-- Data for Name: tb_cor_user_session; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_user_session (system_code, session_token, user_id, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_credit_mst; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_credit_mst (system_code, user_id, balance, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_credit_ledger; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_credit_ledger (system_code, ledger_id, user_id, delta, balance_after, reason, ref, created_at) FROM stdin;
\.


--
-- Data for Name: tb_cor_edoc_document; Type: TABLE DATA; Schema: brunner_template; Owner: -
--

COPY brunner_template.tb_cor_edoc_document (system_code, id, title, description, version, pages, runtime_data, menu_path, created_by, created_at, updated_by, updated_at) FROM stdin;
\.


--
-- Name: tb_cor_chat_msg_msg_id_seq; Type: SEQUENCE SET; Schema: brunner_template; Owner: -
--

SELECT pg_catalog.setval('brunner_template.tb_cor_chat_msg_msg_id_seq', 1, false);


--
-- Name: tb_cor_chatroom_invite_invite_id_seq; Type: SEQUENCE SET; Schema: brunner_template; Owner: -
--

SELECT pg_catalog.setval('brunner_template.tb_cor_chatroom_invite_invite_id_seq', 1, false);


--
-- Name: tb_cor_complaint_complaint_id_seq; Type: SEQUENCE SET; Schema: brunner_template; Owner: -
--

SELECT pg_catalog.setval('brunner_template.tb_cor_complaint_complaint_id_seq', 1, false);


--
-- Name: tb_cor_schedule_participant_participant_id_seq; Type: SEQUENCE SET; Schema: brunner_template; Owner: -
--

SELECT pg_catalog.setval('brunner_template.tb_cor_schedule_participant_participant_id_seq', 1, false);


--
-- Name: tb_cor_schedule_schedule_id_seq; Type: SEQUENCE SET; Schema: brunner_template; Owner: -
--

SELECT pg_catalog.setval('brunner_template.tb_cor_schedule_schedule_id_seq', 1, false);


--
-- Name: tb_cor_chat_custom_emoji tb_chat_custom_emoji_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chat_custom_emoji
    ADD CONSTRAINT tb_chat_custom_emoji_pkey PRIMARY KEY (system_code, id);


--
-- Name: tb_cor_chat_reaction tb_chat_reaction_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chat_reaction
    ADD CONSTRAINT tb_chat_reaction_pkey PRIMARY KEY (system_code, message_id, user_id, emoji);


--
-- Name: tb_cor_android_tester tb_cor_android_tester_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_android_tester
    ADD CONSTRAINT tb_cor_android_tester_pkey PRIMARY KEY (system_code, email);


--
-- Name: tb_cor_chat_file tb_cor_chat_file_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chat_file
    ADD CONSTRAINT tb_cor_chat_file_pkey PRIMARY KEY (system_code, id);


--
-- Name: tb_cor_chat_msg tb_cor_chat_msg_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chat_msg
    ADD CONSTRAINT tb_cor_chat_msg_pkey PRIMARY KEY (system_code, msg_id);


--
-- Name: tb_cor_chat_read_receipt tb_cor_chat_read_receipt_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chat_read_receipt
    ADD CONSTRAINT tb_cor_chat_read_receipt_pkey PRIMARY KEY (system_code, room_id, message_id, user_id);


--
-- Name: tb_cor_chatroom_invite tb_cor_chatroom_invite_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chatroom_invite
    ADD CONSTRAINT tb_cor_chatroom_invite_pkey PRIMARY KEY (invite_id);


--
-- Name: tb_cor_chatroom_member_device_key tb_cor_chatroom_member_device_key_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chatroom_member_device_key
    ADD CONSTRAINT tb_cor_chatroom_member_device_key_pkey PRIMARY KEY (system_code, room_id, user_id, device_id);


--
-- Name: tb_cor_chatroom_member_key tb_cor_chatroom_member_key_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chatroom_member_key
    ADD CONSTRAINT tb_cor_chatroom_member_key_pkey PRIMARY KEY (system_code, room_id, user_id);


--
-- Name: tb_cor_chatroom_mst tb_cor_chatroom_mst_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chatroom_mst
    ADD CONSTRAINT tb_cor_chatroom_mst_pkey PRIMARY KEY (system_code, id);


--
-- Name: tb_cor_chatroom_room_key_history tb_cor_chatroom_room_key_history_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chatroom_room_key_history
    ADD CONSTRAINT tb_cor_chatroom_room_key_history_pkey PRIMARY KEY (system_code, room_id, key_hash);


--
-- Name: tb_cor_chatroom_room_key tb_cor_chatroom_room_key_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chatroom_room_key
    ADD CONSTRAINT tb_cor_chatroom_room_key_pkey PRIMARY KEY (system_code, room_id);


--
-- Name: tb_cor_chatroom_users tb_cor_chatroom_users_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_chatroom_users
    ADD CONSTRAINT tb_cor_chatroom_users_pkey PRIMARY KEY (system_code, room_id, user_id);


--
-- Name: tb_cor_complaint tb_cor_complaint_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_complaint
    ADD CONSTRAINT tb_cor_complaint_pkey PRIMARY KEY (complaint_id);


--
-- Name: tb_cor_friend_invite tb_cor_friend_invite_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_friend_invite
    ADD CONSTRAINT tb_cor_friend_invite_pkey PRIMARY KEY (invite_code);


--
-- Name: tb_cor_push_subscription tb_cor_push_subscription_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_push_subscription
    ADD CONSTRAINT tb_cor_push_subscription_pkey PRIMARY KEY (user_id, endpoint);


--
-- Name: tb_cor_schedule_participant tb_cor_schedule_participant_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_schedule_participant
    ADD CONSTRAINT tb_cor_schedule_participant_pkey PRIMARY KEY (participant_id);


--
-- Name: tb_cor_schedule_participant tb_cor_schedule_participant_schedule_id_user_id_key; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_schedule_participant
    ADD CONSTRAINT tb_cor_schedule_participant_schedule_id_user_id_key UNIQUE (schedule_id, user_id);


--
-- Name: tb_cor_schedule tb_cor_schedule_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_schedule
    ADD CONSTRAINT tb_cor_schedule_pkey PRIMARY KEY (schedule_id);


--
-- Name: tb_cor_sql_info tb_cor_sql_info_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_sql_info
    ADD CONSTRAINT tb_cor_sql_info_pkey PRIMARY KEY (system_code, sql_name, sql_seq);


--
-- Name: tb_cor_txn_hist tb_cor_txn_hist_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_txn_hist
    ADD CONSTRAINT tb_cor_txn_hist_pkey PRIMARY KEY (system_code, transaction_id);


--
-- Name: tb_cor_user_activity_log tb_cor_user_activity_log_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_user_activity_log
    ADD CONSTRAINT tb_cor_user_activity_log_pkey PRIMARY KEY (system_code, activity_date, user_id, activity_type);


--
-- Name: tb_cor_user_e2ee_device_key tb_cor_user_e2ee_device_key_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_user_e2ee_device_key
    ADD CONSTRAINT tb_cor_user_e2ee_device_key_pkey PRIMARY KEY (system_code, user_id, device_id);


--
-- Name: tb_cor_user_friend tb_cor_user_friend_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_user_friend
    ADD CONSTRAINT tb_cor_user_friend_pkey PRIMARY KEY (system_code, user_id, friend_id);


--
-- Name: tb_cor_user_mst tb_cor_user_mst_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_user_mst
    ADD CONSTRAINT tb_cor_user_mst_pkey PRIMARY KEY (system_code, user_id);


--
-- Name: tb_cor_user_session tb_cor_user_session_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_user_session
    ADD CONSTRAINT tb_cor_user_session_pkey PRIMARY KEY (system_code, session_token);


--
-- Name: tb_cor_credit_ledger tb_credit_ledger_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_credit_ledger
    ADD CONSTRAINT tb_credit_ledger_pkey PRIMARY KEY (system_code, ledger_id);


--
-- Name: tb_cor_credit_mst tb_credit_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_credit_mst
    ADD CONSTRAINT tb_credit_pkey PRIMARY KEY (system_code, user_id);


--
-- Name: tb_cor_edoc_document tb_cor_edoc_document_pkey; Type: CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_edoc_document
    ADD CONSTRAINT tb_cor_edoc_document_pkey PRIMARY KEY (system_code, id);


--
-- Name: idx_android_tester_status; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_android_tester_status ON brunner_template.tb_cor_android_tester USING btree (system_code, status, updated_at DESC);


--
-- Name: idx_android_tester_user; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_android_tester_user ON brunner_template.tb_cor_android_tester USING btree (system_code, user_id);


--
-- Name: idx_chat_msg_room_created; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_chat_msg_room_created ON brunner_template.tb_cor_chat_msg USING btree (system_code, room_id, created_at DESC);


--
-- Name: idx_chat_msg_room_id; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_chat_msg_room_id ON brunner_template.tb_cor_chat_msg USING btree (system_code, room_id, msg_id DESC);


--
-- Name: idx_chat_msg_room_user; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_chat_msg_room_user ON brunner_template.tb_cor_chat_msg USING btree (system_code, room_id, user_id);


--
-- Name: idx_chat_read_receipt_room; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_chat_read_receipt_room ON brunner_template.tb_cor_chat_read_receipt USING btree (system_code, room_id);


--
-- Name: idx_chatroom_invite_target; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_chatroom_invite_target ON brunner_template.tb_cor_chatroom_invite USING btree (system_code, target_user_id, status);


--
-- Name: idx_chatroom_users_user; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_chatroom_users_user ON brunner_template.tb_cor_chatroom_users USING btree (system_code, user_id);


--
-- Name: idx_complaint_status; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_complaint_status ON brunner_template.tb_cor_complaint USING btree (system_code, status);


--
-- Name: idx_complaint_user; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_complaint_user ON brunner_template.tb_cor_complaint USING btree (system_code, user_id);


--
-- Name: idx_custom_emoji_user; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_custom_emoji_user ON brunner_template.tb_cor_chat_custom_emoji USING btree (system_code, user_id);


--
-- Name: idx_tb_cor_edoc_document_menu; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_tb_cor_edoc_document_menu ON brunner_template.tb_cor_edoc_document USING btree (system_code, menu_path);


--
-- Name: idx_push_subscription_user; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_push_subscription_user ON brunner_template.tb_cor_push_subscription USING btree (system_code, user_id);


--
-- Name: idx_read_receipt_user_msg; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_read_receipt_user_msg ON brunner_template.tb_cor_chat_read_receipt USING btree (system_code, user_id, message_id);


--
-- Name: idx_schedule_participant_user; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_schedule_participant_user ON brunner_template.tb_cor_schedule_participant USING btree (system_code, user_id);


--
-- Name: idx_schedule_user_time; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_schedule_user_time ON brunner_template.tb_cor_schedule USING btree (system_code, user_id, start_time, end_time);


--
-- Name: idx_tb_cor_chat_reaction_msg; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_tb_cor_chat_reaction_msg ON brunner_template.tb_cor_chat_reaction USING btree (system_code, message_id);


--
-- Name: idx_tb_cor_user_mst_email; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_tb_cor_user_mst_email ON brunner_template.tb_cor_user_mst USING btree (system_code, email_id);


--
-- Name: idx_tb_cor_user_mst_kakao; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_tb_cor_user_mst_kakao ON brunner_template.tb_cor_user_mst USING btree (kakao_id);


--
-- Name: idx_tb_cor_credit_ledger_ref; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_tb_cor_credit_ledger_ref ON brunner_template.tb_cor_credit_ledger USING btree (system_code, ref, reason);


--
-- Name: idx_tb_cor_credit_ledger_user; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_tb_cor_credit_ledger_user ON brunner_template.tb_cor_credit_ledger USING btree (system_code, user_id, created_at);


--
-- Name: idx_txn_hist_time; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_txn_hist_time ON brunner_template.tb_cor_txn_hist USING btree (system_code, create_time DESC);


--
-- Name: idx_user_activity_log_date; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_user_activity_log_date ON brunner_template.tb_cor_user_activity_log USING btree (system_code, activity_date DESC);


--
-- Name: idx_user_activity_log_user_date; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_user_activity_log_user_date ON brunner_template.tb_cor_user_activity_log USING btree (system_code, user_id, activity_date DESC);


--
-- Name: idx_user_mst_kakao_id; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE UNIQUE INDEX idx_user_mst_kakao_id ON brunner_template.tb_cor_user_mst USING btree (kakao_id) WHERE (kakao_id IS NOT NULL);


--
-- Name: idx_user_session_user; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE INDEX idx_user_session_user ON brunner_template.tb_cor_user_session USING btree (system_code, user_id);


--
-- Name: uq_chatroom_invite_pending; Type: INDEX; Schema: brunner_template; Owner: -
--

CREATE UNIQUE INDEX uq_chatroom_invite_pending ON brunner_template.tb_cor_chatroom_invite USING btree (system_code, room_id, target_user_id) WHERE ((status)::text = 'PENDING'::text);


--
-- Name: tb_cor_schedule_participant tb_cor_schedule_participant_schedule_id_fkey; Type: FK CONSTRAINT; Schema: brunner_template; Owner: -
--

ALTER TABLE ONLY brunner_template.tb_cor_schedule_participant
    ADD CONSTRAINT tb_cor_schedule_participant_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES brunner_template.tb_cor_schedule(schedule_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


