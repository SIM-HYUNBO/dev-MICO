DO $$
BEGIN
  IF to_regclass('brunner_template.tb_cor_edoc_document') IS NULL
     AND to_regclass('brunner_template.tb_doc_document') IS NOT NULL THEN
    ALTER TABLE brunner_template.tb_doc_document RENAME TO tb_cor_edoc_document;
  END IF;

  IF to_regclass('brunner_template.tb_cor_edoc_component') IS NULL
     AND to_regclass('brunner_template.tb_doc_component_template') IS NOT NULL THEN
    ALTER TABLE brunner_template.tb_doc_component_template RENAME TO tb_cor_edoc_component;
  END IF;
END $$;

DO $$
BEGIN
  IF to_regclass('brunner_template.tb_cor_edoc_document') IS NOT NULL AND EXISTS (
    SELECT 1
      FROM pg_constraint
     WHERE conname = 'tb_doc_document_pkey'
       AND connamespace = 'brunner_template'::regnamespace
  ) THEN
    ALTER TABLE brunner_template.tb_cor_edoc_document
      RENAME CONSTRAINT tb_doc_document_pkey TO tb_cor_edoc_document_pkey;
  END IF;

  IF to_regclass('brunner_template.tb_cor_edoc_component') IS NOT NULL AND EXISTS (
    SELECT 1
      FROM pg_constraint
     WHERE conname = 'tb_doc_component_template_pkey'
       AND connamespace = 'brunner_template'::regnamespace
  ) THEN
    ALTER TABLE brunner_template.tb_cor_edoc_component
      RENAME CONSTRAINT tb_doc_component_template_pkey TO tb_cor_edoc_component_pkey;
  END IF;
END $$;

ALTER INDEX IF EXISTS brunner_template.idx_doc_document_menu
  RENAME TO idx_tb_cor_edoc_document_menu;

DO $$
BEGIN
  IF to_regclass('brunner_template.tb_cor_sql_info') IS NOT NULL THEN
    UPDATE brunner_template.TB_COR_SQL_INFO
       SET SQL_NAME = replace(replace(
             SQL_NAME,
             'TB_DOC_DOCUMENT', 'TB_COR_EDOC_DOCUMENT'),
             'TB_DOC_COMPONENT_TEMPLATE', 'TB_COR_EDOC_COMPONENT'),
           SQL_CONTENT = replace(replace(replace(replace(
             SQL_CONTENT,
             'TB_DOC_DOCUMENT', 'TB_COR_EDOC_DOCUMENT'),
             'tb_doc_document', 'tb_cor_edoc_document'),
             'TB_DOC_COMPONENT_TEMPLATE', 'TB_COR_EDOC_COMPONENT'),
             'tb_doc_component_template', 'tb_cor_edoc_component'),
           UPDATE_USER_ID = 'SYSTEM',
           UPDATE_TIME = NOW()
     WHERE SQL_NAME LIKE '%TB_DOC_DOCUMENT%'
        OR SQL_NAME LIKE '%TB_DOC_COMPONENT_TEMPLATE%'
        OR SQL_CONTENT ILIKE '%tb_doc_document%'
        OR SQL_CONTENT ILIKE '%tb_doc_component_template%';
  END IF;

  IF to_regclass('brunner_template.tb_cor_table_retention_policy') IS NOT NULL THEN
    UPDATE brunner_template.TB_COR_TABLE_RETENTION_POLICY
       SET TABLE_NAME = replace(replace(
             TABLE_NAME,
             'TB_DOC_DOCUMENT', 'TB_COR_EDOC_DOCUMENT'),
             'TB_DOC_COMPONENT_TEMPLATE', 'TB_COR_EDOC_COMPONENT'),
           UPDATE_USER_ID = 'SYSTEM',
           UPDATE_TIME = NOW()
     WHERE TABLE_NAME IN ('TB_DOC_DOCUMENT', 'TB_DOC_COMPONENT_TEMPLATE');
  END IF;
END $$;
