-- Direct chat participant restoration dynamic SQL.
-- Used when one side left a 1:1 room and the remaining side sends a message.

INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'select_TB_COR_DIRECT_CHAT_PARTICIPANT',
  1,
  'SELECT DISTINCT p.user_id FROM (SELECT created_by AS user_id FROM brunner_template.TB_COR_CHATROOM_MST WHERE system_code = $1 AND id = $2 UNION SELECT user_id FROM brunner_template.TB_COR_CHATROOM_USERS WHERE system_code = $1 AND room_id = $2 UNION SELECT user_id FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND room_id = $2 AND user_id IS NOT NULL) p WHERE p.user_id IS NOT NULL AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND r.id = $2 AND COALESCE(r.room_type, ''GROUP'') = ''DIRECT'')',
  'SYSTEM',
  NOW()
)
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET
  SQL_CONTENT = EXCLUDED.SQL_CONTENT,
  UPDATE_USER_ID = 'SYSTEM',
  UPDATE_TIME = NOW();
