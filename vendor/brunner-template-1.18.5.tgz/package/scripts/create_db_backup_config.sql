-- DB 백업 설정.
--
-- 왜 DB 에 두나
--   백업 여부·주기·시각이 환경변수면 바꿀 때마다 재배포해야 한다. 운영 중에 "오늘은
--   백업 끄자", "새벽 4시 말고 2시로" 같은 판단이 바로 반영되지 않는다. 보존정책 스케줄
--   (TB_COR_TABLE_RETENTION_CONFIG)과 같은 방식으로 DB 에 두고 관리자 화면에서 고친다.
--
--   락도 함께 둔다. 인스턴스가 여러 개면 같은 시각에 각자 백업을 떠서 R2 를 서로
--   덮어쓰고 DB 부하도 배가 된다. 테넌트별 락이라 한 테넌트의 백업이 다른 테넌트를
--   막지 않는다.
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_DB_BACKUP_CONFIG (
  SYSTEM_CODE             VARCHAR(2)   NOT NULL,
  ENABLED                 BOOLEAN      NOT NULL DEFAULT TRUE,
  RUN_AT                  VARCHAR(5)   NOT NULL DEFAULT '04:00',
  INTERVAL_HOURS          INTEGER      NOT NULL DEFAULT 24,
  TIMEZONE_OFFSET_MINUTES INTEGER      NOT NULL DEFAULT 540,
  LOCK_OWNER              VARCHAR(120),
  LOCK_UNTIL              TIMESTAMP,
  CREATE_USER_ID          VARCHAR(100),
  CREATE_TIME             TIMESTAMP    DEFAULT NOW(),
  UPDATE_USER_ID          VARCHAR(100),
  UPDATE_TIME             TIMESTAMP    DEFAULT NOW(),
  CONSTRAINT PK_TB_COR_DB_BACKUP_CONFIG PRIMARY KEY (SYSTEM_CODE)
);

COMMENT ON TABLE brunner_template.TB_COR_DB_BACKUP_CONFIG IS 'DB 백업 설정(여부·주기·시각)';

-- 스키마 안의 모든 테넌트에 기본 설정 행을 만들어 둔다.
-- 자기 행이 없으면 화면에서 고칠 것도 없고, 락도 잡을 자리가 없다.
INSERT INTO brunner_template.TB_COR_DB_BACKUP_CONFIG (SYSTEM_CODE, CREATE_USER_ID, UPDATE_USER_ID)
SELECT code, 'system', 'system'
  FROM (
    SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
    UNION SELECT '00'
  ) x
ON CONFLICT (SYSTEM_CODE) DO NOTHING;
