-- 소켓 방 입장 권한 검사에 쓰는 쿼리.
-- server.js 가 SQL 문자열을 직접 들고 있었는데, 스키마 이름이 'BRUNNER' 로 박혀 있어
-- 이 리포에서는 매번 relation 없음 오류가 났다. 그런데 그 함수는 오류 시 접근을
-- 허용하도록 되어 있어(transient 오류로 거부하지 않으려는 의도), 결과적으로 방 입장
-- 권한 검사가 통째로 무력화된 상태였다. 동적 SQL 로 옮겨 스키마가 리포마다 맞도록 한다.

-- 방장이 자기 방 멤버 목록에서 빠져 있을 때 판별용.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_OWNER', 1,
  'SELECT 1 FROM brunner_template.TB_COR_CHATROOM_MST WHERE system_code = $1 AND id = $2::uuid AND created_by = $3 LIMIT 1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
