-- 기반 스키마 — 신규 DB 부트스트랩의 첫 단계
--
-- 원본(brunner-next)에는 이 두 테이블을 만드는 스크립트가 없었다. 운영 DB 에
-- 수동으로 만들어진 뒤 스크립트로 남지 않은 것으로 보이며, 그 상태로는 새 DB 를
-- 세울 수 없다. 코드와 동적 SQL 정의에서 컬럼을 역추적해 복원했다.
--
-- TB_COR_SQL_INFO 가 특히 중요하다. 이 프레임워크는 SQL 을 코드가 아니라 DB 에
-- 저장해두고 이름으로 꺼내 쓰기 때문에(dynamicSql), 이 테이블이 없으면 다른
-- 어떤 기능도 동작하지 않는다. 반드시 가장 먼저 만들어야 한다.

CREATE SCHEMA IF NOT EXISTS brunner_template;

-- ------------------------------------------------------------------
-- 동적 SQL 저장소
-- ------------------------------------------------------------------
-- insert_dynamic_sql_*.sql 시드가 여기에 쿼리를 넣는다.
-- SQL_SEQ 는 같은 이름으로 여러 변형을 두기 위한 것이다
-- (예: update_TB_COR_CREDIT_MST 의 1=증감, 2=조건부 차감).
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE     VARCHAR(2)   NOT NULL,
  SQL_NAME        VARCHAR(200) NOT NULL,
  SQL_SEQ         INT          NOT NULL DEFAULT 1,
  SQL_CONTENT     TEXT         NOT NULL,
  CREATE_USER_ID  VARCHAR(100),
  CREATE_TIME     TIMESTAMP    DEFAULT NOW(),
  UPDATE_USER_ID  VARCHAR(100),
  UPDATE_TIME     TIMESTAMP,
  PRIMARY KEY (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
);

-- ------------------------------------------------------------------
-- 사용자 마스터
-- ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_USER_MST (
  SYSTEM_CODE          VARCHAR(2)   NOT NULL,
  USER_ID              VARCHAR(100) NOT NULL,
  PASSWORD             VARCHAR(200),              -- bcrypt 해시
  USER_NAME            VARCHAR(100),
  ADDRESS              VARCHAR(500),
  PHONE_NUMBER         VARCHAR(50),
  EMAIL_ID             VARCHAR(200),
  USE_FLAG             VARCHAR(1)   DEFAULT 'Y',
  ADMIN_FLAG           BOOLEAN      DEFAULT FALSE,
  REGISTER_NO          VARCHAR(100),
  REGISTER_NAME        VARCHAR(100),
  USER_TYPE            VARCHAR(20),
  KAKAO_ID             VARCHAR(100),              -- 소셜 로그인 연동
  AUTH_CODE            VARCHAR(20),
  PROFILE_IMAGE_SRC TEXT,
  PUBLIC_KEY           TEXT,                      -- E2EE 채팅용 공개키
  EXPIRE_TIME          TIMESTAMP,
  CREATE_TIME          TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, USER_ID)
);

ALTER TABLE brunner_template.TB_COR_USER_MST
  ADD COLUMN IF NOT EXISTS AUTH_CODE VARCHAR(20);

CREATE INDEX IF NOT EXISTS IDX_TB_COR_USER_MST_EMAIL
  ON brunner_template.TB_COR_USER_MST(SYSTEM_CODE, EMAIL_ID);

CREATE INDEX IF NOT EXISTS IDX_TB_COR_USER_MST_KAKAO
  ON brunner_template.TB_COR_USER_MST(KAKAO_ID);

-- ------------------------------------------------------------------
-- 친구 관계 (채팅이 의존한다)
-- ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_USER_FRIEND (
  SYSTEM_CODE  VARCHAR(2)   NOT NULL,
  USER_ID      VARCHAR(100) NOT NULL,
  FRIEND_ID    VARCHAR(100) NOT NULL,
  STATUS       VARCHAR(20)  DEFAULT 'ACCEPTED',
  CREATE_TIME  TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, USER_ID, FRIEND_ID)
);
