-- 프로필 사진·커스텀 이모지를 R2 에 두기 위한 동적 SQL.
-- alter_media_to_r2.sql 이 만든 컬럼(profile_image_key, r2_key)을 요구한다.

-- 프로필 사진 --------------------------------------------------------------

-- 서빙용. 키가 있으면 R2 로, 없으면 옛 data URL 을 그대로 돌려준다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_PROFILE_IMAGE', 1,
  'SELECT profile_image_key, profile_image_src FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 LIMIT 1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 사진을 R2 로 올린 뒤 키와 서빙 경로를 함께 기록한다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST_PROFILE_IMAGE', 1,
  'UPDATE brunner_template.TB_COR_USER_MST SET profile_image_key = $3, profile_image_src = $4 WHERE system_code = $1 AND user_id = $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 이관 배치용 — 아직 data URL 을 들고 있는 행만 골라온다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_PROFILE_IMAGE', 2,
  'SELECT user_id, profile_image_src FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND profile_image_key IS NULL AND profile_image_src LIKE ''data:image/%'' ORDER BY user_id LIMIT $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 커스텀 이모지 ------------------------------------------------------------

-- 서빙용. r2_key 가 있으면 본문 대신 키를 보고 R2 로 넘긴다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHAT_CUSTOM_EMOJI', 2,
  'SELECT user_id, mime_type, file_data, r2_key FROM brunner_template.TB_COR_CHAT_CUSTOM_EMOJI WHERE system_code = $1 AND id = $2::uuid',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 신규 등록은 본문 대신 키만 남긴다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHAT_CUSTOM_EMOJI', 2,
  'INSERT INTO brunner_template.TB_COR_CHAT_CUSTOM_EMOJI (system_code, user_id, name, mime_type, r2_key) VALUES ($1, $2, $3, $4, $5) RETURNING id',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 이관 배치용 — 아직 BYTEA 본문을 들고 있는 행.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHAT_CUSTOM_EMOJI', 3,
  'SELECT id, mime_type, file_data FROM brunner_template.TB_COR_CHAT_CUSTOM_EMOJI WHERE system_code = $1 AND r2_key IS NULL AND file_data IS NOT NULL ORDER BY created_at LIMIT $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 이관 완료 표시 — 본문을 비우고 키를 심는다. DB 볼륨은 이 UPDATE 로 실제로 준다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_CHAT_CUSTOM_EMOJI', 1,
  'UPDATE brunner_template.TB_COR_CHAT_CUSTOM_EMOJI SET r2_key = $3, file_data = NULL WHERE system_code = $1 AND id = $2::uuid',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 채팅 메시지에 박힌 이미지 ------------------------------------------------
-- 메시지 본문은 암호문이라 SQL 로 'data:image/%' 를 거를 수 없다. base64 이미지는
-- 일반 대화문보다 훨씬 길다는 점을 이용해 길이로 후보만 추리고, 실제 판정은
-- 복호화한 뒤에 한다. 이관이 진행될수록 후보가 줄어 스캔도 저절로 가벼워진다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHAT_MSG_IMAGE_CANDIDATE', 1,
  'SELECT msg_id, room_id, message FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND msg_id > $2 AND octet_length(message) > 2000 ORDER BY msg_id LIMIT $3',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_CHAT_MSG_IMAGE', 1,
  'UPDATE brunner_template.TB_COR_CHAT_MSG SET message = $3 WHERE system_code = $1 AND msg_id = $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
