-- 크레딧: 잔액 + 원장(내역)
-- 결제(토스페이먼츠)로 충전하고 각 서비스가 자기 사유로 차감한다.

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CREDIT_MST (
  SYSTEM_CODE  VARCHAR(2)   NOT NULL,
  USER_ID      VARCHAR(100) NOT NULL,
  BALANCE      INT          DEFAULT 0,
  UPDATED_AT   TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, USER_ID)
);

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CREDIT_LEDGER (
  SYSTEM_CODE   VARCHAR(2)   NOT NULL,
  LEDGER_ID     VARCHAR(64)  NOT NULL,
  USER_ID       VARCHAR(100) NOT NULL,
  DELTA         INT          NOT NULL,        -- +충전/지급, -차감
  BALANCE_AFTER INT,
  REASON        VARCHAR(40),                  -- starter / purchase / <서비스별 사유>
  REF           VARCHAR(100),                 -- 관련 id (결제 orderId 등)
  CREATED_AT    TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, LEDGER_ID)
);

CREATE INDEX IF NOT EXISTS IDX_TB_COR_CREDIT_LEDGER_USER
  ON brunner_template.TB_COR_CREDIT_LEDGER(SYSTEM_CODE, USER_ID, CREATED_AT);

-- 멱등 지급 조회(REF+REASON) — 결제 orderId 중복 충전 방지
CREATE INDEX IF NOT EXISTS IDX_TB_COR_CREDIT_LEDGER_REF
  ON brunner_template.TB_COR_CREDIT_LEDGER(SYSTEM_CODE, REF, REASON);
