// 테넌트를 정하는 통로가 SYSTEM_CODE 하나인지 빌드 전에 검사한다.
//
// 왜
//   CLAUDE.md 는 NEXT_PUBLIC_SYSTEM_CODE·TENANT_SYSTEM_CODE 를 쓰지 말라고 정해
//   두었는데, 코드가 그걸 어기고 SYSTEM_CODE 가 없을 때 폴백으로 읽고 있었다.
//   .env.example 은 그 변수에 'your_system_code' 를 예시로 박아 두었다.
//
//   아무도 관리하지 않는 변수가 테넌트를 정할 수 있으니, 예제값이 그대로 남은
//   배포가 조용히 'your_system_code' 를 테넌트로 삼았다. 공유 DB 라벨 테이블에
//   그 코드로만 2,869 행이 쌓였고(잘못된 값 전체로는 22,952 행) 아무도 몰랐다.
//   화면은 멀쩡히 돌아서 표시가 나지 않는다.
//
//   규칙을 문서에만 두면 또 어긴다. 빌드를 세운다.
//
// 실행: node scripts/tenant_env_gate.cjs   (위반 시 exit 1)

const fs = require("fs");
const path = require("path");

const ROOT = process.env.BRUNNER_APP_DIR || process.cwd();
const FORBIDDEN = /\b(NEXT_PUBLIC_SYSTEM_CODE|TENANT_SYSTEM_CODE)\b/;
const SCAN_DIRS = ["lib", "pages", "components", "scripts"];
const SCAN_FILES = [".env.example", "server.js"];
const EXT = new Set([".js", ".cjs", ".mjs", ".jsx", ".ts", ".tsx"]);

// 이 게이트 자신은 금지어를 들고 있어야 검사할 수 있다.
const EXEMPT = new Set(["tenant_env_gate.cjs"]);

const violations = [];

// 주석은 사고 경위를 남기는 자리라 허용한다. 실제 참조만 막는다.
const isComment = (line) => /^\s*(\/\/|\*|\/\*|#|--)/.test(line);

const check = (file) => {
  if (EXEMPT.has(path.basename(file))) return;
  let text;
  try {
    text = fs.readFileSync(file, "utf8");
  } catch {
    return;
  }
  text.split(/\r?\n/).forEach((line, i) => {
    if (isComment(line) || !FORBIDDEN.test(line)) return;
    violations.push(`${path.relative(ROOT, file)}:${i + 1}  ${line.trim()}`);
  });
};

const walk = (dir) => {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name === "node_modules" || e.name === ".next") continue;
      walk(full);
    } else if (EXT.has(path.extname(e.name))) {
      check(full);
    }
  }
};

for (const d of SCAN_DIRS) walk(path.join(ROOT, d));
for (const f of SCAN_FILES) check(path.join(ROOT, f));

if (violations.length) {
  console.error(
    "[tenant-env-gate] 테넌트는 SYSTEM_CODE 하나로만 정한다. " +
      "아래 참조를 지워라 (설명이 필요하면 주석으로 남길 것):",
  );
  for (const v of violations) console.error("  " + v);
  process.exit(1);
}
console.log("[tenant-env-gate] 금지된 테넌트 환경변수 참조 없음.");
