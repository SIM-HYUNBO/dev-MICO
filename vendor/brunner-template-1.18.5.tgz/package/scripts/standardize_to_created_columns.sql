-- 컬럼명 표준화: create_time/update_time/create_user_id/update_user_id → created_at/updated_at/created_by/updated_by
-- rename_all_columns.sql 실행 여부 관계없이 멱등하게 원복
-- trigger: 2026-06-14d

DO $$
BEGIN
  -- TB_COR_EDOC_DOCUMENT (rename_doc_document_columns.sql로 인해 이미 변경됐을 수 있음)
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_edoc_document' AND column_name='create_user_id') THEN
    ALTER TABLE brunner_template.TB_COR_EDOC_DOCUMENT RENAME COLUMN create_user_id TO created_by;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_edoc_document' AND column_name='create_time') THEN
    ALTER TABLE brunner_template.TB_COR_EDOC_DOCUMENT RENAME COLUMN create_time TO created_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_edoc_document' AND column_name='update_user_id') THEN
    ALTER TABLE brunner_template.TB_COR_EDOC_DOCUMENT RENAME COLUMN update_user_id TO updated_by;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_edoc_document' AND column_name='update_time') THEN
    ALTER TABLE brunner_template.TB_COR_EDOC_DOCUMENT RENAME COLUMN update_time TO updated_at;
  END IF;

  -- TB_COR_COMPLAINT: create_time → created_at
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_complaint' AND column_name='create_time') THEN
    ALTER TABLE brunner_template.TB_COR_COMPLAINT RENAME COLUMN create_time TO created_at;
  END IF;

  -- TB_COR_SCHEDULE: create_time → created_at
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_schedule' AND column_name='create_time') THEN
    ALTER TABLE brunner_template.TB_COR_SCHEDULE RENAME COLUMN create_time TO created_at;
  END IF;

  -- TB_COR_SCHEDULE_PARTICIPANT: create_time → created_at
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_schedule_participant' AND column_name='create_time') THEN
    ALTER TABLE brunner_template.TB_COR_SCHEDULE_PARTICIPANT RENAME COLUMN create_time TO created_at;
  END IF;

  -- 아래는 rename_all_columns.sql이 먼저 실행됐을 경우 원복 (IF EXISTS로 안전하게 처리)
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_chat_file' AND column_name='create_time') THEN
    ALTER TABLE brunner_template.TB_COR_CHAT_FILE RENAME COLUMN create_time TO created_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_chat_custom_emoji' AND column_name='create_time') THEN
    ALTER TABLE brunner_template.TB_COR_CHAT_CUSTOM_EMOJI RENAME COLUMN create_time TO created_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_user_session' AND column_name='create_time') THEN
    ALTER TABLE brunner_template.TB_COR_USER_SESSION RENAME COLUMN create_time TO created_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_friend_invite' AND column_name='create_time') THEN
    ALTER TABLE brunner_template.TB_COR_FRIEND_INVITE RENAME COLUMN create_time TO created_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_user_e2ee_device_key' AND column_name='update_time') THEN
    ALTER TABLE brunner_template.TB_COR_USER_E2EE_DEVICE_KEY RENAME COLUMN update_time TO updated_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_chatroom_member_key' AND column_name='update_time') THEN
    ALTER TABLE brunner_template.TB_COR_CHATROOM_MEMBER_KEY RENAME COLUMN update_time TO updated_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_chatroom_member_device_key' AND column_name='update_time') THEN
    ALTER TABLE brunner_template.TB_COR_CHATROOM_MEMBER_DEVICE_KEY RENAME COLUMN update_time TO updated_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_chatroom_room_key' AND column_name='update_time') THEN
    ALTER TABLE brunner_template.TB_COR_CHATROOM_ROOM_KEY RENAME COLUMN update_time TO updated_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_chatroom_room_key_history' AND column_name='update_time') THEN
    ALTER TABLE brunner_template.TB_COR_CHATROOM_ROOM_KEY_HISTORY RENAME COLUMN update_time TO updated_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_chatroom_mst' AND column_name='create_user_id') THEN
    ALTER TABLE brunner_template.TB_COR_CHATROOM_MST RENAME COLUMN create_user_id TO created_by;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_cor_chat_msg' AND column_name='create_time') THEN
    ALTER TABLE brunner_template.TB_COR_CHAT_MSG RENAME COLUMN create_time TO created_at;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_universe' AND column_name='create_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_universe' AND column_name='update_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_universe_symbol' AND column_name='create_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_universe_symbol' AND column_name='update_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_daily_snapshot' AND column_name='create_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_daily_snapshot' AND column_name='update_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_intraday_snapshot' AND column_name='create_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_cache' AND column_name='create_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_cache' AND column_name='update_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_watchlist' AND column_name='create_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_watchlist' AND column_name='update_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_provider_log' AND column_name='create_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_screening_rule' AND column_name='create_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_screening_rule' AND column_name='update_time') THEN
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='brunner_template' AND table_name='tb_stk_screening_result' AND column_name='create_time') THEN
  END IF;

  RAISE NOTICE '컬럼명 표준화 완료: *_at / *_by';
END $$;

-- TB_COR_EDOC_DOCUMENT 동적 SQL 재등록 (created_by/created_at/updated_by/updated_at 기준)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_EDOC_DOCUMENT', 1,
  'SELECT d.system_code, d.id, d.title, d.description, d.version, d.created_by, d.created_at, d.updated_at, d.updated_by, d.runtime_data, d.pages, d.menu_path FROM brunner_template.tb_cor_edoc_document d WHERE d.system_code = $1 AND d.id = $2',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_EDOC_DOCUMENT', 2,
  'SELECT d.system_code, d.id, d.title, d.description, d.version, d.created_by, d.created_at, d.updated_at, d.updated_by, d.runtime_data, d.pages, d.menu_path FROM brunner_template.tb_cor_edoc_document d WHERE d.system_code = $1 AND d.created_by = $2 ORDER BY d.updated_at DESC, d.created_at DESC',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_EDOC_DOCUMENT', 3,
  'SELECT d.system_code, d.id, d.title, d.description, d.version, d.created_by, d.created_at, d.updated_at, d.updated_by, d.runtime_data, d.pages, d.menu_path FROM brunner_template.tb_cor_edoc_document d WHERE (d.runtime_data->>''isPublic'')::boolean = true AND d.system_code = $1 ORDER BY d.updated_at DESC, d.created_at DESC',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_EDOC_DOCUMENT', 1,
  'INSERT INTO brunner_template.TB_COR_EDOC_DOCUMENT (system_code, id, title, description, version, created_by, created_at, updated_by, updated_at, runtime_data, pages, menu_path) VALUES ($1, $2, $3, $4, $5, $6, NOW(), $6, NOW(), $7::jsonb, $8::jsonb, $9)',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_EDOC_DOCUMENT', 1,
  'UPDATE brunner_template.TB_COR_EDOC_DOCUMENT SET title = $3, description = $4, updated_by = $5, updated_at = NOW(), version = COALESCE(version, 0) + 1, runtime_data = $6::jsonb, pages = $7::jsonb, menu_path = $8 WHERE system_code = $1 AND id = $2',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'delete_TB_COR_EDOC_DOCUMENT', 1,
  'DELETE FROM brunner_template.TB_COR_EDOC_DOCUMENT WHERE system_code = $1 AND id = $2',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- TB_COR_COMPLAINT 동적 SQL 재등록 (create_time → created_at)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_COMPLAINT', 1,
  'INSERT INTO brunner_template.TB_COR_COMPLAINT (SYSTEM_CODE, USER_ID, USER_NAME, CONTENT, IMAGES) VALUES ($1, $2, $3, $4, $5) RETURNING COMPLAINT_ID, CREATED_AT',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_COMPLAINT', 1,
  'SELECT COMPLAINT_ID, USER_ID, USER_NAME, CONTENT, IMAGES, STATUS, RESOLUTION, RESOLVED_BY, RESOLVED_TIME, APPROVE_TIME, CREATED_AT FROM brunner_template.TB_COR_COMPLAINT WHERE SYSTEM_CODE = $1 AND USER_ID = $2 ORDER BY CREATED_AT DESC',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_COMPLAINT', 2,
  'SELECT COMPLAINT_ID, USER_ID, USER_NAME, CONTENT, IMAGES, STATUS, RESOLUTION, RESOLVED_BY, RESOLVED_TIME, APPROVE_TIME, CREATED_AT FROM brunner_template.TB_COR_COMPLAINT WHERE SYSTEM_CODE = $1 ORDER BY CREATED_AT DESC',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- TB_COR_SCHEDULE 동적 SQL 재등록 (올바른 12파라미터 버전: repeat_type, repeat_until, schedule_type 포함)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_SCHEDULE', 1,
  'INSERT INTO brunner_template.TB_COR_SCHEDULE (SYSTEM_CODE, USER_ID, TITLE, DESCRIPTION, START_TIME, END_TIME, IS_ALL_DAY, COLOR, REMINDER_MINUTES, REPEAT_TYPE, REPEAT_UNTIL, SCHEDULE_TYPE) VALUES ($1, $2, $3, $4, $5::timestamp, $6::timestamp, $7, $8, $9, $10, $11::date, $12) RETURNING SCHEDULE_ID',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
