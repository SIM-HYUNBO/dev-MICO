// 정의 없이 호출되는 식별자를 잡는 배포 전 게이트.
//
// 왜 필요한가 — dropdownMenuitem 이 isAiContentDocument 를 정의 없이 부르고 있었다.
// 그 코드 경로(로그인 후 공용문서 섹션)가 실행되는 순간 ReferenceError 가 나면서
// 메뉴 조립 전체가 reject 되어, 로그인하면 햄버거 메뉴가 통째로 비었다.
// 빌드는 통과한다 — 번들러는 런타임 참조를 검사하지 않는다.
// 같은 유형을 네 곳 더 찾았다(영상 생성 실패 기록이 안 남던 것 포함).
//
// 이미 프로젝트에 있는 @babel/parser + @babel/traverse 로만 검사한다.
// 실행: node scripts/undef_gate.cjs   (위반 시 exit 1)

const fs = require("fs");
const path = require("path");
const parser = require("@babel/parser");
const traverseModule = require("@babel/traverse");
const traverse = traverseModule.default || traverseModule;

// 이 스크립트는 파생 저장소의 node_modules 안에서도 실행된다. 자기 위치를
// 앱 루트로 단정하면 그 저장소의 파일이 아니라 패키지 안을 검사하게 된다.
const rootDir = process.env.BRUNNER_APP_DIR || process.cwd();
const SCAN = ["components", "lib", "pages", "server.js"];
const SKIP_DIR = new Set(["node_modules", ".next", ".git", "public"]);

// ECMAScript·Node 내장 전역은 실행 중인 런타임에서 그대로 가져온다.
// 손으로 적으면 Date·Set·Promise 처럼 반드시 빠뜨린다(실제로 빠뜨렸다).
const GLOBALS = new Set(Object.getOwnPropertyNames(globalThis));

// 런타임에 없는 브라우저 전역만 손으로 채운다.
[
  "window", "document", "navigator", "location", "localStorage", "sessionStorage",
  "fetch", "console", "setTimeout", "clearTimeout", "setInterval", "clearInterval",
  "setImmediate", "requestAnimationFrame", "cancelAnimationFrame",
  "alert", "confirm", "prompt", "URL", "URLSearchParams", "Blob", "File",
  "FileReader", "FormData", "Headers", "Request", "Response", "AbortController",
  "AbortSignal", "Image", "Audio", "Event", "CustomEvent", "MouseEvent",
  "KeyboardEvent", "TouchEvent", "MutationObserver", "IntersectionObserver",
  "ResizeObserver", "WebSocket", "Worker", "crypto", "btoa", "atob",
  "performance", "history", "screen", "matchMedia", "getComputedStyle",
  "HTMLElement", "HTMLCanvasElement", "Node", "DOMParser", "TextEncoder",
  "TextDecoder", "structuredClone", "queueMicrotask", "SpeechSynthesisUtterance",
  "speechSynthesis", "MediaRecorder", "AudioContext", "webkitAudioContext",
  "RTCPeerConnection", "Notification", "caches", "indexedDB", "DataTransfer",
  "CanvasRenderingContext2D", "Path2D", "OffscreenCanvas", "ImageData",
  "Range", "Selection", "XMLHttpRequest", "EventSource", "BroadcastChannel",
  "ClipboardItem", "IntersectionObserverEntry", "getSelection", "scrollTo",
  "process", "Buffer", "__dirname", "__filename", "module", "require",
  "exports", "global", "globalThis", "React", "JSX",
].forEach((g) => GLOBALS.add(g));

const walk = (p, out = []) => {
  if (!fs.existsSync(p)) return out;
  if (p.split(path.sep).some((seg) => SKIP_DIR.has(seg))) return out;
  const st = fs.statSync(p);
  if (st.isFile()) {
    if (/\.(js|jsx|mjs|cjs)$/.test(p)) out.push(p);
    return out;
  }
  for (const e of fs.readdirSync(p)) walk(path.join(p, e), out);
  return out;
};

const files = SCAN.flatMap((d) => walk(path.join(rootDir, d)));
const findings = [];
let parsed = 0;

for (const file of files) {
  const code = fs.readFileSync(file, "utf8");
  let ast;
  try {
    ast = parser.parse(code, {
      sourceType: "unambiguous",
      allowReturnOutsideFunction: true,
      plugins: ["jsx", "classProperties", "optionalChaining", "nullishCoalescingOperator", "topLevelAwait", "dynamicImport"],
    });
  } catch (e) {
    findings.push(`${path.relative(rootDir, file).split(path.sep).join("/")}:${e.loc?.line ?? 0}  파싱 실패: ${e.message}`);
    continue;
  }
  parsed += 1;

  traverse(ast, {
    ReferencedIdentifier(p) {
      const name = p.node.name;
      if (GLOBALS.has(name)) return;
      if (p.scope.hasBinding(name, true)) return;
      // JSX 태그 이름 중 소문자는 HTML 요소다(<div> 등).
      if (p.parentPath?.isJSXOpeningElement?.() && /^[a-z]/.test(name)) return;
      findings.push(
        `${path.relative(rootDir, file).split(path.sep).join("/")}:${p.node.loc?.start.line ?? 0}  '${name}' 이(가) 정의되어 있지 않습니다`,
      );
    },
  });
}

console.log("\n=== 정의 없는 식별자 게이트 (목표 0) ===");
console.log(`검사 파일 ${parsed}개`);

// 한 파일도 못 읽었다면 경로가 어긋난 것이다. 조용히 통과시키면 게이트가 무의미하다.
if (parsed === 0) {
  console.error("[undef_gate] 검사된 파일이 0개입니다 — 경로를 확인하세요.");
  process.exit(1);
}

const unique = [...new Set(findings)];
if (unique.length === 0) {
  console.log("위반 0건 ✅");
  process.exit(0);
}
unique.forEach((f) => console.log("   ✗ " + f));
console.log(`\n위반 ${unique.length}건 — 목표 0`);
console.log("전역인데 잡혔다면 이 파일의 GLOBALS 에 추가하세요.");
process.exit(1);
