const fs = require("fs");

const pkg = require("../package.json");

const appBaseUrl = (process.env.APP_BASE_URL || "https://www.brunner.co.kr").replace(/\/+$/, "");
const expectedVersion = process.env.EXPECTED_VERSION || pkg.version;
const expectedCommitSha = process.env.EXPECTED_COMMIT_SHA || "";
const timeoutMs = Number(process.env.TIMEOUT_SECONDS || 600) * 1000;
const intervalMs = Number(process.env.INTERVAL_SECONDS || 20) * 1000;
const githubToken = process.env.GITHUB_TOKEN || "";
const githubRepo = process.env.GITHUB_REPOSITORY || "";
const notifyUser = process.env.WEB_DEPLOY_NOTIFY_USER || "";
const deployIssueTitle = "Railway 배포 완료 알림";

const startedAt = Date.now();
let attempt = 0;
let lastPayload = null;
let lastError = null;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function buildInfoUrl() {
  const url = new URL("/api/build-info", appBaseUrl);
  url.searchParams.set("ts", String(Date.now()));
  return url;
}

function commitMatches(servedCommit) {
  if (!expectedCommitSha || !servedCommit) {
    return true;
  }

  return (
    servedCommit === expectedCommitSha ||
    servedCommit.startsWith(expectedCommitSha) ||
    expectedCommitSha.startsWith(servedCommit)
  );
}

function writeSummary(status, payload) {
  const summaryPath = process.env.GITHUB_STEP_SUMMARY;
  if (!summaryPath) {
    return;
  }

  const rows = [
    "## Web deployment check",
    "",
    `- Status: ${status}`,
    `- URL: ${appBaseUrl}/api/build-info`,
    `- Expected version: ${expectedVersion}`,
    `- Served version: ${payload?.version || "(none)"}`,
    `- Served commit: ${payload?.commitSha || "(none)"}`,
    `- Attempts: ${attempt}`,
    "",
  ];

  fs.appendFileSync(summaryPath, rows.join("\n"));
}

async function fetchGithubJson(url, options = {}) {
  if (!githubToken || !githubRepo) {
    return null;
  }

  const response = await fetch(url, {
    ...options,
    headers: {
      accept: "application/vnd.github+json",
      authorization: `Bearer ${githubToken}`,
      "content-type": "application/json",
      "x-github-api-version": "2022-11-28",
      ...(options.headers || {}),
    },
  });

  const text = await response.text();
  const payload = text ? JSON.parse(text) : null;

  if (!response.ok) {
    throw new Error(`GitHub API ${response.status}: ${text.slice(0, 200)}`);
  }

  return payload;
}

async function findDeployIssue() {
  const issues = await fetchGithubJson(
    `https://api.github.com/repos/${githubRepo}/issues?state=open&per_page=100`
  );

  return (
    issues?.find((issue) => !issue.pull_request && issue.title === deployIssueTitle) || null
  );
}

async function ensureDeployIssue() {
  const existingIssue = await findDeployIssue();
  if (existingIssue) {
    return existingIssue;
  }

  return fetchGithubJson(`https://api.github.com/repos/${githubRepo}/issues`, {
    method: "POST",
    body: JSON.stringify({
      title: deployIssueTitle,
      body: [
        "This issue records when the web deployment is actually served in production.",
        "",
        "- GitHub Actions polls `/api/build-info` after deployable main changes.",
        "- When Railway starts serving the new version, a comment is posted here.",
      ].join("\n"),
    }),
  });
}

async function fetchCommitMessages(sha) {
  if (!sha || !githubToken || !githubRepo) return [];
  try {
    // 해당 SHA 포함 최근 3개 커밋 메시지 가져오기
    const data = await fetchGithubJson(
      `https://api.github.com/repos/${githubRepo}/commits?sha=${sha}&per_page=3`
    );
    if (!Array.isArray(data)) return [];
    return data.map((c) => {
      const msg = c.commit?.message?.split("\n")[0] || "";
      const short = c.sha?.slice(0, 7) || "";
      return `\`${short}\` ${msg}`;
    });
  } catch {
    return [];
  }
}

async function postDeployComment(status, payload) {
  if (!githubToken || !githubRepo) {
    return;
  }

  const issue = await ensureDeployIssue();
  const version = payload?.version || expectedVersion;
  const mention = notifyUser ? `@${notifyUser} ` : "";
  const statusText =
    status === "ready" ? "Railway 배포 완료" : "Railway 배포 감지 타임아웃";

  await fetchGithubJson(
    `https://api.github.com/repos/${githubRepo}/issues/${issue.number}`,
    {
      method: "PATCH",
      body: JSON.stringify({ title: `Railway 배포 완료 알림 [${version}]` }),
    }
  );

  const sha = payload?.commitSha || expectedCommitSha;
  const commitLines = await fetchCommitMessages(sha);
  const commitSection = commitLines.length > 0
    ? ["", "**변경 내용:**", ...commitLines.map((l) => `- ${l}`)]
    : [];

  await fetchGithubJson(
    `https://api.github.com/repos/${githubRepo}/issues/${issue.number}/comments`,
    {
      method: "POST",
      body: JSON.stringify({
        body: [
          `${mention}${statusText}`,
          "",
          `- 버전: **${payload?.version || expectedVersion}**`,
          `- 커밋: \`${sha ? sha.slice(0, 7) : "(none)"}\``,
          `- 빌드 시각: ${payload?.buildTime || "(none)"}`,
          `- 확인 URL: ${appBaseUrl}/api/build-info`,
          ...commitSection,
        ].join("\n"),
      }),
    }
  );
}

async function notifyDeployStatus(status, payload) {
  try {
    await postDeployComment(status, payload);
  } catch (error) {
    console.warn(`GitHub deploy notification failed: ${error.message}`);
  }
}

async function fetchBuildInfo() {
  const response = await fetch(buildInfoUrl(), {
    headers: {
      "cache-control": "no-cache",
      pragma: "no-cache",
    },
  });

  const text = await response.text();
  let payload = null;

  try {
    payload = text ? JSON.parse(text) : null;
  } catch (error) {
    throw new Error(`Invalid JSON from build-info: ${text.slice(0, 200)}`);
  }

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${text.slice(0, 200)}`);
  }

  return payload;
}

async function main() {
  console.log(`Waiting for ${appBaseUrl} to serve version ${expectedVersion}`);

  while (Date.now() - startedAt <= timeoutMs) {
    attempt += 1;

    try {
      lastPayload = await fetchBuildInfo();
      lastError = null;

      const versionOk = lastPayload?.version === expectedVersion;
      const commitOk = commitMatches(lastPayload?.commitSha);

      console.log(
        `[${attempt}] served version=${lastPayload?.version || "(none)"} commit=${
          lastPayload?.commitSha || "(none)"
        } buildTime=${lastPayload?.buildTime || "(none)"}`
      );

      if (versionOk && commitOk) {
        writeSummary("ready", lastPayload);
        await notifyDeployStatus("ready", lastPayload);
        console.log("Web deployment is serving the expected version.");
        return;
      }
    } catch (error) {
      lastError = error;
      console.log(`[${attempt}] ${error.message}`);
    }

    await sleep(intervalMs);
  }

  writeSummary("timeout", lastPayload);
  await notifyDeployStatus("timeout", lastPayload);
  console.error("Timed out waiting for the web deployment.");
  if (lastPayload) {
    console.error(`Last payload: ${JSON.stringify(lastPayload)}`);
  }
  if (lastError) {
    console.error(`Last error: ${lastError.message}`);
  }
  process.exit(1);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
