-- Kakao 인증 및 친구 초대 동적 SQL

-- kakao_id로 유저 조회
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST_BY_KAKAO', 1,
  'SELECT user_id, user_name, email_id, profile_image_src, admin_flag, user_type, register_no, register_name FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND kakao_id = $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- kakao_id로 유저 업데이트
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST_KAKAO_ID', 1,
  'UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = $3 WHERE system_code = $1 AND user_id = $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 자동 생성된 카카오 계정에서 kakao_id 연결 해제
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST_KAKAO_ID', 2,
  'UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = NULL WHERE system_code = $1 AND user_id = $2',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 자동 생성된 카카오 계정의 kakao_id를 기존 일반 사용자 계정으로 단일 SQL 안에서 이관
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST_KAKAO_ID', 3,
  'WITH cleared AS (UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = NULL WHERE system_code = $1 AND user_id = $2 AND kakao_id = $4 RETURNING 1), linked AS (UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = $4 WHERE system_code = $1 AND user_id = $3 AND EXISTS (SELECT 1 FROM cleared) RETURNING user_id, user_name, email_id, profile_image_src, admin_flag, user_type, register_no, register_name) SELECT user_id, user_name, email_id, profile_image_src, admin_flag, user_type, register_no, register_name FROM linked',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- kakao_id 연결과 사용자 조회를 한 번에 처리
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST_KAKAO_ID', 4,
  'UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = $3 WHERE system_code = $1 AND user_id = $2 RETURNING user_id, user_name, email_id, profile_image_src, admin_flag, user_type, register_no, register_name',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- kakao_id가 없는 계정에만 안전하게 kakao_id 연결 (userId 충돌 처리용)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST_KAKAO_ID', 5,
  'UPDATE brunner_template.TB_COR_USER_MST SET kakao_id = $3 WHERE system_code = $1 AND user_id = $2 AND kakao_id IS NULL RETURNING user_id, user_name, email_id, profile_image_src, admin_flag, user_type, register_no, register_name',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Kakao 유저 신규 생성
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_USER_MST_KAKAO', 1,
  'INSERT INTO brunner_template.TB_COR_USER_MST (system_code, user_id, password, user_name, address, phone_number, email_id, use_flag, register_no, user_type, register_name, expire_time, kakao_id) VALUES ($1, $2, $3, $4, $5, $6, $7, ''Y'', $8, $9, $4, $10, $11) ON CONFLICT DO NOTHING',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 친구 초대 생성
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_FRIEND_INVITE', 1,
  'INSERT INTO brunner_template.TB_COR_FRIEND_INVITE (invite_code, system_code, inviter_id) VALUES ($1, $2, $3)',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 친구 초대 조회
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_FRIEND_INVITE', 1,
  'SELECT fi.invite_code, fi.inviter_id, u.user_name as inviter_name, u.profile_image_src as inviter_image FROM brunner_template.TB_COR_FRIEND_INVITE fi JOIN brunner_template.TB_COR_USER_MST u ON fi.system_code = u.system_code AND fi.inviter_id = u.user_id WHERE fi.invite_code = $1 AND fi.system_code = $2 AND fi.expire_at > NOW() AND fi.used_at IS NULL',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- user_id로 카카오 연결 대상 유저 조회
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST', 6,
  'SELECT user_id, user_name, email_id, profile_image_src, admin_flag, user_type, register_no, register_name FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 LIMIT 1',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- email로 기존 계정 자동 연결 조회
-- 한 사람에게 계정 하나. 이미 등록된 계정이 있으면 카카오로 들어와도 새
-- 계정을 만들지 않고 그 계정에 연결한다.
--
-- 예전에는 관리자 계정을 제외했다. 카카오가 확인해 주는 것은 메일 주소뿐이고,
-- 이 앱의 비밀번호 재설정은 전화번호까지 요구하므로, 관리자를 열어 주면
-- 메일 하나만 쥐어도 관리자가 되기 때문이다. 그 대가를 알고 정책상 여는 것이며,
-- 관리자 계정이 이 경로로 연결되면 서버 로그에 남긴다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST', 7,
  'SELECT user_id, user_name, email_id, profile_image_src, admin_flag, user_type, register_no, register_name FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND LOWER(TRIM(email_id)) = LOWER(TRIM($2)) ORDER BY CASE WHEN user_id LIKE ''k%'' THEN 1 ELSE 0 END, user_id LIMIT 1',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 친구 초대 수락 조회 (이미 같은 사용자가 사용한 링크도 양방향 친구 복구 허용)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_FRIEND_INVITE', 2,
  'SELECT fi.invite_code, fi.inviter_id, fi.invitee_id, fi.used_at, u.user_name as inviter_name, u.profile_image_src as inviter_image FROM brunner_template.TB_COR_FRIEND_INVITE fi JOIN brunner_template.TB_COR_USER_MST u ON fi.system_code = u.system_code AND fi.inviter_id = u.user_id WHERE fi.invite_code = $1 AND fi.system_code = $2 AND fi.expire_at > NOW() AND (fi.used_at IS NULL OR fi.invitee_id = $3)',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 친구 초대 사용 처리
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_FRIEND_INVITE', 1,
  'UPDATE brunner_template.TB_COR_FRIEND_INVITE SET used_at = NOW(), invitee_id = $3 WHERE invite_code = $1 AND system_code = $2 AND used_at IS NULL',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 내가 보낸 초대 목록 조회 (상태 포함)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_FRIEND_INVITE_BY_INVITER', 1,
  'SELECT invite_code, invitee_id, used_at, expire_at, created_at FROM brunner_template.TB_COR_FRIEND_INVITE WHERE system_code = $1 AND inviter_id = $2 ORDER BY created_at DESC LIMIT 10',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
