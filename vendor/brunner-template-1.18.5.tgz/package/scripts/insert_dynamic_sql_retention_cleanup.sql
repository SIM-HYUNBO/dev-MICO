-- 보관기간 정리 실행부(lib/tableRetentionCleanup.js)가 쓰는 동적 SQL.
--
-- 왜 여기로 옮겼나
--   이 시스템의 공통 규칙은 모든 DB 쿼리를 TB_COR_SQL_INFO 에 등록해 쓰는 것이다.
--
-- 여기로 옮기지 못한 두 곳
--   1) 퍼지 인덱스 생성(CREATE INDEX CONCURRENTLY) — 인덱스명·테이블·컬럼이 모두
--      런타임 계산값이다. 식별자는 파라미터로 넘길 수 없다.
--   2) 실제 삭제(WITH victims ... DELETE) — 대상 테이블과 날짜 컬럼이 정책마다
--      다르고 테넌트 조건도 붙었다 빠졌다 한다. 고정 본문이 성립하지 않는다.
--   두 곳 모두 그 자리에 왜 예외인지 적어 두었다.
--
--   테이블에 system_code 컬럼이 있는지 보는 조회는 새로 만들지 않고
--   select_TB_COR_SYSTEM_CODE_COLUMN 을 그대로 쓴다. 본문이 같다.
--
-- 왜 테넌트를 돌며 심나
--   getSQL 은 {systemCode}_{name}_{seq} 로만 찾고 '00' 으로 폴백하지 않는다.
--
-- 본문은 한 글자도 바꾸지 않았다.
DO $seed$
DECLARE
  t    text;
  defs constant text[][] := ARRAY[
    -- 퍼지 대상 테넌트 목록. 사용자 테이블에 실제로 있는 시스템코드
    ['select_TB_COR_USER_MST','9',
     'SELECT DISTINCT system_code
         FROM brunner_template.TB_COR_USER_MST
        WHERE system_code IS NOT NULL
        ORDER BY system_code'],
    -- 정책 행에 마지막 실행 결과를 남긴다
    ['update_TB_COR_TABLE_RETENTION_POLICY','1',
     'UPDATE brunner_template.TB_COR_TABLE_RETENTION_POLICY
        SET last_run_at = NOW(),
            last_deleted_count = $1,
            last_error = $2,
            update_time = NOW()
      WHERE system_code = $3 AND table_name = $4'],
    -- 정리 실행 이력 한 건
    ['insert_TB_COR_TABLE_RETENTION_RUN_HIST','1',
     'INSERT INTO brunner_template.TB_COR_TABLE_RETENTION_RUN_HIST
         (system_code, table_name, date_column, retention_days, batch_size, max_delete_per_run,
          deleted_count, limited, error_message, trigger_type, run_started_at, run_finished_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, NOW())'],
    -- 실행할 정책. 날짜 컬럼이 실재하는 행만, 테넌트 구분 가능 여부까지
    ['select_TB_COR_TABLE_RETENTION_POLICY','2',
     'SELECT p.system_code, p.table_name, p.date_column, p.retention_days,
            p.batch_size, p.max_delete_per_run, p.enabled,
            EXISTS (
              SELECT 1 FROM information_schema.columns sc
               WHERE sc.table_schema = $1
                 AND sc.table_name = p.table_name
                 AND sc.column_name = ''system_code''
            ) AS tenant_scoped
       FROM brunner_template.TB_COR_TABLE_RETENTION_POLICY p
       JOIN information_schema.columns c
         ON c.table_schema = $1
        AND c.table_name = p.table_name
        AND c.column_name = p.date_column
        AND c.data_type IN (''timestamp without time zone'',''timestamp with time zone'',''date'')
      WHERE ($2::text IS NULL OR p.table_name = $2)
      ORDER BY p.table_name, p.system_code']
  ];
  i int;
BEGIN
  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
      UNION SELECT '00'
    ) x ORDER BY code
  LOOP
    FOR i IN 1 .. array_length(defs, 1) LOOP
      INSERT INTO brunner_template.TB_COR_SQL_INFO
        (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
      VALUES (t, defs[i][1], defs[i][2]::int, defs[i][3], 'claude', NOW())
      ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
      DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
    END LOOP;
  END LOOP;
END
$seed$;
