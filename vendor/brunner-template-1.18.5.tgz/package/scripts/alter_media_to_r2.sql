-- 미디어 바이트를 Postgres 볼륨에서 R2로 옮기기 위한 스키마 보정.
-- (프로필 사진 base64, 커스텀 이모지 BYTEA 가 DB 용량을 직접 먹고, 매 pg_dump 백업에도
--  통째로 딸려 들어간다. base64 는 원본보다 33% 크다.)

-- 1) 프로필 사진 ------------------------------------------------------------
-- 이 컬럼이 담는 값의 실제 역할은 처음부터 "base64"가 아니라 "<img src> 에 넣을
-- 문자열"이었다. R2 로 옮기면 여기에 data URL 대신 서빙 경로가 들어가므로,
-- 이름을 내용에 맞게 바로잡는다. 바이트 자체는 PROFILE_IMAGE_KEY 가 가리킨다.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'zicp' AND table_name = 'tb_cor_user_mst'
      AND column_name = 'profile_image_base64'
  ) THEN
    ALTER TABLE brunner_template.TB_COR_USER_MST RENAME COLUMN PROFILE_IMAGE_BASE64 TO PROFILE_IMAGE_SRC;
  END IF;
END $$;

-- 새로 만든 DB 는 create_core_tables.sql 이 이미 SRC 로 만들어 두므로 위 rename 이
-- 돌지 않는다. 어느 경로로 왔든 컬럼이 있도록 보장한다.
ALTER TABLE brunner_template.TB_COR_USER_MST
  ADD COLUMN IF NOT EXISTS PROFILE_IMAGE_SRC TEXT;

ALTER TABLE brunner_template.TB_COR_USER_MST
  ADD COLUMN IF NOT EXISTS PROFILE_IMAGE_KEY VARCHAR(500);

COMMENT ON COLUMN brunner_template.TB_COR_USER_MST.PROFILE_IMAGE_SRC IS
  '프로필 사진을 화면에 표시할 때 <img src> 에 그대로 넣는 문자열. R2 저장분은 서빙 경로, 이관 전 옛 행은 data URL.';
COMMENT ON COLUMN brunner_template.TB_COR_USER_MST.PROFILE_IMAGE_KEY IS
  'R2 오브젝트 키. 값이 있으면 사진 본문은 R2 에 있고 PROFILE_IMAGE_SRC 는 서빙 경로다.';

-- 2) 커스텀 이모지 ----------------------------------------------------------
ALTER TABLE brunner_template.TB_COR_CHAT_CUSTOM_EMOJI
  ADD COLUMN IF NOT EXISTS R2_KEY VARCHAR(500);

-- R2 로 옮기면 파일 본문은 비므로 NOT NULL 을 푼다(채팅 첨부와 같은 방식).
ALTER TABLE brunner_template.TB_COR_CHAT_CUSTOM_EMOJI
  ALTER COLUMN FILE_DATA DROP NOT NULL;

COMMENT ON COLUMN brunner_template.TB_COR_CHAT_CUSTOM_EMOJI.R2_KEY IS
  'R2 오브젝트 키. 값이 있으면 FILE_DATA 는 비어 있고 본문은 R2 에 있다.';
