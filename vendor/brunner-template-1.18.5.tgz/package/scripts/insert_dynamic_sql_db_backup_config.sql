-- DB 백업 설정 동적 SQL. 스키마 안의 모든 테넌트에 심는다.
DO $seed$
DECLARE
  t    text;
  defs constant text[][] := ARRAY[
    ['select_TB_COR_DB_BACKUP_CONFIG',
     'SELECT system_code, enabled, run_at, interval_hours, timezone_offset_minutes, update_user_id, update_time FROM brunner_template.TB_COR_DB_BACKUP_CONFIG WHERE system_code = $1'],
    ['update_TB_COR_DB_BACKUP_CONFIG',
     'UPDATE brunner_template.TB_COR_DB_BACKUP_CONFIG SET enabled = $2, run_at = $3, interval_hours = $4, timezone_offset_minutes = $5, update_user_id = $6, update_time = NOW() WHERE system_code = $1'],
    -- 락: 이미 잡혀 있으면 아무 행도 갱신되지 않아 그 인스턴스는 이번 회차를 건너뛴다.
    ['update_TB_COR_DB_BACKUP_CONFIG_lock',
     'UPDATE brunner_template.TB_COR_DB_BACKUP_CONFIG SET lock_owner = $2, lock_until = NOW() + ($3 || '' minutes'')::interval WHERE system_code = $1 AND (lock_until IS NULL OR lock_until < NOW())'],
    ['update_TB_COR_DB_BACKUP_CONFIG_unlock',
     'UPDATE brunner_template.TB_COR_DB_BACKUP_CONFIG SET lock_owner = NULL, lock_until = NULL WHERE system_code = $1 AND lock_owner = $2']
  ];
  i int;
BEGIN
  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
      UNION SELECT '00'
    ) x ORDER BY code
  LOOP
    FOR i IN 1 .. array_length(defs, 1) LOOP
      INSERT INTO brunner_template.TB_COR_SQL_INFO
        (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
      VALUES (t, defs[i][1], 1, defs[i][2], 'claude', NOW())
      ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
      DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
    END LOOP;
  END LOOP;
END
$seed$;
