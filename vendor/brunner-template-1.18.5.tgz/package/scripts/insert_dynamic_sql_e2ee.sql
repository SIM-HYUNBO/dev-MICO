-- E2EE 비밀채팅 동적 SQL 등록

-- [0] 두 사용자가 함께 있는 일반(비밀 아닌) 1:1 채팅방 조회 — is_secret=FALSE 필터 명시
-- select_TB_COR_CHATROOM_USERS seq=3
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_USERS', 3,
  'SELECT r.id AS room_id, r.name AS room_name FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND COALESCE(r.is_secret, FALSE) = FALSE AND COALESCE(r.room_type, ''GROUP'') = ''DIRECT'' AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2) AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id AND u.user_id = $3) ORDER BY r.id LIMIT 1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [1] 채팅방 목록에 is_secret 포함 (getChatRoomList 보완용)
-- select_TB_COR_CHATROOM_MST seq=2
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_MST', 2,
  'SELECT r.id, COALESCE(r.is_secret, FALSE) AS is_secret FROM brunner_template.TB_COR_CHATROOM_MST r INNER JOIN brunner_template.TB_COR_CHATROOM_USERS u ON u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2 WHERE r.system_code = $1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [2] 사용자 공개키 저장 (UPSERT)
-- upsert_TB_COR_USER_MST_pubkey seq=1
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'upsert_TB_COR_USER_MST_pubkey', 1,
  'UPDATE brunner_template.TB_COR_USER_MST SET public_key = $1 WHERE system_code = $2 AND user_id = $3',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [3] 사용자 공개키 조회
-- select_TB_COR_USER_MST_pubkey seq=1
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST_pubkey', 1,
  'SELECT public_key FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 LIMIT 1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [4] 비밀채팅방 조회 — 1:1 방 이름의 두 사용자 조합이 맞으면 나간 멤버도 재입장용으로 탐색
-- select_TB_COR_CHATROOM_USERS seq=4
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_USERS', 4,
  'SELECT r.id AS room_id, r.name AS room_name FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND COALESCE(r.is_secret, FALSE) = TRUE AND COALESCE(r.room_type, ''GROUP'') = ''DIRECT'' AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2) AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id AND u.user_id = $3) ORDER BY r.id LIMIT 1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [5] 비밀채팅방 생성 (is_secret=TRUE)
-- insert_TB_COR_CHATROOM_MST seq=2
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHATROOM_MST', 2,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type) VALUES ($1, $2, $3, $4, TRUE, ''GROUP'') ON CONFLICT DO NOTHING',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [6] 멤버별 암호화된 룸키 저장 (단체 비밀방)
-- upsert_TB_COR_CHATROOM_MEMBER_KEY seq=1
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'upsert_TB_COR_CHATROOM_MEMBER_KEY', 1,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_MEMBER_KEY (system_code, room_id, user_id, encrypted_key, key_provider_id) VALUES ($1, $2::uuid, $3, $4, $5) ON CONFLICT (system_code, room_id, user_id) DO UPDATE SET encrypted_key = EXCLUDED.encrypted_key, key_provider_id = EXCLUDED.key_provider_id',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [7] 멤버별 암호화된 룸키 조회
-- select_TB_COR_CHATROOM_MEMBER_KEY seq=1
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_MEMBER_KEY', 1,
  'SELECT encrypted_key, key_provider_id FROM brunner_template.TB_COR_CHATROOM_MEMBER_KEY WHERE system_code = $1 AND room_id = $2::uuid AND user_id = $3 LIMIT 1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'upsert_TB_COR_USER_E2EE_DEVICE_KEY', 1,
  'INSERT INTO brunner_template.TB_COR_USER_E2EE_DEVICE_KEY (system_code, user_id, device_id, public_key, updated_at) VALUES ($1, $2, $3, $4, NOW()) ON CONFLICT (system_code, user_id, device_id) DO UPDATE SET public_key = EXCLUDED.public_key, updated_at = NOW()',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_E2EE_DEVICE_KEY', 1,
  'SELECT device_id, public_key FROM brunner_template.TB_COR_USER_E2EE_DEVICE_KEY WHERE system_code = $1 AND user_id = $2 AND ($3::varchar IS NULL OR device_id = $3) ORDER BY updated_at DESC',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'upsert_TB_COR_CHATROOM_MEMBER_DEVICE_KEY', 1,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_MEMBER_DEVICE_KEY (system_code, room_id, user_id, device_id, encrypted_key, key_provider_id, key_provider_device_id, updated_at) VALUES ($1, $2::uuid, $3, $4, $5, $6, $7, NOW()) ON CONFLICT (system_code, room_id, user_id, device_id) DO UPDATE SET encrypted_key = EXCLUDED.encrypted_key, key_provider_id = EXCLUDED.key_provider_id, key_provider_device_id = EXCLUDED.key_provider_device_id, updated_at = NOW()',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_MEMBER_DEVICE_KEY', 1,
  'SELECT encrypted_key, key_provider_id, key_provider_device_id FROM brunner_template.TB_COR_CHATROOM_MEMBER_DEVICE_KEY WHERE system_code = $1 AND room_id = $2::uuid AND user_id = $3 AND device_id = $4 LIMIT 1',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [룸키 직접 저장] upsert_TB_COR_CHATROOM_ROOM_KEY seq=1
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'upsert_TB_COR_CHATROOM_ROOM_KEY', 1,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_ROOM_KEY (system_code, room_id, room_key_b64, updated_at) VALUES ($1, $2::uuid, $3, NOW()) ON CONFLICT (system_code, room_id) DO UPDATE SET room_key_b64 = EXCLUDED.room_key_b64, updated_at = NOW()',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [룸키 직접 조회] select_TB_COR_CHATROOM_ROOM_KEY seq=1
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_ROOM_KEY', 1,
  'SELECT r.room_key_b64 FROM brunner_template.TB_COR_CHATROOM_ROOM_KEY r JOIN brunner_template.TB_COR_CHATROOM_USERS u ON r.system_code = u.system_code AND r.room_id = u.room_id WHERE r.system_code = $1 AND r.room_id = $2::uuid AND u.user_id = $3 LIMIT 1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [룸키 후보 저장] upsert_TB_COR_CHATROOM_ROOM_KEY_HISTORY seq=1
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'upsert_TB_COR_CHATROOM_ROOM_KEY_HISTORY', 1,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_ROOM_KEY_HISTORY (system_code, room_id, key_hash, room_key_b64, updated_at) VALUES ($1, $2::uuid, md5($3), $3, NOW()) ON CONFLICT (system_code, room_id, key_hash) DO UPDATE SET updated_at = NOW()',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [룸키 후보 조회] select_TB_COR_CHATROOM_ROOM_KEY_HISTORY seq=1
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_ROOM_KEY_HISTORY', 1,
  'SELECT h.room_key_b64 FROM brunner_template.TB_COR_CHATROOM_ROOM_KEY_HISTORY h JOIN brunner_template.TB_COR_CHATROOM_USERS u ON h.system_code = u.system_code AND h.room_id = u.room_id WHERE h.system_code = $1 AND h.room_id = $2::uuid AND u.user_id = $3 ORDER BY h.updated_at DESC',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
