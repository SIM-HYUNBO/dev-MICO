-- R2 저장용 insert (file_data 없음, r2_key 저장)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHAT_FILE', 2,
  'INSERT INTO brunner_template.TB_COR_CHAT_FILE (system_code, id, room_id, sender_id, file_name, mime_type, file_size, r2_key) VALUES ($1, $2::uuid, $3::uuid, $4, $5, $6, $7, $8)',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- r2_key 포함 조회
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHAT_FILE', 2,
  'SELECT mime_type, file_size, file_name, file_data, r2_key FROM brunner_template.TB_COR_CHAT_FILE WHERE system_code = $1 AND id = $2::uuid',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
