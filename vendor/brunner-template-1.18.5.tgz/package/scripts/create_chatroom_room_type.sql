-- 채팅방 종류 고정값 추가: DIRECT(1:1) / GROUP(단체방)
ALTER TABLE brunner_template.TB_COR_CHATROOM_MST
  ADD COLUMN IF NOT EXISTS room_type VARCHAR(20) DEFAULT 'GROUP';

UPDATE brunner_template.TB_COR_CHATROOM_MST
SET room_type = 'DIRECT'
WHERE name LIKE '%◁▷%';

UPDATE brunner_template.TB_COR_CHATROOM_MST
SET room_type = 'GROUP'
WHERE room_type IS NULL
   OR room_type NOT IN ('DIRECT', 'GROUP');

ALTER TABLE brunner_template.TB_COR_CHATROOM_MST
  ALTER COLUMN room_type SET DEFAULT 'GROUP';
