-- 채팅 목록/안읽음 조회 성능 개선 인덱스
-- 메시지 무제한 보관으로 누적되며 채팅방 목록(MAX created_at)·안읽음 집계(전체 메시지 조인)가 느려지는 문제 대응.
-- 쿼리는 그대로 두고 조인/정렬에 맞는 인덱스만 추가한다. 모두 IF NOT EXISTS(1회 생성).

-- 채팅방 목록: 방별 마지막 메시지 시각 MAX(created_at) 및 정렬
CREATE INDEX IF NOT EXISTS IDX_CHAT_MSG_ROOM_CREATED
  ON brunner_template.TB_COR_CHAT_MSG (system_code, room_id, created_at DESC);

-- 안읽음 집계: 방별 타인 메시지 조인(user_id 필터)
CREATE INDEX IF NOT EXISTS IDX_CHAT_MSG_ROOM_USER
  ON brunner_template.TB_COR_CHAT_MSG (system_code, room_id, user_id);

-- 안읽음 집계: 읽음이력 LEFT JOIN(rr.user_id + rr.message_id로 매칭, rr.message_id IS NULL 판정)
CREATE INDEX IF NOT EXISTS IDX_READ_RECEIPT_USER_MSG
  ON brunner_template.TB_COR_CHAT_READ_RECEIPT (system_code, user_id, message_id);
