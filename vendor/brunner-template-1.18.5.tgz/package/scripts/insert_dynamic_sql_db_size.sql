-- DB 전체 용량 조회(볼륨 사용량 자동 경보용). 시스템 함수라 파라미터 없음.
--
-- 왜 테넌트를 돌며 심나
--   getSQL 은 {systemCode}_{name}_{seq} 로만 찾고 '00' 으로 폴백하지 않는다.
--   '00' 에만 심어 두면 SYSTEM_CODE 가 '00' 이 아닌 시스템에서는 용량 경보와
--   관리자 적재량 화면이 조용히 죽는다.
DO $seed$
DECLARE
  t    text;
  defs constant text[][] := ARRAY[
    ['select_TB_COR_DB_SIZE','1',
     'SELECT pg_database_size(current_database()) AS bytes']
  ];
  i int;
BEGIN
  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
      UNION SELECT '00'
    ) x ORDER BY code
  LOOP
    FOR i IN 1 .. array_length(defs, 1) LOOP
      INSERT INTO brunner_template.TB_COR_SQL_INFO
        (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
      VALUES (t, defs[i][1], defs[i][2]::int, defs[i][3], 'claude', NOW())
      ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
      DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
    END LOOP;
  END LOOP;
END
$seed$;
