-- 채팅방 목록에 last_message_at 추가 + 최근 메시지 순 정렬
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_MST', 1,
  'SELECT r.id, r.name, r.created_by, COALESCE(r.is_secret, FALSE) AS is_secret, (SELECT COUNT(*) FROM brunner_template.TB_COR_CHATROOM_USERS u2 WHERE u2.system_code = $1 AND u2.room_id = r.id) AS member_count, (SELECT MAX(m.created_at) FROM brunner_template.TB_COR_CHAT_MSG m WHERE m.system_code = $1 AND m.room_id = r.id) AS last_message_at FROM brunner_template.TB_COR_CHATROOM_MST r INNER JOIN brunner_template.TB_COR_CHATROOM_USERS u ON u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2 WHERE r.system_code = $1 ORDER BY last_message_at DESC NULLS LAST, r.name ASC',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
