-- 관리자 DB 적재량/보존정책 화면(pages/api/biz/dbUsage.js)이 쓰는 동적 SQL.
--
-- 왜 여기로 옮겼나
--   이 화면은 쿼리를 코드에 문자열로 들고 있었다. 이 시스템의 공통 규칙은 모든
--   DB 쿼리를 TB_COR_SQL_INFO 에 등록해 쓰는 것이다. 코드에 박혀 있으면 배포 없이
--   고칠 수 없고, 같은 쿼리가 크론과 화면에 따로 존재하게 된다(실제로 DB 용량
--   조회가 크론은 동적 SQL, 화면은 하드코딩으로 갈려 있었다).
--
-- 왜 테넌트를 돌며 심나
--   getSQL 은 {systemCode}_{name}_{seq} 로만 찾고 '00' 으로 폴백하지 않는다.
--   '00' 에만 심으면 SYSTEM_CODE 가 다른 시스템에서는 이 화면이 통째로 죽는다.
--
-- 본문은 그대로 옮겼다. 딱 하나, 이력 조회의 LIMIT 는 코드가 상수를 문자열에
-- 끼워 넣던 자리라 $3 파라미터로 바꿨다 — 상수를 본문에 굳히면 값을 바꿀 때
-- 다시 시드를 심어야 한다. 스키마는 run_sql.cjs 의 retargetSchema 가 배포마다
-- 실제 DB_SCHEMA 로 바꿔 넣는다.
DO $seed$
DECLARE
  t    text;
  defs constant text[][] := ARRAY[
    -- 스키마 안에서 보존정책을 걸 수 있는 날짜 컬럼 목록
    ['select_TB_COR_DATE_COLUMN','1',
     'SELECT table_name, column_name
       FROM information_schema.columns
      WHERE table_schema = $1
        AND data_type IN (''timestamp without time zone'',''timestamp with time zone'',''date'')
      ORDER BY table_name, ordinal_position'],
    -- 고른 테이블/컬럼이 실제로 날짜 컬럼인지 확인
    ['select_TB_COR_DATE_COLUMN','2',
     'SELECT 1
       FROM information_schema.columns
      WHERE table_schema = $1
        AND table_name = $2
        AND column_name = $3
        AND data_type IN (''timestamp without time zone'',''timestamp with time zone'',''date'')'],
    -- 그 테이블에 system_code 컬럼이 있는지 확인(테넌트 경계)
    ['select_TB_COR_SYSTEM_CODE_COLUMN','1',
     'SELECT 1
         FROM information_schema.columns
        WHERE table_schema = $1 AND table_name = $2 AND column_name = ''system_code'''],
    -- 테이블별 적재량(크기·행수). 관리자 DB 적재량 화면
    ['select_TB_COR_TABLE_USAGE','1',
     'SELECT c.relname AS table_name,
            obj_description(c.oid, ''pg_class'') AS table_description,
            pg_total_relation_size(c.oid) AS total_bytes,
            pg_size_pretty(pg_total_relation_size(c.oid)) AS total_size,
            GREATEST(COALESCE(s.n_live_tup, c.reltuples::bigint), 0) AS approx_rows
       FROM pg_class c
       JOIN pg_namespace n ON n.oid = c.relnamespace
       LEFT JOIN pg_stat_all_tables s ON s.relid = c.oid
      WHERE n.nspname = $1
        AND c.relkind IN (''r'', ''p'')
      ORDER BY pg_total_relation_size(c.oid) DESC'],
    -- 자기 시스템의 보존정책 목록
    ['select_TB_COR_TABLE_RETENTION_POLICY','1',
     'SELECT system_code, table_name, date_column, retention_days, enabled,
              recommendation_level, recommendation_reason,
              last_run_at, last_deleted_count, last_error
         FROM brunner_template.TB_COR_TABLE_RETENTION_POLICY
        WHERE system_code = $1
        ORDER BY table_name'],
    -- 보존정책 저장. 언제나 자기 시스템 행
    ['upsert_TB_COR_TABLE_RETENTION_POLICY','1',
     'INSERT INTO brunner_template.TB_COR_TABLE_RETENTION_POLICY
       (system_code, table_name, date_column, retention_days, enabled, update_user_id, update_time)
     VALUES ($1, $2, $3, $4, $5, $6, NOW())
     ON CONFLICT (system_code, table_name) DO UPDATE SET
       date_column = EXCLUDED.date_column,
       retention_days = EXCLUDED.retention_days,
       enabled = EXCLUDED.enabled,
       update_user_id = EXCLUDED.update_user_id,
       update_time = NOW()'],
    -- 자기 시스템의 정리 실행 시각 설정
    ['select_TB_COR_TABLE_RETENTION_CONFIG','1',
     'SELECT system_code, run_at, timezone_offset_minutes
         FROM brunner_template.TB_COR_TABLE_RETENTION_CONFIG
        WHERE system_code = $1
        LIMIT 1'],
    -- 정리 실행 시각 저장. 퍼지 락도 이 행에 걸린다
    ['upsert_TB_COR_TABLE_RETENTION_CONFIG','1',
     'INSERT INTO brunner_template.TB_COR_TABLE_RETENTION_CONFIG
       (system_code, id, run_at, timezone_offset_minutes, update_user_id, update_time)
     VALUES ($1, ''default'', $2, $3, $4, NOW())
     ON CONFLICT (system_code) DO UPDATE SET
       run_at = EXCLUDED.run_at,
       timezone_offset_minutes = EXCLUDED.timezone_offset_minutes,
       update_user_id = EXCLUDED.update_user_id,
       update_time = NOW()'],
    -- 최근 정리 실행 이력. $1=일수, $2=시스템코드, $3=최대 행수
    ['select_TB_COR_TABLE_RETENTION_RUN_HIST','1',
     'SELECT run_id, system_code, table_name, date_column, retention_days, batch_size, max_delete_per_run,
              deleted_count, limited, error_message, trigger_type, run_started_at, run_finished_at
         FROM brunner_template.TB_COR_TABLE_RETENTION_RUN_HIST
        WHERE run_started_at >= NOW() - ($1 || '' days'')::INTERVAL
          AND system_code = $2
        ORDER BY run_started_at DESC, run_id DESC
        LIMIT $3']
  ];
  i int;
BEGIN
  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
      UNION SELECT '00'
    ) x ORDER BY code
  LOOP
    FOR i IN 1 .. array_length(defs, 1) LOOP
      INSERT INTO brunner_template.TB_COR_SQL_INFO
        (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
      VALUES (t, defs[i][1], defs[i][2]::int, defs[i][3], 'claude', NOW())
      ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
      DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
    END LOOP;
  END LOOP;
END
$seed$;
