-- 채팅 기반 테이블
--
-- 원본(brunner-next)에는 이 테이블들을 만드는 스크립트가 없다. 운영 DB 에 수동으로
-- 만들어진 뒤 스크립트로 남지 않은 것으로 보인다. create_chatroom_room_type.sql 이
-- TB_COR_CHATROOM_MST 를 ALTER 하는데 정작 CREATE 가 없어, 신규 DB 부트스트랩이
-- 5번째 파일에서 멈춘다.
--
-- 컬럼은 동적 SQL 정의(insert_dynamic_sql_*.sql)의 INSERT/SELECT 목록과
-- 인덱스 정의(create_chat_*_indexes.sql)에서 역추적했다.

-- ------------------------------------------------------------------
-- 채팅방
-- ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHATROOM_MST (
  SYSTEM_CODE  VARCHAR(2)   NOT NULL,
  ID           UUID         NOT NULL DEFAULT gen_random_uuid(),
  NAME         VARCHAR(200),
  CREATED_BY   VARCHAR(100),
  IS_SECRET    BOOLEAN      DEFAULT FALSE,   -- 비밀방(E2EE)
  ROOM_TYPE    VARCHAR(20),                  -- DIRECT / GROUP / OPEN
  CREATED_AT   TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, ID)
);

-- ------------------------------------------------------------------
-- 방 참여자
-- ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHATROOM_USERS (
  SYSTEM_CODE  VARCHAR(2)   NOT NULL,
  ROOM_ID      UUID         NOT NULL,
  USER_ID      VARCHAR(100) NOT NULL,
  CREATED_AT   TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, ROOM_ID, USER_ID)
);

CREATE INDEX IF NOT EXISTS IDX_CHATROOM_USERS_USER
  ON brunner_template.TB_COR_CHATROOM_USERS (SYSTEM_CODE, USER_ID);

-- ------------------------------------------------------------------
-- 메시지
-- ------------------------------------------------------------------
-- MESSAGE 는 비밀방에서 암호화된 문자열이 들어간다(lib/chatEncryption.js).
-- 삭제는 행을 지우지 않고 MESSAGE 를 NULL 로 만든다 — 읽음 이력이 참조하기 때문.
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHAT_MSG (
  SYSTEM_CODE  VARCHAR(2)   NOT NULL,
  MSG_ID       BIGSERIAL    NOT NULL,
  ROOM_ID      UUID         NOT NULL,
  USER_ID      VARCHAR(100) NOT NULL,
  USER_NAME    VARCHAR(100),                  -- 발신 시점 이름을 함께 남긴다
  MESSAGE      TEXT,
  -- 답장 원문 정보를 JSON 문자열로 담는다. chatroom.js 가 읽을 때
  -- JSON.parse 하므로 숫자 id 하나가 아니라 객체 전체가 들어온다.
  REPLY_TO     TEXT,
  CREATED_AT   TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, MSG_ID)
);

-- ------------------------------------------------------------------
-- 읽음 이력
-- ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHAT_READ_RECEIPT (
  SYSTEM_CODE  VARCHAR(2)   NOT NULL,
  ROOM_ID      UUID         NOT NULL,
  MESSAGE_ID   BIGINT       NOT NULL,
  USER_ID      VARCHAR(100) NOT NULL,
  READ_AT      TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, ROOM_ID, MESSAGE_ID, USER_ID)
);

-- ------------------------------------------------------------------
-- 트랜잭션 이력 (backendServer 가 요청/응답을 남긴다)
-- ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_TXN_HIST (
  SYSTEM_CODE             VARCHAR(2)   NOT NULL,
  TRANSACTION_ID          VARCHAR(64)  NOT NULL,
  REQUEST_IP              VARCHAR(100),
  REQUEST_MESSAGE_CONTENT TEXT,
  REPLY_MESSAGE_CONTENT   TEXT,
  CREATE_TIME             TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, TRANSACTION_ID)
);

CREATE INDEX IF NOT EXISTS IDX_TXN_HIST_TIME
  ON brunner_template.TB_COR_TXN_HIST (SYSTEM_CODE, CREATE_TIME DESC);

-- ------------------------------------------------------------------
-- eDoc 문서
-- ------------------------------------------------------------------
-- PAGES / RUNTIME_DATA 는 문서 디자이너가 만든 구조를 JSON 으로 담는다.
-- MENU_PATH 가 있으면 드롭다운 메뉴에 자동으로 붙는다(dropdownMenuitem.js).
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_EDOC_DOCUMENT (
  SYSTEM_CODE  VARCHAR(2)   NOT NULL,
  ID           VARCHAR(64)  NOT NULL,
  TITLE        VARCHAR(300),
  DESCRIPTION  TEXT,
  VERSION      INT          DEFAULT 1,
  PAGES        JSONB,
  RUNTIME_DATA JSONB,
  MENU_PATH    VARCHAR(200),
  CREATED_BY   VARCHAR(100),
  CREATED_AT   TIMESTAMP    DEFAULT NOW(),
  UPDATED_BY   VARCHAR(100),
  UPDATED_AT   TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, ID)
);

CREATE INDEX IF NOT EXISTS IDX_TB_COR_EDOC_DOCUMENT_MENU
  ON brunner_template.TB_COR_EDOC_DOCUMENT (SYSTEM_CODE, MENU_PATH);

-- 이미 BIGINT 로 만들어진 DB 보정
ALTER TABLE brunner_template.TB_COR_CHAT_MSG
  ALTER COLUMN REPLY_TO TYPE TEXT USING REPLY_TO::text;
