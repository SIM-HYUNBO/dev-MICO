-- TB_COR_CHAT_REACTION.EMOJI 컬럼 길이 확장 (커스텀 이모지 포맷 '[custom-emoji:{uuid}]' 지원)
ALTER TABLE brunner_template.TB_COR_CHAT_REACTION ALTER COLUMN EMOJI TYPE VARCHAR(100);
