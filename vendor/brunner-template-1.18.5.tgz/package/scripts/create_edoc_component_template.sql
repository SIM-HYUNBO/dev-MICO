-- 문서 디자이너 컴포넌트 팔레트
--
-- 원본(brunner-next)에는 이 테이블을 만드는 스크립트도, 조회 동적 SQL 도 없었다.
-- 운영 DB 에 수동으로 들어간 뒤 스크립트로 남지 않은 것으로 보인다. 그 상태로는
-- 문서 디자이너에 들어가는 순간 select_TB_COR_EDOC_COMPONENT 을 찾지
-- 못해 "Database operation failed." 만 뜨고 팔레트가 비어 있게 된다.
-- 코드가 읽는 필드(id, type, template_json.type)를 근거로 복원했다.

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_EDOC_COMPONENT (
  SYSTEM_CODE    VARCHAR(2)   NOT NULL,
  ID             VARCHAR(64)  NOT NULL,
  TYPE           VARCHAR(40)  NOT NULL,
  TEMPLATE_JSON  JSONB        NOT NULL,
  SORT_ORDER     INT          DEFAULT 0,
  CREATE_USER_ID VARCHAR(100),
  CREATE_TIME    TIMESTAMP    DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, ID)
);

ALTER TABLE brunner_template.TB_COR_EDOC_COMPONENT
  ADD COLUMN IF NOT EXISTS SORT_ORDER INT DEFAULT 0;

-- 팔레트 항목. type 은 lib/constants.js 의 edocComponentType 과 정확히 같아야
-- 한다 — handleAddComponent 가 template_json.type 으로 분기하기 때문에, 철자가
-- 어긋나면 그 항목만 아무 동작도 하지 않는다.
INSERT INTO brunner_template.TB_COR_EDOC_COMPONENT
  (SYSTEM_CODE, ID, TYPE, TEMPLATE_JSON, SORT_ORDER, CREATE_USER_ID)
VALUES
  ('00', 'tpl_text',      'Text',      '{"type":"Text"}'::jsonb,      10, 'SYSTEM'),
  ('00', 'tpl_table',     'Table',     '{"type":"Table"}'::jsonb,     20, 'SYSTEM'),
  ('00', 'tpl_image',     'Image',     '{"type":"Image"}'::jsonb,     30, 'SYSTEM'),
  ('00', 'tpl_input',     'Input',     '{"type":"Input"}'::jsonb,     40, 'SYSTEM'),
  ('00', 'tpl_checklist', 'Checklist', '{"type":"Checklist"}'::jsonb, 50, 'SYSTEM'),
  ('00', 'tpl_button',    'Button',    '{"type":"Button"}'::jsonb,    60, 'SYSTEM'),
  ('00', 'tpl_video',     'Video',     '{"type":"Video"}'::jsonb,     70, 'SYSTEM'),
  ('00', 'tpl_linktext',  'LinkText',  '{"type":"LinkText"}'::jsonb,  80, 'SYSTEM'),
  ('00', 'tpl_lottie',    'Lottie',    '{"type":"Lottie"}'::jsonb,    90, 'SYSTEM'),
  ('00', 'tpl_card',      'Card',      '{"type":"Card"}'::jsonb,     100, 'SYSTEM')
ON CONFLICT (SYSTEM_CODE, ID) DO UPDATE
  SET TYPE = EXCLUDED.TYPE,
      TEMPLATE_JSON = EXCLUDED.TEMPLATE_JSON,
      SORT_ORDER = EXCLUDED.SORT_ORDER;

-- 조회 동적 SQL — eDocComponentTemplate.js 가 [systemCode] 하나만 넘긴다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_EDOC_COMPONENT', 1,
  'SELECT id, type, template_json, sort_order FROM brunner_template.TB_COR_EDOC_COMPONENT WHERE system_code = $1 ORDER BY sort_order, id',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_USER_ID = EXCLUDED.CREATE_USER_ID, UPDATE_TIME = NOW();
