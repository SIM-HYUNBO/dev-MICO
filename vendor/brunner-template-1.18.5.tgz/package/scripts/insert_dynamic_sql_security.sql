-- Basic user lookup used by signup, friend invite, and profile reads.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST', 1,
  'SELECT user_id, user_name, email_id, profile_image_src, admin_flag, user_type, register_no, register_name FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 LIMIT 1',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Sign-in user lookup. authService 의 signin 과 refreshSession 이 함께 쓴다.
-- 이 시드가 없으면 로그인 자체가 되지 않는다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST', 2,
  'SELECT user_id, password, user_name, email_id, admin_flag, user_type, register_no, register_name, profile_image_src, expire_time FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 AND COALESCE(use_flag, ''Y'') = ''Y'' LIMIT 1',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Password reset identity and auth-code lookup.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST', 3,
  'SELECT user_id, password, phone_number, email_id, auth_code FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 AND COALESCE(use_flag, ''Y'') = ''Y'' LIMIT 1',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- User profile lookup.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST', 4,
  'SELECT user_id, user_name, address, phone_number, email_id, profile_image_src, expire_time, register_no FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 LIMIT 1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Session refresh account lookup.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST', 8,
  'SELECT user_id, user_name, email_id, admin_flag, user_type, register_no, register_name, profile_image_src FROM brunner_template.TB_COR_USER_MST WHERE system_code = $1 AND user_id = $2 AND COALESCE(use_flag, ''Y'') = ''Y'' LIMIT 1',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Password reset update.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST', 1,
  'UPDATE brunner_template.TB_COR_USER_MST SET password = $1, auth_code = NULL WHERE system_code = $2 AND user_id = $3 AND phone_number = $4 AND auth_code = $5 AND COALESCE(use_flag, ''Y'') = ''Y''',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Password reset auth-code update.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST', 2,
  'UPDATE brunner_template.TB_COR_USER_MST SET auth_code = $1 WHERE system_code = $2 AND user_id = $3 AND COALESCE(use_flag, ''Y'') = ''Y''',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Soft delete account.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST', 3,
  'UPDATE brunner_template.TB_COR_USER_MST SET use_flag = ''N'', auth_code = NULL WHERE system_code = $1 AND user_id = $2 AND phone_number = $3 AND auth_code = $4 AND COALESCE(use_flag, ''Y'') = ''Y''',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- User profile update.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST', 4,
  'UPDATE brunner_template.TB_COR_USER_MST SET user_name = $3, address = $4, phone_number = $5, email_id = $6, profile_image_src = $7, register_no = COALESCE($8, register_no) WHERE system_code = $1 AND user_id = $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Password update.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST', 5,
  'UPDATE brunner_template.TB_COR_USER_MST SET password = $3 WHERE system_code = $1 AND user_id = $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Admin account expiration update.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_MST', 6,
  'UPDATE brunner_template.TB_COR_USER_MST SET expire_time = $3 WHERE system_code = $1 AND user_id = $2',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 아래 4건은 gonello-mockup 쪽 시드에만 있었다. 회원가입(insert_..._USER_MST)과
-- 사용자 파라미터 조회/저장이라 템플릿에 없으면 새 프로젝트는 가입부터 막힌다.

-- Manual signup.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_USER_MST', 1,
  'INSERT INTO brunner_template.TB_COR_USER_MST (system_code, user_id, password, user_name, address, phone_number, email_id, use_flag, register_no, user_type, register_name, expire_time) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_USER_ID = EXCLUDED.CREATE_USER_ID, UPDATE_TIME = NOW();

