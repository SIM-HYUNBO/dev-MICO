-- 채팅 메시지 수정 / 삭제(soft delete) 동적쿼리 등록
-- 기존 테이블 컬럼(message)만 사용 — 스키마 변경 불필요
-- 실행 후: 서버 재시작 필요

-- [1] 메시지 수정: update_TB_COR_CHAT_MSG seq=1
-- $1: newMessage, $2: systemCode, $3: roomId, $4: messageId, $5: userId
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'update_TB_COR_CHAT_MSG',
  1,
  'UPDATE brunner_template.TB_COR_CHAT_MSG SET message = $1 WHERE system_code = $2 AND room_id = $3 AND msg_id = $4 AND user_id = $5',
  'SYSTEM',
  NOW()
) ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE
  SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [2] 메시지 삭제(soft delete): delete_TB_COR_CHAT_MSG seq=2
-- message를 NULL로 설정 — 로드 시 NULL이면 deleted 처리
-- $1: systemCode, $2: roomId, $3: messageId, $4: userId
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'delete_TB_COR_CHAT_MSG',
  2,
  'UPDATE brunner_template.TB_COR_CHAT_MSG SET message = NULL WHERE system_code = $1 AND room_id = $2 AND msg_id = $3 AND user_id = $4',
  'SYSTEM',
  NOW()
) ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE
  SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- [3] 단건 메시지 원본 조회 (이미지 lazy load용)
-- $1: systemCode, $2: msgId
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'select_TB_COR_CHAT_MSG_BY_ID',
  1,
  'SELECT msg_id AS id, message FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND msg_id = $2',
  'SYSTEM',
  NOW()
) ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE
  SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
