-- DB 백업 이력.
--
-- 왜 남기나
--   백업은 실패해도 서비스에 영향이 없어서 로그에만 남기고 끝났다. 그 결과 "7일 롤링
--   백업이 있다" 고 믿는 채로 하나도 없는 상태가 유지될 수 있었다(2026-07 볼륨 사고).
--   관리자가 화면에서 언제 무엇이 얼마나 백업됐는지 직접 볼 수 있어야 한다.
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_DB_BACKUP_HIST (
  SYSTEM_CODE  VARCHAR(2)   NOT NULL,
  BACKUP_ID    BIGSERIAL,
  STARTED_AT   TIMESTAMP    NOT NULL DEFAULT NOW(),
  FINISHED_AT  TIMESTAMP,
  RESULT       VARCHAR(20)  NOT NULL,          -- OK / FAILED
  METHOD       VARCHAR(40),                    -- pg_dump / node
  OBJECT_KEY   TEXT,                           -- R2 오브젝트 키
  SIZE_BYTES   BIGINT,
  TABLE_COUNT  INTEGER,
  ROW_COUNT    BIGINT,
  ERROR_MESSAGE TEXT,
  TRIGGERED_BY VARCHAR(50),                    -- cron / 관리자 아이디
  PRIMARY KEY (SYSTEM_CODE, BACKUP_ID)
);

CREATE INDEX IF NOT EXISTS idx_db_backup_hist_started
  ON brunner_template.TB_COR_DB_BACKUP_HIST (SYSTEM_CODE, STARTED_AT DESC);

COMMENT ON TABLE brunner_template.TB_COR_DB_BACKUP_HIST IS 'DB 백업 이력';
