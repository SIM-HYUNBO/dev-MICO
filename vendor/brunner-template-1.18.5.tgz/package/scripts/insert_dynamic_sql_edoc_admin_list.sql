-- 공용문서 목록의 관리자 조회.
--
-- 왜 필요한가
--   목록(seq 3)은 isPublic = true 만 돌려준다. 관리자·내부 문서를 isPublic = false 로
--   바꾸면 관리자조차 메뉴에서 볼 수 없게 되므로, 세션으로 관리자임을 확인한 요청에만
--   쓰는 전체 조회를 따로 둔다. 권한 판정은 서버가 하고, 이 SQL 은 그 결과에만 쓰인다.
DO $seed$
DECLARE
  t text;
  body constant text :=
    'SELECT d.system_code, d.id, d.title, d.description, d."version", d.created_by, '
    'd.created_at, d.updated_at, d.updated_by, d.runtime_data, d.pages, d.menu_path '
    'FROM brunner_template.tb_cor_edoc_document d WHERE d.system_code = $1 '
    'ORDER BY d.updated_at DESC, d.created_at DESC';
BEGIN
  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
      UNION SELECT '00'
    ) x ORDER BY code
  LOOP
    INSERT INTO brunner_template.TB_COR_SQL_INFO
      (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
    VALUES (t, 'select_TB_COR_EDOC_DOCUMENT', 4, body, 'claude', NOW())
    ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
    DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
  END LOOP;
END
$seed$;
