-- select_TB_COR_CHATROOM_USERS seq=2 — profile_image_src 포함으로 업데이트
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES (
  '00',
  'select_TB_COR_CHATROOM_USERS',
  2,
  'SELECT cu.user_id, u.user_name, u.profile_image_src FROM brunner_template.TB_COR_CHATROOM_USERS cu LEFT JOIN brunner_template.TB_COR_USER_MST u ON u.system_code = cu.system_code AND u.user_id = cu.user_id WHERE cu.system_code = $1 AND cu.room_id = $2',
  'claude',
  NOW()
)
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
