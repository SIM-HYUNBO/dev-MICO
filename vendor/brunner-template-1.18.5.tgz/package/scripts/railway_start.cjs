// Railway production entrypoint.
// Applies required DB SQL before starting the web server, then syncs repo docs best-effort.

const { spawn, spawnSync } = require("child_process");
const path = require("path");

// 이 스크립트는 두 자리에서 실행된다 — 이 저장소 자신, 그리고 파생 서비스의
// node_modules/brunner-template. 스크립트는 패키지 안에서 찾고, 서버는 앱 루트에서
// 띄워야 한다. 둘을 구분하지 않으면 파생 서비스에서 패키지의 pages 를 서빙하게 된다.
// 이 저장소에서 실행하면 두 값이 같으므로 동작이 달라지지 않는다.
const packageRoot = path.join(__dirname, "..");
const appDir = process.env.BRUNNER_APP_DIR || process.cwd();
const packageScript = (name) => path.join(__dirname, name);

const runRequired = (label, args) => {
  console.log(`[railway_start] ${label}`);
  const result = spawnSync(process.execPath, args, {
    cwd: appDir,
    stdio: "inherit",
    env: process.env,
  });

  if (result.status !== 0) {
    const code = result.status ?? 1;
    console.error(`[railway_start] ${label} failed with exit code ${code}.`);
    process.exit(code);
  }
};

const runOptional = (label, args) => {
  console.log(`[railway_start] ${label}`);
  const result = spawnSync(process.execPath, args, {
    cwd: appDir,
    stdio: "inherit",
    env: process.env,
  });

  if (result.status !== 0) {
    const code = result.status ?? 1;
    console.warn(`[railway_start] ${label} failed with exit code ${code}; continuing.`);
  }
};

runRequired("Apply DB SQL scripts", [packageScript("run_sql.cjs")]);
runRequired("Apply resource text table and seed", [packageScript("apply_resource_text_seed.cjs")]);

// 시드가 하나 빠지거나 SQL_NAME 이 어긋나면 배포는 그대로 성공하고 그 기능만 조용히 죽는다.
// (select_BRUNNER_DB_SIZE 는 개명 때 코드가 안 따라와 매 배포마다 지워지고 있었는데,
//  배포 로그에는 아무 표시도 없었다.) 검증은 소스의 getSQL 이름을 DB 와 대조한다.
// 실패해도 서버는 띄운다 — 미등록 하나로 전체를 못 뜨게 만드는 쪽이 더 위험하다.
if (process.env.VERIFY_DYNAMIC_SQL_ON_START !== "false") {
  runOptional("Verify dynamic SQL registrations", [packageScript("verify_dynamic_sql.cjs")]);
}

// 문서 동기화는 실패해도 되는 단계인데, 재시도를 반복하는 동안 서버가 뜨지
// 않아 헬스체크가 컨테이너를 죽였다(신규 설치본에는 PLAN.md 가 없어 매번 걸렸다).
// 기동을 막지 않도록 서버를 띄운 뒤 뒤에서 돌린다.
const syncRepoDocsInBackground = () => {
  if (process.env.SYNC_REPO_DOCS_ON_START === "false") return;
  console.log("[railway_start] Sync repository docs to eDoc (background)");
  const child = spawn(process.execPath, [packageScript("sync_repo_docs_to_edoc.cjs")], {
    cwd: appDir,
    stdio: "inherit",
    env: process.env,
  });
  child.on("exit", (code) => {
    if (code !== 0) console.warn(`[railway_start] Repository doc sync exited with ${code}; ignored.`);
  });
};

console.log("[railway_start] Start web server");
const server = spawn(process.execPath, [path.join(packageRoot, "server.js")], {
  cwd: appDir,
  stdio: "inherit",
  env: process.env,
});

// 서버가 뜨기 시작한 뒤에 돌린다. 실패해도 기동에는 영향이 없다.
syncRepoDocsInBackground();

const forwardSignal = (signal) => {
  if (!server.killed) server.kill(signal);
};

process.on("SIGTERM", () => forwardSignal("SIGTERM"));
process.on("SIGINT", () => forwardSignal("SIGINT"));

server.on("exit", (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }
  process.exit(code ?? 0);
});
