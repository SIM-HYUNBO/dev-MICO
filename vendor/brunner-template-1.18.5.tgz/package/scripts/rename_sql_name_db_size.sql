-- SQL_NAME 개명: select_DB_SIZE -> select_TB_COR_DB_SIZE
--
-- 경위
--   SQL_NAME 규칙은 {verb}_{TABLE} 이고 테이블명은 영역 접두어(TB_COR_ 등)를 갖는다.
--   이 이름은 그 접두어가 없어 목록을 이름순으로 볼 때 코어 쿼리 무리에서 혼자
--   떨어져 나온다. sql_name_gate 는 BRUNNER 토큰만 보므로 이것은 걸러지지 않았다.
--
-- 이 파일이 insert_dynamic_sql_db_size.sql 보다 앞에 있어야 하는 이유
--   뒤에 두면 새 이름 행이 먼저 생기고 옛 행이 그대로 남아, 같은 쿼리가 두 이름으로
--   공존한다. 먼저 지우고 나서 시드가 새 이름으로 심게 한다.
--
-- 배포 창(window)
--   구버전 컨테이너는 잠시 옛 이름을 찾는다. dbCapacityMonitor 는 등록이 없으면
--   경고만 남기고 건너뛰고 1시간 주기라, 그 사이 유실되는 것은 없다.
--
-- 재실행해도 결과가 같다.

DELETE FROM brunner_template.TB_COR_SQL_INFO
 WHERE SQL_NAME = 'select_DB_SIZE';
