-- 테이블 이름 규칙 통일: tb_{영역약어}_{기능}
--
-- chat/credit 도 코어 영역인데 tb_chat_*, tb_credit_* 로 따로 떨어져 있었다.
-- (tb_credit 은 기능약어조차 없어 tb_영역_기능 형태가 아니었다.)
-- 나머지 30개가 이미 tb_cor_* 이므로 cor 로 통일한다.
--
-- rename 이라 데이터는 그대로 보존된다. 새 이름이 이미 있으면(재실행·신규 DB)
-- IF EXISTS 로 조용히 넘어가므로 몇 번 돌려도 안전하다.
--
-- 중요: 이 파일은 create_credit.sql / create_chat_reaction_table.sql /
-- create_custom_emoji_table.sql 보다 반드시 먼저 실행돼야 한다. 새 이름으로
-- 빈 테이블이 먼저 생기면 rename 대상이 충돌해 실패한다.
-- (run_sql.cjs 의 SQL_FILES 에서 create_core_tables.sql 바로 다음에 둔다.)

-- 크레딧은 AI 콘텐츠 전용이 아니라 결제로 충전하고 각 서비스가 차감하는 코어 기능이다.
-- brunner-next 에서는 크레딧이 AI Studio 안에서 태어나 TB_AIC_* 를, 나머지 저장소는
-- TB_CREDIT_* 를 달고 있었다. 세 저장소가 같은 파일을 쓰므로 두 출처를 모두 적는다.
--
-- 주의: ALTER TABLE IF EXISTS 는 "원본이 없을 때"만 넘어가고 "대상이 이미 있을 때"는
-- 42P07 로 실패한다. TB_CREDIT 과 TB_AIC_CREDIT 은 대상이 같아서, 두 테이블이 함께
-- 있는 DB 라면 뒤엣것이 실패하고 run_sql 이 통째로 중단돼 서버가 기동하지 못한다.
-- 그래서 원본 존재 + 대상 부재를 모두 확인하고 rename 한다.
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT * FROM (VALUES
      ('tb_credit',             'tb_cor_credit_mst'),
      ('tb_credit_ledger',      'tb_cor_credit_ledger'),
      ('tb_aic_credit',         'tb_cor_credit_mst'),
      ('tb_aic_credit_ledger',  'tb_cor_credit_ledger'),
      ('tb_chat_reaction',      'tb_cor_chat_reaction'),
      ('tb_chat_custom_emoji',  'tb_cor_chat_custom_emoji')
    ) AS t(old_name, new_name)
  LOOP
    IF to_regclass('brunner_template.' || r.old_name) IS NOT NULL
       AND to_regclass('brunner_template.' || r.new_name) IS NULL THEN
      EXECUTE format('ALTER TABLE brunner_template.%I RENAME TO %I', r.old_name, r.new_name);
    END IF;
  END LOOP;

  -- 인덱스는 테이블을 rename 해도 이름이 따라오지 않는다. 직접 맞춰 준다.
  -- 여기도 대상 이름이 겹치므로(구 credit / 구 aic credit) 같은 방식으로 확인한다.
  FOR r IN
    SELECT * FROM (VALUES
      ('idx_tb_credit_ledger_user',     'idx_tb_cor_credit_ledger_user'),
      ('idx_tb_credit_ledger_ref',      'idx_tb_cor_credit_ledger_ref'),
      ('idx_tb_aic_credit_ledger_user', 'idx_tb_cor_credit_ledger_user'),
      ('idx_tb_aic_credit_ledger_ref',  'idx_tb_cor_credit_ledger_ref'),
      ('idx_tb_chat_reaction_msg',      'idx_tb_cor_chat_reaction_msg')
    ) AS t(old_name, new_name)
  LOOP
    IF to_regclass('brunner_template.' || r.old_name) IS NOT NULL
       AND to_regclass('brunner_template.' || r.new_name) IS NULL THEN
      EXECUTE format('ALTER INDEX brunner_template.%I RENAME TO %I', r.old_name, r.new_name);
    END IF;
  END LOOP;
END $$;

-- PRIMARY KEY 제약 이름(tb_credit_pkey 등)은 그대로 둔다. 내부 식별자라 화면·코드
-- 어디에도 노출되지 않고, 바꾸면 되돌릴 때 추적만 어려워진다.

-- 아래 두 블록은 대상 테이블이 아직 없는 신규 DB에서도 실행 순서에 상관없이
-- 안전하도록 to_regclass 로 존재 여부를 확인하고 돈다.
DO $$
BEGIN
  -- 구 이름으로 등록된 동적 SQL 삭제.
  -- 새 이름은 뒤따르는 insert_dynamic_sql_*.sql 이 다시 심으므로, 지우지 않으면
  -- 없어진 테이블을 가리키는 죽은 항목이 TB_COR_SQL_INFO 에 남는다.
  IF to_regclass('brunner_template.tb_cor_sql_info') IS NOT NULL THEN
    DELETE FROM brunner_template.TB_COR_SQL_INFO WHERE SQL_NAME IN (
      'select_TB_CREDIT',
      'update_TB_CREDIT',
      'select_TB_CREDIT_LEDGER',
      'insert_TB_CREDIT_LEDGER',
      'select_TB_CREDIT_LIST',
      'select_TB_AIC_CREDIT',
      'update_TB_AIC_CREDIT',
      'select_TB_AIC_CREDIT_LEDGER',
      'insert_TB_AIC_CREDIT_LEDGER',
      'select_TB_AIC_CREDIT_LIST',
      'delete_TB_CHAT_REACTION',
      'upsert_TB_CHAT_REACTION',
      'select_TB_CHAT_REACTION_BY_MESSAGES',
      'select_TB_CHAT_CUSTOM_EMOJI',
      'insert_TB_CHAT_CUSTOM_EMOJI',
      'delete_TB_CHAT_CUSTOM_EMOJI',
      'select_TB_CHAT_CUSTOM_EMOJI_LIST'
    );
  END IF;

  -- 구 이름으로 걸려 있던 보존정책도 새 이름으로 옮긴다. 이름이 안 맞으면 정책이
  -- 붙지 않은 테이블로 보여 자동 삭제가 조용히 멈춘다.
  IF to_regclass('brunner_template.tb_cor_table_retention_policy') IS NOT NULL THEN
    UPDATE brunner_template.TB_COR_TABLE_RETENTION_POLICY p SET TABLE_NAME = n.new_name
      FROM (VALUES
        ('tb_credit',             'tb_cor_credit_mst'),
        ('tb_credit_ledger',      'tb_cor_credit_ledger'),
        ('tb_aic_credit',         'tb_cor_credit_mst'),
        ('tb_aic_credit_ledger',  'tb_cor_credit_ledger'),
        ('tb_chat_reaction',      'tb_cor_chat_reaction'),
        ('tb_chat_custom_emoji',  'tb_cor_chat_custom_emoji')
      ) AS n(old_name, new_name)
     WHERE p.TABLE_NAME = n.old_name
       AND NOT EXISTS (
         SELECT 1 FROM brunner_template.TB_COR_TABLE_RETENTION_POLICY x WHERE x.TABLE_NAME = n.new_name
       );
  END IF;
END $$;
