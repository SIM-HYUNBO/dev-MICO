-- 사용자 확장속성 (User Params)
--
-- 사용자마다 임의의 key-value 를 JSONB 로 들고 있는 테이블이다. 설정 화면의
-- 푸시 알림음(pushNotificationSound)이 여기에 저장되고, 내 계정 화면의
-- UserParamEditor 로 직접 편집한다. 로그인 응답(authService)에 함께 실려 나간다.
--
-- 자기 스키마만 건드린다
--   예전에는 이 파일이 brunner_template·brunner 스키마에도 같은 테이블을 만들었다.
--   세 서비스가 한 DB 를 쓰다 보니 편의로 넣은 것인데, 스키마 소유가 갈리면 어느
--   리포가 그 테이블의 정본인지 알 수 없어진다. 지금은 각 리포가 자기 스키마만
--   책임지고(brunner 는 brunner-next 가 소유), run_sql 도 DB_SCHEMA 가 자기 소유와
--   다르면 DDL 을 건너뛴다. 그 원칙에 맞춰 교차 스키마 생성을 걷어냈다.
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_USER_PARAM_INFO (
  SYSTEM_CODE  VARCHAR(2)   NOT NULL,
  USER_ID      VARCHAR(100) NOT NULL,
  USER_PARAMS  JSONB        DEFAULT '{}'::jsonb,
  CREATED_AT   TIMESTAMP    DEFAULT NOW(),
  UPDATED_AT   TIMESTAMP,
  PRIMARY KEY (SYSTEM_CODE, USER_ID)
);

-- CREATE TABLE IF NOT EXISTS 는 테이블이 이미 있으면 통째로 건너뛴다. 옛 세대의
-- 테이블에 컬럼이 빠져 있어도 알 수 없으므로 개별로 보강한다.
ALTER TABLE brunner_template.TB_COR_USER_PARAM_INFO
  ADD COLUMN IF NOT EXISTS SYSTEM_CODE VARCHAR(2)   NOT NULL DEFAULT '00';
ALTER TABLE brunner_template.TB_COR_USER_PARAM_INFO
  ADD COLUMN IF NOT EXISTS USER_PARAMS JSONB        DEFAULT '{}'::jsonb;
ALTER TABLE brunner_template.TB_COR_USER_PARAM_INFO
  ADD COLUMN IF NOT EXISTS CREATED_AT  TIMESTAMP    DEFAULT NOW();
ALTER TABLE brunner_template.TB_COR_USER_PARAM_INFO
  ADD COLUMN IF NOT EXISTS UPDATED_AT  TIMESTAMP;

COMMENT ON TABLE brunner_template.TB_COR_USER_PARAM_INFO IS '사용자 확장속성 (key-value JSONB)';
