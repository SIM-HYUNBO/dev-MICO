-- kakao_id 컬럼 추가 및 친구 초대 테이블 생성
ALTER TABLE brunner_template.TB_COR_USER_MST ADD COLUMN IF NOT EXISTS kakao_id VARCHAR(30);
-- 카카오 계정 하나로 여러 시스템에 각각 가입할 수 있어야 하므로 테넌트를 앞에 둔다.
CREATE UNIQUE INDEX IF NOT EXISTS uq_tb_cor_user_mst_system_kakao
  ON brunner_template.TB_COR_USER_MST(system_code, kakao_id) WHERE kakao_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_FRIEND_INVITE (
  invite_code  VARCHAR(36)  NOT NULL,
  system_code  VARCHAR(10)  NOT NULL,
  inviter_id   VARCHAR(50)  NOT NULL,
  created_at   TIMESTAMP    NOT NULL DEFAULT NOW(),
  expire_at    TIMESTAMP    NOT NULL DEFAULT (NOW() + INTERVAL '7 days'),
  used_at      TIMESTAMP,
  invitee_id   VARCHAR(50),
  CONSTRAINT pk_tb_cor_friend_invite PRIMARY KEY (system_code, invite_code)
);
