-- 채팅 첨부를 DB(BYTEA) 대신 R2 오브젝트 스토리지에 두기 위한 컬럼.
-- insert_dynamic_sql_chat_file_r2.sql 의 쿼리가 이 컬럼을 요구한다.
ALTER TABLE brunner_template.TB_COR_CHAT_FILE
  ADD COLUMN IF NOT EXISTS R2_KEY VARCHAR(500);

-- R2 로 옮기면 파일 본문은 비므로 NOT NULL 을 푼다.
ALTER TABLE brunner_template.TB_COR_CHAT_FILE
  ALTER COLUMN FILE_DATA DROP NOT NULL;
