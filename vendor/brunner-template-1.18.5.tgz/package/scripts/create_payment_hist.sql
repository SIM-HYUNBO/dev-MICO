-- 결제 이력 — 토스페이먼츠 승인 기록.
--
-- 지금까지 크레딧 충전 결제는 크레딧 원장(TB_COR_CREDIT_LEDGER)에 "몇 크레딧이
-- 늘었다"만 남았다. 원 금액도 paymentKey 도 저장하지 않아 환불 요청이 오면
-- 얼마를 돌려줘야 하는지 DB 로 알 수 없고, 토스 취소 API 를 부를 키도 없었으며,
-- 월 정산 대사(토스 입금액 vs 우리 매출)도 맞춰볼 근거가 없었다.
--
-- 크레딧 원장은 "크레딧이 어떻게 움직였나", 이 표는 "돈이 어떻게 움직였나" 를
-- 담당한다. 둘은 ORDER_ID 로 연결된다(원장의 REF = 이 표의 ORDER_ID).

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_PAYMENT_HIST (
  SYSTEM_CODE     VARCHAR(2)   NOT NULL,
  ORDER_ID        VARCHAR(150) NOT NULL,        -- 토스 주문번호. 멱등 키이자 크레딧 원장 REF 와 연결
  PAYMENT_KEY     VARCHAR(200),                 -- 토스 결제 키. 취소·조회 API 에 필수
  USER_ID         VARCHAR(100) NOT NULL,
  AMOUNT_WON      INT          NOT NULL DEFAULT 0,   -- 실제 결제 금액(원)
  CREDITS_GRANTED INT          NOT NULL DEFAULT 0,   -- 그 대가로 지급한 크레딧
  METHOD          VARCHAR(60),                  -- 카드 / 간편결제 등 토스가 알려주는 결제수단
  STATUS          VARCHAR(20)  NOT NULL DEFAULT 'APPROVED', -- APPROVED | CANCELED | PARTIAL_CANCELED
  CANCELED_AMOUNT INT          NOT NULL DEFAULT 0,   -- 부분취소 누적액
  APPROVED_AT     TIMESTAMP,
  CANCELED_AT     TIMESTAMP,
  RAW_RESPONSE    TEXT,                         -- 토스 응답 원문. 분쟁·장애 시 근거가 된다
  CREATE_TIME     TIMESTAMP    NOT NULL DEFAULT NOW(),
  UPDATE_TIME     TIMESTAMP    NOT NULL DEFAULT NOW(),
  PRIMARY KEY (SYSTEM_CODE, ORDER_ID)
);

-- 사용자별 결제 내역 조회(최근순)
CREATE INDEX IF NOT EXISTS IDX_TB_COR_PAYMENT_HIST_USER
  ON brunner_template.TB_COR_PAYMENT_HIST (SYSTEM_CODE, USER_ID, APPROVED_AT DESC);

-- 취소 처리 시 paymentKey 로 역인덱스가 필요하다
CREATE INDEX IF NOT EXISTS IDX_TB_COR_PAYMENT_HIST_KEY
  ON brunner_template.TB_COR_PAYMENT_HIST (SYSTEM_CODE, PAYMENT_KEY);
