-- 채팅 메시지 및 읽음 이력 조회 성능 개선 인덱스

-- TB_COR_CHAT_MSG: 방별 최신 메시지 조회 (ORDER BY msg_id DESC LIMIT 20)
CREATE INDEX IF NOT EXISTS IDX_CHAT_MSG_ROOM_ID
  ON brunner_template.TB_COR_CHAT_MSG (system_code, room_id, msg_id DESC);

-- TB_COR_CHAT_READ_RECEIPT: 방별 읽음 이력 조회
CREATE INDEX IF NOT EXISTS IDX_CHAT_READ_RECEIPT_ROOM
  ON brunner_template.TB_COR_CHAT_READ_RECEIPT (system_code, room_id);
