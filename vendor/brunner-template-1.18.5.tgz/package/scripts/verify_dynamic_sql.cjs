// scripts/verify_dynamic_sql.cjs
//
// 코드가 실제로 꺼내 쓰는 동적 SQL 이 DB 에 다 등록돼 있는지 확인한다.
//
// 이 프레임워크는 SQL 을 코드가 아니라 TB_COR_SQL_INFO 에 두고 이름으로
// 꺼내 쓴다. 그래서 시드 하나가 안 들어가면 그 기능만 조용히 죽고, 화면에는
// "Database operation failed." 만 뜬다. 어느 이름이 빠졌는지 알 수 없어
// 시드 파일을 처음부터 뒤지게 되는데, 그러지 않으려고 만든 스크립트다.
//
// 예전에는 확인할 이름을 손으로 적어 뒀었다. 그 목록이 코드보다 먼저 낡아
// 제거된 주식 기능 이름만 남았고, 없는 테이블을 조회해서 늘 실패했다.
// 그래서 목록을 적지 않고 소스에서 직접 뽑는다.
//
//   node scripts/verify_dynamic_sql.cjs

const { Client } = require("pg");
const fs = require("fs");
const path = require("path");

require("dotenv").config({ path: path.join(__dirname, "../.env") });

const ROOT = path.join(__dirname, "..");
const SCAN_DIRS = ["pages/api", "lib", "components/core/server"];
// 소문자로 접는다 — lib/dbSchema.js 와 같은 규칙.
const SCHEMA = (process.env.DB_SCHEMA || "").trim().toLowerCase() || "brunner_template";
const quoteIdent = (name) => `"${String(name).replace(/"/g, `""`)}"`;
const qualifiedTable = (tableName) => `${quoteIdent(SCHEMA)}.${quoteIdent(tableName)}`;
// 이 배포의 테넌트. '00' 고정이면 테넌트 배포에서 남의 등록분을 검사하게 된다.
const TENANT = (process.env.SYSTEM_CODE || "").trim() || "00";

// getSQL(시스템코드, "이름", 시퀀스) — 인자가 여러 줄에 걸쳐 있어도 잡는다.
// 이름을 변수로 넘기는 호출은 정적으로 알 수 없으므로 건너뛴다.
const CALL = /getSQL\(\s*[^,()]+,\s*[`"']([A-Za-z0-9_]+)[`"']\s*,\s*(\d+)/g;

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else if (/\.(js|cjs|mjs)$/.test(entry.name)) out.push(full);
  }
  return out;
}

function collectRequired() {
  const required = new Map(); // "이름|시퀀스" -> Set(상대경로)
  for (const dir of SCAN_DIRS) {
    for (const file of walk(path.join(ROOT, dir))) {
      const src = fs.readFileSync(file, "utf8");
      let m;
      CALL.lastIndex = 0;
      while ((m = CALL.exec(src))) {
        const key = `${m[1]}|${m[2]}`;
        if (!required.has(key)) required.set(key, new Set());
        required.get(key).add(path.relative(ROOT, file));
      }
    }
  }
  return required;
}

async function main() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error("DATABASE_URL is required.");

  const required = collectRequired();
  if (required.size === 0) {
    throw new Error("소스에서 getSQL 호출을 하나도 찾지 못했다 — 스캔 경로를 확인할 것.");
  }

  const client = new Client({
    connectionString,
    ssl: /require/i.test(process.env.SSL_MODE || "") ? { rejectUnauthorized: false } : false,
  });
  await client.connect();

  let registered;
  try {
    const result = await client.query(
      `SELECT sql_name, sql_seq FROM ${qualifiedTable("TB_COR_SQL_INFO")} WHERE system_code = $1`,
      [TENANT],
    );
    registered = new Set(result.rows.map((r) => `${r.sql_name}|${r.sql_seq}`));
  } finally {
    await client.end().catch(() => {});
  }

  const missing = [...required.keys()].filter((k) => !registered.has(k)).sort();

  console.log(
    `소스가 요구하는 SQL ${required.size}건, DB(${SCHEMA})에 등록된 SQL ${registered.size}건.`,
  );

  if (missing.length === 0) {
    console.log("빠진 것 없음.");
    return;
  }

  console.log(`\n등록되지 않은 SQL ${missing.length}건:`);
  for (const key of missing) {
    const [name, seq] = key.split("|");
    console.log(`  - ${name} (seq ${seq})`);
    for (const file of required.get(key)) console.log(`      ${file}`);
  }
  // 어느 기능이 죽는지 눈으로 보고 시드를 다시 넣으라는 뜻이므로 실패로 끝낸다.
  process.exitCode = 1;
}

main().catch((err) => {
  console.error(`[verify_dynamic_sql] ${err.message}`);
  process.exit(1);
});
