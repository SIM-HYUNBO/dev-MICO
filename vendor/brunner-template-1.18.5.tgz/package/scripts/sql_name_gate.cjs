// 동적 SQL 의 SQL_NAME 규칙을 빌드 전에 검사한다.
//
// 왜
//   SQL_NAME 은 {verb}_{TABLE} 이다. 테이블명이 이미 영역 접두어(TB_COR_/TB_STK_/
//   TB_DOC_/TB_AIC_)를 갖고 있어 스키마 토큰을 두지 않는다. 그리고
//   alias_sql_names_without_brunner.sql 이 매 배포마다 '%_BRUNNER_%' 이름을 지운다.
//
//   그래서 이름에 BRUNNER 를 넣으면 심자마자 지워지고, 그 이름을 부르는 화면만 조용히
//   죽는다. 실제로 select_BRUNNER_TABLE_USAGE 가 그랬다 — 정리 게이트를 켠 커밋에서
//   새 시드가 옛 규칙 이름으로 태어나, 8/20 부터 매 배포마다 심고-지우기를 반복하며
//   관리자 DB 적재량 화면이 계속 실패하고 있었다. 배포 로그에는 아무 표시도 없다.
//
//   경고로 두면 같은 일이 또 지나간다. 넣을 이유가 없는 이름이므로 빌드를 세운다.
//
// 실행: node scripts/sql_name_gate.cjs   (위반 시 exit 1)

const fs = require("fs");
const path = require("path");

// 검사 대상은 이 게이트가 있는 곳이 아니라 "돌리는 앱"이다. 파생 서비스는 이 파일을
// node_modules/brunner-template/scripts/ 에서 실행하는데, __dirname 기준으로 잡으면
// 패키지 자신만 훑고 정작 그 서비스의 시드·코드는 한 번도 안 본다.
// 다른 게이트(node_entry_alias_gate·doc_sync_gate)와 같은 기준을 쓴다.
const ROOT = process.env.BRUNNER_APP_DIR || process.cwd();
const SCRIPTS = path.join(ROOT, "scripts");

// 스키마 토큰이 박힌 옛 이름. 대소문자 구분 없이 본다.
const FORBIDDEN = /\b[a-z]+_BRUNNER_[A-Z0-9_]+\b/i;

// 이 파일들은 옛 이름을 "다루는" 자리라 예외다.
//   - alias_...: 옛 이름을 지우는 패턴 자체를 담고 있다
//   - restore_...: 과거 스냅샷이며 run_sql 목록에 없다(적용되지 않는다)
const EXEMPT_SQL = new Set([
  "alias_sql_names_without_brunner.sql",
  "restore_brunner_template_sql_info.sql",
]);

const violations = [];

// 1) 시드가 등록하는 이름 — scripts 를 갖지 않는 서비스도 있다.
const sqlInfoName = /'00'\s*,\s*'([A-Za-z0-9_]+)'\s*,\s*\d+\s*,/g;
for (const file of fs.existsSync(SCRIPTS) ? fs.readdirSync(SCRIPTS) : []) {
  if (!file.endsWith(".sql") || EXEMPT_SQL.has(file)) continue;
  const text = fs.readFileSync(path.join(SCRIPTS, file), "utf8");
  sqlInfoName.lastIndex = 0;
  let match;
  while ((match = sqlInfoName.exec(text))) {
    if (FORBIDDEN.test(match[1])) {
      violations.push(`scripts/${file}: 시드가 '${match[1]}' 로 등록한다`);
    }
  }
}

// 2) 코드가 부르는 이름
const getSqlName = /getSQL\(\s*[^,]+,\s*["'`]([A-Za-z0-9_]+)["'`]/g;
const walk = (dir) => {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === ".next" || entry.name.startsWith(".")) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walk(full);
      continue;
    }
    if (!/\.(js|jsx|ts|tsx|cjs|mjs)$/.test(entry.name)) continue;
    const text = fs.readFileSync(full, "utf8");
    getSqlName.lastIndex = 0;
    let match;
    while ((match = getSqlName.exec(text))) {
      if (FORBIDDEN.test(match[1])) {
        violations.push(`${path.relative(ROOT, full)}: 코드가 '${match[1]}' 를 부른다`);
      }
    }
  }
};
for (const dir of ["pages", "lib", "components"]) {
  const full = path.join(ROOT, dir);
  if (fs.existsSync(full)) walk(full);
}

if (violations.length > 0) {
  console.error("[sql-name-gate] SQL_NAME 에 스키마 토큰(BRUNNER)이 들어갔다.");
  console.error("  이 이름은 alias_sql_names_without_brunner.sql 이 매 배포마다 지운다 —");
  console.error("  등록해도 곧바로 사라지고 그 기능만 조용히 죽는다. 스키마 토큰을 빼고 {verb}_{TABLE} 로 쓴다.");
  for (const line of violations) console.error(`  - ${line}`);
  process.exit(1);
}

console.log("[sql-name-gate] SQL_NAME 규칙 위반 없음.");
