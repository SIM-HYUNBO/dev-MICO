-- eDoc 공용문서 조회 동적 SQL 수정
-- admin 계정 삭제 이후 creator admin_flag 의존 제거 — isPublic = true 조건만 유지
-- trigger: 2026-06-14a

INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'select_TB_COR_EDOC_DOCUMENT',
  3,
  'SELECT d.system_code, d.id, d.title, d.description, d."version", d.created_by, d.created_at, d.updated_at, d.updated_by, d.runtime_data, d.pages, d.menu_path FROM brunner_template.tb_cor_edoc_document d WHERE (d.runtime_data->>''isPublic'')::boolean = true AND d.system_code = $1 ORDER BY d.updated_at DESC, d.created_at DESC',
  'SYSTEM',
  NOW()
)
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET
  SQL_CONTENT = EXCLUDED.SQL_CONTENT,
  CREATE_TIME = NOW();
