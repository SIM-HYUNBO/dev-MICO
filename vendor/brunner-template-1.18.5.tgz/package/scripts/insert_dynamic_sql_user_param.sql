-- 사용자 확장속성 동적 SQL.
--
-- pages/api/biz/security/userService.js 의 selectUserParamInfo / upsertUserParamInfo 가
-- 아래 세 이름을 요구한다. 하나라도 없으면 그 화면만 조용히 죽는다.
--
-- 테넌트마다 심는다
--   스키마를 하나로 통합해 SYSTEM_CODE 로 테넌트를 가르는 구조다. 시드를 '00' 으로
--   박아두면 01/02 에는 등록이 안 되고, 그 테넌트에서만 이 기능이 죽는다. 그리고
--   테넌트 배포(zicp/brunner-template)는 남의 스키마에 DDL 을 돌리지 않으므로
--   대신 심어줄 주체도 없다. 스키마를 소유한 쪽이 그 안의 모든 테넌트에 심는다.
--   기준은 이미 이 스키마에 존재하는 SYSTEM_CODE 이고, '00' 은 항상 포함한다.
--
-- 조회 결과에 system_code 를 담지 않는다
--   테넌트는 서버가 배포 환경변수로 정하므로 클라이언트가 알 필요가 없다. 응답에
--   실어 보내면 클라이언트가 그 값을 다시 요청에 넣는 패턴이 생기는데, 그게 바로
--   막아둔 테넌트 위조 경로다. 화면도 user_params 만 읽는다.
DO $seed$
DECLARE
  t    text;
  defs constant text[][] := ARRAY[
    ['select_TB_COR_USER_PARAM_INFO',
     'SELECT user_params FROM brunner_template.TB_COR_USER_PARAM_INFO WHERE system_code = $1 AND user_id = $2'],
    ['insert_TB_COR_USER_PARAM_INFO',
     'INSERT INTO brunner_template.TB_COR_USER_PARAM_INFO (system_code, user_id, user_params) VALUES ($1, $2, $3::jsonb)'],
    ['update_TB_COR_USER_PARAM_INFO',
     'UPDATE brunner_template.TB_COR_USER_PARAM_INFO SET user_params = $3::jsonb, updated_at = NOW() WHERE system_code = $1 AND user_id = $2']
  ];
  i int;
BEGIN
  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
      UNION SELECT '00'
    ) x ORDER BY code
  LOOP
    FOR i IN 1 .. array_length(defs, 1) LOOP
      INSERT INTO brunner_template.TB_COR_SQL_INFO
        (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
      VALUES (t, defs[i][1], 1, defs[i][2], 'claude', NOW())
      ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
      DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
    END LOOP;
  END LOOP;
END
$seed$;
