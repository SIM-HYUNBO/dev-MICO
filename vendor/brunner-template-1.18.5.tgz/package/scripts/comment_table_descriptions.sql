-- Table descriptions used by the admin DB usage screen.
-- Safe to run repeatedly; skips tables that do not exist yet.
DO $$
BEGIN
  IF to_regclass('brunner_template.tb_cor_chat_custom_emoji') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chat_custom_emoji IS 'Custom chat emoji definitions and image metadata';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chat_reaction') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chat_reaction IS 'Chat message reaction records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_android_tester') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_android_tester IS 'Android tester allowlist and tester metadata';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chat_file') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chat_file IS 'Uploaded chat file metadata';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chat_msg') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chat_msg IS 'Chat message body and message metadata';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chat_read_receipt') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chat_read_receipt IS 'Chat message read receipt records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chatroom_invite') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chatroom_invite IS 'Chatroom invitation records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chatroom_invite_token') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chatroom_invite_token IS 'Chatroom invite token records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chatroom_member_device_key') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chatroom_member_device_key IS 'Per-device encrypted chatroom member key records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chatroom_member_key') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chatroom_member_key IS 'Encrypted chatroom member key records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chatroom_mst') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chatroom_mst IS 'Chatroom master records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chatroom_room_key') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chatroom_room_key IS 'Current encrypted chatroom room key records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chatroom_room_key_history') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chatroom_room_key_history IS 'Historical encrypted chatroom room key records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_chatroom_users') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_chatroom_users IS 'Chatroom membership records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_complaint') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_complaint IS 'User complaint and support request records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_friend_invite') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_friend_invite IS 'Friend invitation records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_post_comment_info') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_post_comment_info IS 'Board post comment records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_post_info') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_post_info IS 'Board post master records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_push_subscription') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_push_subscription IS 'Web push subscription endpoint records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_schedule') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_schedule IS 'User schedule master records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_schedule_participant') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_schedule_participant IS 'Schedule participant records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_sql_info') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_sql_info IS 'Dynamic SQL registry used by backend services';
  END IF;
  IF to_regclass('brunner_template.tb_cor_table_retention_config') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_table_retention_config IS 'Table retention cleanup schedule and lease configuration';
  END IF;
  IF to_regclass('brunner_template.tb_cor_table_retention_policy') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_table_retention_policy IS 'Table retention policy configured by administrators';
  END IF;
  IF to_regclass('brunner_template.tb_cor_table_retention_run_hist') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_table_retention_run_hist IS 'Table retention cleanup execution history';
  END IF;
  IF to_regclass('brunner_template.tb_cor_txn_hist') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_txn_hist IS 'Backend transaction request and response history';
  END IF;
  IF to_regclass('brunner_template.tb_cor_user_activity_log') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_user_activity_log IS 'User activity audit and usage log records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_user_e2ee_device_key') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_user_e2ee_device_key IS 'User device public keys for end-to-end encryption';
  END IF;
  IF to_regclass('brunner_template.tb_cor_user_friend') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_user_friend IS 'User friendship relationship records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_user_mst') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_user_mst IS 'User master account and profile records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_user_param_info') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_user_param_info IS 'User preference and parameter records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_user_session') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_user_session IS 'User login session and expiry records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_credit_mst') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_credit_mst IS 'General service credit balance by user';
  END IF;
  IF to_regclass('brunner_template.tb_cor_credit_ledger') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_credit_ledger IS 'General service credit charge and usage ledger';
  END IF;
  IF to_regclass('brunner_template.tb_cor_edoc_component') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_edoc_component IS 'Reusable document component template records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_edoc_document') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_edoc_document IS 'Document master and document content records';
  END IF;
  IF to_regclass('brunner_template.tb_cor_seed_state') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_seed_state IS 'Database seed fingerprint state used to skip already-applied seed SQL';
  END IF;
  IF to_regclass('brunner_template.tb_cor_game_play_stat') IS NOT NULL THEN
    COMMENT ON TABLE brunner_template.tb_cor_game_play_stat IS 'Game play statistics and aggregate play metrics';
  END IF;
END $$;
