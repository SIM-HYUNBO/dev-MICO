// Node 가 직접 실행하는 진입점(server.js, scripts/*.cjs)에서 "@/" 별칭을 막는다.
//
// 왜
//   "@/..." 는 Next 번들러(jsconfig paths)가 푸는 별칭이다. server.js 와 배포 시작
//   스크립트는 번들러를 거치지 않고 Node 가 그대로 실행하므로 별칭이 풀리지 않는다.
//   실제로 lib/tenantResolver.js 하나가 "@/lib/..." 를 import 한 것 때문에
//   ERR_MODULE_NOT_FOUND: Cannot find package '@/lib' 로 서버가 기동 단계에서 죽고
//   healthcheck 가 통째로 실패했다. 배포 로그를 볼 때까지 원인이 보이지 않는 종류의
//   사고라, 빌드 전에 정적으로 막는다.
//
// 무엇을
//   진입점에서 상대경로 import/require 를 따라가며 도달 가능한 모든 파일을 훑어
//   ① "@/" 별칭 ② 존재하지 않는 상대경로 를 찾으면 빌드를 실패시킨다.
//   페이지·컴포넌트(번들러가 처리하는 코드)는 대상이 아니다.

const fs = require("fs");
const path = require("path");

// 이 스크립트는 파생 저장소의 node_modules 안에서도 실행된다. 자기 위치를
// 앱 루트로 단정하면 그 저장소의 파일이 아니라 패키지 안을 검사하게 된다.
const root = process.env.BRUNNER_APP_DIR || process.cwd();

const ENTRIES = [
  "server.js",
  ...fs
    .readdirSync(__dirname)
    .filter((f) => f.endsWith(".cjs") && f !== "node_entry_alias_gate.cjs")
    .map((f) => path.join("scripts", f)),
];

const SPEC_RE = /(?:from\s+|import\s*\(\s*|require\s*\(\s*)["']([^"']+)["']/g;
const EXTS = ["", ".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx"];

// 주석 안의 예시 코드를 import 로 오인하면(실제로 "await import(\"./lib/x.js\")" 를
// 설명하는 주석이 있었다) 게이트가 거짓 경보를 낸다. 노이즈 큰 게이트는 안 쓰느니만
// 못하므로 먼저 주석을 걷어낸다. URL 의 "//" 는 앞 글자가 ':' 인 경우로 구분한다.
const stripComments = (src) =>
  src
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/(^|[^:])\/\/.*$/gm, "$1");

const readSpecs = (file) => {
  const src = stripComments(fs.readFileSync(file, "utf8"));
  const out = [];
  let m;
  while ((m = SPEC_RE.exec(src))) out.push(m[1]);
  SPEC_RE.lastIndex = 0;
  return out;
};

const resolveRelative = (spec, fromFile) => {
  const base = path.resolve(path.dirname(fromFile), spec);
  const candidates = [
    ...EXTS.map((e) => base + e),
    ...EXTS.filter(Boolean).map((e) => path.join(base, "index" + e)),
  ];
  return candidates.find((c) => fs.existsSync(c) && fs.statSync(c).isFile()) || null;
};

const seen = new Set();
const problems = [];

const walk = (file, chain) => {
  if (seen.has(file)) return;
  seen.add(file);
  const trail = [...chain, path.relative(root, file)];

  for (const spec of readSpecs(file)) {
    if (spec.startsWith("@/")) {
      problems.push({ spec, kind: "별칭", trail });
      continue;
    }
    if (!spec.startsWith(".")) continue; // npm 패키지
    const resolved = resolveRelative(spec, file);
    if (!resolved) {
      problems.push({ spec, kind: "누락", trail });
      continue;
    }
    walk(resolved, trail);
  }
};

for (const entry of ENTRIES) {
  const full = path.join(root, entry);
  if (fs.existsSync(full)) walk(full, []);
}

if (problems.length === 0) {
  console.log(`[alias-gate] OK — Node 실행 경로 ${seen.size}개 파일에 별칭/누락 없음`);
  process.exit(0);
}

console.error("[alias-gate] Node 가 직접 실행하는 경로에서 풀 수 없는 import 를 찾았다.");
for (const p of problems) {
  console.error(`  - ${p.kind}: "${p.spec}"`);
  console.error(`      경로: ${p.trail.join(" -> ")}`);
}
console.error('  고치는 법: "@/lib/x" -> "./x.js" 처럼 확장자를 포함한 상대경로로 바꾼다.');
process.exit(1);
