// 저장소 문서가 eDoc 문서로 "제대로" 만들어지는지 검사한다.
//
// 왜
//   README 를 비롯한 저장소 문서는 sync_repo_docs_to_edoc 이 eDoc 으로 올려 사용자가
//   햄버거 메뉴 공용문서에서 그대로 읽는다. 변환기가 다루지 못하는 문법(코드펜스,
//   인용문 안의 펜스, 셀에 파이프가 든 표)은 조용히 깨진 문서가 되어 나가는데,
//   동기화 실패가 아니라 "성공했지만 내용이 이상한" 상태라 로그로는 알 수 없다.
//   실제로 mermaid 흐름도가 소스째 실리고, 표 한 개가 열이 밀려 있었다.
//
// 무엇을
//   실제 변환기를 그대로 돌려 만들어진 컴포넌트를 검사한다.
//   - 렌더러가 아는 타입인가
//   - 타입별 필수 runtime_data 가 있는가
//   - 표의 각 행이 헤더와 열 수가 같은가
//   - 본문 텍스트에 코드/다이어그램 소스나 표·체크리스트 원문이 남지 않았는가
//
// 실행: node scripts/doc_sync_gate.cjs   (위반 시 exit 1)

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

// 이 스크립트는 파생 저장소의 node_modules 안에서도 실행된다. 자기 위치를
// 앱 루트로 단정하면 그 저장소의 파일이 아니라 패키지 안을 검사하게 된다.
const ROOT = process.env.BRUNNER_APP_DIR || process.cwd();
const SYNC = path.join(__dirname, "sync_repo_docs_to_edoc.cjs");

const src = fs.readFileSync(SYNC, "utf8");
const from = src.indexOf("const componentType = {");
const to = src.indexOf("function markdownToEDoc(");
if (from < 0 || to < 0) {
  console.error("[doc-gate] sync_repo_docs_to_edoc.cjs 구조가 바뀌었다 — 게이트를 손봐야 한다.");
  process.exit(1);
}
eval(src.slice(from, to));

// 동기화 대상은 스크립트의 DOCS 목록에서 그대로 읽는다(둘이 갈라지지 않게).
const FILES = [...src.matchAll(/file:\s*"([^"]+\.md)"/g)].map((m) => m[1]);

const SUPPORTED = new Set([
  "Text", "Table", "Image", "Input", "Checklist",
  "Button", "Video", "LinkText", "Lottie", "Card",
]);
const REQUIRED = {
  Text: ["content"],
  Table: ["columns", "rows"],
  Image: ["src"],
  Checklist: ["items"],
  Button: ["buttonText"],
};

let violations = 0;
console.log("=== 저장소 문서 변환 게이트 ===");

for (const file of FILES) {
  const full = path.join(ROOT, file);
  if (!fs.existsSync(full)) {
    console.log(`  ${file.padEnd(20)} 파일 없음 — 동기화 대상에서 빼거나 파일을 만든다`);
    violations += 1;
    continue;
  }

  const comps = markdownToComponents(fs.readFileSync(full, "utf8"), "gate");
  const found = [];
  const ids = new Set();

  for (const c of comps) {
    if (!SUPPORTED.has(c.type)) found.push(`렌더러가 모르는 타입 ${c.type}`);
    if (!c.id) found.push("id 없는 컴포넌트");
    else if (ids.has(c.id)) found.push(`id 중복 ${c.id}`);
    ids.add(c.id);

    const rd = c.runtime_data;
    if (!rd || typeof rd !== "object") { found.push(`${c.type}: runtime_data 없음`); continue; }
    for (const k of REQUIRED[c.type] || []) {
      if (rd[k] === undefined || rd[k] === null) found.push(`${c.type}: ${k} 누락`);
    }

    if (c.type === "Text" && typeof rd.content === "string") {
      if (!rd.content.trim()) found.push("빈 Text");
      if (/```|sequenceDiagram|graph (TD|LR)|->>/.test(rd.content)) found.push("코드·다이어그램 소스가 본문에 남음");
      if (/^\s*\|/m.test(rd.content)) found.push("표가 표 컴포넌트가 아니라 텍스트로 떨어짐");
      if (/^\s*[-*]\s+\[[ x]\]/m.test(rd.content)) found.push("체크리스트가 텍스트로 떨어짐");
    }

    if (c.type === "Table") {
      const width = Array.isArray(rd.columns) ? rd.columns.length : 0;
      if (!width) found.push("표에 헤더가 없음");
      if (!Array.isArray(rd.rows)) found.push("표 rows 형식 오류");
      else if (rd.rows.some((r) => !Array.isArray(r) || r.length !== width)) {
        found.push("표에 열 수가 어긋난 행이 있음 (셀 안의 | 는 \\| 로 적는다)");
      }
    }
  }

  const uniq = [...new Set(found)];
  if (uniq.length) {
    violations += uniq.length;
    console.log(`  ❌ ${file} (컴포넌트 ${comps.length}개)`);
    uniq.forEach((v) => console.log(`       - ${v}`));
  } else {
    console.log(`  ✅ ${file.padEnd(20)} 컴포넌트 ${comps.length}개`);
  }
}

console.log("");
if (violations) {
  console.error(`[doc-gate] 위반 ${violations}건 — 이대로 배포하면 사용자 문서가 깨진 채로 나간다.`);
  process.exit(1);
}
console.log("[doc-gate] OK — 모든 저장소 문서가 정상 변환된다.");
