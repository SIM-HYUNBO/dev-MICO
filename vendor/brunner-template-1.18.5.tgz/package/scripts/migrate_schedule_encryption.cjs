// 기존 일정 title/description을 AES-256-GCM으로 암호화하는 1회성 마이그레이션
// 이미 enc: 접두사가 있는 행은 건너뜀 (idempotent)

const { Client } = require("pg");
const crypto = require("crypto");
const path = require("path");

require("dotenv").config({ path: path.join(__dirname, "../.env") });


const ALGORITHM = "aes-256-gcm";
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const ENCODING = "base64";
const PREFIX = "enc:";

function getKey() {
  const raw = process.env.APP_ENCRYPTION_KEY || "";
  if (!raw) throw new Error("APP_ENCRYPTION_KEY 환경변수가 설정되지 않았습니다.");
  return crypto.createHash("sha256").update(raw + ":schedule").digest();
}

function encrypt(plaintext) {
  if (!plaintext || plaintext.startsWith(PREFIX)) return plaintext;
  const key = getKey();
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return PREFIX + Buffer.concat([iv, authTag, encrypted]).toString(ENCODING);
}

async function run() {
  if (!process.env.APP_ENCRYPTION_KEY) {
    console.log("[migrate_schedule_encryption] APP_ENCRYPTION_KEY 미설정 — 마이그레이션 스킵.");
    return;
  }

  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();

  try {
    const { rows } = await client.query(
      `SELECT schedule_id, title, description FROM brunner_template.TB_COR_SCHEDULE
       WHERE title NOT LIKE '${PREFIX}%' OR (description IS NOT NULL AND description NOT LIKE '${PREFIX}%')`
    );

    if (rows.length === 0) {
      console.log("[migrate_schedule_encryption] 암호화할 행 없음. 완료.");
      return;
    }

    console.log(`[migrate_schedule_encryption] ${rows.length}건 암호화 시작...`);
    let count = 0;

    for (const row of rows) {
      const encTitle = encrypt(row.title);
      const encDesc = row.description ? encrypt(row.description) : null;
      await client.query(
        `UPDATE brunner_template.TB_COR_SCHEDULE SET title = $1, description = $2 WHERE schedule_id = $3`,
        [encTitle, encDesc, row.schedule_id]
      );
      count++;
    }

    console.log(`[migrate_schedule_encryption] ${count}건 암호화 완료.`);
  } finally {
    await client.end();
  }
}

run().catch((e) => { console.error(e); process.exit(1); });
