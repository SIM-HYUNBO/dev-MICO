-- 채팅방 room_type 포함 동적 SQL

-- 목록 조회: room_type을 함께 내려 홈에서 1:1/단체방을 고정 분류한다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_MST', 1,
  'SELECT r.id, r.name, r.created_by, COALESCE(r.is_secret, FALSE) AS is_secret, COALESCE(r.room_type, ''GROUP'') AS room_type, (SELECT COUNT(*) FROM brunner_template.TB_COR_CHATROOM_USERS u2 WHERE u2.system_code = $1 AND u2.room_id = r.id) AS member_count, (SELECT u2.user_id FROM brunner_template.TB_COR_CHATROOM_USERS u2 WHERE u2.system_code = $1 AND u2.room_id = r.id AND u2.user_id <> $2 ORDER BY u2.user_id LIMIT 1) AS direct_peer_user_id, (SELECT COALESCE(NULLIF(TRIM(um.user_name), ''''), u2.user_id) FROM brunner_template.TB_COR_CHATROOM_USERS u2 LEFT JOIN brunner_template.TB_COR_USER_MST um ON um.system_code = u2.system_code AND um.user_id = u2.user_id WHERE u2.system_code = $1 AND u2.room_id = r.id AND u2.user_id <> $2 ORDER BY u2.user_id LIMIT 1) AS direct_peer_name, (SELECT MAX(m.created_at) FROM brunner_template.TB_COR_CHAT_MSG m WHERE m.system_code = $1 AND m.room_id = r.id) AS last_message_at FROM brunner_template.TB_COR_CHATROOM_MST r INNER JOIN brunner_template.TB_COR_CHATROOM_USERS u ON u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2 WHERE r.system_code = $1 ORDER BY last_message_at DESC NULLS LAST, r.name ASC',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 일반 단체방 생성.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHATROOM_MST', 1,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type) VALUES ($1, $2, $3, $4, FALSE, ''GROUP'') ON CONFLICT DO NOTHING',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 비밀 단체방 생성.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHATROOM_MST', 2,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type) VALUES ($1, $2, $3, $4, TRUE, ''GROUP'') ON CONFLICT DO NOTHING',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 일반 1:1 방 생성.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHATROOM_MST', 3,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type) VALUES ($1, $2, $3, $4, FALSE, ''DIRECT'') ON CONFLICT DO NOTHING',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 비밀 1:1 방 생성.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHATROOM_MST', 4,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type) VALUES ($1, $2, $3, $4, TRUE, ''DIRECT'') ON CONFLICT DO NOTHING',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
