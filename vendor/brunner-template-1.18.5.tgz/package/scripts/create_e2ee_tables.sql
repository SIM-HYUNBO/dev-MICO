-- E2EE 비밀채팅 스키마 변경
ALTER TABLE brunner_template.TB_COR_CHATROOM_MST ADD COLUMN IF NOT EXISTS is_secret BOOLEAN DEFAULT FALSE;
ALTER TABLE brunner_template.TB_COR_USER_MST ADD COLUMN IF NOT EXISTS public_key TEXT;

-- 단체 비밀방 멤버별 암호화된 룸키 저장
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHATROOM_MEMBER_KEY (
  system_code    VARCHAR(10)  NOT NULL,
  room_id        UUID         NOT NULL,
  user_id        VARCHAR(50)  NOT NULL,
  encrypted_key  TEXT         NOT NULL,
  key_provider_id VARCHAR(50) NOT NULL,
  PRIMARY KEY (system_code, room_id, user_id)
);

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_USER_E2EE_DEVICE_KEY (
  system_code    VARCHAR(10)  NOT NULL,
  user_id        VARCHAR(50)  NOT NULL,
  device_id      VARCHAR(120) NOT NULL,
  public_key     TEXT         NOT NULL,
  updated_at     TIMESTAMP    NOT NULL DEFAULT NOW(),
  PRIMARY KEY (system_code, user_id, device_id)
);

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHATROOM_MEMBER_DEVICE_KEY (
  system_code             VARCHAR(10)  NOT NULL,
  room_id                 UUID         NOT NULL,
  user_id                 VARCHAR(50)  NOT NULL,
  device_id               VARCHAR(120) NOT NULL,
  encrypted_key           TEXT         NOT NULL,
  key_provider_id         VARCHAR(50)  NOT NULL,
  key_provider_device_id  VARCHAR(120),
  updated_at              TIMESTAMP    NOT NULL DEFAULT NOW(),
  PRIMARY KEY (system_code, room_id, user_id, device_id)
);

-- 비밀방 룸키 직접 저장 (방별 단일 키, 멤버이면 누구나 조회 가능)
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHATROOM_ROOM_KEY (
  system_code  VARCHAR(10)  NOT NULL,
  room_id      UUID         NOT NULL,
  room_key_b64 TEXT         NOT NULL,
  updated_at   TIMESTAMP    NOT NULL DEFAULT NOW(),
  PRIMARY KEY (system_code, room_id)
);

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHATROOM_ROOM_KEY_HISTORY (
  system_code  VARCHAR(10)  NOT NULL,
  room_id      UUID         NOT NULL,
  key_hash     VARCHAR(32)  NOT NULL,
  room_key_b64 TEXT         NOT NULL,
  updated_at   TIMESTAMP    NOT NULL DEFAULT NOW(),
  PRIMARY KEY (system_code, room_id, key_hash)
);
