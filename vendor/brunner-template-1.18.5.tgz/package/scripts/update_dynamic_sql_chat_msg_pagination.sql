-- 채팅 메시지 조회 쿼리 개선: LIMIT 기반 페이지네이션
-- [1] seq=1: 초기 로드 — 최신 20개만 가져오도록 LIMIT 20 추가
-- [2] seq=2: 스크롤 업 페이지네이션 — msg_id < $3 기준으로 이전 20개 조회
-- 실행 후: 서버 재시작 필요

-- ※ 아래 SELECT 컬럼 목록이 현재 DB의 seq=1 쿼리와 다를 경우
--   컬럼 명칭을 맞춰서 수정한 뒤 실행하세요.

-- [1] seq=1 UPDATE: LIMIT 1000 → 20 (기존 전체 조회 → 최신 20개)
UPDATE brunner_template.TB_COR_SQL_INFO
SET SQL_CONTENT = 'SELECT msg_id AS id, user_id AS "userId", user_name AS "userName", message, reply_to AS "replyTo", created_at AS ts FROM brunner_template.tb_cor_chat_msg WHERE system_code = $1 AND room_id = $2::uuid ORDER BY msg_id DESC LIMIT 20'
WHERE SYSTEM_CODE = '00'
  AND SQL_NAME = 'select_TB_COR_CHAT_MSG'
  AND SQL_SEQ = 1;

-- [2] seq=2 INSERT: beforeId 기준 이전 20개 페이지네이션
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'select_TB_COR_CHAT_MSG',
  2,
  'SELECT msg_id AS id, user_id AS "userId", user_name AS "userName", message, reply_to AS "replyTo", created_at AS ts FROM brunner_template.tb_cor_chat_msg WHERE system_code = $1 AND room_id = $2::uuid AND msg_id < $3 ORDER BY msg_id DESC LIMIT 20',
  'SYSTEM',
  NOW()
)
-- 재적용해도 실패하지 않게 한다. 이 파일만 ON CONFLICT 가 빠져 있어,
-- 이미 적용된 DB 에 db:init 을 다시 돌리면 PK 충돌로 여기서 멈췄다.
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_USER_ID = EXCLUDED.CREATE_USER_ID, UPDATE_TIME = NOW();

-- 이미 seq=2가 등록된 경우
UPDATE brunner_template.TB_COR_SQL_INFO
SET SQL_CONTENT = 'SELECT msg_id AS id, user_id AS "userId", user_name AS "userName", message, reply_to AS "replyTo", created_at AS ts FROM brunner_template.tb_cor_chat_msg WHERE system_code = $1 AND room_id = $2::uuid AND msg_id < $3 ORDER BY msg_id DESC LIMIT 20'
WHERE SYSTEM_CODE = '00'
  AND SQL_NAME = 'select_TB_COR_CHAT_MSG'
  AND SQL_SEQ = 2;
