-- 방 삭제 시 관련 데이터 cascade delete용 동적쿼리 등록
-- 실행 후: 서버 재시작 필요

-- [1] 방 전체 메시지 삭제: delete_TB_COR_CHAT_MSG seq=3
-- $1: systemCode, $2: roomId
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'delete_TB_COR_CHAT_MSG',
  3,
  'DELETE FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND room_id = $2',
  'SYSTEM',
  NOW()
) ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE
  SET SQL_CONTENT = EXCLUDED.SQL_CONTENT;

-- [2] 방 읽음 정보 삭제: delete_TB_COR_CHAT_READ_RECEIPT seq=1
-- $1: systemCode, $2: roomId
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'delete_TB_COR_CHAT_READ_RECEIPT',
  1,
  'DELETE FROM brunner_template.TB_COR_CHAT_READ_RECEIPT WHERE system_code = $1 AND room_id = $2',
  'SYSTEM',
  NOW()
) ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE
  SET SQL_CONTENT = EXCLUDED.SQL_CONTENT;

-- [3] 나 외의 다른 사람이 보낸 메시지 건수 조회: select_TB_COR_CHAT_MSG seq=3
-- $1: systemCode, $2: roomId, $3: userId(나) → { cnt }
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'select_TB_COR_CHAT_MSG',
  3,
  'SELECT COUNT(*) AS cnt FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND room_id = $2 AND message IS NOT NULL AND user_id != $3',
  'SYSTEM',
  NOW()
) ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE
  SET SQL_CONTENT = EXCLUDED.SQL_CONTENT;

-- [4] 방의 전체 멤버 삭제: delete_TB_COR_CHATROOM_USERS seq=2
-- $1: systemCode, $2: roomId
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'delete_TB_COR_CHATROOM_USERS',
  2,
  'DELETE FROM brunner_template.TB_COR_CHATROOM_USERS WHERE system_code = $1 AND room_id = $2',
  'SYSTEM',
  NOW()
) ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE
  SET SQL_CONTENT = EXCLUDED.SQL_CONTENT;

-- [5] 특정 방 직접 삭제: delete_TB_COR_CHATROOM_MST seq=1
-- $1: systemCode, $2: roomId
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'delete_TB_COR_CHATROOM_MST',
  1,
  'DELETE FROM brunner_template.TB_COR_CHATROOM_MST WHERE system_code = $1 AND id = $2',
  'SYSTEM',
  NOW()
) ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE
  SET SQL_CONTENT = EXCLUDED.SQL_CONTENT;
