-- 코어에서만 쓰는데 이름이 규칙에 안 맞거나, 부르는 코드가 없어진 SQL_NAME 을 지운다.
--
-- select_TABLE_USAGE
--   테이블별 적재량 조회다. 시드에만 있고 부르는 코드는 없었다 — 화면(dbUsage.js)은
--   같은 일을 하는 쿼리를 코드에 하드코딩해 따로 들고 있었다. 그 쿼리를
--   select_TB_COR_TABLE_USAGE 로 등록하면서 이 이름은 쓸 자리가 없어졌다.
--   영역 접두어가 없어 이름 규칙에도 어긋난다. 코어 전용 쿼리이므로 파생 리포가
--   이 이름을 부를 일도 없다.
--
-- 이 파일이 insert_dynamic_sql_db_usage.sql 보다 앞에 있어야 하는 이유
--   순서가 반대면 새 이름을 심은 뒤 옛 이름이 남아, 같은 일을 하는 등록이 둘이 된다.
--
-- 재실행해도 결과가 같다.

DELETE FROM brunner_template.TB_COR_SQL_INFO
 WHERE SQL_NAME = 'select_TABLE_USAGE';
