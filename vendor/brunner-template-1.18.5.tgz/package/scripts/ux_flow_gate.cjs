#!/usr/bin/env node
"use strict";
// UX 흐름 게이트 — 끊긴 내비게이션(막다른 흐름) 검출.
// 새 화면/라우트를 추가하다 오타·삭제된 페이지로 링크하면 사용자가 막다른 곳에 빠진다.
// 이건 pages/ 라우트와 대조해 정적으로 확실히 잡을 수 있는 부류다.
// (로딩/에러/확인 모달 유무 같은 흐름 결함은 커스텀 패턴이 많아 정적 검출 시 오탐이 커서 제외 — 실사용 리뷰로 본다.)
const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();
const walk = (d, a = []) => {
  for (const f of fs.readdirSync(d)) {
    const p = path.join(d, f);
    const s = fs.statSync(p);
    if (s.isDirectory()) { if (!/node_modules|\.next|\.git/.test(p)) walk(p, a); }
    else if (/\.(js|jsx|ts|tsx)$/.test(p)) a.push(p);
  }
  return a;
};

// pages/ → 유효 라우트 집합
const pagesDir = path.join(ROOT, "pages");
const routeSet = new Set();
const toRoute = (file) => {
  let r = "/" + path.relative(pagesDir, file).replace(/\\/g, "/").replace(/\.(js|jsx|ts|tsx)$/, "");
  return r.replace(/\/index$/, "") || "/";
};
for (const f of walk(pagesDir)) {
  if (/\/api\//.test(f) || /\/_(app|document|error)\b/.test(f)) continue;
  routeSet.add(toRoute(f));
}
const routeExists = (rt) => {
  if (routeSet.has(rt)) return true;
  for (const r of routeSet) {
    if (!r.includes("[")) continue; // 동적 세그먼트 매칭
    if (new RegExp("^" + r.replace(/\[[^/]+\]/g, "[^/]+") + "$").test(rt)) return true;
  }
  return false;
};

// router.push/replace("..."), href="...", window.location = "..." 에서 내부 절대경로 추출
const navRe = /(?:router\.(?:push|replace)\(\s*|href\s*[=:]\s*|window\.location(?:\.href|\.replace)?\s*[=(]\s*)["'`]([^"'`]+)["'`]/g;
const findings = [];
for (const file of [...walk(path.join(ROOT, "components")), ...walk(pagesDir)]) {
  const lines = fs.readFileSync(file, "utf8").split("\n");
  lines.forEach((ln, i) => {
    let m; navRe.lastIndex = 0;
    while ((m = navRe.exec(ln))) {
      const target = m[1];
      if (!target.startsWith("/") || target.startsWith("/api/") || target.startsWith("//") || target.includes("${")) continue;
      const clean = target.split("?")[0].split("#")[0].replace(/\/$/, "") || "/";
      if (!routeExists(clean)) findings.push(`${file.replace(ROOT + "/", "")}:${i + 1}  → ${target}`);
    }
  });
}
const list = [...new Set(findings)];

console.log("\n=== UX 흐름 게이트 (끊긴 내비게이션) ===");
console.log(`유효 라우트 ${routeSet.size}개\n`);
list.forEach((s) => console.log("   - " + s));
console.log("=".repeat(44));
console.log(`끊긴 내비게이션(막다른 흐름) 위반: ${list.length}건 — 목표 0`);
process.exit(list.length ? 1 : 0);
