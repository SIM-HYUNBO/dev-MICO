-- 채팅방 목록 조회 SQL 수정 — 초대받은 방도 목록에 포함되도록 CHATROOM_USERS JOIN 방식으로 교체
-- select_TB_COR_CHATROOM_MST seq=1
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_MST', 1,
  'SELECT r.id, r.name, r.created_by, COALESCE(r.is_secret, FALSE) AS is_secret, (SELECT COUNT(*) FROM brunner_template.TB_COR_CHATROOM_USERS u2 WHERE u2.system_code = $1 AND u2.room_id = r.id) AS member_count FROM brunner_template.TB_COR_CHATROOM_MST r INNER JOIN brunner_template.TB_COR_CHATROOM_USERS u ON u.system_code = $1 AND u.room_id = r.id AND u.user_id = $2 WHERE r.system_code = $1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- insert_TB_COR_CHATROOM_USERS seq=1 — 멱등 INSERT (중복 무시)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHATROOM_USERS', 1,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_USERS (system_code, room_id, user_id) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- insert_TB_COR_CHATROOM_USERS seq=2 — room_id로 system_code 자동 조회 (composite FK 안전)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHATROOM_USERS', 2,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_USERS (system_code, room_id, user_id) SELECT m.system_code, m.id, $2 FROM brunner_template.TB_COR_CHATROOM_MST m WHERE m.id = $1::uuid ON CONFLICT DO NOTHING',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
