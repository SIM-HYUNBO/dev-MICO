-- fn_table_usage() 를 지운다.
--
-- 경위
--   테이블별 크기와 정확한 행수를 돌려주던 함수다. 유일한 호출자는 동적 SQL
--   select_TABLE_USAGE 였는데, 그 등록 자체가 부르는 코드 없이 시드에만 남아
--   있었다(delete_dead_sql_names.sql 참고). 화면(pages/api/biz/dbUsage.js)은
--   같은 일을 스키마를 파라미터로 받는 쿼리로 따로 하고 있었다.
--
-- 왜 함수 쪽을 버리나
--   함수 본문에 스키마가 'brunner_template' 리터럴로 박혀 있어 자기 설치 스키마
--   하나만 본다. 대상도 상위 80개로 잘려 있다. 남은 구현이 더 넓으므로 함수를
--   되살리는 쪽이 아니라 지우는 쪽이 맞다.
--
-- 지우지 않으면 매 배포마다 아무도 부르지 않는 함수를 다시 만든다.
-- 재실행해도 결과가 같다.

DROP FUNCTION IF EXISTS brunner_template.fn_table_usage();
