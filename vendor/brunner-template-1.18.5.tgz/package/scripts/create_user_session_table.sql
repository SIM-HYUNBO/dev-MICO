-- 사용자 세션 토큰 테이블 (REST API 인증용)
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_USER_SESSION (
  system_code   VARCHAR(10)  NOT NULL,
  session_token VARCHAR(64)  NOT NULL,
  user_id       VARCHAR(50)  NOT NULL,
  created_at    TIMESTAMP    NOT NULL DEFAULT NOW(),
  expires_at    TIMESTAMP    NOT NULL DEFAULT (NOW() + INTERVAL '30 days'),
  PRIMARY KEY (system_code, session_token)
);

CREATE INDEX IF NOT EXISTS idx_user_session_user
  ON brunner_template.TB_COR_USER_SESSION (system_code, user_id);
