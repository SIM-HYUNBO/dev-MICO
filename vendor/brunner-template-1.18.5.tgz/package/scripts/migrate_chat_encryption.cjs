// scripts/migrate_chat_encryption.cjs
// 기존 평문 채팅 메시지를 AES-256-GCM 암호화로 일괄 변환

const { Client } = require("pg");
const crypto = require("crypto");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, "../.env") });


const ALGORITHM = "aes-256-gcm";
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const PREFIX = "enc:";
const BATCH_SIZE = 200;

function getKey() {
  const raw = process.env.APP_ENCRYPTION_KEY || "";
  if (!raw) throw new Error("APP_ENCRYPTION_KEY 환경변수가 필요합니다.");
  return crypto.createHash("sha256").update(raw).digest();
}

function encrypt(plaintext) {
  if (!plaintext || plaintext.startsWith(PREFIX)) return plaintext;
  const key = getKey();
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return PREFIX + Buffer.concat([iv, authTag, encrypted]).toString("base64");
}

async function main() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL이 필요합니다.");
  if (!process.env.APP_ENCRYPTION_KEY) throw new Error("APP_ENCRYPTION_KEY가 필요합니다.");

  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.SSL_MODE === "require" ? { rejectUnauthorized: false } : false,
  });

  await client.connect();
  console.log("DB 연결 완료");

  // 평문 메시지 수 조회
  const countRes = await client.query(
    `SELECT COUNT(*) FROM brunner_template.TB_COR_CHAT_MSG WHERE message IS NOT NULL AND message NOT LIKE $1`,
    [PREFIX + "%"]
  );
  const total = parseInt(countRes.rows[0].count, 10);
  console.log(`암호화 대상 메시지: ${total}건`);

  if (total === 0) {
    console.log("모든 메시지가 이미 암호화되어 있습니다.");
    await client.end();
    return;
  }

  let offset = 0;
  let processed = 0;

  while (offset < total) {
    const res = await client.query(
      `SELECT msg_id, message, reply_to FROM brunner_template.TB_COR_CHAT_MSG
       WHERE message IS NOT NULL AND message NOT LIKE $1
       ORDER BY msg_id LIMIT $2 OFFSET $3`,
      [PREFIX + "%", BATCH_SIZE, offset]
    );

    if (res.rows.length === 0) break;

    for (const row of res.rows) {
      const encMessage = encrypt(row.message);

      let encReplyTo = row.reply_to;
      if (row.reply_to) {
        try {
          const rt = typeof row.reply_to === "string" ? JSON.parse(row.reply_to) : row.reply_to;
          if (rt?.message && !rt.message.startsWith(PREFIX)) {
            rt.message = encrypt(rt.message);
          }
          encReplyTo = JSON.stringify(rt);
        } catch {}
      }

      await client.query(
        `UPDATE brunner_template.TB_COR_CHAT_MSG SET message = $1, reply_to = $2 WHERE msg_id = $3`,
        [encMessage, encReplyTo, row.msg_id]
      );
    }

    processed += res.rows.length;
    offset += BATCH_SIZE;
    console.log(`진행: ${processed}/${total}건 완료`);
  }

  console.log(`\n마이그레이션 완료: 총 ${processed}건 암호화`);
  await client.end();
}

main().catch((err) => {
  console.error("마이그레이션 실패:", err.message);
  process.exit(1);
});
