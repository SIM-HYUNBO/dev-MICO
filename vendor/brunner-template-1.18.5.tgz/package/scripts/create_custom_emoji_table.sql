-- 개인 커스텀 이모지 테이블
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_CHAT_CUSTOM_EMOJI (
  system_code  VARCHAR(10)  NOT NULL,
  id           UUID         NOT NULL DEFAULT gen_random_uuid(),
  user_id      VARCHAR(50)  NOT NULL,
  name         VARCHAR(50)  NOT NULL,
  mime_type    VARCHAR(100) NOT NULL DEFAULT 'image/png',
  file_data    BYTEA        NOT NULL,
  created_at   TIMESTAMP    NOT NULL DEFAULT NOW(),
  PRIMARY KEY (system_code, id)
);

CREATE INDEX IF NOT EXISTS idx_custom_emoji_user
  ON brunner_template.TB_COR_CHAT_CUSTOM_EMOJI (system_code, user_id);
