-- 테이블 보관기간 정리 크론(lib/tableRetentionCron.js)이 쓰는 동적 SQL.
--
-- 왜 여기로 옮겼나
--   이 시스템의 공통 규칙은 모든 DB 쿼리를 TB_COR_SQL_INFO 에 등록해 쓰는 것이다.
--   이 크론은 설정 행 생성·스케줄 조회·실행 락 획득/반납 네 쿼리를 코드에 문자열로
--   들고 있었다.
--
-- 왜 테넌트를 돌며 심나
--   getSQL 은 {systemCode}_{name}_{seq} 로만 찾고 '00' 으로 폴백하지 않는다.
--   '00' 에만 심으면 SYSTEM_CODE 가 다른 시스템에서 정리 크론이 통째로 멈춘다.
--
-- 본문은 한 글자도 바꾸지 않았다. 스키마는 run_sql.cjs 의 retargetSchema 가
-- 배포마다 실제 DB_SCHEMA 로 바꿔 넣는다.
DO $seed$
DECLARE
  t    text;
  defs constant text[][] := ARRAY[
    -- 테넌트마다 기본 설정 행을 만들어 둔다. 락을 자기 행에 잡기 위함
    ['insert_TB_COR_TABLE_RETENTION_CONFIG','1',
     'INSERT INTO brunner_template.TB_COR_TABLE_RETENTION_CONFIG
         (system_code, id, run_at, timezone_offset_minutes, create_user_id, update_user_id)
       SELECT t.system_code, ''default'', $2, $3, ''system'', ''system''
         FROM UNNEST($1::text[]) AS t(system_code)
       ON CONFLICT (system_code) DO NOTHING'],
    -- 테넌트 목록에 대한 실행 스케줄. 행이 없는 테넌트도 NULL 로 돌려준다
    ['select_TB_COR_TABLE_RETENTION_CONFIG','2',
     'SELECT t.system_code, c.run_at, c.timezone_offset_minutes
         FROM UNNEST($1::text[]) AS t(system_code)
         LEFT JOIN brunner_template.TB_COR_TABLE_RETENTION_CONFIG c
                ON c.system_code = t.system_code
        ORDER BY t.system_code'],
    -- 실행 락 획득. 만료됐거나 내가 가진 락일 때만 잡힌다
    ['update_TB_COR_TABLE_RETENTION_CONFIG','1',
     'UPDATE brunner_template.TB_COR_TABLE_RETENTION_CONFIG
          SET lock_owner = $1,
              lock_until = NOW() + ($2::int * INTERVAL ''1 minute''),
              update_time = NOW()
        WHERE system_code = $3
          AND (lock_until IS NULL OR lock_until < NOW() OR lock_owner = $1)
        RETURNING system_code'],
    -- 실행 락 반납. 내가 가진 락일 때만 푼다
    ['update_TB_COR_TABLE_RETENTION_CONFIG','2',
     'UPDATE brunner_template.TB_COR_TABLE_RETENTION_CONFIG
          SET lock_owner = NULL,
              lock_until = NULL,
              update_time = NOW()
        WHERE system_code = $2
          AND lock_owner = $1']
  ];
  i int;
BEGIN
  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
      UNION SELECT '00'
    ) x ORDER BY code
  LOOP
    FOR i IN 1 .. array_length(defs, 1) LOOP
      INSERT INTO brunner_template.TB_COR_SQL_INFO
        (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
      VALUES (t, defs[i][1], defs[i][2]::int, defs[i][3], 'claude', NOW())
      ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
      DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
    END LOOP;
  END LOOP;
END
$seed$;
