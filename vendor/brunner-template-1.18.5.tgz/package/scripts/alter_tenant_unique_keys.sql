-- 테넌트 경계를 넘는 유니크 키를 시스템별로 가른다.
--
-- 왜
--   같은 DB 안에서 SYSTEM_CODE 로 테넌트를 나누는데, 아래 키들에는 SYSTEM_CODE 가
--   빠져 있다. 그대로 두면 한 테넌트가 쓴 값 때문에 다른 테넌트가 같은 값을 못 쓰고
--   (카카오 계정·초대코드), 아이디가 겹치면 남의 기기로 푸시가 간다(푸시 구독).
--
-- 안전장치
--   run_sql 은 실패하면 서버 기동을 막으므로, 없는 테이블·이미 끝난 마이그레이션은
--   조용히 건너뛴다. 반복 실행해도 결과가 같다.

DO $$
DECLARE
  t         record;
  old_name  text;
  new_cols  text[];
  rel       regclass;
BEGIN
  FOR t IN
    SELECT * FROM (VALUES
      ('tb_cor_push_subscription', 'p', ARRAY['user_id','endpoint'], 'pk_tb_cor_push_subscription'),
      ('tb_cor_friend_invite', 'p', ARRAY['invite_code'], 'pk_tb_cor_friend_invite'),
      ('tb_cor_chatroom_invite_token', 'p', ARRAY['token'], 'pk_tb_cor_chatroom_invite_token'),
      ('tb_cor_schedule_participant', 'u', ARRAY['schedule_id','user_id'], 'uq_tb_cor_schedule_participant_sys')
    ) AS v(tbl, kind, old_cols, new_name)
  LOOP
    -- 아직 없는 테이블은 건너뛴다.
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.tables
       WHERE table_schema = 'brunner_template' AND table_name = t.tbl
    ) OR NOT EXISTS (
      SELECT 1 FROM information_schema.columns
       WHERE table_schema = 'brunner_template' AND table_name = t.tbl AND column_name = 'system_code'
    ) THEN
      CONTINUE;
    END IF;

    rel := format('brunner_template.%I', t.tbl)::regclass;
    new_cols := ARRAY['system_code'] || t.old_cols;

    -- 테넌트가 빠진 옛 제약을 찾는다(컬럼 구성이 정확히 일치할 때만).
    SELECT c.conname INTO old_name
      FROM pg_constraint c
     WHERE c.conrelid = rel
       AND c.contype = t.kind
       AND (
         SELECT array_agg(a.attname::text ORDER BY a.attname)
           FROM unnest(c.conkey) k
           JOIN pg_attribute a ON a.attrelid = rel AND a.attnum = k
       ) = (SELECT array_agg(x ORDER BY x) FROM unnest(t.old_cols) x);

    IF old_name IS NOT NULL THEN
      EXECUTE format('ALTER TABLE brunner_template.%I DROP CONSTRAINT %I', t.tbl, old_name);
    END IF;

    -- 새 키가 이미 있으면 아무것도 하지 않는다.
    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint c
       WHERE c.conrelid = rel
         AND c.contype = t.kind
         AND (
           SELECT array_agg(a.attname::text ORDER BY a.attname)
             FROM unnest(c.conkey) k
             JOIN pg_attribute a ON a.attrelid = rel AND a.attnum = k
         ) = (SELECT array_agg(x ORDER BY x) FROM unnest(new_cols) x)
    ) THEN
      EXECUTE format(
        'ALTER TABLE brunner_template.%I ADD CONSTRAINT %I %s (%s)',
        t.tbl,
        t.new_name,
        CASE t.kind WHEN 'p' THEN 'PRIMARY KEY' ELSE 'UNIQUE' END,
        (SELECT string_agg(quote_ident(x), ', ') FROM unnest(new_cols) x)
      );
    END IF;

    old_name := NULL;
  END LOOP;
END $$;

-- 카카오 계정 유니크는 제약이 아니라 부분 인덱스로 걸려 있다.
-- 카카오 계정 하나로 여러 시스템에 각각 가입할 수 있어야 하므로 테넌트를 앞에 둔다.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema = 'brunner_template' AND table_name = 'tb_cor_user_mst' AND column_name = 'kakao_id'
  ) THEN
    DROP INDEX IF EXISTS brunner_template.idx_user_mst_kakao_id;
    CREATE UNIQUE INDEX IF NOT EXISTS uq_tb_cor_user_mst_system_kakao
      ON brunner_template.tb_cor_user_mst (system_code, kakao_id) WHERE kakao_id IS NOT NULL;
  END IF;
END $$;
