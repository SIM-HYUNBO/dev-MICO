// 파생 저장소가 템플릿에서 얼마나 갈라졌는지 측정한다.
//
// 왜 필요한가
//   파생 저장소는 템플릿 파일을 그대로 복사해 두고 일부만 고쳐 쓴다. 시간이
//   지나면 "일부러 고친 것"과 "그냥 낡은 것"이 섞여 구분되지 않는다. 실제로
//   zicp 는 scripts 96 개 중 86 개가 템플릿과 달랐는데, 그중 무엇이 의도된
//   커스터마이징인지 아무도 말할 수 없는 상태였다. 그러면 되돌릴 수도, 템플릿을
//   올릴 수도 없다.
//
// 무엇을 보나
//   저장소의 파일을 패키지의 같은 경로와 비교해 네 가지로 나눈다.
//     same     내용이 같다 — 저장소에 둘 이유가 없다. 지우면 패키지 것이 쓰인다.
//     override 다르고, overrides 목록에 있다 — 의도된 교체다.
//     drift    다르고, 목록에 없다 — 왜 다른지 아무도 모르는 상태다.
//     own      패키지에 없다 — 이 시스템 고유 파일이다.
//
//   고유 파일이 공용 이름공간(components/core, lib) 안에 있으면 따로 짚는다.
//   그 자리에 두면 나중에 템플릿이 같은 이름을 만들 때 충돌하고, 무엇이 우리
//   것인지도 읽는 사람이 알 수 없다.
//
// 쓰는 법
//   node node_modules/brunner-template/scripts/template_drift.cjs
//   node node_modules/brunner-template/scripts/template_drift.cjs --json
//   node node_modules/brunner-template/scripts/template_drift.cjs --prune-same

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const appDir = process.env.BRUNNER_APP_DIR || process.cwd();
const packageRoot = path.join(__dirname, "..");

// 비교 대상 — 저장소와 패키지가 같은 경로를 공유하는 곳들.
const COMPARE_ROOTS = ["components", "lib", "pages", "scripts", "styles", "public"];
// 내용이 같아도 저장소에 남아 있어야 하는 자리. Next 는 앱 루트의 pages 만
// 라우팅하고 앱의 public 만 서빙하므로, 패키지에 같은 파일이 있어도 지우면
// 그 URL 과 자산이 사라진다.
const REQUIRED_COPY_ROOTS = ["pages", "public"];
const isRequiredCopy = (relative) => REQUIRED_COPY_ROOTS.some((root) => relative.startsWith(`${root}/`));
// 고유 파일이 있어도 되는 자리. 이 밖의 고유 파일은 위치를 짚어 준다.
const OWN_CODE_ROOTS = ["service", "app"];
const SKIP_DIR = new Set(["node_modules", ".git", ".next", "vendor"]);

const readOverrides = () => {
  const file = path.join(appDir, "template-overrides.json");
  if (!fs.existsSync(file)) return { entries: [], exists: false };
  try {
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    const entries = Array.isArray(parsed) ? parsed : parsed.overrides || [];
    return { entries: entries.map((e) => (typeof e === "string" ? { path: e } : e)), exists: true };
  } catch (error) {
    console.error(`[drift] template-overrides.json 을 읽지 못했다: ${error.message}`);
    process.exit(1);
  }
};

const hashOf = (file) => crypto.createHash("sha1").update(fs.readFileSync(file)).digest("hex");

const walk = (root, base) => {
  const dir = path.join(root, base);
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    if (SKIP_DIR.has(entry.name)) return [];
    const relative = path.posix.join(base, entry.name);
    if (entry.isDirectory()) return walk(root, relative);
    return entry.isFile() ? [relative] : [];
  });
};

const overrides = readOverrides();
const overrideSet = new Set(overrides.entries.map((e) => e.path));
const overrideReason = new Map(overrides.entries.map((e) => [e.path, e.reason || ""]));

const result = { same: [], sameRequired: [], override: [], drift: [], own: [], ownInSharedSpace: [] };

for (const root of COMPARE_ROOTS) {
  for (const relative of walk(appDir, root)) {
    const packageFile = path.join(packageRoot, relative);
    if (!fs.existsSync(packageFile)) {
      result.own.push(relative);
      if (relative.startsWith("components/core/") || relative.startsWith("lib/")) {
        result.ownInSharedSpace.push(relative);
      }
      continue;
    }
    if (hashOf(path.join(appDir, relative)) === hashOf(packageFile)) {
      (isRequiredCopy(relative) ? result.sameRequired : result.same).push(relative);
    } else if (overrideSet.has(relative)) {
      result.override.push(relative);
    } else {
      result.drift.push(relative);
    }
  }
}

if (process.argv.includes("--json")) {
  console.log(JSON.stringify(result, null, 2));
  process.exit(0);
}

if (process.argv.includes("--prune-same")) {
  for (const relative of result.same) {
    fs.unlinkSync(path.join(appDir, relative));
  }
  console.log(`[drift] 패키지와 동일한 파일 ${result.same.length} 개를 지웠다.`);
  process.exit(0);
}

const list = (label, files, note) => {
  console.log(`\n${label}: ${files.length}`);
  if (note && files.length) console.log(`  ${note}`);
  files.slice(0, 40).forEach((f) => {
    const reason = overrideReason.get(f);
    console.log(`  - ${f}${reason ? `  (${reason})` : ""}`);
  });
  if (files.length > 40) console.log(`  ... 외 ${files.length - 40} 개`);
};

console.log(`앱: ${appDir}`);
console.log(`패키지: ${packageRoot}`);
if (!overrides.exists) {
  console.log("template-overrides.json 이 없다. 의도한 교체를 여기에 적으면 drift 와 구분된다.");
}

list("same (지워도 되는 사본)", result.same, "패키지의 같은 파일이 대신 쓰인다.");
list("same (지우면 안 되는 사본)", result.sameRequired, "pages 와 public 은 앱 루트에 있어야 라우팅·서빙된다.");
list("override (의도한 교체)", result.override);
list("drift (이유가 기록되지 않은 차이)", result.drift, "교체가 맞으면 template-overrides.json 에 적고, 아니면 되돌린다.");
list("own (이 시스템 고유)", result.own);
list("own 인데 공용 이름공간에 있음", result.ownInSharedSpace, `${OWN_CODE_ROOTS.join(" 또는 ")} 아래로 옮긴다.`);

console.log(
  `\n요약 — same ${result.same.length}(+유지필요 ${result.sameRequired.length}) / override ${result.override.length} / drift ${result.drift.length} / own ${result.own.length}`,
);

if (process.argv.includes("--strict") && result.drift.length) {
  process.exit(1);
}
