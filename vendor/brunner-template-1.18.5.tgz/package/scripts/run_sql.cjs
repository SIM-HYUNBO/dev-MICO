// scripts/run_sql.cjs
// DB table migration and dynamic SQL registration runner.
// last updated: 2026-06-18 R2 migration

const { Client } = require("pg");
const fs = require("fs");
const crypto = require("crypto");
const path = require("path");

// 파생 서비스에서는 이 파일이 node_modules 안에 있다. .env 는 패키지가 아니라
// 실행하는 앱 루트에 있으므로 그쪽을 먼저 본다.
const appDir = process.env.BRUNNER_APP_DIR || process.cwd();
require("dotenv").config({ path: path.join(appDir, ".env") });
require("dotenv").config({ path: path.join(__dirname, "../.env") });

// 스키마 DDL 은 한 곳만 책임진다.
//
// 세 서비스(brunner-next / brunner-template / zicp)는 brunner 스키마 하나를 공유하고
// SYSTEM_CODE 로만 갈린다. 옛 brunner_template · zicp 스키마는 이관 뒤 없어졌다.
// 여기 SQL 파일들은 스키마 이름을 그대로 박고 있고 TB_COR_SQL_INFO 를 DELETE 하는
// 것도 있어, 두 배포가 같은 스키마에 각자 DDL 을 돌리면 서로의 등록분을 지운다.
// 그래서 스키마를 소유한 배포(SCHEMA_OWNER)만 DDL 을 적용하고, 나머지는 건너뛴다.
// 소유자가 심을 때 그 스키마 안의 모든 테넌트(00·01·02)분을 함께 등록한다.
const SCHEMA_OWNER = "brunner";
// 소문자로 접는다. PostgreSQL 이 따옴표 없는 식별자를 그렇게 다루므로, 대소문자를
// 살리면 참조하는 모든 자리에서 따옴표를 씌워야 하고 한 군데만 빠져도 무너진다.
const DB_SCHEMA = (process.env.DB_SCHEMA || "").trim().toLowerCase() || "brunner_template";

if (!/^[a-z_][a-z0-9_]*$/.test(DB_SCHEMA)) {
  console.error(`[run_sql] DB_SCHEMA 형식이 올바르지 않다: ${DB_SCHEMA}`);
  process.exit(1);
}

const quoteIdentifier = (identifier) => `"${String(identifier).replace(/"/g, '""')}"`;
const DB_SCHEMA_SQL = quoteIdentifier(DB_SCHEMA);

// 이 리포는 남의 스키마에 얹혀 사는 테넌트라 기본값이 false 다. 하지만 설치
// 마법사로 만든 시스템은 자기 스키마의 주인이므로 스스로 DDL 을 적용해야 한다.
// 하드코딩해 두면 파생 시스템이 DB 를 영원히 초기화하지 못한다.
// 파생 서비스는 자기 SQL 을 따로 갖는다(예: 그 서비스 전용 리소스 시드). 목록을
// 앱 저장소에 두게 해야 패키지의 run_sql 을 그대로 쓰면서도 자기 것을 돌릴 수 있다.
// 스키마 소유자가 아니면 공용 DDL 은 건너뛰고 이 목록만 돌린다 — 남의 스키마에
// DDL 을 적용하지 않으면서 자기 데이터는 넣기 위해서다.
const readServiceSqlFiles = () => {
  const file = path.join(appDir, "scripts", "service_sql_files.json");
  if (!fs.existsSync(file)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    const list = Array.isArray(parsed) ? parsed : parsed.files || [];
    return list.map((entry) => String(entry).trim()).filter(Boolean);
  } catch (error) {
    console.error(`[run_sql] service_sql_files.json 을 읽지 못했다: ${error.message}`);
    process.exit(1);
  }
};

const OWNS_SCHEMA = String(process.env.DB_SCHEMA_OWNED || "").toLowerCase() === "true";


if (!OWNS_SCHEMA) {
  // 소유자가 아니어도 이 서비스 전용 SQL 은 돌려야 한다. 공용 DDL 만 건너뛴다.
  const serviceOnly = readServiceSqlFiles();
  if (serviceOnly.length) {
    console.log(`[run_sql] 스키마 소유자가 아니다 — 공용 DDL 은 건너뛰고 서비스 전용 SQL ${serviceOnly.length} 건만 적용한다.`);
    process.env.SQL_FILES = serviceOnly.join(",");
  } else {
    console.log(
    `[run_sql] 이 배포는 스키마 소유자가 아니다(DB_SCHEMA=${DB_SCHEMA}). DB_SCHEMA_OWNED 가 true 가 아니다. ` +
      `DDL 은 소유 배포가 모든 테넌트분을 함께 적용한다 — 건너뛴다.`
    );
    process.exit(0);
  }
}


// 적용 순서를 담은 단일 목록.
//
// 왜 파일로 빼나
//   신규 설치 위저드도 같은 목록을 그대로 적용해야 한다. 목록이 두 벌이면 한쪽에만 새
//   스크립트가 등록돼, 새로 설치한 시스템에만 테이블·쿼리가 빠진다(실제로 설치본에
//   테이블 11개와 동적 SQL 61건이 빠져 있었다).
const readInstallSqlFiles = () => {
  // 패키지로 설치된 앱은 이 스크립트를 node_modules 안에서 실행하고 cwd 는
  // 앱 루트다. appDir 만 보면 목록 파일을 못 찾아 기동이 통째로 죽는다.
  // SQL 본문과 같은 규칙으로, 앱이 자기 목록을 두면 그것을 먼저 쓰고
  // 없으면 패키지에 들어 있는 것을 쓴다.
  const candidates = [
    path.join(appDir, "scripts", "install_sql_files.json"),
    path.join(__dirname, "install_sql_files.json"),
  ];
  const file = candidates.find((candidate) => fs.existsSync(candidate));
  if (!file) {
    throw new Error(`install_sql_files.json not found: ${candidates.join(", ")}`);
  }
  const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
  const list = Array.isArray(parsed) ? parsed : parsed.files || [];
  // 항목은 파일명 문자열이거나 { file, why } 다. why 에는 그 자리에 있어야 하는 이유를 적는다
  // (예: rename 은 create 보다 앞이어야 한다). 순서 제약은 목록을 옮길 때 제일 먼저 잃는다.
  return list
    .map((entry) => String(typeof entry === "string" ? entry : entry?.file || "").trim())
    .filter(Boolean);
};

const DEFAULT_SQL_FILES = readInstallSqlFiles();

const sqlFilesFromEnv = (process.env.SQL_FILES || "")
  .split(",")
  .map((file) => file.trim())
  .filter(Boolean);

const serviceSqlFiles = readServiceSqlFiles();
const sqlFiles = sqlFilesFromEnv.length > 0
  ? sqlFilesFromEnv
  : [...DEFAULT_SQL_FILES, ...serviceSqlFiles];

const getSslConfig = () => {
  const mode = (process.env.SSL_MODE || "").trim().toLowerCase();
  if (mode === "disable" || mode === "false" || mode === "0") return false;
  if (mode === "require" || process.env.RAILWAY_ENVIRONMENT || process.env.NODE_ENV === "production") {
    return { rejectUnauthorized: false };
  }
  return false;
};

// 이 리포가 소유한 스키마 이름. SQL 본문에 리터럴로 박혀 있다.
const OWN_SCHEMA = "brunner_template";
const RETARGETABLE_SCHEMAS = ["brunner_template", "brunner"];

// 소유 스키마 이름을 이 배포가 실제로 보는 스키마로 바꾼다. 안 바꾸면
// DB_SCHEMA=brunner 로 뜬 설치본이 DDL 을 brunner_template 에 적용해,
// 앱이 보는 스키마와 DDL 이 적용되는 스키마가 영구히 갈린다.
const retargetSchema = (sql) => {
  let retargeted = sql;
  for (const schema of RETARGETABLE_SCHEMAS) {
    if (schema === DB_SCHEMA) continue;
    const schemaPrefix = new RegExp(
      `\\b${schema}\\.(?=(?:TB_|tb_|IDX_|idx_|UQ_|uq_|[A-Za-z0-9_]+_pkey|%I))`,
      "g",
    );
    retargeted = retargeted.replace(schemaPrefix, `${DB_SCHEMA_SQL}.`);
  }
  return retargeted;
};

// 앱이 자기 SQL 을 두면 그것을 먼저 쓰고, 없으면 패키지에 들어 있는 것을 쓴다.
const readSqlFile = (fileName) => {
  const candidates = [path.join(appDir, "scripts", fileName), path.join(__dirname, fileName)];
  const fullPath = candidates.find((candidate) => fs.existsSync(candidate));
  if (!fullPath) {
    throw new Error(`SQL file not found: ${fileName}`);
  }
  return retargetSchema(fs.readFileSync(fullPath, "utf8").trim());
};

// DB 재시작/복구 중처럼 잠시 뒤 사라지는 일시적 오류. 이 경우 즉시 실패시키지 않고 재시도한다.
// (recovery mode 한 번에 배포 전체가 막혀 사이트가 다운되는 것을 방지)
const TRANSIENT_DB_ERROR =
  /recovery mode|starting up|the database system is|ECONNREFUSED|ECONNRESET|Connection terminated|connection refused|could not connect|ETIMEDOUT|timeout expired/i;

// 시드 내용 전체의 지문. 이게 그대로면 적용해봐야 결과가 같으므로 건너뛴다.
//
// 배포마다 무조건 다시 적용하면 두 가지가 걸린다. 관리 화면(/mainPages/dynamicSql)
// 에서 손본 쿼리가 다음 배포에 시드 값으로 되돌아가고, 앱 기동이 마이그레이션
// 성공에 묶여 DB 가 잠깐 흔들리면 아예 뜨지 못한다. 시드가 바뀐 배포에서만
// 돌게 해서 둘 다 피한다.
const seedFingerprint = () =>
  crypto
    .createHash("sha256")
    .update(sqlFiles.map((f) => `${f}\n${readSqlFile(f)}`).join("\n--\n"))
    .digest("hex");

const FINGERPRINT_DDL = `
  CREATE TABLE IF NOT EXISTS ${DB_SCHEMA_SQL}.TB_COR_SEED_STATE (
    ID          VARCHAR(20) PRIMARY KEY,
    FINGERPRINT VARCHAR(64) NOT NULL,
    APPLIED_AT  TIMESTAMP   DEFAULT NOW()
  )`;

const applyAll = async () => {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: getSslConfig(),
  });
  await client.connect();
  try {
    const fingerprint = seedFingerprint();
    if (process.env.RUN_SQL_FORCE !== "true") {
      try {
        await client.query(`CREATE SCHEMA IF NOT EXISTS ${DB_SCHEMA_SQL}`);
        await client.query(FINGERPRINT_DDL);
        const prev = await client.query(
          `SELECT fingerprint FROM ${DB_SCHEMA_SQL}.TB_COR_SEED_STATE WHERE id = 'seed'`,
        );
        if (prev.rows[0]?.fingerprint === fingerprint) {
          console.log("[run_sql] 시드가 지난 적용과 같습니다 — 건너뜁니다. (RUN_SQL_FORCE=true 로 강제 실행)");
          return;
        }
      } catch (e) {
        // 지문 확인에 실패하면 판단할 근거가 없으니 그냥 적용한다.
        console.warn(`[run_sql] 시드 지문 확인 실패, 그대로 적용합니다: ${e.message}`);
      }
    }

    console.log(`[run_sql] Applying ${sqlFiles.length} SQL file(s) to schema ${DB_SCHEMA}.`);
    await client.query(`CREATE SCHEMA IF NOT EXISTS ${DB_SCHEMA_SQL}`);
    await client.query(FINGERPRINT_DDL);
    for (const fileName of sqlFiles) {
      const sql = readSqlFile(fileName);
      if (!sql) {
        console.log(`[run_sql] Skip empty file: ${fileName}`);
        continue;
      }
      console.log(`[run_sql] ${fileName}`);
      await client.query(sql);
    }
    await client.query(
      `INSERT INTO ${DB_SCHEMA_SQL}.TB_COR_SEED_STATE (id, fingerprint, applied_at)
         VALUES ('seed', $1, NOW())
       ON CONFLICT (id) DO UPDATE SET fingerprint = EXCLUDED.fingerprint, applied_at = NOW()`,
      [fingerprint],
    );
  } finally {
    await client.end().catch(() => {});
  }
};

async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is required.");
  }
  const maxAttempts = parseInt(process.env.RUN_SQL_MAX_ATTEMPTS || "10", 10);
  for (let attempt = 1; ; attempt++) {
    try {
      await applyAll();
      break;
    } catch (err) {
      const transient = TRANSIENT_DB_ERROR.test(err && err.message);
      if (transient && attempt < maxAttempts) {
        const wait = Math.min(30000, 3000 * attempt); // 3s,6s,9s...최대 30s
        console.warn(`[run_sql] transient DB error (attempt ${attempt}/${maxAttempts}): ${err.message} — retry in ${wait}ms`);
        await new Promise((r) => setTimeout(r, wait));
        continue;
      }
      throw err;
    }
  }
  console.log("[run_sql] SQL scripts applied.");
}

main().catch((err) => {
  console.error("[run_sql] Failed:", err.message);
  process.exit(1);
});
