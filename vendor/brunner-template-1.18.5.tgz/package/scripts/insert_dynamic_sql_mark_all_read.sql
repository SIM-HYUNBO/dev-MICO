-- 방의 모든 메시지를 현재 사용자 읽음 처리 (일괄 INSERT)
-- $1: systemCode, $2: roomId, $3: userId
-- 실행 후: 서버 재시작 필요

-- 최초 등록 시
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'insert_TB_COR_CHAT_READ_RECEIPT_ALL',
  1,
  'INSERT INTO brunner_template.TB_COR_CHAT_READ_RECEIPT (system_code, room_id, message_id, user_id) SELECT msg.system_code, msg.room_id, msg.msg_id, $3 FROM brunner_template.TB_COR_CHAT_MSG msg LEFT JOIN brunner_template.TB_COR_CHAT_READ_RECEIPT rr ON rr.system_code = msg.system_code AND rr.room_id = msg.room_id AND rr.message_id = msg.msg_id AND rr.user_id = $3 WHERE msg.room_id = $2::uuid AND msg.system_code = $1 AND msg.user_id != $3 AND msg.message IS NOT NULL AND rr.message_id IS NULL ON CONFLICT DO NOTHING',
  'SYSTEM',
  NOW()
)
-- 재적용해도 실패하지 않게 한다. 바깥 INSERT 에 ON CONFLICT 가 없어서,
-- 이미 적용된 DB 에 db:init 을 다시 돌리면 PK 충돌로 여기서 멈췄다.
-- (안쪽 SQL 문자열의 ON CONFLICT 는 이 INSERT 와 무관하다)
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_USER_ID = EXCLUDED.CREATE_USER_ID, UPDATE_TIME = NOW();

-- 이미 등록된 경우 UPDATE
UPDATE brunner_template.TB_COR_SQL_INFO
SET SQL_CONTENT = 'INSERT INTO brunner_template.TB_COR_CHAT_READ_RECEIPT (system_code, room_id, message_id, user_id) SELECT msg.system_code, msg.room_id, msg.msg_id, $3 FROM brunner_template.TB_COR_CHAT_MSG msg LEFT JOIN brunner_template.TB_COR_CHAT_READ_RECEIPT rr ON rr.system_code = msg.system_code AND rr.room_id = msg.room_id AND rr.message_id = msg.msg_id AND rr.user_id = $3 WHERE msg.room_id = $2::uuid AND msg.system_code = $1 AND msg.user_id != $3 AND msg.message IS NOT NULL AND rr.message_id IS NULL ON CONFLICT DO NOTHING'
WHERE SYSTEM_CODE = '00'
  AND SQL_NAME = 'insert_TB_COR_CHAT_READ_RECEIPT_ALL'
  AND SQL_SEQ = 1;
