-- 오픈채팅 동적 SQL 등록

-- 오픈채팅 목록 조회 ($1=systemCode, $2=category or 'ALL')
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_OPENCHAT_LIST', 1,
  'SELECT r.id, r.name, r.category, r.owner_id, COALESCE(r.description, '''') AS description, COALESCE(r.max_members, 100) AS max_members, (SELECT COUNT(*) FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id) AS member_count, (SELECT MAX(m.created_at) FROM brunner_template.TB_COR_CHAT_MSG m WHERE m.system_code = $1 AND m.room_id = r.id) AS last_message_at FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND r.room_type = ''OPEN'' AND ($2 = ''ALL'' OR r.category = $2) ORDER BY member_count DESC, last_message_at DESC NULLS LAST',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 오픈채팅 방 단건 조회 ($1=systemCode, $2=roomId)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_OPENCHAT_LIST', 2,
  'SELECT r.id, r.name, r.category, r.owner_id, COALESCE(r.description, '''') AS description, COALESCE(r.max_members, 100) AS max_members, r.room_type, (SELECT COUNT(*) FROM brunner_template.TB_COR_CHATROOM_USERS u WHERE u.system_code = $1 AND u.room_id = r.id) AS member_count FROM brunner_template.TB_COR_CHATROOM_MST r WHERE r.system_code = $1 AND r.id = $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 오픈채팅 방 생성 ($1=systemCode, $2=roomId, $3=name, $4=userId, $5=category, $6=description, $7=maxMembers)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_OPENCHAT_MST', 1,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_MST (system_code, id, name, created_by, is_secret, room_type, category, owner_id, description, max_members) VALUES ($1, $2, $3, $4::varchar, FALSE, ''OPEN'', $5, $4::varchar, $6, $7) ON CONFLICT DO NOTHING',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 방장 이전 ($1=systemCode, $2=roomId, $3=newOwnerId)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_OPENCHAT_OWNER', 1,
  'UPDATE brunner_template.TB_COR_CHATROOM_MST SET owner_id = $3 WHERE system_code = $1 AND id = $2',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
