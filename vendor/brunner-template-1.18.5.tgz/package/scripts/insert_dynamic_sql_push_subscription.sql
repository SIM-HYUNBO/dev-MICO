-- Push subscription table and dynamic SQL.
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_PUSH_SUBSCRIPTION (
  system_code VARCHAR(2) NOT NULL DEFAULT '00',
  user_id VARCHAR(100) NOT NULL,
  endpoint TEXT NOT NULL,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  PRIMARY KEY (system_code, user_id, endpoint)
);

ALTER TABLE brunner_template.TB_COR_PUSH_SUBSCRIPTION
  ADD COLUMN IF NOT EXISTS system_code VARCHAR(2) DEFAULT '00';

ALTER TABLE brunner_template.TB_COR_PUSH_SUBSCRIPTION
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT NOW();

UPDATE brunner_template.TB_COR_PUSH_SUBSCRIPTION
   SET system_code = '00'
 WHERE system_code IS NULL;

ALTER TABLE brunner_template.TB_COR_PUSH_SUBSCRIPTION
  ALTER COLUMN system_code SET DEFAULT '00';

ALTER TABLE brunner_template.TB_COR_PUSH_SUBSCRIPTION
  ALTER COLUMN system_code SET NOT NULL;

CREATE INDEX IF NOT EXISTS IDX_PUSH_SUBSCRIPTION_USER
  ON brunner_template.TB_COR_PUSH_SUBSCRIPTION (system_code, user_id);

-- 테넌트는 리터럴로 박지 않는다 — 이 등록분은 다른 테넌트로도 복제되므로 '00' 을 박아 두면
-- 그 배포가 남의 서비스 구독을 읽고 쓰게 된다(브런너 채팅 한 통에 zicp 앱에서도 알림이 뜬 원인).
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_PUSH_SUBSCRIPTION', 1,
  'WITH updated AS (UPDATE brunner_template.TB_COR_PUSH_SUBSCRIPTION SET system_code = $1, p256dh = $4, auth = $5, created_at = NOW() WHERE user_id = $2 AND endpoint = $3 RETURNING 1) INSERT INTO brunner_template.TB_COR_PUSH_SUBSCRIPTION (system_code, user_id, endpoint, p256dh, auth) SELECT $1, $2, $3, $4, $5 WHERE NOT EXISTS (SELECT 1 FROM updated)',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- User push subscriptions for chat, schedule, and direct request notifications.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_PUSH_SUBSCRIPTION', 1,
  'SELECT user_id, endpoint, p256dh, auth FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE system_code = $1 AND user_id = ANY($2::text[])',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 구독 회전(pushsubscriptionchange) 시 옛 endpoint로 소유 userId를 찾아 새 구독으로 이관한다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_PUSH_SUBSCRIPTION', 2,
  'SELECT user_id FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE endpoint = $1 LIMIT 1',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 구독 누적 정리 — 유저당 최근 5개만 남기고 오래된(대부분 죽은) 구독을 지운다.
-- iOS는 회전으로 endpoint가 매번 바뀌는데 죽은 endpoint에도 201을 줘서 만료 정리가 안 걸려 무한 누적된다.
-- 한 기기에 수십 개가 쌓이면 매 메시지마다 그만큼 중복 발송돼 APNs가 그 기기를 throttle → 실제 알림이 끊긴다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'delete_TB_COR_PUSH_SUBSCRIPTION', 3,
  'DELETE FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE system_code = $1 AND user_id = $2 AND endpoint NOT IN (SELECT endpoint FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE system_code = $1 AND user_id = $2 ORDER BY created_at DESC LIMIT 5)',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 진단용: 특정 유저의 구독 목록(endpoint+등록시각)을 최근순으로 조회한다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_PUSH_SUBSCRIPTION', 3,
  'SELECT endpoint, created_at FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE system_code = $1 AND user_id = $2 ORDER BY created_at DESC',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Admin push subscriptions for complaint notifications.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_ADMIN_PUSH_SUBSCRIPTION', 1,
  'SELECT ps.endpoint, ps.p256dh, ps.auth FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION ps JOIN brunner_template.TB_COR_USER_MST u ON u.system_code = ps.system_code AND u.user_id = ps.user_id WHERE ps.system_code = $1 AND (u.admin_flag = true OR u.admin_flag::text = ''Y'')',
  'codex', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'delete_TB_COR_PUSH_SUBSCRIPTION',
  1,
  'DELETE FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE user_id = $1 AND endpoint = $2',
  'codex',
  NOW()
)
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- Prevent the same browser/device endpoint from staying attached to multiple users.
INSERT INTO brunner_template.TB_COR_SQL_INFO (
  SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME
) VALUES (
  '00',
  'delete_TB_COR_PUSH_SUBSCRIPTION',
  2,
  'DELETE FROM brunner_template.TB_COR_PUSH_SUBSCRIPTION WHERE endpoint = $1',
  'codex',
  NOW()
)
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
