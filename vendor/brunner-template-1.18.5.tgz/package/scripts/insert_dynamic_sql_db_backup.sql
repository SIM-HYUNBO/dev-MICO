-- DB 백업 이력 동적 SQL. 스키마 안의 모든 테넌트에 심는다.
DO $seed$
DECLARE
  t    text;
  defs constant text[][] := ARRAY[
    ['insert_TB_COR_DB_BACKUP_HIST',
     'INSERT INTO brunner_template.TB_COR_DB_BACKUP_HIST (system_code, started_at, finished_at, result, method, object_key, size_bytes, table_count, row_count, error_message, triggered_by) VALUES ($1, $2, NOW(), $3, $4, $5, $6, $7, $8, $9, $10) RETURNING backup_id'],
    -- 조회는 최근 7일치만. 그보다 오래된 것은 화면에서 볼 이유가 없다.
    ['select_TB_COR_DB_BACKUP_HIST',
     'SELECT backup_id, started_at, finished_at, result, method, object_key, size_bytes, table_count, row_count, error_message, triggered_by FROM brunner_template.TB_COR_DB_BACKUP_HIST WHERE system_code = $1 AND started_at >= NOW() - INTERVAL ''7 days'' ORDER BY started_at DESC LIMIT $2'],
    ['delete_TB_COR_DB_BACKUP_HIST',
     'DELETE FROM brunner_template.TB_COR_DB_BACKUP_HIST WHERE system_code = $1 AND started_at < NOW() - ($2 || '' days'')::interval']
  ];
  i int;
BEGIN
  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
      UNION SELECT '00'
    ) x ORDER BY code
  LOOP
    FOR i IN 1 .. array_length(defs, 1) LOOP
      INSERT INTO brunner_template.TB_COR_SQL_INFO
        (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
      VALUES (t, defs[i][1], 1, defs[i][2], 'claude', NOW())
      ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
      DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
    END LOOP;
  END LOOP;
END
$seed$;
