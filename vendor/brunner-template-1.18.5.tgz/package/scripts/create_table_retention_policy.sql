-- Admin-configured table retention policies.
-- Cleanup runs in small batches from server.js and only for enabled policies.
CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_TABLE_RETENTION_POLICY (
  -- 보존정책은 테넌트마다 자기 행을 갖는다. 상속되는 기본 행은 두지 않는다.
  SYSTEM_CODE           VARCHAR(2)   NOT NULL DEFAULT '00',
  TABLE_NAME            VARCHAR(128) NOT NULL,
  DATE_COLUMN           VARCHAR(128) NOT NULL,
  RETENTION_DAYS        INTEGER      NOT NULL CHECK (RETENTION_DAYS > 0),
  ENABLED               BOOLEAN      NOT NULL DEFAULT FALSE,
  BATCH_SIZE            INTEGER      NOT NULL DEFAULT 1000 CHECK (BATCH_SIZE > 0),
  MAX_DELETE_PER_RUN    INTEGER      NOT NULL DEFAULT 10000 CHECK (MAX_DELETE_PER_RUN > 0),
  RECOMMENDATION_LEVEL  VARCHAR(20)  NOT NULL DEFAULT 'optional',
  RECOMMENDATION_REASON VARCHAR(300),
  LAST_RUN_AT           TIMESTAMP,
  LAST_DELETED_COUNT    INTEGER      NOT NULL DEFAULT 0,
  LAST_ERROR            TEXT,
  CREATE_USER_ID        VARCHAR(100),
  CREATE_TIME           TIMESTAMP    DEFAULT NOW(),
  UPDATE_USER_ID        VARCHAR(100),
  UPDATE_TIME           TIMESTAMP    DEFAULT NOW(),
  CONSTRAINT PK_TB_COR_TABLE_RETENTION_POLICY PRIMARY KEY (SYSTEM_CODE, TABLE_NAME)
);

ALTER TABLE brunner_template.TB_COR_TABLE_RETENTION_POLICY
  ADD COLUMN IF NOT EXISTS SYSTEM_CODE VARCHAR(2) NOT NULL DEFAULT '00',
  ADD COLUMN IF NOT EXISTS DATE_COLUMN VARCHAR(128) NOT NULL DEFAULT 'create_time',
  ADD COLUMN IF NOT EXISTS RETENTION_DAYS INTEGER NOT NULL DEFAULT 365 CHECK (RETENTION_DAYS > 0),
  ADD COLUMN IF NOT EXISTS ENABLED BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS BATCH_SIZE INTEGER NOT NULL DEFAULT 1000 CHECK (BATCH_SIZE > 0),
  ADD COLUMN IF NOT EXISTS MAX_DELETE_PER_RUN INTEGER NOT NULL DEFAULT 10000 CHECK (MAX_DELETE_PER_RUN > 0),
  ADD COLUMN IF NOT EXISTS RECOMMENDATION_LEVEL VARCHAR(20) NOT NULL DEFAULT 'optional',
  ADD COLUMN IF NOT EXISTS RECOMMENDATION_REASON VARCHAR(300),
  ADD COLUMN IF NOT EXISTS LAST_RUN_AT TIMESTAMP,
  ADD COLUMN IF NOT EXISTS LAST_DELETED_COUNT INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS LAST_ERROR TEXT,
  ADD COLUMN IF NOT EXISTS CREATE_USER_ID VARCHAR(100),
  ADD COLUMN IF NOT EXISTS CREATE_TIME TIMESTAMP DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS UPDATE_USER_ID VARCHAR(100),
  ADD COLUMN IF NOT EXISTS UPDATE_TIME TIMESTAMP DEFAULT NOW();

-- 기존 DB 는 PK 가 TABLE_NAME 단일이다. (SYSTEM_CODE, TABLE_NAME) 으로 올린다.
-- 아래 시드 INSERT 의 ON CONFLICT 가 이 복합키를 대상으로 하므로 반드시 먼저 와야 한다.
DO $$
DECLARE
  pk_name text;
  pk_cols int;
  rel     regclass := 'brunner_template.tb_cor_table_retention_policy'::regclass;
BEGIN
  SELECT c.conname, array_length(c.conkey, 1)
    INTO pk_name, pk_cols
    FROM pg_constraint c
   WHERE c.conrelid = rel AND c.contype = 'p';

  IF pk_name IS NOT NULL AND pk_cols = 1 THEN
    EXECUTE format('ALTER TABLE brunner_template.tb_cor_table_retention_policy DROP CONSTRAINT %I', pk_name);
    pk_name := NULL;
  END IF;

  IF pk_name IS NULL THEN
    ALTER TABLE brunner_template.tb_cor_table_retention_policy
      ADD CONSTRAINT pk_tb_cor_table_retention_policy PRIMARY KEY (SYSTEM_CODE, TABLE_NAME);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS IDX_RETENTION_POLICY_ENABLED
  ON brunner_template.TB_COR_TABLE_RETENTION_POLICY (ENABLED, TABLE_NAME);

CREATE INDEX IF NOT EXISTS IDX_RETENTION_TB_COR_USER_SESSION_EXPIRES
  ON brunner_template.TB_COR_USER_SESSION (expires_at);

CREATE INDEX IF NOT EXISTS IDX_RETENTION_TB_COR_USER_ACTIVITY_DATE
  ON brunner_template.TB_COR_USER_ACTIVITY_LOG (activity_date);

CREATE INDEX IF NOT EXISTS IDX_RETENTION_TB_COR_TXN_HIST_TIME
  ON brunner_template.TB_COR_TXN_HIST (create_time);

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_TABLE_RETENTION_CONFIG (
  -- 퍼지 실행 시각·타임존·락을 시스템별로 갖는다. 락이 테넌트별로 갈라져야
  -- 한 고객사 퍼지가 다른 고객사를 막지 않는다.
  SYSTEM_CODE              VARCHAR(2)  NOT NULL DEFAULT '00',
  ID                       VARCHAR(20) NOT NULL DEFAULT 'default',
  RUN_AT                   VARCHAR(5)   NOT NULL DEFAULT '03:30',
  TIMEZONE_OFFSET_MINUTES  INTEGER      NOT NULL DEFAULT 540,
  LOCK_OWNER               VARCHAR(120),
  LOCK_UNTIL               TIMESTAMP,
  CREATE_USER_ID           VARCHAR(100),
  CREATE_TIME              TIMESTAMP    DEFAULT NOW(),
  UPDATE_USER_ID           VARCHAR(100),
  UPDATE_TIME              TIMESTAMP    DEFAULT NOW(),
  CONSTRAINT CK_RETENTION_CONFIG_RUN_AT CHECK (RUN_AT ~ '^[0-2][0-9]:[0-5][0-9]$'),
  CONSTRAINT PK_TB_COR_TABLE_RETENTION_CONFIG PRIMARY KEY (SYSTEM_CODE)
);

ALTER TABLE brunner_template.TB_COR_TABLE_RETENTION_CONFIG
  ADD COLUMN IF NOT EXISTS SYSTEM_CODE VARCHAR(2) NOT NULL DEFAULT '00',
  ADD COLUMN IF NOT EXISTS RUN_AT VARCHAR(5) NOT NULL DEFAULT '03:30',
  ADD COLUMN IF NOT EXISTS TIMEZONE_OFFSET_MINUTES INTEGER NOT NULL DEFAULT 540,
  ADD COLUMN IF NOT EXISTS LOCK_OWNER VARCHAR(120),
  ADD COLUMN IF NOT EXISTS LOCK_UNTIL TIMESTAMP,
  ADD COLUMN IF NOT EXISTS CREATE_USER_ID VARCHAR(100),
  ADD COLUMN IF NOT EXISTS CREATE_TIME TIMESTAMP DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS UPDATE_USER_ID VARCHAR(100),
  ADD COLUMN IF NOT EXISTS UPDATE_TIME TIMESTAMP DEFAULT NOW();

-- 기존 DB 는 PK 가 ID 단일이다. SYSTEM_CODE 로 옮긴다.
-- 아래 시드 INSERT 의 ON CONFLICT 가 이 키를 대상으로 하므로 반드시 먼저 와야 한다.
DO $$
DECLARE
  pk_name text;
  pk_cols int;
  rel     regclass := 'brunner_template.tb_cor_table_retention_config'::regclass;
BEGIN
  SELECT c.conname, array_length(c.conkey, 1)
    INTO pk_name, pk_cols
    FROM pg_constraint c
   WHERE c.conrelid = rel AND c.contype = 'p';

  IF pk_name IS NOT NULL AND pk_cols = 1
     AND EXISTS (
       SELECT 1 FROM pg_attribute a
        WHERE a.attrelid = rel
          AND a.attname = 'id'
          AND a.attnum = (SELECT conkey[1] FROM pg_constraint WHERE conname = pk_name AND conrelid = rel)
     ) THEN
    EXECUTE format('ALTER TABLE brunner_template.tb_cor_table_retention_config DROP CONSTRAINT %I', pk_name);
    pk_name := NULL;
  END IF;

  IF pk_name IS NULL THEN
    ALTER TABLE brunner_template.tb_cor_table_retention_config
      ADD CONSTRAINT pk_tb_cor_table_retention_config PRIMARY KEY (SYSTEM_CODE);
  END IF;
END $$;

-- 테넌트마다 자기 실행 설정 행을 갖는다(락도 이 행에 걸린다).
-- 테넌트 목록은 사용자 테이블에서 뽑고, 아직 없으면 기본 시스템 하나로 시작한다.
DO $$
DECLARE
  tenants text[];
BEGIN
  IF to_regclass('brunner_template.tb_cor_user_mst') IS NOT NULL THEN
    EXECUTE 'SELECT array_agg(DISTINCT system_code) FROM brunner_template.tb_cor_user_mst WHERE system_code IS NOT NULL'
      INTO tenants;
  END IF;
  IF tenants IS NULL OR array_length(tenants, 1) IS NULL THEN
    tenants := ARRAY['00'];
  END IF;

  INSERT INTO brunner_template.TB_COR_TABLE_RETENTION_CONFIG
    (SYSTEM_CODE, ID, RUN_AT, TIMEZONE_OFFSET_MINUTES, CREATE_USER_ID, UPDATE_USER_ID)
  SELECT t, 'default', '03:30', 540, 'system', 'system' FROM UNNEST(tenants) t
  ON CONFLICT (SYSTEM_CODE) DO NOTHING;
END $$;

CREATE TABLE IF NOT EXISTS brunner_template.TB_COR_TABLE_RETENTION_RUN_HIST (
  RUN_ID                  BIGSERIAL PRIMARY KEY,
  SYSTEM_CODE             VARCHAR(2)   NOT NULL DEFAULT '00',
  TABLE_NAME              VARCHAR(128) NOT NULL,
  DATE_COLUMN             VARCHAR(128) NOT NULL,
  RETENTION_DAYS          INTEGER      NOT NULL,
  BATCH_SIZE              INTEGER      NOT NULL,
  MAX_DELETE_PER_RUN      INTEGER      NOT NULL,
  DELETED_COUNT           INTEGER      NOT NULL DEFAULT 0,
  LIMITED                 BOOLEAN      NOT NULL DEFAULT FALSE,
  ERROR_MESSAGE           TEXT,
  TRIGGER_TYPE            VARCHAR(20)  NOT NULL DEFAULT 'scheduled',
  RUN_STARTED_AT          TIMESTAMP    NOT NULL DEFAULT NOW(),
  RUN_FINISHED_AT         TIMESTAMP    NOT NULL DEFAULT NOW()
);

ALTER TABLE brunner_template.TB_COR_TABLE_RETENTION_RUN_HIST
  ADD COLUMN IF NOT EXISTS SYSTEM_CODE VARCHAR(2) NOT NULL DEFAULT '00';

-- 퍼지 대상 조회가 테넌트로 먼저 좁혀지므로 실행 이력도 같은 순서로 찾는다.
CREATE INDEX IF NOT EXISTS IDX_RETENTION_RUN_HIST_SYSTEM_STARTED
  ON brunner_template.TB_COR_TABLE_RETENTION_RUN_HIST (SYSTEM_CODE, RUN_STARTED_AT DESC);

CREATE INDEX IF NOT EXISTS IDX_RETENTION_RUN_HIST_STARTED
  ON brunner_template.TB_COR_TABLE_RETENTION_RUN_HIST (RUN_STARTED_AT DESC);

CREATE INDEX IF NOT EXISTS IDX_RETENTION_RUN_HIST_TABLE_STARTED
  ON brunner_template.TB_COR_TABLE_RETENTION_RUN_HIST (TABLE_NAME, RUN_STARTED_AT DESC);

-- Conservative default policies for framework-owned operational data.
-- User-authored content such as chat, posts, documents, and complaints remains opt-in.
-- 기본 정책을 테넌트마다 심는다. 상속되는 '기본 행' 은 두지 않는다 —
-- SYSTEM_CODE 는 언제나 실제 시스템 코드('00','01',...)여야 한다.
-- 관리자가 화면에서 값을 바꾸면 create/update_user_id 가 'system' 이 아니게 되어
-- 아래 DO UPDATE 대상에서 빠진다(사람이 정한 값을 배포가 되돌리지 않는다).
DO $$
DECLARE
  tenants text[];
BEGIN
  IF to_regclass('brunner_template.tb_cor_user_mst') IS NOT NULL THEN
    EXECUTE 'SELECT array_agg(DISTINCT system_code) FROM brunner_template.tb_cor_user_mst WHERE system_code IS NOT NULL'
      INTO tenants;
  END IF;
  IF tenants IS NULL OR array_length(tenants, 1) IS NULL THEN
    tenants := ARRAY['00'];
  END IF;

  INSERT INTO brunner_template.TB_COR_TABLE_RETENTION_POLICY
    (SYSTEM_CODE, TABLE_NAME, DATE_COLUMN, RETENTION_DAYS, ENABLED, BATCH_SIZE, MAX_DELETE_PER_RUN,
     RECOMMENDATION_LEVEL, RECOMMENDATION_REASON, CREATE_USER_ID, UPDATE_USER_ID)
  SELECT t.code, v.*
    FROM UNNEST(tenants) AS t(code)
    CROSS JOIN (VALUES
      ('tb_cor_user_session', 'expires_at', 30, TRUE, 1000, 10000,
       'recommended', 'Expired authentication sessions', 'system', 'system'),
      ('tb_cor_user_activity_log', 'activity_date', 90, TRUE, 1000, 10000,
       'recommended', 'User activity logs', 'system', 'system'),
      ('tb_cor_txn_hist', 'create_time', 7, TRUE, 1000, 10000,
       'recommended', 'Request and response transaction history', 'system', 'system'),
  -- 정리 배치가 돌 때마다 정책 수만큼 행이 쌓인다. 화면은 최근 30건만 조회하므로
  -- 그보다 오래된 이력은 보관 가치가 없다. 한 달치만 남긴다.
      ('tb_cor_table_retention_run_hist', 'run_started_at', 30, TRUE, 1000, 10000,
       'recommended', 'Cleanup run history', 'system', 'system'),
  -- 백업 이력. 화면은 최근 7일치만 조회하지만, 사고 후 되짚어볼 여지를 두어 한 달 보관한다.
  -- 정리는 이 보존정책이 맡는다 — 백업 크론이 따로 지우면 정리 규칙이 두 벌이 된다.
      ('tb_cor_db_backup_hist', 'started_at', 30, TRUE, 1000, 10000,
       'recommended', 'DB backup history', 'system', 'system')
    ) AS v(table_name, date_column, retention_days, enabled, batch_size, max_delete_per_run,
           recommendation_level, recommendation_reason, create_user_id, update_user_id)
  ON CONFLICT (SYSTEM_CODE, TABLE_NAME) DO UPDATE SET
  DATE_COLUMN = EXCLUDED.DATE_COLUMN,
  RETENTION_DAYS = EXCLUDED.RETENTION_DAYS,
  ENABLED = EXCLUDED.ENABLED,
  BATCH_SIZE = EXCLUDED.BATCH_SIZE,
  MAX_DELETE_PER_RUN = EXCLUDED.MAX_DELETE_PER_RUN,
  RECOMMENDATION_LEVEL = EXCLUDED.RECOMMENDATION_LEVEL,
  RECOMMENDATION_REASON = EXCLUDED.RECOMMENDATION_REASON,
  UPDATE_TIME = NOW()
  WHERE brunner_template.TB_COR_TABLE_RETENTION_POLICY.CREATE_USER_ID = 'system'
    AND brunner_template.TB_COR_TABLE_RETENTION_POLICY.UPDATE_USER_ID = 'system';
END $$;

-- 테넌트 필터가 붙은 뒤로는 날짜 단일 인덱스로 테넌트 하나를 지우려고 전체를 훑는다.
-- 기본 정책이 켜져 있는 테이블에 복합 인덱스를 미리 만들어 둔다.
-- run_sql 은 실패하면 서버 기동을 막으므로, 아직 없는 테이블은 조용히 건너뛴다.
DO $$
DECLARE
  t record;
BEGIN
  FOR t IN
    SELECT * FROM (VALUES
      ('tb_cor_user_activity_log', 'activity_date', 'idx_retention_tb_cor_user_activity_sys_date'),
      ('tb_cor_txn_hist',          'create_time',   'idx_retention_tb_cor_txn_hist_sys_time')
    ) AS v(tbl, col, idx)
  LOOP
    IF EXISTS (
      SELECT 1 FROM information_schema.columns
       WHERE table_schema = 'brunner_template' AND table_name = t.tbl AND column_name = 'system_code'
    ) AND EXISTS (
      SELECT 1 FROM information_schema.columns
       WHERE table_schema = 'brunner_template' AND table_name = t.tbl AND column_name = t.col
    ) THEN
      EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON brunner_template.%I (system_code, %I)', t.idx, t.tbl, t.col);
    END IF;
  END LOOP;
END $$;
