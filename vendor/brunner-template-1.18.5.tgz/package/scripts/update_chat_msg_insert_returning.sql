-- insert_TB_COR_CHAT_MSG에 RETURNING msg_id 추가
-- DB가 할당한 msg_id를 서버로 반환하여 in-memory id와 동기화
UPDATE brunner_template.TB_COR_SQL_INFO
SET SQL_CONTENT = SQL_CONTENT || ' RETURNING msg_id'
WHERE SYSTEM_CODE = '00'
  AND SQL_NAME = 'insert_TB_COR_CHAT_MSG'
  AND SQL_SEQ = 1
  AND SQL_CONTENT NOT LIKE '% RETURNING%';
