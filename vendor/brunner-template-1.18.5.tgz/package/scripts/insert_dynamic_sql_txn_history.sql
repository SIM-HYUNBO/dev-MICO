-- 트랜잭션 이력 조회 동적 SQL 등록
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_TXN_HIST', 1,
  'SELECT transaction_id, request_ip, request_message_content, reply_message_content, create_time FROM brunner_template.TB_COR_TXN_HIST WHERE system_code = $1 AND (coalesce(length($2::text), 0) = 0 OR CAST(request_message_content AS TEXT) ILIKE CONCAT(''%'', $2, ''%'') OR CAST(reply_message_content AS TEXT) ILIKE CONCAT(''%'', $2, ''%'') OR CAST(transaction_id AS TEXT) ILIKE CONCAT(''%'', $2, ''%'') OR request_ip ILIKE CONCAT(''%'', $2, ''%'')) ORDER BY create_time DESC LIMIT 500',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 트랜잭션 이력 저장
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_TXN_HIST', 1,
  'INSERT INTO brunner_template.TB_COR_TXN_HIST (SYSTEM_CODE, TRANSACTION_ID, REQUEST_IP, REQUEST_MESSAGE_CONTENT, REPLY_MESSAGE_CONTENT) VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING',
  'claude', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();

-- 오래된 트랜잭션 이력 삭제
