-- 시드로 남지 않은 동적 SQL 복원
--
-- 이 프레임워크는 SQL 을 코드가 아니라 TB_COR_SQL_INFO 에 두고 이름으로 꺼내
-- 쓴다. 아래 33건은 원본 운영 DB 에만 있고 스크립트로 남지 않아, 새 스키마에서는
-- 게시판·채팅·친구·동적SQL 관리 화면이 통째로 "Database operation failed." 로
-- 죽었다. 호출부가 넘기는 파라미터 순서와 화면이 읽는 필드에서 역추적해 복원했다.
--
-- 파라미터 순서는 호출부와 정확히 맞아야 한다. 바꿀 일이 있으면
-- node scripts/verify_dynamic_sql.cjs 로 대조할 것.

-- ==================================================================
-- 게시판
-- ==================================================================

-- 목록: [systemCode, postType]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_POST_INFO', 1,
  'SELECT post_id, post_type, post_content, create_user_id, create_time FROM brunner_template.TB_COR_POST_INFO WHERE system_code = $1 AND post_type = $2 ORDER BY create_time DESC',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 단건: [systemCode, postId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_POST_INFO', 2,
  'SELECT post_id, post_type, post_content, create_user_id, create_time FROM brunner_template.TB_COR_POST_INFO WHERE system_code = $1 AND post_id = $2 LIMIT 1',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 등록: [systemCode, postId, postType, content, userId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_POST_INFO', 1,
  'INSERT INTO brunner_template.TB_COR_POST_INFO (system_code, post_id, post_type, post_content, create_user_id, create_time) VALUES ($1, $2, $3, $4, $5, NOW())',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 수정: [systemCode, postId, content, userId] — 작성자 본인만
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_POST_INFO', 1,
  'UPDATE brunner_template.TB_COR_POST_INFO SET post_content = $3, update_user_id = $4, update_time = NOW() WHERE system_code = $1 AND post_id = $2 AND create_user_id = $4',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 삭제: [systemCode, postId, userId] — 작성자 본인만
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'delete_TB_COR_POST_INFO', 1,
  'DELETE FROM brunner_template.TB_COR_POST_INFO WHERE system_code = $1 AND post_id = $2 AND create_user_id = $3',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 글 삭제 시 딸린 댓글 정리: [systemCode, postId, userId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'delete_TB_COR_POST_COMMENT_INFO', 1,
  'DELETE FROM brunner_template.TB_COR_POST_COMMENT_INFO c WHERE c.system_code = $1 AND c.post_id = $2 AND EXISTS (SELECT 1 FROM brunner_template.TB_COR_POST_INFO p WHERE p.system_code = c.system_code AND p.post_id = c.post_id AND p.create_user_id = $3)',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 글별 댓글 목록: [systemCode, postId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_POST_COMMENT_INFO', 1,
  'SELECT post_id, comment_id, comment_content, create_user_id, create_time FROM brunner_template.TB_COR_POST_COMMENT_INFO WHERE system_code = $1 AND post_id = $2 ORDER BY create_time',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 댓글 단건: [systemCode, postId, commentId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_POST_COMMENT_INFO', 2,
  'SELECT post_id, comment_id, comment_content, create_user_id, create_time FROM brunner_template.TB_COR_POST_COMMENT_INFO WHERE system_code = $1 AND post_id = $2 AND comment_id = $3 LIMIT 1',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 댓글 등록: [systemCode, postId, commentId, content, userId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_POST_COMMENT_INFO', 1,
  'INSERT INTO brunner_template.TB_COR_POST_COMMENT_INFO (system_code, post_id, comment_id, comment_content, create_user_id, create_time) VALUES ($1, $2, $3, $4, $5, NOW())',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 댓글 수정: [systemCode, postId, commentId, content, userId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_POST_COMMENT_INFO', 2,
  'UPDATE brunner_template.TB_COR_POST_COMMENT_INFO SET comment_content = $4, update_user_id = $5, update_time = NOW() WHERE system_code = $1 AND post_id = $2 AND comment_id = $3 AND create_user_id = $5',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 댓글 삭제: [systemCode, postId, commentId, userId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'delete_TB_COR_POST_COMMENT_INFO', 2,
  'DELETE FROM brunner_template.TB_COR_POST_COMMENT_INFO WHERE system_code = $1 AND post_id = $2 AND comment_id = $3 AND create_user_id = $4',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- ==================================================================
-- 채팅
-- ==================================================================

-- 메시지 등록: [systemCode, roomId, userId, userName, message, replyTo]
-- msg_id 를 돌려줘야 한다 — 호출부가 result.rows[0].msg_id 를 읽는다.
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHAT_MSG', 1,
  'INSERT INTO brunner_template.TB_COR_CHAT_MSG (system_code, room_id, user_id, user_name, message, reply_to, created_at) VALUES ($1, $2::uuid, $3, $4, $5, $6, NOW()) RETURNING msg_id, created_at',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 방의 메시지 목록: [systemCode, roomId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHAT_MSG', 1,
  'SELECT msg_id, room_id, user_id, user_name, message, reply_to, created_at FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND room_id = $2::uuid ORDER BY msg_id',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 방 비우기: [systemCode, roomId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'delete_TB_COR_CHAT_MSG', 1,
  'DELETE FROM brunner_template.TB_COR_CHAT_MSG WHERE system_code = $1 AND room_id = $2::uuid',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 읽음 처리: [systemCode, roomId, msgId, userId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHAT_READ_RECEIPT', 1,
  'INSERT INTO brunner_template.TB_COR_CHAT_READ_RECEIPT (system_code, room_id, message_id, user_id, read_at) VALUES ($1, $2::uuid, $3, $4, NOW()) ON CONFLICT (system_code, room_id, message_id, user_id) DO NOTHING',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 방의 읽음 기록: [systemCode, roomId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHAT_READ_RECEIPT', 1,
  'SELECT room_id, message_id, user_id, read_at FROM brunner_template.TB_COR_CHAT_READ_RECEIPT WHERE system_code = $1 AND room_id = $2::uuid',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 방 인원수: [systemCode, roomId] — DIRECT/GROUP 판정에 쓴다
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_MEMBER_COUNT', 1,
  'SELECT COUNT(*)::int AS cnt FROM brunner_template.TB_COR_CHATROOM_USERS WHERE system_code = $1 AND room_id = $2::uuid',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 방 나가기/강퇴: [systemCode, roomId, userId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'delete_TB_COR_CHATROOM_USERS', 1,
  'DELETE FROM brunner_template.TB_COR_CHATROOM_USERS WHERE system_code = $1 AND room_id = $2::uuid AND user_id = $3',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 방 이름 변경: [roomName, systemCode, roomId, userId] — 만든 사람만
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_CHATROOM_MST', 1,
  'UPDATE brunner_template.TB_COR_CHATROOM_MST SET name = $1 WHERE system_code = $2 AND id = $3::uuid AND created_by = $4',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 방 종류 갱신: [roomType, systemCode, roomId] — 인원수 변동 시 DIRECT/GROUP 재판정
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_CHATROOM_MST_ROOM_TYPE', 1,
  'UPDATE brunner_template.TB_COR_CHATROOM_MST SET room_type = $1 WHERE system_code = $2 AND id = $3::uuid AND COALESCE(room_type, '''') <> ''OPEN''',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 초대 토큰 발급: [systemCode, token, roomId, inviterId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_CHATROOM_INVITE_TOKEN', 1,
  'INSERT INTO brunner_template.TB_COR_CHATROOM_INVITE_TOKEN (system_code, token, room_id, inviter_id, created_at, expire_at) VALUES ($1, $2, $3::uuid, $4, NOW(), NOW() + INTERVAL ''7 days'') ON CONFLICT (system_code, token) DO NOTHING',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 초대 토큰 조회: [token] — 시스템코드를 받지 않는다(링크만으로 들어온다)
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_CHATROOM_INVITE_TOKEN', 1,
  'SELECT t.system_code, t.token, t.room_id, t.inviter_id, t.expire_at, r.name AS room_name FROM brunner_template.TB_COR_CHATROOM_INVITE_TOKEN t LEFT JOIN brunner_template.TB_COR_CHATROOM_MST r ON r.system_code = t.system_code AND r.id = t.room_id WHERE t.system_code = $1 AND t.token = $2 AND t.expire_at > NOW()',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- ==================================================================
-- 친구
-- ==================================================================

-- 친구 신청: [systemCode, userId, friendId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_USER_FRIEND', 1,
  'INSERT INTO brunner_template.TB_COR_USER_FRIEND (system_code, user_id, friend_id, status, create_time) VALUES ($1, $2, $3, ''PENDING'', NOW()) ON CONFLICT (system_code, user_id, friend_id) DO UPDATE SET status = ''PENDING''',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 친구 목록: [systemCode, userId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_FRIEND', 1,
  'SELECT f.friend_id, f.status, f.create_time, u.user_name, u.phone_number, u.profile_image_src FROM brunner_template.TB_COR_USER_FRIEND f LEFT JOIN brunner_template.TB_COR_USER_MST u ON u.system_code = f.system_code AND u.user_id = f.friend_id WHERE f.system_code = $1 AND f.user_id = $2 ORDER BY u.user_name, f.friend_id',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 수락: [systemCode, userId, friendId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_FRIEND', 1,
  'UPDATE brunner_template.TB_COR_USER_FRIEND SET status = ''ACCEPTED'' WHERE system_code = $1 AND user_id = $2 AND friend_id = $3',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 거절/차단: [systemCode, userId, friendId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_USER_FRIEND', 2,
  'UPDATE brunner_template.TB_COR_USER_FRIEND SET status = ''REJECTED'' WHERE system_code = $1 AND user_id = $2 AND friend_id = $3',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 친구 삭제: [systemCode, userId, friendId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'delete_TB_COR_USER_FRIEND', 1,
  'DELETE FROM brunner_template.TB_COR_USER_FRIEND WHERE system_code = $1 AND user_id = $2 AND friend_id = $3',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 친구 검색: [systemCode, userId, keyword] — 자기 자신과 이미 맺은 사람은 제외
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_USER_MST', 5,
  'SELECT u.user_id, u.user_name, u.email_id, u.profile_image_src FROM brunner_template.TB_COR_USER_MST u WHERE u.system_code = $1 AND u.user_id <> $2 AND COALESCE(u.use_flag, ''Y'') = ''Y'' AND (LOWER(u.user_id) LIKE LOWER(''%'' || $3 || ''%'') OR LOWER(u.user_name) LIKE LOWER(''%'' || $3 || ''%'') OR LOWER(u.email_id) LIKE LOWER(''%'' || $3 || ''%'')) AND NOT EXISTS (SELECT 1 FROM brunner_template.TB_COR_USER_FRIEND f WHERE f.system_code = u.system_code AND f.user_id = $2 AND f.friend_id = u.user_id) ORDER BY u.user_name, u.user_id LIMIT 50',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- ==================================================================
-- 동적 SQL 관리 화면
-- ==================================================================

-- 전체 목록: [systemCode]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_SQL_INFO', 1,
  'SELECT system_code, sql_name, sql_seq, sql_content, create_user_id, create_time, update_user_id, update_time FROM brunner_template.TB_COR_SQL_INFO WHERE system_code = $1 ORDER BY sql_name, sql_seq',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 단건: [systemCode, sqlName, sqlSeq]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'select_TB_COR_SQL_INFO', 2,
  'SELECT system_code, sql_name, sql_seq, sql_content, create_user_id, create_time, update_user_id, update_time FROM brunner_template.TB_COR_SQL_INFO WHERE system_code = $1 AND sql_name = $2 AND sql_seq = $3 LIMIT 1',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 등록: [systemCode, sqlName, sqlSeq, sqlContent, userId]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'insert_TB_COR_SQL_INFO', 1,
  'INSERT INTO brunner_template.TB_COR_SQL_INFO (system_code, sql_name, sql_seq, sql_content, create_user_id, create_time) VALUES ($1, $2, $3, $4, $5, NOW())',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 수정: [sqlContent, userId, systemCode, sqlName, sqlSeq] — 앞 두 개가 SET 절이다
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'update_TB_COR_SQL_INFO', 1,
  'UPDATE brunner_template.TB_COR_SQL_INFO SET sql_content = $1, update_user_id = $2, update_time = NOW() WHERE system_code = $3 AND sql_name = $4 AND sql_seq = $5',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();

-- 삭제: [systemCode, sqlName, sqlSeq]
INSERT INTO brunner_template.TB_COR_SQL_INFO (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
VALUES ('00', 'delete_TB_COR_SQL_INFO', 1,
  'DELETE FROM brunner_template.TB_COR_SQL_INFO WHERE system_code = $1 AND sql_name = $2 AND sql_seq = $3',
  'SYSTEM', NOW())
ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, UPDATE_TIME = NOW();
