-- 오픈채팅 지원을 위한 TB_COR_CHATROOM_MST 컬럼 추가
ALTER TABLE brunner_template.TB_COR_CHATROOM_MST
  ADD COLUMN IF NOT EXISTS category    VARCHAR(20),
  ADD COLUMN IF NOT EXISTS owner_id    VARCHAR(100),
  ADD COLUMN IF NOT EXISTS description VARCHAR(200),
  ADD COLUMN IF NOT EXISTS max_members INT DEFAULT 100;

-- 기존 방의 owner_id를 created_by로 초기화
UPDATE brunner_template.TB_COR_CHATROOM_MST
SET owner_id = created_by
WHERE owner_id IS NULL AND created_by IS NOT NULL;
