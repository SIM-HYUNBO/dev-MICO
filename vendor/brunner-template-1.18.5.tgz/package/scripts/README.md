# DB 초기화

## 스키마 분리

`brunner-next` 와 **같은 DB 를 써도 되지만 스키마는 반드시 분리**합니다.
템플릿의 SQL 원본은 `brunner_template` 스키마명을 기준으로 작성되어 있습니다.

```
DATABASE_URL=postgresql://user:password@host:5432/dbname
```

실행 시에는 `DB_SCHEMA` 환경변수로 적용 대상 스키마를 정합니다. `scripts/run_sql.cjs`가
SQL 파일의 `brunner_template.`/`brunner.` 스키마 접두어를 입력한 `DB_SCHEMA`로 바꿔
적용합니다. `micoMES`처럼 대문자가 섞인 스키마명도 PostgreSQL quoted identifier로
처리합니다.

## 실행

```bash
npm run db:init
```

`scripts/run_sql.cjs` 가 `DEFAULT_SQL_FILES` 순서대로 56개 파일을 실행합니다.
순서가 중요합니다.

1. **`create_core_tables.sql`** — 가장 먼저. 이 프레임워크는 SQL 을 코드가 아니라
   DB(`TB_COR_SQL_INFO`)에 저장해두고 이름으로 꺼내 쓰기 때문에, 이 테이블이 없으면
   이후 시드가 들어갈 곳이 없고 어떤 기능도 동작하지 않습니다.
2. `create_chat_tables.sql` — 채팅·문서·트랜잭션 기반 테이블
3. 기능별 테이블 생성
4. 스키마 보정 (`alter_*`, 인덱스)
5. 동적 SQL 시드 (`insert_dynamic_sql_*`)
6. 동적 SQL 갱신 (`update_*`) — 5번 시드를 다듬으므로 반드시 뒤에

## brunner-next 와 같은 DB 를 써도 안전합니다

이 스크립트는 `DB_SCHEMA`로 지정한 스키마만 만들고, 원본 `brunner` 스키마의 테이블은
읽지도 쓰지도 않습니다. 동적 SQL 시드도 자기 스키마의
`TB_COR_SQL_INFO` 에만 들어가므로 원본의 저장된 쿼리를 덮어쓰지 않습니다.

## Node 없이 한 번에 적용하기

`scripts/schema_full.sql` 은 2026-08-13 시점의 덤프입니다. **설치 위저드는 이 파일을 쓰지 않습니다** —
위저드와 `run_sql.cjs` 모두 `scripts/install_sql_files.json` 의 스크립트를 적용합니다.
이 덤프는 그 이후 추가된 테이블·쿼리를 담고 있지 않으므로 참고용으로만 보세요.
psql·pgAdmin·Railway 콘솔에서 그대로 실행할 수는 있지만, 최신 스키마가 아닙니다.

```bash
psql "$DATABASE_URL" -f scripts/schema_full.sql
```

## 검증 결과

임시 PostgreSQL 16 에 실제로 실행해 확인했습니다.

- 57개 파일 전부 오류 없이 적용
- 테이블 **28개** 생성, 동적 SQL **132건** 등록
- 등록된 SQL 을 전부 `PREPARE` 로 파싱 검증 — **132건 통과, 실패 0**
- `schema_full.sql` 을 빈 DB 에 재적용해도 동일 결과

`PREPARE` 검증이 역추적 DDL 의 오류 13건을 잡았습니다. `room_id` 가 VARCHAR 이 아니라
UUID 여야 했고, `admin_flag` 는 BOOLEAN 이었으며, `TB_COR_CHAT_MSG.user_name` 과
`TB_COR_CHAT_FILE.r2_key` 컬럼이 빠져 있었습니다.

## 복원한 기반 스키마

`create_core_tables.sql` 과 `create_chat_tables.sql` 은 이 템플릿에서 새로 작성했습니다.

원본에는 다음 테이블을 만드는 스크립트가 **없었습니다.** 운영 DB 에 수동으로 만들어진 뒤
스크립트로 남지 않은 것으로 보이며, 그대로는 신규 DB 부트스트랩이 5번째 파일에서
멈춥니다(`relation "tb_cor_chatroom_mst" does not exist`).

| 파일 | 복원한 테이블 |
|------|---------------|
| `create_core_tables.sql` | `TB_COR_SQL_INFO`, `TB_COR_USER_MST`, `TB_COR_USER_FRIEND` |
| `create_chat_tables.sql` | `TB_COR_CHATROOM_MST`, `TB_COR_CHATROOM_USERS`, `TB_COR_CHAT_MSG`, `TB_COR_CHAT_READ_RECEIPT`, `TB_COR_TXN_HIST`, `TB_COR_EDOC_DOCUMENT` |

컬럼은 동적 SQL 정의의 INSERT/SELECT 목록과 인덱스 정의에서 역추적했습니다.

> ⚠️ 원본 운영 DB 와 컬럼 타입·길이가 정확히 일치한다고 보장할 수 없습니다.
> 원본에 접근 가능하다면 `\d brunner.TB_COR_USER_MST` 등으로 대조해 보정하세요.
> 부트스트랩이 통과하고 참조가 모두 해소되는 것까지는 확인했습니다.
