/** @type {import('next').NextConfig} */
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const pkg = require("./package.json");

const nextConfig = {
  env: {
    NEXT_PUBLIC_APP_VERSION: pkg.version,
    NEXT_PUBLIC_BUILD_TIME: new Date().toISOString(),
  },
  reactStrictMode: false,
  async headers() {
    return [
      {
        source: "/((?!_next/static|_next/image|favicon.ico|logo.png|sw.js).*)",
        headers: [
          {
            key: "Cache-Control",
            value: "no-store, no-cache, must-revalidate",
          },
        ],
      },
    ];
  },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "www.notion.so",
      },
      {
        protocol: "https",
        hostname: "images.unsplash.com",
      },
      {
        protocol: "https",
        hostname: "s3.us-west-2.amazonaws.com",
      },
    ],
  },
  webpack: (config, options) => {
    config.experiments = {
      topLevelAwait: true,
      layers: true,
    };

    if (!options.isServer) {
      config.resolve.fallback = { fs: false, dns: false };
    }

    // ✅ Watchpack 에러 방지
    config.watchOptions = {
      ignored: [
        "**/node_modules",
        "**/.git",
        "**/.next",
        "C:/DumpStack.log.tmp",
        "**/pagefile.sys",
        "**/hiberfil.sys",
        "**/System Volume Information",
      ],
    };

    return config;
  },
  turbopack: {},
};

export default nextConfig;
