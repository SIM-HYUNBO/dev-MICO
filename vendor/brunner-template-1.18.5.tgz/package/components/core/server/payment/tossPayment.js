// 공통 결제 모듈 — 토스페이먼츠 (기능 무관 재사용)
// 결제 "승인"만 담당. 승인 후 처리(크레딧 적립·구독 활성 등)는 각 기능이 담당한다.

const CONFIRM_URL = "https://api.tosspayments.com/v1/payments/confirm";
const CANCEL_URL = (paymentKey) =>
  `https://api.tosspayments.com/v1/payments/${encodeURIComponent(paymentKey)}/cancel`;

export const isTossConfigured = () => !!process.env.TOSS_SECRET_KEY;

/**
 * 토스 결제 승인.
 * @returns {{ ok:boolean, status:number, data:object }}
 * 중복 승인 시 토스가 거부하므로 호출측은 자연스러운 멱등성을 얻는다.
 */
export const confirmPayment = async ({ paymentKey, orderId, amount }) => {
  const secret = process.env.TOSS_SECRET_KEY;
  if (!secret) throw new Error("TOSS_SECRET_KEY 미설정");
  const auth = Buffer.from(`${secret}:`).toString("base64");
  const res = await fetch(CONFIRM_URL, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/json" },
    body: JSON.stringify({ paymentKey, orderId, amount: Number(amount) }),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
};

/**
 * 결제 단건 조회(권위 있는 금액/상태). 이미 승인된 결제의 실제 금액을
 * 클라이언트 쿼리(amount)를 신뢰하지 않고 토스에서 직접 확인할 때 사용한다.
 * @returns {{ ok:boolean, status:number, data:object }} data.totalAmount, data.status, data.orderId 등
 */
export const getPayment = async (paymentKey) => {
  const secret = process.env.TOSS_SECRET_KEY;
  if (!secret) throw new Error("TOSS_SECRET_KEY 미설정");
  const auth = Buffer.from(`${secret}:`).toString("base64");
  const res = await fetch(`https://api.tosspayments.com/v1/payments/${encodeURIComponent(paymentKey)}`, {
    method: "GET",
    headers: { Authorization: `Basic ${auth}` },
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
};

/**
 * 결제 취소(전액).
 *
 * 부분취소는 cancelAmount 를 함께 보내야 하지만, 크레딧을 쪼개 회수하는 정책이
 * 서비스마다 달라 공통 모듈에서는 전액만 다룬다.
 *
 * Idempotency-Key 를 주문번호로 고정한다. 네트워크 재시도나 사용자의 연타로
 * 같은 결제가 두 번 환불되는 일을 토스 쪽에서 막아 준다.
 *
 * @returns {{ ok:boolean, status:number, data:object }}
 */
export const cancelPayment = async ({ paymentKey, cancelReason, idempotencyKey }) => {
  const secret = process.env.TOSS_SECRET_KEY;
  if (!secret) throw new Error("TOSS_SECRET_KEY 미설정");
  const auth = Buffer.from(`${secret}:`).toString("base64");

  const headers = {
    Authorization: `Basic ${auth}`,
    "Content-Type": "application/json",
  };
  if (idempotencyKey) headers["Idempotency-Key"] = String(idempotencyKey).slice(0, 300);

  const res = await fetch(CANCEL_URL(paymentKey), {
    method: "POST",
    headers,
    body: JSON.stringify({ cancelReason: cancelReason || "고객 요청" }),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
};
