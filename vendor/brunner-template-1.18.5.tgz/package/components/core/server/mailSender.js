import { Resend } from "resend";

/**
 * 메일 발송.
 *
 * 발신 주소는 환경변수(MAIL_FROM)로 둔다. 원본에서는 호출부가 `from` 을 넘기는데
 * 여기서 무시하고 있어, 하드코딩된 주소가 실제로는 쓰이지 않는 죽은 값이었다.
 *
 * 키가 없어도 서버는 죽지 않는다. 메일은 부가 기능이므로 경고만 남기고 넘어간다.
 */

const FROM =
  process.env.MAIL_FROM ?? process.env.RESEND_FROM ?? "onboarding@resend.dev";

let resend = null;
let warned = false;

/** 키가 있을 때만 클라이언트를 만든다 — 모듈 로드 시점에 만들면 키 없이도 인스턴스가 생긴다. */
const client = () => {
  if (!process.env.RESEND_API_KEY) return null;
  if (!resend) resend = new Resend(process.env.RESEND_API_KEY);
  return resend;
};

export const isMailConfigured = () => !!process.env.RESEND_API_KEY;

export const sendMail = async (mailOption) => {
  const c = client();
  if (!c) {
    // 호출마다 찍으면 로그가 시끄러워지므로 한 번만 알린다.
    if (!warned) {
      console.warn("[mail] RESEND_API_KEY 미설정 — 메일 발송을 건너뜁니다.");
      warned = true;
    }
    return;
  }

  if (!mailOption?.to) {
    console.warn("[mail] 수신자가 없어 발송하지 않습니다. (MAIL_USER 미설정?)");
    return;
  }

  try {
    const { data, error } = await c.emails.send({
      from: mailOption.from || FROM,
      to: mailOption.to,
      subject: mailOption.subject,
      text: mailOption.text,
    });
    if (error) throw new Error(error.message);
    console.log("Email sent:", data.id);
  } catch (e) {
    console.error(`Error sending email: message:${e.message}\n stack:${e.stack}\n`);
  }
};
