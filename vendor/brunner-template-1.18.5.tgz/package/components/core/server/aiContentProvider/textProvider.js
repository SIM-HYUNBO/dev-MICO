// AI 콘텐츠 텍스트 생성 provider
// 기본·최우선: Claude(Anthropic). 선택/폴백: OpenAI.
// Claude는 의존성 추가 없이 fetch로 직접 호출한다.

import OpenAI from "openai";

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const DEFAULT_ANTHROPIC_MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5";
const DEFAULT_OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-5-mini";
const GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models";
const DEFAULT_GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const GROQ_BASE_URL = "https://api.groq.com/openai/v1";
const DEFAULT_GROQ_MODEL = process.env.GROQ_MODEL || "llama-3.3-70b-versatile";
// Pollinations 텍스트(OpenAI 호환) — 이미지용으로 이미 붙여둔 무료 토큰을 그대로 써서, 다른 provider 계정이
// 소진돼도 스토리보드가 도는 안정적 무료 경로를 제공한다.
const POLLINATIONS_TEXT_BASE_URL = process.env.POLLINATIONS_TEXT_BASE_URL || "https://gen.pollinations.ai/v1";
const DEFAULT_POLLINATIONS_TEXT_MODEL = process.env.POLLINATIONS_TEXT_MODEL || "openai";
const CEREBRAS_BASE_URL = "https://api.cerebras.ai/v1";
// 모델명/접근이 바뀌어도 죽지 않게 후보를 순서대로 시도(첫 성공 사용). 404(모델없음)면 다음 후보로.
const CEREBRAS_MODELS = (process.env.CEREBRAS_MODEL || "llama-3.3-70b,llama3.1-8b,llama-3.1-8b,qwen-3-32b,llama-4-scout-17b-16e-instruct")
  .split(",").map((s) => s.trim()).filter(Boolean);
const DEFAULT_CEREBRAS_MODEL = CEREBRAS_MODELS[0];
const configuredMaxTokens = parseInt(process.env.AIC_TEXT_MAX_TOKENS || "4000", 10);
const MAX_TOKENS = Number.isFinite(configuredMaxTokens) && configuredMaxTokens > 0 ? configuredMaxTokens : 4000;

// TEXT 생성 1회 비용 단위
export const TEXT_COST_UNIT = 1;

const callClaude = async ({ systemPrompt, userPrompt, apiKey: overrideApiKey, maxTokens }) => {
  const apiKey = overrideApiKey || process.env.ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error("ANTHROPIC_API_KEY 미설정");

  const res = await fetch(ANTHROPIC_URL, {
    method: "POST",
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: DEFAULT_ANTHROPIC_MODEL,
      max_tokens: maxTokens || MAX_TOKENS,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    const err = new Error(`Anthropic ${res.status}: ${errText}`);
    err.status = res.status;
    err.headers = res.headers; // fetch Headers — retry-after / anthropic-ratelimit-*-reset 보존
    throw err;
  }

  const data = await res.json();
  const text = (data.content || [])
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n")
    .trim();

  if (!text) throw new Error("Claude가 빈 응답을 반환했습니다.");
  return { text, provider: "claude", model: DEFAULT_ANTHROPIC_MODEL };
};

const callOpenAI = async ({ systemPrompt, userPrompt, apiKey: overrideApiKey, maxTokens }) => {
  const apiKey = overrideApiKey || process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY 미설정");

  const openai = new OpenAI({ apiKey });
  const tokenLimitKey = /^gpt-5/i.test(DEFAULT_OPENAI_MODEL) ? "max_completion_tokens" : "max_tokens";
  const completion = await openai.chat.completions.create({
    model: DEFAULT_OPENAI_MODEL,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    [tokenLimitKey]: maxTokens || MAX_TOKENS,
  });

  const text = completion.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error("OpenAI가 빈 응답을 반환했습니다.");
  return { text, provider: "openai", model: DEFAULT_OPENAI_MODEL };
};

// Groq (무료 티어 — Llama 등 오픈모델, OpenAI 호환). baseURL만 교체해 OpenAI SDK 재사용.
const callGroq = async ({ systemPrompt, userPrompt, apiKey: overrideApiKey, maxTokens }) => {
  const apiKey = overrideApiKey || process.env.GROQ_API_KEY;
  if (!apiKey) throw new Error("GROQ_API_KEY 미설정");

  const groq = new OpenAI({ apiKey, baseURL: GROQ_BASE_URL });
  const completion = await groq.chat.completions.create({
    model: DEFAULT_GROQ_MODEL,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    max_tokens: maxTokens || MAX_TOKENS,
  });

  const text = completion.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error("Groq가 빈 응답을 반환했습니다.");
  return { text, provider: "groq", model: DEFAULT_GROQ_MODEL };
};

// Cerebras (무료 티어 — Llama 등, 초고속 추론, OpenAI 호환). baseURL만 교체해 OpenAI SDK 재사용.
const callCerebras = async ({ systemPrompt, userPrompt, apiKey: overrideApiKey, maxTokens }) => {
  const apiKey = overrideApiKey || process.env.CEREBRAS_API_KEY;
  if (!apiKey) throw new Error("CEREBRAS_API_KEY 미설정");

  const cerebras = new OpenAI({ apiKey, baseURL: CEREBRAS_BASE_URL });
  let lastErr;
  for (const model of CEREBRAS_MODELS) {
    try {
      const completion = await cerebras.chat.completions.create({
        model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        max_tokens: maxTokens || MAX_TOKENS,
      });
      const text = completion.choices?.[0]?.message?.content?.trim();
      if (!text) throw new Error("Cerebras가 빈 응답을 반환했습니다.");
      return { text, provider: "cerebras", model };
    } catch (e) {
      lastErr = e;
      // 모델 없음(404)/잘못된 모델이면 다음 후보로. 그 외(429 한도·5xx)면 즉시 중단(모델 바꿔도 소용없음).
      const status = e?.status;
      if (status === 404 || status === 400) continue;
      throw e;
    }
  }
  throw lastErr || new Error("Cerebras 모델 후보를 모두 실패했습니다.");
};

// Pollinations 텍스트(OpenAI 호환, Bearer 토큰) — 이미지용 POLLINATIONS_TOKEN 재사용.
const callPollinations = async ({ systemPrompt, userPrompt, apiKey: overrideApiKey, maxTokens }) => {
  const apiKey = overrideApiKey || process.env.POLLINATIONS_TOKEN;
  if (!apiKey) throw new Error("POLLINATIONS_TOKEN 미설정");
  const client = new OpenAI({ apiKey, baseURL: POLLINATIONS_TEXT_BASE_URL });
  const completion = await client.chat.completions.create({
    model: DEFAULT_POLLINATIONS_TEXT_MODEL,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    max_tokens: maxTokens || MAX_TOKENS,
  });
  const text = completion.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error("Pollinations가 빈 응답을 반환했습니다.");
  return { text, provider: "pollinations", model: DEFAULT_POLLINATIONS_TEXT_MODEL };
};

// Google Gemini (무료 티어 관대) — 텍스트 폴백. SDK 없이 REST 직접 호출.
const callGemini = async ({ systemPrompt, userPrompt, apiKey: overrideApiKey, maxTokens }) => {
  const apiKey = overrideApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY 미설정");

  const res = await fetch(`${GEMINI_URL}/${DEFAULT_GEMINI_MODEL}:generateContent?key=${apiKey}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents: [{ role: "user", parts: [{ text: userPrompt }] }],
      generationConfig: { maxOutputTokens: maxTokens || MAX_TOKENS },
    }),
  });
  if (!res.ok) {
    const t = await res.text();
    const err = new Error(`Gemini ${res.status}: ${t}`); // 본문의 retryDelay 정보 보존
    err.status = res.status;
    err.headers = res.headers;
    throw err;
  }

  const data = await res.json();
  const text = (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("\n").trim();
  if (!text) throw new Error("Gemini가 빈 응답을 반환했습니다.");
  return { text, provider: "gemini", model: DEFAULT_GEMINI_MODEL };
};

// provider 실패 원인 분류 — no_key(키 없음) / rate_limit(한도) / error(그 외)
const classifyError = (e) => {
  const status = e?.status;
  const msg = String(e?.message || "");
  if (/미설정|no[_ ]?key|api key/i.test(msg) && !/rate|limit|quota/i.test(msg)) return "no_key";
  if (status === 429 || /\b429\b|rate.?limit|quota|exceeded your current|hard limit|insufficient|billing|overloaded|too many requests/i.test(msg)) {
    return "rate_limit";
  }
  if (status === 401 || status === 403) return "no_key";
  return "error";
};

// 429 등에서 "언제부터 다시 쓸 수 있는지"를 초 단위로 추정.
// OpenAI/Groq 헤더(retry-after), Anthropic reset 헤더, Gemini retryDelay 본문, 메시지 문구 모두 대응.
const retrySecondsFromError = (e) => {
  const h = e?.headers;
  const headerVal = (k) => {
    if (!h) return null;
    if (typeof h.get === "function") return h.get(k);
    return h[k] ?? h[k.toLowerCase()] ?? null;
  };
  const raw = headerVal("retry-after");
  if (raw != null && !isNaN(Number(raw))) return Math.max(1, Math.ceil(Number(raw)));

  const durToSeconds = (v) => {
    if (v == null) return null;
    const s = String(v).trim();
    if (!isNaN(Number(s))) return Math.ceil(Number(s));
    const m = s.match(/^(\d+(?:\.\d+)?)\s*(ms|s|m|h)?$/i);
    if (!m) return null;
    const n = Number(m[1]);
    const unit = (m[2] || "s").toLowerCase();
    return Math.ceil(unit === "ms" ? n / 1000 : unit === "m" ? n * 60 : unit === "h" ? n * 3600 : n);
  };
  const reset =
    headerVal("anthropic-ratelimit-requests-reset") ||
    headerVal("anthropic-ratelimit-tokens-reset") ||
    headerVal("x-ratelimit-reset-requests") ||
    headerVal("x-ratelimit-reset-tokens");
  if (reset) {
    // 절대시각(ISO)면 남은 초, 아니면 duration
    const iso = Date.parse(reset);
    if (!isNaN(iso)) return Math.max(1, Math.ceil((iso - Date.now()) / 1000));
    const d = durToSeconds(reset);
    if (d) return d;
  }

  const msg = String(e?.message || "");
  let m = msg.match(/try again in ([\d.]+)\s*(ms|s|m)/i);
  if (m) return durToSeconds(`${m[1]}${(m[2] || "s").toLowerCase()}`);
  m = msg.match(/retryDelay["']?\s*:\s*["']?(\d+(?:\.\d+)?)s/i);
  if (m) return Math.ceil(Number(m[1]));
  m = msg.match(/in\s+(\d+(?:\.\d+)?)\s*(seconds?|minutes?|hours?)/i);
  if (m) {
    const n = Number(m[1]);
    return Math.ceil(/hour/i.test(m[2]) ? n * 3600 : /min/i.test(m[2]) ? n * 60 : n);
  }
  return null;
};

// caller 이름 → BYOK 키 provider 이름(개인키 관리 화면과 연결)
const BYOK_PROVIDER_OF = { cerebras: "cerebras", groq: "groq", gemini: "gemini", claude: "anthropic", openai: "openai", pollinations: "pollinations" };

// 기본 우선순위: 무료 우선(cerebras → groq → gemini → pollinations) → 유료(claude → openai).
// pollinations는 이미지용 토큰을 재사용하는 무료·안정 경로라, 계정 기반 무료들이 소진돼도 스토리보드가 돈다.
// TEXT_PROVIDER_ORDER 환경변수(쉼표구분)로 재정의 가능. 예: "claude,gemini,groq,openai"
const DEFAULT_ORDER = ["cerebras", "groq", "gemini", "pollinations", "claude", "openai"];
const ENV_ORDER = (process.env.TEXT_PROVIDER_ORDER || "")
  .split(",").map((s) => s.trim()).filter((s) => DEFAULT_ORDER.includes(s));

// 설정 언어에 어긋나는 문자(다른 언어 스크립트) 범위 — 순도 게이트용.
// 일부 무료 모델(Llama 등)이 한국어에 한자·가나·기타 문자를 흘리는 것을 걸러낸다.
const CJK_KANA = "\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff\\uf900-\\ufaff"; // 가나 + 한자
const OTHER_SCRIPTS = "\\u0600-\\u06ff\\u0400-\\u04ff\\u0590-\\u05ff\\u0e00-\\u0e7f\\u0900-\\u097f"; // 아랍/키릴/히브리/태국/데바나가리
const HANGUL = "\\uac00-\\ud7a3\\u1100-\\u11ff\\u3130-\\u318f";
const DISALLOWED_SCRIPTS = {
  "ko-KR": new RegExp(`[${CJK_KANA}${OTHER_SCRIPTS}]`, "g"),
  "en-US": new RegExp(`[${HANGUL}${CJK_KANA}${OTHER_SCRIPTS}]`, "g"),
  "ja-JP": new RegExp(`[${HANGUL}${OTHER_SCRIPTS}]`, "g"),
};
const countDisallowed = (text, code) => {
  const re = DISALLOWED_SCRIPTS[code] || DISALLOWED_SCRIPTS["ko-KR"];
  const m = String(text || "").match(re);
  return m ? m.length : 0;
};
// 설정 언어에 어긋나는 문자를 제거(최종 정제). 언어별 안전 — ja-JP는 한자·가나 보존.
// 이물 문자 제거로 생기는 이중 공백만 정리한다.
const stripDisallowed = (text, code) => {
  const re = DISALLOWED_SCRIPTS[code] || DISALLOWED_SCRIPTS["ko-KR"];
  return String(text || "").replace(re, "").replace(/[ \t]{2,}/g, " ");
};

/**
 * 텍스트 생성. 우선순위 체인(기본): Groq → Gemini → Claude → OpenAI (무료 우선).
 * 앞선 provider가 실패(키 없음/429/오류)하거나 설정 언어 순도가 미달이면 다음으로 자동 폴백한다.
 * @param {object} p
 * @param {string} p.systemPrompt  프리셋 시스템 프롬프트
 * @param {string} p.userPrompt    연재자의 요청(초안 생성 or 수정 요청)
 * @param {string} [p.provider]    "groq" | "gemini" | "claude" | "openai" — 지정 시 그 provider를 우선
 * @param {string} [p.languageCode] 설정 언어(ko-KR/en-US/ja-JP) — 출력 순도 검사에 사용
 * @returns {{text, provider, model, costUnit}}
 */
export const generateText = async ({ systemPrompt, userPrompt, provider, providerOrder, apiKeys = {}, languageCode, maxTokens, validate, skipPurity = false }) => {
  const has = {
    cerebras: !!(apiKeys.cerebras || process.env.CEREBRAS_API_KEY),
    groq: !!(apiKeys.groq || process.env.GROQ_API_KEY),
    claude: !!(apiKeys.anthropic || process.env.ANTHROPIC_API_KEY),
    gemini: !!(apiKeys.gemini || process.env.GEMINI_API_KEY),
    openai: !!(apiKeys.openai || process.env.OPENAI_API_KEY),
    pollinations: !!process.env.POLLINATIONS_TOKEN,
  };
  const callers = {
    cerebras: () => callCerebras({ systemPrompt, userPrompt, apiKey: apiKeys.cerebras, maxTokens }),
    groq: () => callGroq({ systemPrompt, userPrompt, apiKey: apiKeys.groq, maxTokens }),
    claude: () => callClaude({ systemPrompt, userPrompt, apiKey: apiKeys.anthropic, maxTokens }),
    gemini: () => callGemini({ systemPrompt, userPrompt, apiKey: apiKeys.gemini, maxTokens }),
    openai: () => callOpenAI({ systemPrompt, userPrompt, apiKey: apiKeys.openai, maxTokens }),
    pollinations: () => callPollinations({ systemPrompt, userPrompt, maxTokens }),
  };
  const requestedOrder = Array.isArray(providerOrder)
    ? providerOrder.map((p) => String(p || "").toLowerCase()).filter((p) => callers[p])
    : [];
  const base = requestedOrder.length ? requestedOrder : (ENV_ORDER.length ? ENV_ORDER : DEFAULT_ORDER);
  const order = provider && base.includes(provider)
    ? [provider, ...base.filter((p) => p !== provider)]
    : base;

  let lastError = null;
  const attempts = [];
  const providerStates = []; // 한도 안내 모달용 — provider별 실패 원인·재시도 시각
  let bestDirty = null; // 순도 미달이지만 그중 가장 깨끗한 결과(전부 미달 시 폴백)
  for (const p of order) {
    if (!has[p]) {
      attempts.push(`${p}:no_key`);
      providerStates.push({ provider: p, byokProvider: BYOK_PROVIDER_OF[p] || p, reason: "no_key", retryAfterSeconds: null });
      continue;
    }
    try {
      const result = await callers[p]();
      // 유효성 콜백(예: 문서 JSON 파싱)을 통과 못하면(무료 모델이 깨진/불완전 JSON 생성) 다음 provider로.
      if (typeof validate === "function" && !validate(result.text)) {
        attempts.push(`${p}:invalid`);
        lastError = lastError || "provider 출력이 유효성 검증(JSON 등)에 실패";
        continue;
      }
      // JSON 문서 생성 등 언어 순도 검사가 오히려 내용을 훼손하는 용도는 필터를 건너뛴다.
      // (languageCode 미전달은 ko-KR로 폴백돼 한자·가나를 이물로 지우므로, 명시적 skip이 필요.)
      if (skipPurity) {
        attempts.push(`${p}:ok`);
        return { ...result, costUnit: TEXT_COST_UNIT, fallbackError: lastError, attempts };
      }
      const bad = countDisallowed(result.text, languageCode);
      if (bad === 0) {
        attempts.push(`${p}:ok`);
        return { ...result, costUnit: TEXT_COST_UNIT, fallbackError: lastError, attempts };
      }
      // 이물 문자 포함 → 다음 provider로. 전부 미달일 때를 대비해 최선본 보관.
      attempts.push(`${p}:dirty(${bad})`);
      if (!bestDirty || bad < bestDirty.bad) bestDirty = { result, bad };
      console.warn(`[textProvider] ${p} 언어 순도 미달(${bad}자) → 다음 provider`);
    } catch (e) {
      lastError = e.message;
      attempts.push(`${p}:err(${e.message.slice(0, 120)})`);
      providerStates.push({
        provider: p,
        byokProvider: BYOK_PROVIDER_OF[p] || p,
        reason: classifyError(e),
        retryAfterSeconds: retrySecondsFromError(e),
      });
      console.warn(`[textProvider] ${p} 실패 → 다음 provider: ${e.message}`);
    }
  }
  // 모든 provider가 순도 미달이면 그중 가장 깨끗한 결과를 최종 정제(이물 문자 제거)해 반환
  if (bestDirty) {
    return {
      ...bestDirty.result,
      text: stripDisallowed(bestDirty.result.text, languageCode),
      costUnit: TEXT_COST_UNIT, fallbackError: lastError, attempts, impure: bestDirty.bad,
    };
  }
  const err = new Error(lastError || "사용 가능한 텍스트 provider가 없습니다(키 미설정).");
  err.providerStates = providerStates;
  err.attempts = attempts;
  err.limitReached = providerStates.some((s) => s.reason === "rate_limit");
  throw err;
};
