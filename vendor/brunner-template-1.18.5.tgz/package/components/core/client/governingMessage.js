import React from "react";
import * as constants from "@/lib/constants";

const GoverningMessage = ({ governingMessage = constants.emptyString }) => {
  const formattedMessage = governingMessage.split("\n").map((line, index) => (
    <React.Fragment key={index}>
      {line}
      <br />
    </React.Fragment>
  ));

  return <p>{formattedMessage}</p>;
};

export default GoverningMessage;
