"use client";

import { useState } from "react";
import { Share2, Check } from "lucide-react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";

// 공개 페이지 공유 버튼 — navigator.share 우선, 없으면 링크 복사
export default function PublicShareButton({ url, title, lang = "ko-KR" }) {
  const [copied, setCopied] = useState(false);
  const tl = (k) => commonFunctions.getResourceByLanguage(k, constants.resourceType.label, lang);

  const onShare = async () => {
    const shareUrl = url || (typeof window !== "undefined" ? window.location.href : "");
    try {
      if (typeof navigator !== "undefined" && navigator.share) {
        await navigator.share({ title, url: shareUrl });
        return;
      }
    } catch {
      return; // 사용자가 공유 취소
    }
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {}
  };

  return (
    <button
      type="button"
      onClick={onShare}
      className="inline-flex items-center gap-1.5 rounded-lg border border-[var(--border)] px-3 py-2 text-sm font-semibold text-[var(--general-text-color)] transition hover:bg-[var(--surface-alt)]"
    >
      {copied ? <Check size={15} /> : <Share2 size={15} />}
      {copied ? tl("publicShareCopied") : tl("publicShare")}
    </button>
  );
}
