"use strict";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

export async function RequestServer(
  jRequest,
  method = constants.httpMethod.POST,
  serverUrl = `/api/backendServer`,
) {
  let res = null;
  let jResponse = null;

  // 세션 토큰을 항상 실어 보낸다. 서버가 요청 본문의 userId 를 그대로 믿지
  // 않고 신원을 확인할 수 있어야 하는데, 호출부마다 토큰을 챙기게 하면
  // 빠뜨리는 곳이 반드시 생긴다. 이미 담아 보낸 요청은 그대로 둔다.
  if (jRequest && !jRequest.sessionToken) {
    const token = userInfo.getLoginSessionToken?.();
    if (token) jRequest = { ...jRequest, sessionToken: token };
  }

  // 관리자 모드도 같은 이유로 항상 실어 보낸다.
  //
  // adminMode 는 브라우저(localStorage)에만 있는 설정이라 서버가 알 수 없다. 관리자가
  // "일반 사용자 모드"로 내려도 서버는 여전히 admin_flag 로 관리자라고 판단해, 화면에서
  // 숨긴 것들이 API 로는 그대로 내려왔다. 예전에 AI 관리자 대기열에서 같은 사고가 나
  // 그 호출에만 따로 실어 보내는 식으로 막았는데, 호출부마다 챙기면 반드시 빠뜨린다.
  // 여기서 한 번에 싣는다.
  //
  // 이 값은 권한을 줄이기만 한다 — false 면 관리자 기능을 끄고, true 라고 보내도
  // 서버가 admin_flag 를 따로 확인하므로 일반 사용자가 관리자가 되지는 않는다.
  if (jRequest && jRequest.adminMode === undefined) {
    jRequest = { ...jRequest, adminMode: userInfo.isAdminUser?.() !== false };
  }

  try {
    res = await fetch(serverUrl, {
      method: method,
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(jRequest),
    });

    jResponse = await res.json();
    return jResponse;
  } catch (e) {
    // 날것 예외(예: "TypeError: Load failed")는 사용자에게 노출하지 않는다 — 콘솔에만 남기고
    // 사용자에겐 브랜드 톤의 깔끔한 안내 문구만 보여준다.
    console.error("[RequestServer] 요청 실패:", jRequest?.commandName, e);
    jResponse = {};
    jResponse.error_code = constants.errorCode.RequestException;
    jResponse.error_message = commonFunctions.getResourceByLanguage(
      `SERVER_NOT_CONNECTTED`,
      constants.resourceType.message,
      jRequest.languageCode,
    );
    return jResponse;
  }
}
