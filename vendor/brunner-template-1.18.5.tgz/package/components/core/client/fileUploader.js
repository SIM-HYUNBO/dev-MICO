"use client";
import { useState, useRef } from "react";
import { Button } from "antd";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

export function FileUploader({ onFileChange, onFileUpload, fileData }) {
  const [open, setOpen] = useState(false);
  const fileInputRef = useRef(null);

  const handleCancel = () => {
    setOpen(false);

    // ⭐ 핵심: file input 초기화
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div>
      <div className="flex justify-center items-center">
        <Button onClick={() => setOpen((v) => !v)}>
          {open ? L("uploadClose") : L("excelUpload")}
        </Button>
      </div>

      {open && (
        <div className="border p-4 w-96 rounded-lg general-text-bg-color">
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            onChange={onFileChange}
            className="mb-2 file:border file:rounded file:px-3 file:py-1 file:semi-text-bg-color"
          />

          {fileData?.length > 0 && (
            <div className="semi-text-bg-color p-2 mb-2 max-h-36 overflow-auto rounded">
              <pre className="text-sm">
                {JSON.stringify(fileData.slice(0, 5), null, 2)}
              </pre>
            </div>
          )}

          <div className="flex justify-end gap-2">
            <Button onClick={handleCancel}>{L("cancel")}</Button>

            <Button
              onClick={() => onFileUpload(fileData)}
              disabled={!fileData || fileData.length === 0}
            >
              Save
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
