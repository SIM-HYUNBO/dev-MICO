import React, { useState, useEffect } from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import { RequestServer } from "@/components/core/client/requestServer";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import Loading from "@/components/core/client/loading";
import { Input, Button, Table } from "antd";

function BrunnerBoard({ boardType }) {
  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");

  const [loading, setLoading] = useState(false);
  const { BrunnerMessageBox, openOkCancelModal, openOkModal, openInputModal } =
    useModal();
  const [posts, setPosts] = useState([]);
  const [postText, setPostText] = useState(constants.emptyString);

  const tl = (key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.label, currentLanguageCode);

  useEffect(() => {
    setCurrentSystemCode(userInfo.getCurrentSystemCode());
    setCurrentLoginUserId(userInfo.getLoginUserId());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  // 게시글 목록 조회
  const fetchPosts = async () => {
    try {
      const jRequest = {
        commandName: constants.commands.POST_INFO_SELECT_ALL,
                languageCode: userInfo.getCurrentLanguageCode(),
        postInfo: { postType: boardType },
      };
      // setLoading(true);
      const jResponse = await RequestServer(jRequest);
      // setLoading(false);

      if (jResponse.error_code === constants.errorCode.Success) {
        setPosts(jResponse.data);
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  useEffect(() => {
    if (boardType) {
      fetchPosts();
    }
  }, [boardType]);

  const handlePostChange = (e) => {
    setPostText(e.target.value);
  };

  // 2. 게시글 작성 */
  const handleAddPost = async () => {
    try {
      if (postText.trim()) {
        var jRequest = {};
        var jResponse = null;

        const userId = currentLoginUserId;
        const postType = `${boardType}`;

        const newPost = {
          postType: postType,
          content: postText,
          userId: userId,
        };

        jRequest.commandName = constants.commands.POST_INFO_INSERT_ONE;
        jRequest.languageCode = userInfo.getCurrentLanguageCode();
        jRequest.postInfo = newPost;

        setLoading(true); // 데이터 로딩 시작
        jResponse = await RequestServer(jRequest);
        setLoading(false); // 데이터 로딩 끝

        if (jResponse.error_code === constants.errorCode.Success) {
          setPosts([jResponse.data, ...posts]);
          setPostText(constants.emptyString);
        } else {
          await openOkModal(
            jResponse.error_message,
            constants.messageCategory.Error,
          );
        }
      }
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  // 3. 게시글 편집 후 저장 */
  const handleEditPost = async (postId, newContent) => {
    try {
      var jRequest = {};
      var jResponse = null;

      if (!currentLoginUserId) {
        await openOkModal(
          commonFunctions.getResourceByLanguage(
            `NO_PERMISSION`,
            constants.resourceType.message,
            currentLanguageCode,
          ),
          constants.messageCategory.Error,
        );
        return;
      }

      jRequest.commandName = constants.commands.POST_INFO_UPDATE_ONE;
      jRequest.languageCode = currentLanguageCode;
      jRequest.postInfo = {
        postId: postId,
        content: newContent,
        userId: currentLoginUserId,
      };

      setLoading(true); // 데이터 로딩 시작
      jResponse = await RequestServer(jRequest);
      setLoading(false); // 데이터 로딩 끝

      if (jResponse.error_code === constants.errorCode.Success) {
        const updatedPosts = posts.map((post) =>
          post.post_id === postId
            ? {
                ...post,
                post_content: newContent,
                update_user_id: currentLoginUserId,
              }
            : post,
        );
        setPosts(updatedPosts);
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  // 4. 게시글 삭제 */
  const handleDeletePost = async (postId) => {
    try {
      var jRequest = {};
      var jResponse = null;

      const userId = currentLoginUserId;
      if (!userId) {
        await openOkModal(
          commonFunctions.getResourceByLanguage(
            `NO_PERMISSION`,
            constants.resourceType.message,
            currentLanguageCode,
          ),
          constants.messageCategory.Error,
        );
        return;
      }

      jRequest.commandName = constants.commands.POST_INFO_DELETE_ONE;
      jRequest.languageCode = currentLanguageCode;
      jRequest.postInfo = {
        postId: postId,
        userId: userId,
      };

      setLoading(true); // 데이터 로딩 시작작
      jResponse = await RequestServer(jRequest);
      setLoading(false); // 데이터 로딩 끝

      if (jResponse.error_code === constants.errorCode.Success) {
        const updatedPosts = posts.filter((post) => post.post_id !== postId);
        setPosts(updatedPosts);
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  // 5. 댓글 저장 */
  const handleAddComment = async (postId, commentText) => {
    try {
      var jRequest = {};
      var jResponse = null;

      jRequest.commandName = constants.commands.POST_COMMENT_INFO_INSERT_ONE;
      jRequest.languageCode = currentLanguageCode;
      jRequest.commentInfo = {
        postId: postId,
        content: commentText,
        userId: currentLoginUserId,
      };

      jResponse = await RequestServer(jRequest);

      if (jResponse.error_code === constants.errorCode.Success) {
        const updatedPosts = posts.map((post) => {
          if (post.post_id === postId) {
            return {
              ...post,
              comments: [...post.comments, jResponse.commentInfo],
            };
          }
          return post;
        });
        setPosts(updatedPosts);
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  // 6. 댓글 편집 후 저장
  const handleEditComment = async (postId, commentId, newContent) => {
    try {
      var jRequest = {};
      var jResponse = null;

      if (!currentLoginUserId) {
        await openOkModal(
          commonFunctions.getResourceByLanguage(
            `NO_PERMISSION`,
            constants.resourceType.message,
            currentLanguageCode,
          ),
          constants.messageCategory.Error,
        );
        return;
      }

      const post = posts.find((post) => post.post_id === postId);

      jRequest.commandName = constants.commands.POST_COMMENT_INFO_UPDATE_ONE;
      jRequest.languageCode = currentLanguageCode;
      jRequest.commentInfo = {
        postId: postId,
        commentId: commentId,
        content: newContent,
        userId: currentLoginUserId,
      };

      jResponse = await RequestServer(jRequest);

      if (jResponse.error_code === constants.errorCode.Success) {
        const updatedPosts = posts.map((post) => {
          if (post.post_id === postId) {
            const updatedComments = post.comments?.map((comment, index) =>
              comment.comment_id === commentId
                ? { ...comment, comment_content: newContent }
                : comment,
            );
            return { ...post, comments: updatedComments };
          }
          return post;
        });
        setPosts(updatedPosts);
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  // 7. 댓글 삭제
  const handleDeleteComment = async (postId, commentId) => {
    try {
      var jRequest = {};
      var jResponse = null;

      if (!currentLoginUserId) {
        await openOkModal(
          commonFunctions.getResourceByLanguage(
            `NO_PERMISSION`,
            constants.resourceType.message,
            currentLanguageCode,
          ),
          constants.messageCategory.Error,
        );
        return;
      }

      jRequest.commandName = constants.commands.POST_COMMENT_INFO_DELETE_ONE;
      jRequest.languageCode = currentLanguageCode;
      jRequest.commentInfo = {
        postId: postId,
        commentId: commentId,
        userId: currentLoginUserId,
      };

      jResponse = await RequestServer(jRequest);

      if (jResponse.error_code === constants.errorCode.Success) {
        const updatedPosts = posts.map((post) => {
          if (post.post_id === postId) {
            const updatedComments = post.comments.filter(
              (_, index) => index !== commentId,
            );
            return { ...post, comments: updatedComments };
          }
          return post;
        });
        setPosts(updatedPosts);
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    } catch (e) {
      await openOkModal(
        `Error deleting comment: message:${e.message}\n stack:${e.stack}\n`,
        constants.messageCategory.Exception,
      );
    }
  };

  return (
    <div className={`w-full max-w-4xl mx-auto`}>
      <BrunnerMessageBox />
      {loading && <Loading />}
      <div className={`my-2 flex`}>
        <textarea
          value={postText}
          onChange={handlePostChange}
          placeholder={tl("boardNewPostPlaceholder")}
          maxLength="1000"
          className={`w-full 
                      p-2 
                      border 
                      border-[var(--border-color)] 
                      rounded-md 
                      medium-text-color`}
        />
        <Button
          onClick={handleAddPost}
          className="mt-2 px-4 py-2 rounded-md ml-2 justify-end"
          style={{ backgroundColor: "var(--success)", color: "#fff", borderColor: "transparent" }}
        >
          {tl("boardSubmitPost")}
        </Button>
      </div>
      <div className={`post-list`}>
        {posts.map((post) => (
          <BoardContent
            key={post.post_id}
            post={post}
            onAddComment={handleAddComment}
            onEditPost={handleEditPost}
            onDeletePost={handleDeletePost}
            onEditComment={handleEditComment}
            onDeleteComment={handleDeleteComment}
          />
        ))}
      </div>
    </div>
  );
}

/* 게시글 컴포넌트

* 데이터 모델

post.post_id : String (일련번호)
post.create_user_id : String
post.post_content : String
post.create_time : Date
post.comments : JsonArray of JsonObject 

comment.comment_id:  : String (일련번호)
comment.create_user_id
comment.comment_content
comment.create_time
*/

function BoardContent({
  post,
  onAddComment,
  onEditPost,
  onDeletePost,
  onEditComment,
  onDeleteComment,
}) {
  // 로딩 & 메시지 박스
  // {
  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");

  const [loading, setLoading] = useState(false);
  const { BrunnerMessageBox, openOkCancelModal, openOkModal, openInputModal } =
    useModal();
  // BoardContent 자체 번역 헬퍼 — 바깥 BrunnerBoard 의 tl 은 이 컴포넌트 스코프에
  // 들어오지 않아, 예전에는 이 아래 JSX 가 그려지는 순간 ReferenceError 가 났다.
  const tl = (key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.label, currentLanguageCode);

  const [commentText, setCommentText] = useState(constants.emptyString);
  const [isEditingPost, setIsEditingPost] = useState(false);
  const [editedPostText, setEditedPostText] = useState(post.post_content);
  const [editingCommentId, setEditingCommentId] = useState(null);
  const [editedCommentText, setEditedCommentText] = useState(
    constants.emptyString,
  );

  useEffect(() => {
    setCurrentSystemCode(userInfo.getCurrentSystemCode());
    setCurrentLoginUserId(userInfo.getLoginUserId());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  const handleCommentChange = (e) => {
    setCommentText(e.target.value);
  };

  const handleAddComment = () => {
    if (commentText.trim()) {
      onAddComment(post.post_id, commentText);
      setCommentText(constants.emptyString);
    }
  };

  const handleEditPostChange = (e) => {
    setEditedPostText(e.target.value);
  };

  const handleEditPost = () => {
    onEditPost(post.post_id, editedPostText);
    setIsEditingPost(false);
  };

  const handleDeletePost = () => {
    onDeletePost(post.post_id);
  };

  const handleEditCommentChange = (e) => {
    setEditedCommentText(e.target.value);
  };

  const handleEditComment = (commentId) => {
    onEditComment(post.post_id, commentId, editedCommentText);
    setEditingCommentId(null);
  };

  const handleDeleteComment = (commentId) => {
    onDeleteComment(post.post_id, commentId);
  };

  return (
    <div className={`border-b border-[var(--border-color)] py-4`}>
      {isEditingPost ? (
        <div>
          <textarea
            value={editedPostText}
            onChange={handleEditPostChange}
            className={`w-full 
                        p-2 
                        border 
                        border-[var(--border-color)] 
                        rounded-md 
                        text-[var(--text-muted)] 
                        dark:text-[var(--text-muted)]`}
          />
          <Button
            onClick={handleEditPost}
            className="mt-2 px-4 py-2 rounded-md"
            style={{ backgroundColor: "var(--brand-blue)", color: "#fff", borderColor: "transparent" }}
          >
            {tl("save")}
          </Button>
          <Button
            onClick={() => setIsEditingPost(false)}
            className="mt-2 ml-2 px-4 py-2 rounded-md"
            style={{ backgroundColor: "var(--text-muted)", color: "#fff", borderColor: "transparent" }}
          >
            {tl("cancel")}
          </Button>
        </div>
      ) : (
        <div className={`w-full text-left`}>
          <strong className={`text-left text-sm`}>{post.create_user_id}</strong>
          <span className={`text-[var(--semi-text-color)] ml-2 text-sm`}>
            {new Date(post.create_time).toLocaleString()}
          </span>
          <br />
          <p className={`w-full text-left`}>{post.post_content}</p>
        </div>
      )}
      <div className={`flex mt-2`}>
        {!isEditingPost && (
          <>
            <Button
              onClick={async () => {
                if (!currentLoginUserId) {
                  await openOkModal(
                    commonFunctions.getResourceByLanguage(
                      `NO_PERMISSION`,
                      constants.resourceType.message,
                      currentLanguageCode,
                    ),
                    constants.messageCategory.Error,
                  );
                  return;
                }
                setIsEditingPost(true);
              }}
              className="px-1 rounded-md"
              style={{ backgroundColor: "var(--warn)", color: "#fff", borderColor: "transparent" }}
            >
              {/* 연필아이콘 */}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-3 h-3"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M16.862 4.487l2.651 2.651a2 2 0 010 2.828l-9.9 9.9a4 4 0 01-1.414.94l-3.53 1.178a.5.5 0 01-.633-.633l1.178-3.53a4 4 0 01.94-1.414l9.9-9.9a2 2 0 012.828 0z"
                />
              </svg>
            </Button>
            <Button
              onClick={async () => {
                if (!currentLoginUserId) {
                  await openOkModal(
                    commonFunctions.getResourceByLanguage(
                      `NO_PERMISSION`,
                      constants.resourceType.message,
                      currentLanguageCode,
                    ),
                    constants.messageCategory.Error,
                  );
                  return;
                }
                handleDeletePost();
              }}
              className="px-2 rounded-md"
              style={{ backgroundColor: "var(--danger)", color: "#fff", borderColor: "transparent" }}
            >
              -
            </Button>
          </>
        )}
      </div>
      <div className={`ml-5 mt-2`}>
        {post.comments?.map((comment, index) => (
          <div key={index} className={`ml-1 mb-2`}>
            {editingCommentId === comment.comment_id ? (
              <div>
                <input
                  type="text"
                  value={editedCommentText}
                  onChange={handleEditCommentChange}
                  className={`w-full 
                              p-1 
                              border 
                              border-[var(--border-color)] 
                              rounded-md`}
                />
                <Button
                  onClick={() => handleEditComment(comment.comment_id)}
                  className="mt-2 p-1 rounded-md"
                  style={{ backgroundColor: "var(--brand-blue)", color: "#fff", borderColor: "transparent" }}
                >
                  {tl("save")}
                </Button>
                <Button
                  onClick={() => setEditingCommentId(null)}
                  className="mt-2 ml-1 p-1 rounded-md"
                  style={{ backgroundColor: "var(--text-muted)", color: "#fff", borderColor: "transparent" }}
                >
                  {tl("cancel")}
                </Button>
              </div>
            ) : (
              <div className={`w-full text-left`}>
                <strong className={`text-left text-sm`}>
                  {comment.create_user_id}
                </strong>
                <span className={`text-[var(--semi-text-color)] ml-2 text-sm`}>
                  {new Date(comment.create_time).toLocaleString()}
                </span>
                <br />
                <p className={`w-full text-left`}>{comment.comment_content}</p>
              </div>
            )}
            <div className={`flex mt-1`}>
              {editingCommentId !== comment.comment_id && (
                <>
                  <Button
                    onClick={async () => {
                      if (!currentLoginUserId) {
                        await openOkModal(
                          commonFunctions.getResourceByLanguage(
                            `NO_PERMISSION`,
                            constants.resourceType.message,
                            currentLanguageCode,
                          ),
                          constants.messageCategory.Error,
                        );
                        return;
                      }
                      setEditingCommentId(comment.comment_id);
                      setEditedCommentText(comment.comment_content);
                    }}
                    className="px-1 rounded-md"
                    style={{ backgroundColor: "var(--warn)", color: "#fff", borderColor: "transparent" }}
                  >
                    {/* 연필아이콘 */}
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="w-3 h-3"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={2}
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M16.862 4.487l2.651 2.651a2 2 0 010 2.828l-9.9 9.9a4 4 0 01-1.414.94l-3.53 1.178a.5.5 0 01-.633-.633l1.178-3.53a4 4 0 01.94-1.414l9.9-9.9a2 2 0 012.828 0z"
                      />
                    </svg>
                  </Button>
                  <Button
                    onClick={async () => {
                      if (!currentLoginUserId) {
                        await openOkModal(
                          commonFunctions.getResourceByLanguage(
                            `NO_PERMISSION`,
                            constants.resourceType.message,
                            currentLanguageCode(),
                          ),
                          constants.messageCategory.Error,
                        );
                        return;
                      }
                      handleDeleteComment(comment.comment_id);
                    }}
                    className="px-2 rounded-md"
                    style={{ backgroundColor: "var(--danger)", color: "#fff", borderColor: "transparent" }}
                  >
                    -
                  </Button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
      <div className={`flex mt-2`}>
        <input
          type="text"
          value={commentText}
          onChange={handleCommentChange}
          placeholder={tl("boardNewCommentPlaceholder")}
          className={`flex-1 
                      p-1
                      border 
                      border-[var(--border-color)] 
                      rounded-md 
                      medium-text-color`}
        />
        <Button
          onClick={handleAddComment}
          className="ml-1 p-1 rounded-md"
          style={{ backgroundColor: "var(--brand-blue)", color: "#fff", borderColor: "transparent" }}
        >
          +
        </Button>
      </div>
    </div>
  );
}

export default BrunnerBoard;
