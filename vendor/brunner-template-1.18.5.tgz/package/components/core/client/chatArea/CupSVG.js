"use client";

// SVG cup geometry
export const CUP = {
  vw: 160,
  vh: 220,
  topLeft:  { x: 28,  y: 32  },
  topRight: { x: 132, y: 32  },
  botLeft:  { x: 44,  y: 188 },
  botRight: { x: 116, y: 188 },
  wallTop: 22,
  wallLeft: 22,
  wallRight: 138,
  wallBot: 194,
};

export function lerp(a, b, t) {
  return a + (b - a) * t;
}

export function liquidPolygon(fill) {
  const { topLeft: tl, topRight: tr, botLeft: bl, botRight: br } = CUP;
  if (fill <= 0) return null;
  const f = Math.max(0, Math.min(1, fill));
  const surfY = lerp(tl.y, bl.y, 1 - f);
  const leftX  = lerp(tl.x, bl.x, (surfY - tl.y) / (bl.y - tl.y));
  const rightX = lerp(tr.x, br.x, (surfY - tr.y) / (br.y - tr.y));
  return { leftX, rightX, surfY };
}

export function SteamPaths() {
  const paths = [
    { x: 60,  d: "M0,40 Q8,-10 0,-40 Q-8,-70 0,-110",  delay: "0s",   dur: "2.4s" },
    { x: 80,  d: "M0,40 Q-10,-10 0,-40 Q10,-70 0,-110", delay: "0.8s", dur: "2.8s" },
    { x: 100, d: "M0,40 Q6,-12 0,-40 Q-6,-68 0,-110",   delay: "1.6s", dur: "2.2s" },
  ];
  return (
    <g>
      <style>{`
        @keyframes steamRise {
          0%   { opacity: 0; transform: translateY(0) scaleX(1); }
          20%  { opacity: 0.55; }
          70%  { opacity: 0.3; }
          100% { opacity: 0; transform: translateY(-30px) scaleX(1.3); }
        }
      `}</style>
      {paths.map((p, i) => (
        <path
          key={i}
          d={p.d}
          transform={`translate(${p.x}, 22)`}
          fill="none"
          stroke="rgba(255,255,255,0.45)"
          strokeWidth="3"
          strokeLinecap="round"
          style={{ animation: `steamRise ${p.dur} ease-in-out infinite`, animationDelay: p.delay }}
        />
      ))}
    </g>
  );
}

export function IceCube({ cfg, liq, fill }) {
  const { topLeft: tl, topRight: tr, botLeft: bl, botRight: br } = CUP;
  const depthY = lerp(tl.y, bl.y, cfg.cy);
  const lx = lerp(tl.x, bl.x, cfg.cy);
  const rx = lerp(tr.x, br.x, cfg.cy);
  const cx = lerp(lx, rx, cfg.cx);
  if (!liq || depthY < liq.surfY) return null;
  return (
    <g transform={`translate(${cx},${depthY}) rotate(${cfg.rot})`}>
      <style>{`
        @keyframes iceBob_${cfg.dur.replace(".", "_")} {
          0%, 100% { transform: rotate(${cfg.rot}deg) translateY(0px); }
          50%       { transform: rotate(${cfg.rot + 4}deg) translateY(-2px); }
        }
      `}</style>
      <rect
        x={-cfg.w / 2} y={-cfg.h / 2}
        width={cfg.w} height={cfg.h}
        rx="4" ry="4"
        fill="rgba(190,230,255,0.55)"
        stroke="rgba(200,240,255,0.85)"
        strokeWidth="1.2"
        style={{
          animation: `iceBob_${cfg.dur.replace(".", "_")} ${cfg.dur} ease-in-out infinite`,
          animationDelay: cfg.delay,
        }}
      />
      <line
        x1={-cfg.w * 0.3} y1={-cfg.h * 0.25}
        x2={cfg.w * 0.2}  y2={cfg.h * 0.2}
        stroke="rgba(255,255,255,0.4)" strokeWidth="1"
      />
    </g>
  );
}

export function DujjeonkuSvg({ level = 100 }) {
  const backRightVisible = level > 67;
  const backRightHalf    = level > 50 && level <= 67;
  const backLeftVisible  = level > 34;
  const backLeftHalf     = level > 17 && level <= 34;
  const frontVisible     = level > 17;
  const frontHalf        = level > 0  && level <= 17;

  const Ball = ({ cx, cy, clipId }) => (
    <g clipPath={clipId ? `url(#${clipId})` : undefined}>
      <circle cx={cx} cy={cy + 2} r="19" fill="#180904" />
      <circle cx={cx} cy={cy}     r="19" fill="#3b1608" />
      <circle cx={cx - 6} cy={cy - 7} r="4" fill="#5c2510" opacity="0.45" />
      <ellipse cx={cx - 7} cy={cy - 6} rx="4" ry="2.5" fill="white" opacity="0.07"
        transform={`rotate(-30 ${cx - 7} ${cy - 6})`} />
    </g>
  );
  const CutFace = ({ cx, cy }) => (
    <>
      <ellipse cx={cx} cy={cy} rx="5"   ry="16" fill="#c07c0a" />
      <ellipse cx={cx} cy={cy} rx="3.5" ry="12" fill="#d4940e" />
      {[-6, -2, 2, 6].map((dy, i) => (
        <line key={i} x1={cx - 3} y1={cy + dy} x2={cx + 3} y2={cy + dy}
          stroke="#f0c030" strokeWidth="1" opacity="0.9" />
      ))}
    </>
  );

  return (
    <svg viewBox="0 0 100 90" width="90" height="80" style={{ overflow: "visible", display: "block" }}>
      <defs>
        <clipPath id="djkBRclip"><rect x="0" y="0" width="73" height="90" /></clipPath>
        <clipPath id="djkBLclip"><rect x="0" y="0" width="27" height="90" /></clipPath>
        <clipPath id="djkFclip"> <rect x="0" y="0" width="50" height="90" /></clipPath>
      </defs>
      {backLeftVisible  && <Ball cx={27} cy={68} clipId={backLeftHalf  ? "djkBLclip" : null} />}
      {backLeftHalf     && <CutFace cx={27} cy={68} />}
      {backRightVisible && <Ball cx={73} cy={68} clipId={backRightHalf ? "djkBRclip" : null} />}
      {backRightHalf    && <CutFace cx={73} cy={68} />}
      {frontVisible && (
        <g clipPath={frontHalf ? "url(#djkFclip)" : undefined}>
          <circle cx="50" cy="52" r="23" fill="#180904" />
          <circle cx="50" cy="50" r="23" fill="#3b1608" />
          <ellipse cx="50" cy="39" rx="14" ry="12" fill="#c07c0a" />
          <ellipse cx="50" cy="39" rx="12" ry="10" fill="#d4940e" />
          {[33, 36, 39, 42, 45, 48].map((y, i) => (
            <line key={i} x1={38} y1={y} x2={62} y2={y} stroke="#f0c030" strokeWidth="1.1" opacity="0.85" />
          ))}
          <ellipse cx="50" cy="39" rx="14" ry="12" fill="none" stroke="#a06008" strokeWidth="1" />
          <circle cx="42" cy="55" r="2.5" fill="#5c2510" opacity="0.5" />
          <ellipse cx="42" cy="41" rx="5" ry="3" fill="white" opacity="0.1" transform="rotate(-30 42 41)" />
        </g>
      )}
      {frontHalf && <CutFace cx={50} cy={50} />}
    </svg>
  );
}

export function ShanghaiButterTteokSvg({ level = 100 }) {
  const domHeight    = 69;
  const domTop       = 10;
  const visibleFromY = domTop + domHeight * (1 - level / 100);
  const clipId       = "tteokClip";

  return (
    <svg viewBox="0 0 100 108" width="80" height="85" style={{ overflow: "visible", display: "block" }}>
      <defs>
        <clipPath id={clipId}>
          <rect x="0" y={visibleFromY} width="100" height={108} />
        </clipPath>
      </defs>
      <path d="M 22 80 L 27 98 Q 50 104 73 98 L 78 80 Z" fill="white" stroke="#ddd" strokeWidth="0.8" />
      {[27, 33, 39, 45, 51, 57, 63, 69, 75].map((x, i) => (
        <line key={i} x1={x} y1="80" x2={x - 0.5} y2="97" stroke="#ccc" strokeWidth="0.6" opacity="0.8" />
      ))}
      <ellipse cx="50" cy="81" rx="27" ry="4" fill="#7a3008" opacity="0.2" />
      <g clipPath={`url(#${clipId})`}>
        <path d="M 23 79 Q 23 14 50 10 Q 77 14 77 79 Z" fill="#8b3c08" />
        <path d="M 25 79 Q 25 16 50 12 Q 75 16 75 79 Z" fill="#c4621a" />
        {[-18, -9, 0, 9, 18].map((dx, i) => (
          <path key={i} d={`M ${50 + dx} 79 Q ${50 + dx * 0.6} 40 50 12`}
            fill="none" stroke="#8b3a06" strokeWidth="2.2" opacity="0.55" />
        ))}
        {[-13.5, -4.5, 4.5, 13.5].map((dx, i) => (
          <path key={i} d={`M ${50 + dx} 79 Q ${50 + dx * 0.5} 38 50 12`}
            fill="none" stroke="#e8841e" strokeWidth="1.2" opacity="0.4" />
        ))}
        <ellipse cx="50" cy="14" rx="10" ry="5" fill="#f0a830" opacity="0.5" />
        <path d="M 36 26 Q 43 13 57 20 Q 48 15 36 26 Z" fill="white" opacity="0.22" />
        <ellipse cx="44" cy="27" rx="7" ry="4" fill="white" opacity="0.15" transform="rotate(-25 44 27)" />
      </g>
      {level < 100 && level > 0 && (
        <ellipse cx="50" cy={visibleFromY} rx={Math.max(2, 24 * (level / 100))} ry="3"
          fill="#d4880e" opacity="0.7" />
      )}
    </svg>
  );
}
