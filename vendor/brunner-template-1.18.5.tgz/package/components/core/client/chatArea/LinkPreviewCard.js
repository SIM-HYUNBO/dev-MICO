import { useEffect, useState } from "react";

const URL_REGEX = /https?:\/\/[^\s<>"{}|\\^`\[\]]+/g;

export function extractFirstUrl(text) {
  if (!text || typeof text !== "string") return null;
  const m = text.match(URL_REGEX);
  return m ? m[0] : null;
}

export default function LinkPreviewCard({ url, isMine }) {
  const [data, setData] = useState(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!url) return;
    let cancelled = false;
    fetch(`/api/linkPreview?url=${encodeURIComponent(url)}`)
      .then((r) => r.json())
      .then((d) => {
        if (cancelled) return;
        if (d.error) setFailed(true);
        else setData(d);
      })
      .catch(() => { if (!cancelled) setFailed(true); });
    return () => { cancelled = true; };
  }, [url]);

  if (failed || !data) return null;

  const isYt = data.isYoutube;

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="mt-1.5 block max-w-[260px] overflow-hidden rounded-[var(--radius-lg)] border no-underline transition hover:opacity-90 active:opacity-80"
      style={{
        borderColor: isMine ? "rgba(255,255,255,0.25)" : "var(--border)",
        background: isMine ? "rgba(255,255,255,0.12)" : "var(--surface)",
        boxShadow: "var(--shadow-card)",
      }}
    >
      {data.image && (
        <div className="relative w-full overflow-hidden" style={{ paddingTop: isYt ? "56.25%" : "52%" }}>
          <img
            src={data.image}
            alt=""
            loading="lazy"
            className="absolute inset-0 h-full w-full object-cover"
            onError={(e) => { e.currentTarget.style.display = "none"; }}
          />
          {isYt && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-600/90">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="white"><path d="M8 5v14l11-7Z"/></svg>
              </div>
            </div>
          )}
        </div>
      )}
      <div className="px-3 py-2">
        {data.siteName && (
          <div className="mb-0.5 text-[10px] font-semibold uppercase tracking-wide" style={{ color: isMine ? "rgba(255,255,255,0.6)" : "var(--text-muted)" }}>
            {data.siteName}
          </div>
        )}
        {data.title && (
          <div className="line-clamp-2 text-[13px] font-semibold leading-tight" style={{ color: isMine ? "white" : "var(--text)" }}>
            {data.title}
          </div>
        )}
        {data.description && (
          <div className="mt-0.5 line-clamp-2 text-[11px] leading-snug" style={{ color: isMine ? "rgba(255,255,255,0.7)" : "var(--text-muted)" }}>
            {data.description}
          </div>
        )}
      </div>
    </a>
  );
}
