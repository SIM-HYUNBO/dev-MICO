"use client";

import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import * as constants from "@/lib/constants";

// ── Constants ──────────────────────────────────────────────────────────────
const W = 460;
const H = 220;
const CIG_Y = 130;
const CIG_H = 14;
const FILTER_X = 60;
const FILTER_W = 55;
const BODY_X = FILTER_X + FILTER_W;
const MAX_BURN = 260;

// ── Particle classes ───────────────────────────────────────────────────────
class SmokeParticle {
  constructor(x, y, puff = false) {
    this.x = x + (Math.random() - 0.5) * 4;
    this.y = y;
    this.vx = (Math.random() - 0.5) * (puff ? 1.8 : 0.6);
    this.vy = -(Math.random() * (puff ? 2.2 : 1.2) + 0.6);
    this.life = 1;
    this.decay = puff
      ? 0.008 + Math.random() * 0.006
      : 0.012 + Math.random() * 0.008;
    this.r = puff ? 8 + Math.random() * 14 : 4 + Math.random() * 8;
    this.dr = puff ? 0.18 : 0.1;
    this.twist = (Math.random() - 0.5) * 0.04;
    this.puff = puff;
  }
  update() {
    this.x += this.vx + Math.sin(this.life * 8) * 0.3;
    this.y += this.vy;
    this.vx += this.twist;
    this.vy *= 0.99;
    this.r += this.dr;
    this.life -= this.decay;
  }
  draw(ctx) {
    const alpha = this.life * (this.puff ? 0.22 : 0.15);
    const lightness = this.puff ? 75 : 80;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
    ctx.fillStyle = `hsla(220,8%,${lightness}%,${alpha})`;
    ctx.fill();
  }
}

class AshParticle {
  constructor(x, y) {
    this.x = x + (Math.random() - 0.5) * 6;
    this.y = y;
    this.vx = (Math.random() - 0.5) * 1.5;
    this.vy = Math.random() * 1 + 0.5;
    this.life = 1;
    this.r = 1.5 + Math.random() * 2;
  }
  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += 0.08;
    this.vx *= 0.98;
    this.life -= 0.015;
  }
  draw(ctx) {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(180,178,170,${this.life * 0.7})`;
    ctx.fill();
  }
}

// ── ember X 계산 헬퍼 ──────────────────────────────────────────────────────
function getEmberX(burn) {
  const bw = Math.max(0, MAX_BURN - burn);
  const tx = BODY_X + bw;
  const ashW = Math.min(burn * 0.18 + 4, 22);
  const grayW = Math.min(burn * 0.12 + 3, 14);
  return tx - ashW - grayW;
}

// ── Pure drawing function ──────────────────────────────────────────────────
function drawCigarette(ctx, burn, isCigSmoking, emberFlicker) {
  const bw = Math.max(0, MAX_BURN - burn);
  const tx = BODY_X + bw;
  const cy = CIG_Y;
  const ch = CIG_H;

  ctx.save();

  // Filter
  const fgGrad = ctx.createLinearGradient(FILTER_X, cy, FILTER_X, cy + ch);
  fgGrad.addColorStop(0, "#d4a96a");
  fgGrad.addColorStop(0.4, "#c89850");
  fgGrad.addColorStop(0.8, "#a87838");
  fgGrad.addColorStop(1, "#8c6030");
  ctx.fillStyle = fgGrad;
  ctx.beginPath();
  ctx.roundRect(FILTER_X, cy, FILTER_W, ch, [4, 0, 0, 4]);
  ctx.fill();
  ctx.strokeStyle = "rgba(0,0,0,0.12)";
  ctx.lineWidth = 0.5;
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,200,0.25)";
  ctx.lineWidth = 0.8;
  ctx.beginPath();
  ctx.moveTo(FILTER_X + 4, cy + 2);
  ctx.lineTo(FILTER_X + FILTER_W - 4, cy + 2);
  ctx.stroke();
  ctx.strokeStyle = "rgba(0,0,0,0.08)";
  ctx.lineWidth = 0.5;
  for (let i = 1; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(FILTER_X + (FILTER_W * i) / 4, cy + 2);
    ctx.lineTo(FILTER_X + (FILTER_W * i) / 4, cy + ch - 2);
    ctx.stroke();
  }

  // Paper body
  if (bw > 0) {
    const grad = ctx.createLinearGradient(BODY_X, cy, BODY_X, cy + ch);
    grad.addColorStop(0, "#f7f2e8");
    grad.addColorStop(0.3, "#ede8d8");
    grad.addColorStop(0.7, "#d8d4c8");
    grad.addColorStop(1, "#c0bdb0");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(BODY_X, cy, bw, ch, [0, 4, 4, 0]);
    ctx.fill();
    ctx.strokeStyle = "rgba(0,0,0,0.08)";
    ctx.lineWidth = 0.5;
    ctx.stroke();
    for (let i = 0; i < 6; i++) {
      const lx = BODY_X + 20 + i * 40;
      if (lx > BODY_X + bw - 10) break;
      ctx.strokeStyle = "rgba(0,0,0,0.05)";
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.moveTo(lx, cy + 2);
      ctx.lineTo(lx, cy + ch - 2);
      ctx.stroke();
    }
    ctx.strokeStyle = "rgba(180,170,150,0.6)";
    ctx.lineWidth = 0.5;
    ctx.beginPath();
    ctx.moveTo(BODY_X, cy + ch * 0.3);
    ctx.lineTo(BODY_X + bw, cy + ch * 0.3);
    ctx.stroke();
  }

  // Burning tip — 재와 몸통 경계에 불꽃
  if (isCigSmoking && bw > 0) {
    const ashW = Math.min(burn * 0.18 + 4, 22);
    const ashGrad = ctx.createLinearGradient(tx - ashW, cy, tx, cy);
    ashGrad.addColorStop(0, "#b0afa8");
    ashGrad.addColorStop(0.5, "#cccbc4");
    ashGrad.addColorStop(1, "#e0dfd8");
    ctx.fillStyle = ashGrad;
    ctx.beginPath();
    ctx.roundRect(tx - ashW, cy + 1, ashW, ch - 2, [2, 4, 4, 2]);
    ctx.fill();

    const grayW = Math.min(burn * 0.12 + 3, 14);
    const grayGrad = ctx.createLinearGradient(
      tx - ashW - grayW,
      cy,
      tx - ashW,
      cy,
    );
    grayGrad.addColorStop(0, "#8a8880");
    grayGrad.addColorStop(1, "#b0afa8");
    ctx.fillStyle = grayGrad;
    ctx.beginPath();
    ctx.roundRect(tx - ashW - grayW, cy + 1, grayW, ch - 2, [2, 0, 0, 2]);
    ctx.fill();

    // ✅ 불꽃: 재(회색 전이구간)와 남은 몸통(종이)의 경계
    const emberX = tx - ashW - grayW;
    const flicker = 0.7 + Math.sin(emberFlicker * 0.3) * 0.3;
    const r = (ch / 2 + 2) * flicker;

    const glow = ctx.createRadialGradient(
      emberX,
      cy + ch / 2,
      0,
      emberX,
      cy + ch / 2,
      r * 2.5,
    );
    glow.addColorStop(0, `rgba(255,180,40,${0.25 * flicker})`);
    glow.addColorStop(0.5, `rgba(255,100,10,${0.12 * flicker})`);
    glow.addColorStop(1, "rgba(255,50,0,0)");
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(emberX, cy + ch / 2, r * 2.5, 0, Math.PI * 2);
    ctx.fill();

    const tipGrad = ctx.createRadialGradient(
      emberX - 2,
      cy + ch / 2 - 1,
      0,
      emberX,
      cy + ch / 2,
      r,
    );
    tipGrad.addColorStop(0, `rgba(255,240,180,${flicker})`);
    tipGrad.addColorStop(0.3, `rgba(255,160,20,${0.95 * flicker})`);
    tipGrad.addColorStop(0.7, `rgba(220,60,10,${0.85 * flicker})`);
    tipGrad.addColorStop(1, `rgba(180,20,0,${0.4 * flicker})`);
    ctx.fillStyle = tipGrad;
    ctx.beginPath();
    ctx.arc(emberX, cy + ch / 2, r, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

// ── Component ──────────────────────────────────────────────────────────────
const SmokingArea = forwardRef(function SmokingArea(
  { onSmokingChange, setCanChat, onStarted, isMuted },
  ref,
) {
  const canvasRef = useRef(null);
  const isMutedRef = useRef(isMuted);
  useEffect(() => { isMutedRef.current = isMuted; }, [isMuted]);

  const playSound = (src) => {
    if (isMutedRef.current || typeof Audio === "undefined") return;
    const a = new Audio(src);
    a.volume = 0.3;
    a.playbackRate = 0.9 + Math.random() * 0.2;
    a.play().catch(() => {});
  };

  const stateRef = useRef({
    smoking: false,
    burn: 0,
    particles: [],
    ashParticles: [],
    puffing: false,
    puffTimer: 0,
    emberFlicker: 0,
    frame: 0,
  });

  const rafRef = useRef(null);
  const burnIntervalRef = useRef(null);

  const [isSmoking, setIsSmoking] = useState(false);
  const [burnPct, setBurnPct] = useState(100);
  const [statusText, setStatusText] = useState("");


  // ── Animation loop ──────────────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    const tick = () => {
      const s = stateRef.current;
      ctx.clearRect(0, 0, W, H);
      s.emberFlicker += 1;
      s.frame += 1;

      if (s.smoking) {
        // ✅ 연기 파티클도 불꽃 위치(emberX)에서 생성
        const emberX = getEmberX(s.burn);
        if (s.frame % 5 === 0) {
          s.particles.push(new SmokeParticle(emberX, CIG_Y, false));
          s.particles.push(new SmokeParticle(emberX, CIG_Y, false));
        }
        if (s.puffing) {
          s.puffTimer -= 1;
          if (s.puffTimer <= 0) s.puffing = false;
          if (s.frame % 2 === 0) {
            for (let i = 0; i < 3; i++) {
              s.particles.push(new SmokeParticle(emberX, CIG_Y, true));
            }
          }
        }
      }

      s.particles = s.particles.filter((p) => p.life > 0);
      s.ashParticles = s.ashParticles.filter((p) => p.life > 0 && p.y < H);
      s.particles.forEach((p) => {
        p.update();
        p.draw(ctx);
      });
      drawCigarette(ctx, s.burn, s.smoking, s.emberFlicker);
      s.ashParticles.forEach((p) => {
        p.update();
        p.draw(ctx);
      });

      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  // ── Actions ─────────────────────────────────────────────────────────────
  const handleStart = () => {
    const s = stateRef.current;
    s.smoking = true;
    s.burn = 0;
    s.particles = [];
    s.ashParticles = [];
    s.puffing = false;
    playSound("/sounds/lighter.mp3");
    onSmokingChange?.(true);
    setCanChat?.(true);
    setIsSmoking(true);
    onStarted?.();
    setBurnPct(100);
    setStatusText(
      commonFunctions.getResourceByLanguage(
        "SMOKING_IN_PROGRESS",
        constants.resourceType.message,
        userInfo.getCurrentLanguageCode(),
      ),
    );

    clearInterval(burnIntervalRef.current);
    burnIntervalRef.current = setInterval(() => {
      const s = stateRef.current;
      if (!s.smoking) return;
      s.burn += 0.4;
      setBurnPct(Math.max(0, 100 - (s.burn / MAX_BURN) * 100));
      if (s.burn + 40 >= MAX_BURN) handleEnd(true);
    }, 300);
  };

  const handlePuff = () => {
    const s = stateRef.current;
    if (!s.smoking) return;
    s.puffing = true;
    s.puffTimer = 40;
    s.burn += 8;
    const emberX = getEmberX(s.burn);
    for (let i = 0; i < 6; i++) {
      s.ashParticles.push(
        new AshParticle(emberX - 5 + Math.random() * 10, CIG_Y + CIG_H),
      );
    }
    playSound("/sounds/puffsound.mp3");
    setTimeout(() => playSound("/sounds/exhale.mp3"), 3500);
    setBurnPct(Math.max(0, 100 - (s.burn / MAX_BURN) * 100));
    if (s.burn >= MAX_BURN) handleEnd(true);
  };

  useImperativeHandle(ref, () => ({
    triggerStart: handleStart,
    triggerPuff: handlePuff,
    isActive: () => stateRef.current.smoking,
  }));

  const handleEnd = useCallback((finished = false) => {
    const s = stateRef.current;
    s.smoking = false;
    s.puffing = false;
    clearInterval(burnIntervalRef.current);
    playSound("/sounds/exhale.mp3");
    onSmokingChange?.(false);
    setCanChat?.(false);
    setIsSmoking(false);
    setBurnPct(0);
    const lang = userInfo.getCurrentLanguageCode();
    setStatusText(
      finished
        ? commonFunctions.getResourceByLanguage(
            "CIGARETTE_BURNED_OUT",
            constants.resourceType.message,
            lang,
          )
        : commonFunctions.getResourceByLanguage(
            "SMOKING_ENDED",
            constants.resourceType.message,
            lang,
          ),
    );
    setTimeout(() => {
      s.burn = 0;
      setBurnPct(100);
      setStatusText("");
    }, 2000);
  }, []); // eslint-disable-line

  // ── Render ──────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col items-center">
      <canvas
        ref={canvasRef}
        width={W}
        height={H}
        className="max-w-full"
        style={{ imageRendering: "crisp-edges" }}
      />

      {statusText && (
        <div className="text-sm text-gray-500 mt-1">{statusText}</div>
      )}

      <div className="w-64 h-1.5 bg-gray-200 rounded-full mt-1 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{
            width: `${burnPct}%`,
            background: burnPct > 30 ? "#e8520a" : "#aaa9a4",
          }}
        />
      </div>

      <div className="flex gap-2 mt-1">
        <button
          disabled={isSmoking}
          onClick={handleStart}
          className={`px-3 py-1 text-white text-sm rounded ${
            isSmoking
              ? "bg-gray-300 cursor-not-allowed"
              : "bg-orange-500 hover:bg-orange-600"
          }`}
        >
          {commonFunctions.getResourceByLanguage(
            "lightCigarette",
            constants.resourceType.label,
            userInfo.getCurrentLanguageCode(),
          )}
        </button>

        <button
          disabled={!isSmoking}
          onClick={handlePuff}
          className={`px-3 py-1 text-gray-800 text-sm rounded ${
            !isSmoking
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-yellow-500 hover:bg-yellow-600"
          }`}
        >
          {commonFunctions.getResourceByLanguage(
            "takePuff",
            constants.resourceType.label,
            userInfo.getCurrentLanguageCode(),
          )}
        </button>

        <button
          disabled={!isSmoking}
          onClick={() => handleEnd(false)}
          className={`px-3 py-1 text-gray-800 text-sm rounded ${
            !isSmoking
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-gray-500 hover:bg-gray-600"
          }`}
        >
          {commonFunctions.getResourceByLanguage(
            "extinguish",
            constants.resourceType.label,
            userInfo.getCurrentLanguageCode(),
          )}
        </button>
      </div>
    </div>
  );
});

export default SmokingArea;
