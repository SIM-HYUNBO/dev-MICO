"use client";

import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import * as constants from "@/lib/constants";
import { ICE_CONFIGS, COFFEE_LIST, BEVERAGE_LIST } from "@/lib/cafeData";
import { playCafeSound } from "@/lib/cafeSounds";
import {
  CUP,
  liquidPolygon,
  SteamPaths,
  IceCube,
  DujjeonkuSvg,
  ShanghaiButterTteokSvg,
} from "@/components/core/client/chatArea/CupSVG";

const DESSERT_LIST = [
  {
    id: "dujjeonku",
    label: "두쫀쿠",
    labelKey: "menuDujjeonku",
    isDessert: true,
    SvgIcon: DujjeonkuSvg,
    accent: "#78350f",
  },
  {
    id: "shanghaibutter",
    label: "상하이버터떡",
    labelKey: "menuShanghaibutter",
    isDessert: true,
    SvgIcon: ShanghaiButterTteokSvg,
    accent: "#b45309",
  },
];

const ALL_DRINKS = [...COFFEE_LIST, ...BEVERAGE_LIST, ...DESSERT_LIST];

const CoffeeArea = forwardRef(function CoffeeArea(
  { onDrinkingChange, setCanChat, onStarted, initialDrinkType, initialTemp, isMuted },
  ref,
) {
  const [isDrinking, setIsDrinking] = useState(false);
  const [drinkType, setDrinkType] = useState(initialDrinkType || "americano");
  const [temp, setTemp] = useState(initialTemp || "hot");
  const [level, setLevel] = useState(0);
  const [isSipping, setIsSipping] = useState(false);
  const [biteCooldown, setBiteCooldown] = useState(false);

  // 동기 접근용 ref (triggerStart → triggerSip 순서 보장)
  const sessionRef = useRef({ isDrinking: false, level: 0 });
  const drinkTypeRef = useRef(initialDrinkType || "americano");
  const isMutedRef = useRef(isMuted);
  useEffect(() => {
    drinkTypeRef.current = drinkType;
  }, [drinkType]);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  useEffect(() => {
    const drink = ALL_DRINKS.find((d) => d.id === drinkType);
    const drinkLabel = drink?.label ?? drinkType;
    const isDessert = !!drink?.isDessert;
    onDrinkingChange?.({ isDrinking, drinkType, drinkLabel, isDessert, temp, level });
    if (level === 0) {
      setIsDrinking(false);
      sessionRef.current.isDrinking = false;
      setCanChat?.(false);
    }
  }, [isDrinking, drinkType, temp, level]);

  const currentDrink = ALL_DRINKS.find((d) => d.id === drinkType);
  const isBeverage = !!currentDrink?.isBeverage;
  const isDessert = !!currentDrink?.isDessert;
  const DessertIcon = currentDrink?.SvgIcon ?? null;
  const liquidColor = isBeverage
    ? currentDrink.color
    : temp === "iced"
    ? currentDrink.icedColor
    : currentDrink.hotColor;
  const liquidDeep = isBeverage
    ? currentDrink.liquid
    : temp === "iced"
    ? currentDrink.icedLiquid
    : currentDrink.hotLiquid;
  const fill = level / 100;
  const liq = liquidPolygon(fill);
  const visibleIce = Math.ceil(fill * ICE_CONFIGS.length);

  const { topLeft: tl, topRight: tr, botLeft: bl, botRight: br } = CUP;

  const handleStart = () => {
    if (sessionRef.current.isDrinking) return;
    if (!isMutedRef.current) {
      playCafeSound(isDessert ? "dessertStart" : "pour");
    }
    sessionRef.current.isDrinking = true;
    sessionRef.current.level = 100;
    setLevel(100);
    setIsDrinking(true);
    setCanChat?.(true);
    onStarted?.();
  };

  const handleSip = () => {
    const s = sessionRef.current;
    if (!s.isDrinking || s.level <= 0) return;
    if (isDessert && biteCooldown) return;
    if (!isMutedRef.current) {
      playCafeSound(isDessert ? "bite" : "sip");
    }
    setIsSipping(true);
    setTimeout(() => setIsSipping(false), 200);
    if (isDessert) {
      setBiteCooldown(true);
      setTimeout(() => setBiteCooldown(false), 900);
    }
    const dt = drinkTypeRef.current;
    const reduction = isDessert ? (dt === "dujjeonku" ? 17 : 20) : 8;
    const next = Math.max(s.level - reduction, 0);
    s.level = next;
    setLevel(next);
    if (next === 0) {
      setTimeout(() => {
        s.isDrinking = false;
        setIsDrinking(false);
        if (!isMutedRef.current) {
          playCafeSound(isDessert ? "dessertFinish" : "finish");
        }
        setCanChat?.(false);
      }, 200);
    }
  };

  const handleEnd = () => {
    if (!sessionRef.current.isDrinking) return;
    sessionRef.current.isDrinking = false;
    sessionRef.current.level = 0;
    setIsDrinking(false);
    setLevel(0);
    if (!isMutedRef.current) {
      playCafeSound(isDessert ? "dessertFinish" : "finish");
    }
    setCanChat?.(false);
  };

  useImperativeHandle(ref, () => ({
    triggerStart: handleStart,
    triggerSip: handleSip,
    isActive: () => sessionRef.current.isDrinking,
  }));

  const langCode = userInfo.getCurrentLanguageCode();
  const getLabel = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.label,
      langCode,
    );
  const getMsg = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.message,
      langCode,
    );

  const statusText = isDrinking
    ? `${level}% ${getMsg("CAFE_STATUS_REMAINING") || "남음"}`
    : "";

  const outerPath = `M ${CUP.wallLeft},${CUP.wallTop} L ${CUP.wallRight},${
    CUP.wallTop
  } L ${br.x + 6},${CUP.wallBot} L ${bl.x - 6},${CUP.wallBot} Z`;
  const innerPath = `M ${tl.x},${tl.y} L ${tr.x},${tr.y} L ${br.x},${br.y} L ${bl.x},${bl.y} Z`;
  const handlePath = `M ${tr.x + 1},${tr.y + 20} C ${tr.x + 38},${tr.y + 18} ${
    tr.x + 38
  },${tr.y + 68} ${tr.x + 1},${tr.y + 66}`;

  const handleSelectDrink = (id) => {
    if (!isDrinking) setDrinkType(id);
  };

  const menuBtnStyle = (item, activeId) =>
    activeId === item.id ? { background: item.accent, color: "#fff" } : {};

  return (
    <div className="cafe-container">
      {/* ---- 메뉴 선택 — 한 줄 압축 ---- */}
      <div
        className="w-full max-w-sm rounded-xl border px-2 py-1 flex items-center gap-1.5 flex-wrap semi-text-bg-color"
        style={{ borderColor: "var(--theme-semi-bg)" }}
      >
        {/* HOT/ICE 토글 — 커피 선택 시만 표시 */}
        {!isBeverage && !isDessert && (
          <div className="inline-flex rounded overflow-hidden border border-gray-300 dark:border-gray-600 shrink-0">
            <button
              onClick={() => setTemp("hot")}
              disabled={isDrinking}
              aria-label="HOT"
              className={`px-1.5 py-0.5 text-[10px] font-bold border-none transition-colors ${
                temp === "hot"
                  ? "bg-orange-500 text-white"
                  : "text-orange-500 temp-btn-off"
              }`}
            >
              🔥
            </button>
            <button
              onClick={() => setTemp("iced")}
              disabled={isDrinking}
              aria-label="ICE"
              className={`px-1.5 py-0.5 text-[10px] font-bold border-none transition-colors border-l ${
                temp === "iced"
                  ? "bg-sky-400 text-white"
                  : "text-sky-500 temp-btn-off"
              }`}
              style={{ borderLeftColor: "var(--theme-semi-bg)" }}
            >
              ❄️
            </button>
          </div>
        )}
        {/* 구분선 */}
        <span
          className="text-gray-300 dark:text-gray-600 text-xs"
          aria-hidden="true"
        >
          ☕
        </span>
        {COFFEE_LIST.map((drink) => (
          <button
            key={drink.id}
            onClick={() => handleSelectDrink(drink.id)}
            disabled={isDrinking}
            className="menu-btn"
            style={menuBtnStyle(drink, drinkType)}
          >
            {drink.label}
          </button>
        ))}
        <span
          className="text-gray-300 dark:text-gray-600 text-xs"
          aria-hidden="true"
        >
          🥤
        </span>
        {BEVERAGE_LIST.map((drink) => (
          <button
            key={drink.id}
            onClick={() => handleSelectDrink(drink.id)}
            disabled={isDrinking}
            className="menu-btn"
            style={menuBtnStyle(drink, drinkType)}
          >
            {drink.label}
          </button>
        ))}
        <span
          className="text-gray-300 dark:text-gray-600 text-xs"
          aria-hidden="true"
        >
          🍰
        </span>
        {DESSERT_LIST.map((item) => (
          <button
            key={item.id}
            onClick={() => handleSelectDrink(item.id)}
            disabled={isDrinking}
            className="menu-btn"
            style={menuBtnStyle(item, drinkType)}
          >
            {item.labelKey ? getLabel(item.labelKey) : item.label}
          </button>
        ))}
      </div>

      {/* ---- CUP + CONTROLS ROW ---- */}
      <div className="flex items-center justify-center gap-[10px] w-full max-w-[400px] flex-wrap">
        {/* DESSERT DISPLAY */}
        {isDessert && (
          <div className="shrink-0 flex flex-col items-center justify-center w-[min(100px,28vw)] max-w-[100px] min-h-[80px] gap-1 box-border">
            <div
              className="flex items-center justify-center"
              style={{
                transform: isSipping ? "scale(0.93)" : "scale(1)",
                transition: "transform 0.15s ease",
                transformOrigin: "center bottom",
              }}
            >
              {DessertIcon && <DessertIcon level={level} />}
            </div>
            {isDrinking && (
              <span className="text-[10px] text-gray-400 font-mono">
                {level}%
              </span>
            )}
            <div className="cafe-progress-track w-[60px]">
              <div
                style={{
                  height: "100%",
                  width: `${level}%`,
                  background: `linear-gradient(90deg, ${currentDrink?.accent}, #7c3aed)`,
                  borderRadius: "999px",
                  transition: "width 0.3s ease",
                }}
              />
            </div>
          </div>
        )}

        {/* SVG CUP */}
        {!isDessert && (
          <div
            className="shrink-0"
            style={{
              transform: isSipping ? "rotate(-12deg)" : "rotate(0deg)",
              transition: "transform 0.2s ease",
              transformOrigin: "bottom center",
            }}
          >
            <svg
              viewBox={`0 0 ${CUP.vw} ${CUP.vh}`}
              className="block overflow-visible w-[min(100px,28vw)] h-auto"
            >
              <defs>
                <clipPath id="cupClip">
                  <path d={innerPath} />
                </clipPath>
                <linearGradient id="liquidGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={liquidColor} />
                  <stop offset="100%" stopColor={liquidDeep} />
                </linearGradient>
                <linearGradient id="cupGrad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#e8e0d8" />
                  <stop offset="40%" stopColor="#f8f4ef" />
                  <stop offset="100%" stopColor="#d4ccc4" />
                </linearGradient>
                <filter id="iceShadow">
                  <feDropShadow
                    dx="0"
                    dy="1"
                    stdDeviation="1"
                    floodColor="rgba(100,160,220,0.4)"
                  />
                </filter>
              </defs>

              {!isBeverage && temp === "hot" && isDrinking && level > 10 && (
                <SteamPaths />
              )}

              <path
                d={outerPath}
                fill="url(#cupGrad)"
                stroke="#c8bfb5"
                strokeWidth="1.5"
              />

              {liq && (
                <g clipPath="url(#cupClip)">
                  <polygon
                    points={`${liq.leftX},${liq.surfY} ${liq.rightX},${liq.surfY} ${br.x},${br.y} ${bl.x},${bl.y}`}
                    fill="url(#liquidGrad)"
                  />
                </g>
              )}

              {currentDrink.hasFoam && isDrinking && liq && (
                <g clipPath="url(#cupClip)">
                  <ellipse
                    cx={(liq.leftX + liq.rightX) / 2}
                    cy={liq.surfY + 4}
                    rx={(liq.rightX - liq.leftX) / 2 - 2}
                    ry={6}
                    fill={
                      currentDrink.hasStrawberry
                        ? "rgba(255,200,210,0.92)"
                        : "rgba(245,235,210,0.88)"
                    }
                  />
                  {currentDrink.hasStrawberry && (
                    <>
                      <ellipse
                        cx={(liq.leftX + liq.rightX) / 2 - 12}
                        cy={liq.surfY + 3}
                        rx="5"
                        ry="6"
                        fill="#e8304a"
                      />
                      <ellipse
                        cx={(liq.leftX + liq.rightX) / 2 + 12}
                        cy={liq.surfY + 4}
                        rx="4"
                        ry="5"
                        fill="#e8304a"
                      />
                      <ellipse
                        cx={(liq.leftX + liq.rightX) / 2}
                        cy={liq.surfY + 2}
                        rx="4"
                        ry="5"
                        fill="#f04060"
                      />
                      <text
                        x={(liq.leftX + liq.rightX) / 2 - 13}
                        y={liq.surfY + 5}
                        fontSize="7"
                        textAnchor="middle"
                        fill="#fff"
                        opacity="0.7"
                      >
                        🍓
                      </text>
                    </>
                  )}
                  {currentDrink.hasChocolate && (
                    <>
                      <line
                        x1={liq.leftX + 14}
                        y1={liq.surfY}
                        x2={liq.leftX + 20}
                        y2={liq.surfY + 8}
                        stroke="#5a2a10"
                        strokeWidth="2"
                        strokeLinecap="round"
                      />
                      <line
                        x1={(liq.leftX + liq.rightX) / 2 - 6}
                        y1={liq.surfY + 2}
                        x2={(liq.leftX + liq.rightX) / 2 + 2}
                        y2={liq.surfY + 9}
                        stroke="#5a2a10"
                        strokeWidth="2"
                        strokeLinecap="round"
                      />
                      <line
                        x1={liq.rightX - 22}
                        y1={liq.surfY + 1}
                        x2={liq.rightX - 16}
                        y2={liq.surfY + 7}
                        stroke="#5a2a10"
                        strokeWidth="2"
                        strokeLinecap="round"
                      />
                    </>
                  )}
                </g>
              )}

              {!isBeverage && temp === "iced" && isDrinking && liq && (
                <g clipPath="url(#cupClip)" filter="url(#iceShadow)">
                  {ICE_CONFIGS.slice(0, visibleIce).map((cfg, i) => (
                    <IceCube key={i} cfg={cfg} liq={liq} fill={fill} />
                  ))}
                </g>
              )}

              <rect
                x={CUP.wallLeft - 1}
                y={CUP.wallTop - 2}
                width={CUP.wallRight - CUP.wallLeft + 2}
                height={10}
                rx="3"
                ry="3"
                fill="#f0ebe4"
                stroke="#c8bfb5"
                strokeWidth="1.2"
              />
              <path
                d={handlePath}
                fill="none"
                stroke="#c8bfb5"
                strokeWidth="10"
                strokeLinecap="round"
              />
              <path
                d={handlePath}
                fill="none"
                stroke="#f0ebe4"
                strokeWidth="7"
                strokeLinecap="round"
              />
              <line
                x1={tl.x + 10}
                y1={tl.y + 8}
                x2={bl.x + 8}
                y2={bl.y - 10}
                stroke="rgba(255,255,255,0.35)"
                strokeWidth="5"
                strokeLinecap="round"
              />
              {isDrinking && (
                <text
                  x={CUP.vw - 8}
                  y={CUP.vh - 8}
                  textAnchor="end"
                  fontSize="11"
                  fill="#9ca3af"
                  fontFamily="monospace"
                >
                  {level}%
                </text>
              )}
            </svg>
          </div>
        )}

        <div className="flex flex-col">
          {!isDessert && (
            <div className="cafe-progress-track">
              <div
                style={{
                  height: "100%",
                  width: `${level}%`,
                  background: isBeverage
                    ? "linear-gradient(90deg, #f472b6, #db2777)"
                    : temp === "hot"
                    ? "linear-gradient(90deg, #f97316, #c2410c)"
                    : "linear-gradient(90deg, #38bdf8, #0284c7)",
                  borderRadius: "999px",
                  transition: "width 0.3s ease",
                }}
              />
            </div>
          )}

          {/* CONTROL BUTTONS */}
          <div className="flex flex-row gap-2 items-stretch">
            <button
              onClick={handleStart}
              disabled={isDrinking}
              className="btn-brand"
            >
              {isDessert ? getLabel("cafeDessertStart") : getLabel("cafeStart")}
            </button>
            <button
              onClick={handleSip}
              disabled={
                !isDrinking || level <= 0 || (isDessert && biteCooldown)
              }
              className="btn-base"
              style={{
                background:
                  !isDrinking || level <= 0 || (isDessert && biteCooldown)
                    ? "#d1d5db"
                    : isDessert
                    ? currentDrink?.accent
                    : isBeverage
                    ? currentDrink?.color
                    : temp === "hot"
                    ? currentDrink?.hotColor
                    : currentDrink?.icedColor,
                boxShadow:
                  !isDrinking || level <= 0
                    ? "none"
                    : "0 2px 6px rgba(0,0,0,0.15)",
              }}
            >
              {isDessert ? getLabel("cafeDessertBite") : getLabel("cafeSip")}
            </button>
            <button
              onClick={handleEnd}
              disabled={!isDrinking}
              className="btn-danger"
            >
              {getLabel("cafeEnd")}
            </button>
          </div>
        </div>
      </div>

      {statusText && <p className="cafe-status-text my-1">{statusText}</p>}
    </div>
  );
});

export default CoffeeArea;
