import React, { useMemo } from "react";
import dynamic from "next/dynamic";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

const Lottie = dynamic(() => import("lottie-react"), { ssr: false });

export default function LottiePlayer({
  jsonString,
  width,
  height,
  opacityValue = 1.0,
  loop = true,
  autoplay = true,
}) {
  // 문자열 → 객체 변환 (잘못된 JSON일 경우 대비)
  const animationData = useMemo(() => {
    try {
      return JSON.parse(jsonString);
    } catch (e) {
      console.error("Invalid JSON string:", e);
      return null;
    }
  }, [jsonString]);

  if (!animationData) {
    return (
      <div style={{ color: "red" }}>{L("lottieInvalidData")}</div>
    );
  }

  return (
    <div style={{ opacity: opacityValue }}>
      <Lottie
        animationData={animationData}
        loop={loop}
        autoplay={autoplay}
        style={{ width, height }}
      />
    </div>
  );
}
