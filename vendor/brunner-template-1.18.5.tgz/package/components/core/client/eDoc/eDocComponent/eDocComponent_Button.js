"use strict";

import React, { useState } from "react";
import * as constants from "@/lib/constants";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import * as userInfo from "@/components/core/client/frames/userInfo";
import * as commonFunctions from "@/lib/commonFunctions";
import { Button } from "antd";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

const ACTION_TYPE = {
  REST_API: "REST_API",
  NAVIGATE: "NAVIGATE",
};

// =======================
// binding 치환 유틸
// =======================
const resolveBindingInObject = (obj, documentData) => {
  if (obj == null) return obj;

  if (typeof obj === "string") {
    const match = obj.match(/^#\{(.+?)\}$/);
    if (match) {
      const key = match[1];
      return commonFunctions.getDocumentBindingValue(documentData, key);
    }
    return obj;
  }

  if (Array.isArray(obj)) {
    return obj.map((item) => resolveBindingInObject(item, documentData));
  }

  if (typeof obj === "object") {
    const result = {};
    for (const k in obj) {
      result[k] = resolveBindingInObject(obj[k], documentData);
    }
    return result;
  }

  return obj;
};

const safeParseWithBinding = (text, documentData) => {
  if (!text) return {};

  try {
    const parsed = JSON.parse(text);
    return resolveBindingInObject(parsed, documentData);
  } catch {
    throw new Error(L("eDocJsonFormatError"));
  }
};

// =======================
// RUNTIME BINDING
// =======================
export const getBindingValue = (component) => {
  if (!component.runtime_data?.bindingKey) return null;
  return component.runtime_data?.items || null;
};

export const setBindingValue = (component, value, setBindingData) => {
  const key = component.runtime_data?.bindingKey;
  if (!key) return;

  setBindingData((prev) => ({
    ...prev,
    [key]: value,
  }));
};

// =======================
// COMPONENT
// =======================
const RenderComponent = (props) => {
  const {
    component,
    documentData,
    setBindingData, // ✅ 추가 (핵심)
    handleComponentClick,
    selectedClass,
    alignmentClass,
    isDesignMode,
  } = props;

  const { BrunnerMessageBox, openOkModal } = useModal();
  const [loading, setLoading] = useState(false);

  const { buttonText, buttonColor, textColor, padding, borderRadius } =
    component.runtime_data || {};

  const style = {
    backgroundColor: buttonColor || "#4F46E5",
    color: textColor || "#FFFFFF",
    padding: padding || "10px 20px",
    border: "none",
    borderRadius: borderRadius || "6px",
  };

  const handleClick = async (comp) => {
    const data = comp.runtime_data || {};
    let result;

    try {
      setLoading(true);

      // ================= REST API =================
      if (data.actionType === ACTION_TYPE.REST_API) {
        const headers = safeParseWithBinding(data.apiHeaders, documentData);
        const body = safeParseWithBinding(data.apiBody, documentData);

        const res = await fetch(data.apiUrl, {
          method: data.apiMethod || "GET",
          headers: {
            "Content-Type": "application/json",
            ...headers,
          },
          body: data.apiMethod !== "GET" ? JSON.stringify(body) : undefined,
        });

        result = await res.json().catch(() => null);

        // 필요하면 여기도 동일하게 binding 연결 가능
        if (component.runtime_data?.bindingKey) {
          const key = component.runtime_data.bindingKey;

          setBindingData((prev) => ({
            ...prev,
            [key]: result,
          }));
        }
      }

      // ================= NAVIGATE =================
      else if (data.actionType === ACTION_TYPE.NAVIGATE) {
        if (!data.navigateUrl) {
          await openOkModal(L("eDocNoUrl"), constants.messageCategory.Error);
          return;
        }

        if (data.navigateUrl.startsWith("/")) {
          window.location.href = data.navigateUrl;
        } else {
          window.open(data.navigateUrl, data.navigateTarget || "_self");
        }
      }
    } catch (e) {
      await openOkModal(
        `${commonFunctions.getResourceByLanguage(
          `FAILED_TO_EXECUTE`,
          constants.resourceType.message,
          userInfo.getCurrentLanguageCode(),
        )}\n ${e.message}`,
        constants.messageCategory.Exception,
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <BrunnerMessageBox />
      <Button
        loading={loading}
        className={`${selectedClass} ${alignmentClass}`}
        style={style}
        onClick={(e) => {
          e.stopPropagation();

          if (isDesignMode) {
            handleComponentClick(e);
          } else {
            handleClick(component);
          }
        }}
      >
        {buttonText || L("eDocDefaultButtonText")}
      </Button>
    </>
  );
};

// =======================
// ✅ DEFAULT
// =======================
export const initDefaultRuntimeData = (defaultRuntimeData) => {
  return {
    ...defaultRuntimeData,
    buttonText: L("eDocDefaultButtonText"),
    buttonColor: "#4F46E5",
    textColor: "#FFFFFF",
    padding: "10px 20px",
    borderRadius: "6px",
    actionType: ACTION_TYPE.REST_API,

    bindingKey: "",
    apiUrl: "",
    apiMethod: "GET",
    apiHeaders: "",
    apiBody: "",

    navigateUrl: "",
    navigateTarget: "_self",
  };
};

// =======================
// ✅ PROPERTY UI
// =======================
export function renderProperty(
  component,
  updateRuntimeData,
  renderWidthProperty,
  renderForceNewLineProperty,
  renderPositionAlignProperty,
) {
  const data = component.runtime_data || {};

  return (
    <div>
      <label>Binding Key</label>
      <input
        value={data.bindingKey || ""}
        onChange={(e) => updateRuntimeData("bindingKey", e.target.value)}
        className="w-full border p-2 mb-2"
        placeholder={L("eDocBindingKeyPlaceholder")}
      />

      <label>{L("eDocButtonTextLabel")}</label>
      <input
        value={data.buttonText || ""}
        onChange={(e) => updateRuntimeData("buttonText", e.target.value)}
        className="w-full border p-2 mb-2"
      />

      <label>Action Type</label>
      <select
        value={data.actionType}
        onChange={(e) => updateRuntimeData("actionType", e.target.value)}
        className="w-full border p-2 mb-2"
      >
        <option value="REST_API">REST API</option>
        <option value="NAVIGATE">Navigate</option>
      </select>

      {data.actionType === "REST_API" && (
        <>
          {/* 🔥 공통 가이드 */}
          <BindingGuide />

          <input
            placeholder="https://api.example.com"
            value={data.apiUrl || ""}
            onChange={(e) => updateRuntimeData("apiUrl", e.target.value)}
            className="w-full border p-2 mb-2"
          />

          <select
            value={data.apiMethod || "GET"}
            onChange={(e) => updateRuntimeData("apiMethod", e.target.value)}
            className="w-full border p-2 mb-2"
          >
            <option>GET</option>
            <option>POST</option>
            <option>PUT</option>
            <option>DELETE</option>
          </select>

          {/* ================= HEADER ================= */}
          <label>Header</label>
          <textarea
            placeholder={`{
  "Authorization": "Bearer TOKEN",
  "Content-Type": "application/json",
  "X-USER-ID": "#{user_id}"
}`}
            value={data.apiHeaders || ""}
            onChange={(e) => updateRuntimeData("apiHeaders", e.target.value)}
            className="w-full border p-2 mb-1"
            rows={4}
          />

          {/* ================= BODY ================= */}
          <label>Body</label>
          <textarea
            placeholder={`{
  "orderNo": "#{order_no}",
  "qty": "#{qty}",
  "remark": "테스트 주문"
}`}
            value={data.apiBody || ""}
            onChange={(e) => updateRuntimeData("apiBody", e.target.value)}
            className="w-full border p-2 mb-1"
            rows={5}
          />
        </>
      )}

      {data.actionType === "NAVIGATE" && (
        <>
          <input
            value={data.navigateUrl || ""}
            onChange={(e) => updateRuntimeData("navigateUrl", e.target.value)}
            className="w-full border p-2 mb-2"
          />

          <select
            value={data.navigateTarget || "_self"}
            onChange={(e) =>
              updateRuntimeData("navigateTarget", e.target.value)
            }
            className="w-full border p-2 mb-2"
          >
            <option value="_self">Current Tab</option>
            <option value="_blank">New Tab</option>
          </select>
        </>
      )}

      {renderWidthProperty()}
      {renderForceNewLineProperty()}
      {renderPositionAlignProperty()}
    </div>
  );
}

const BindingGuide = () => {
  return (
    <div className="text-xs text-gray-600 bg-blue-50 border border-blue-200 p-3 rounded mb-3">
      <label>Binding Guide</label>
      <textarea
        value={commonFunctions.getResourceByLanguage(
          "BINDING_GUIDE",
          constants.resourceType.message,
          userInfo.getCurrentLanguageCode(),
        )}
        readOnly
        className="w-full border p-2 mb-2 text-xs bg-gray-50"
        rows={8}
      />
    </div>
  );
};

export default RenderComponent;
