"use strict";

import React, { useState, useEffect } from "react";
import EDocTextStyleEditor from "@/components/core/client/eDoc/eDocTextStyleEditor";
import { Select } from "antd";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

export const initDefaultRuntimeData = (defaultRuntimeData) => {
  defaultRuntimeData.placeholder = L("eDocDefaultInputPlaceholder");
  defaultRuntimeData.textAlign = "left";
  defaultRuntimeData.positionAlign = "left";

  // font 관련 기본 설정
  defaultRuntimeData.fontFamily = "Arial";
  defaultRuntimeData.fontSize = 12;
  defaultRuntimeData.underline = false;
  defaultRuntimeData.fontColor = "#000000";
  defaultRuntimeData.backgroundColor = "#ffffff";
  defaultRuntimeData.fontWeight = "normal";

  // 입력 가능 여부 (기본값: true)
  defaultRuntimeData.editable = true;

  return defaultRuntimeData;
};

export const getBindingValue = (component) => {
  if (!component.runtime_data?.bindingKey) {
    return null;
  }
  return component.runtime_data?.value || null;
};

export const setBindingValue = (component, value, updateRuntimeData) => {
  if (!component.runtime_data?.bindingKey) return;

  updateRuntimeData("value", value);
};

export const getNewRuntimeData = (component, { key, value }) => {
  return {
    ...(component.runtime_data || {}),
    [key]: value,
  };
};

export function renderProperty(
  component,
  updateRuntimeData,
  renderWidthProperty,
  renderForceNewLineProperty,
  renderPositionAlignProperty,
) {
  const renderComponentProperty = (component) => {
    return (
      <div>
        <label>Binding Key:</label>
        <input
          type="text"
          value={component.runtime_data?.bindingKey || constants.emptyString}
          onChange={(e) => updateRuntimeData("bindingKey", e.target.value)}
          className="w-full border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
        />

        <label>{L("eDocInputValueLabel")}</label>
        <input
          type="text"
          value={component.runtime_data?.value || constants.emptyString}
          onChange={(e) => updateRuntimeData("value", e.target.value)}
          className="w-full border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
        />

        <label>{L("eDocContentAlign")}</label>
        <Select
          value={component.runtime_data?.textAlign || "left"}
          onChange={(e) => updateRuntimeData("textAlign", e.target.value)}
          className="w-full h-12 border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
        >
          <option value="left">{L("eDocAlignLeft")}</option>
          <option value="center">{L("eDocAlignCenter")}</option>
          <option value="right">{L("eDocAlignRight")}</option>
        </Select>

        {/* 입력 가능 여부 */}
        <label className="inline-flex items-center mb-2">
          <input
            type="checkbox"
            checked={component.runtime_data?.editable ?? true}
            onChange={(e) => updateRuntimeData("editable", e.target.checked)}
            className="mr-2"
          />
          {L("eDocEditable")}
        </label>

        {renderWidthProperty()}
        {renderForceNewLineProperty()}
        {renderPositionAlignProperty()}

        <EDocTextStyleEditor
          fontFamily={component.runtime_data?.fontFamily || "Arial"}
          fontSize={component.runtime_data?.fontSize || 12}
          fontWeight={component.runtime_data?.fontWeight || "normal"}
          underline={component.runtime_data?.underline || false}
          fontColor={component.runtime_data?.fontColor || "#000000"}
          backgroundColor={component.runtime_data?.backgroundColor || "#ffffff"}
          onChange={(updatedProps) => {
            Object.entries(updatedProps).forEach(([key, value]) => {
              updateRuntimeData(key, value);
            });
          }}
        />
      </div>
    );
  };

  return renderComponentProperty(component);
}

export default function RenderComponent(props) {
  const {
    documentData,
    pageData,
    component,
    handleComponentClick,
    onRuntimeDataChange,
    selectedClass,
    alignmentClass,
    textAlign,
    isDesignMode,
  } = props;

  const isEditable = component.runtime_data?.editable ?? true;

  const style = {
    width: "100%",
    height: component.runtime_data?.height || "auto",
    textAlign,
    fontFamily: component.runtime_data?.fontFamily || "Arial",
    fontSize: component.runtime_data?.fontSize
      ? `${component.runtime_data.fontSize}px`
      : "14px",
    fontWeight: component.runtime_data?.fontWeight || "normal",
    color: component.runtime_data?.fontColor || "#000000",
    backgroundColor: component.runtime_data?.backgroundColor || "transparent",
    cursor: isEditable ? "text" : "default",
  };

  const [localValue, setLocalValue] = useState(
    component.runtime_data?.value || "",
  );

  useEffect(() => {
    setLocalValue(component.runtime_data?.value || "");
  }, [component.runtime_data?.value]);

  return (
    <input
      type="text"
      className={`${selectedClass} ${alignmentClass} h-8 ${
        isEditable ? "cursor-text" : "cursor-default"
      } ${!isEditable ? "bg-gray-100" : constants.emptyString}`}
      style={style}
      value={localValue}
      placeholder={component.runtime_data?.placeholder || constants.emptyString}
      readOnly={!isEditable}
      onClick={handleComponentClick}
      onChange={(e) => {
        if (!isEditable) return;

        const v = e.target.value;

        // 1. 즉시 UI 반영
        setLocalValue(v);

        // 2. 상위 상태 반영
        onRuntimeDataChange({
          runtime_data: {
            ...component.runtime_data,
            value: v,
          },
        });
      }}
    />
  );
}
