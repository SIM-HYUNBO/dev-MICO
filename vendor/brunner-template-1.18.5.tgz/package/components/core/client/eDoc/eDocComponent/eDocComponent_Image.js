import React from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

export const initDefaultRuntimeData = (defaultRuntimeData) => {
  defaultRuntimeData.src = constants.emptyString;
  defaultRuntimeData.positionAlign = "center"; // 기본 정렬은 중앙

  // font 관련 기본 설정
  defaultRuntimeData.fontFamily = "Arial";
  defaultRuntimeData.fontSize = 12;
  defaultRuntimeData.underline = false;
  defaultRuntimeData.fontColor = "#000000";
  defaultRuntimeData.backgroundColor = "#ffffff";
  defaultRuntimeData.fontWeight = "normal";

  return defaultRuntimeData;
};

export const getBindingValue = (component) => {
  if (!component.runtime_data?.bindingKey) {
    return null;
  }
  // 이미지 컴포넌트는 src 속성을 사용하므로, bindingKey와
  // runtime_data.src를 통해 이미지 URL을 가져옵니다.
  return component.runtime_data?.src || null;
};

export const setBindingValue = (component, value, updateRuntimeData) => {
  if (!component.runtime_data?.bindingKey) return;

  updateRuntimeData("src", value);
};

export const getNewRuntimeData = (component, { key, value }) => {
  return {
    ...(component.runtime_data || {}),
    [key]: value,
  };
};

export function renderProperty(
  component,
  updateRuntimeData,
  renderWidthProperty,
  renderForceNewLineProperty,
  renderPositionAlignProperty,
) {
  const renderComponentProperty = (component) => {
    const handleFileChange = (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onloadend = () => {
        updateRuntimeData("src", reader.result); // Base64 저장!
      };
      reader.readAsDataURL(file);
    };

    return (
      <div>
        <label className="block mb-1">Binding Key:</label>
        <input
          type="text"
          value={component.runtime_data?.bindingKey || constants.emptyString}
          onChange={(e) => updateRuntimeData("bindingKey", e.target.value)}
          className="w-full border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
        />

        <label className="block mb-1">{L("eDocImageUrlLabel")}</label>
        <input
          type="text"
          value={component.runtime_data?.src || constants.emptyString}
          readOnly // 👉 직접 입력 불가!
          placeholder={L("eDocImageAutoFillPlaceholder")}
          className="w-full border border-gray-300 dark:border-gray-600 rounded p-2 mb-2 bg-gray-100 cursor-not-allowed"
        />

        <label className="block mb-1">{L("eDocImageLocalSelectLabel")}</label>
        <input
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="w-full mb-4"
        />

        {renderWidthProperty()}
        {renderForceNewLineProperty()}
        {renderPositionAlignProperty()}
      </div>
    );
  };
  return renderComponentProperty(component);
}

export default function RenderComponent(props) {
  const {
    documentData,
    pageData,
    component,
    handleComponentClick,
    onRuntimeDataChange,
    selectedClass,
    alignmentClass,
    textAlign,
    isDesignMode,
  } = props;

  const style = {
    width: "100%",
    height: component.runtime_data?.height || "auto",
    textAlign: component.runtime_data?.positionAlign, // 텍스트 정렬 적용
  };

  return (
    <div
      className={`${selectedClass} ${alignmentClass} cursor-pointer inline-block`}
      onClick={handleComponentClick}
      style={{
        width: `100%`,
      }}
    >
      {component.runtime_data?.src ? (
        <img
          src={component.runtime_data.src}
          alt={L("eDocImageAlt")}
          className="inline-block h-auto"
          style={style}
        />
      ) : (
        <div className="w-full h-24 bg-gray-200 flex items-center justify-center text-gray-500">
          {L("eDocImageNone")}
        </div>
      )}
    </div>
  );
}
