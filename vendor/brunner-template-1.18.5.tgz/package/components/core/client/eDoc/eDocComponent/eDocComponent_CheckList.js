import React from "react";
import EDocTextStyleEditor from "@/components/core/client/eDoc/eDocTextStyleEditor";
import { Input, Button, Select, Table } from "antd";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

export const initDefaultRuntimeData = (defaultRuntimeData) => {
  defaultRuntimeData.itemCount = 3;
  defaultRuntimeData.items = Array.from({ length: 3 }, (_, i) => ({
    label: `${L("eDocChecklistItemPrefix")} ${i + 1}`,
    checked: false,
  }));
  defaultRuntimeData.positionAlign = "left";

  // font 관련 기본 설정
  defaultRuntimeData.fontFamily = "Arial";
  defaultRuntimeData.fontSize = 12;
  defaultRuntimeData.underline = false;
  defaultRuntimeData.fontColor = "#000000";
  defaultRuntimeData.backgroundColor = "#ffffff";
  defaultRuntimeData.fontWeight = "normal";

  // 실행(뷰어)모드에서 사용자가 체크/해제할 수 있는지 (기본값: true)
  defaultRuntimeData.editable = true;

  return defaultRuntimeData;
};

export const getBindingValue = (component) => {
  if (!component.runtime_data?.bindingKey) {
    return null;
  }
  return component.runtime_data?.items || null;
};

export const setBindingValue = (component, value, updateRuntimeData) => {
  if (!component.runtime_data?.bindingKey) return;

  updateRuntimeData("items", value);
};

export const getNewRuntimeData = (component, newData) => {
  const currentData = component.runtime_data || {};
  let newRuntimeData = { ...currentData };
  const [itemIdx, checked] = newData;
  const items = [...(currentData.items || [])];

  if (items[itemIdx]) {
    items[itemIdx] = { ...items[itemIdx], checked };
    newRuntimeData.items = items;
  }
  return newRuntimeData;
};

export function renderProperty(
  component,
  updateRuntimeData,
  renderWidthProperty,
  renderForceNewLineProperty,
  renderPositionAlignProperty,
) {
  const renderComponentProperty = (component) => {
    const items = component.runtime_data?.items || [];
    const updateItemLabel = (idx, newLabel) => {
      const newItems = items.map((item, i) =>
        i === idx ? { ...item, label: newLabel } : item,
      );
      updateRuntimeData("items", newItems);
    };
    const toggleItemChecked = (idx) => {
      const newItems = items.map((item, i) =>
        i === idx ? { ...item, checked: !item.checked } : item,
      );
      updateRuntimeData("items", newItems);
    };
    const addItem = () => {
      const newItems = [
        ...items,
        { label: `${L("eDocChecklistItemPrefix")} ${items.length + 1}`, checked: false },
      ];
      updateRuntimeData("items", newItems);
    };
    const removeItem = (idx) => {
      const newItems = items.filter((_, i) => i !== idx);
      updateRuntimeData("items", newItems);
    };

    return (
      <div>
        <label>Binding Key:</label>
        <input
          type="text"
          value={component.runtime_data?.bindingKey || constants.emptyString}
          onChange={(e) => updateRuntimeData("bindingKey", e.target.value)}
          className="w-full border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
        />

        <label className="block mb-2">{L("eDocChecklistItemsLabel")}</label>
        {items.map((item, idx) => (
          <div key={idx} className="flex items-center mb-1 gap-2">
            <input
              type="checkbox"
              checked={item.checked}
              onChange={() => toggleItemChecked(idx)}
            />
            <input
              type="text"
              value={item.label}
              onChange={(e) => updateItemLabel(idx, e.target.value)}
              className="border border-gray-300 dark:border-gray-600 rounded p-1 flex-grow"
            />
            <Button
              onClick={() => removeItem(idx)}
              className="px-2 rounded"
              style={{ backgroundColor: "var(--danger)", color: "#fff", borderColor: "transparent" }}
              title={L("eDocChecklistDeleteItem")}
              type="button"
            >
              ×
            </Button>
          </div>
        ))}
        <Button
          onClick={addItem}
          className="mt-2 rounded px-4 py-1"
          style={{ backgroundColor: "var(--brand-blue)", color: "#fff", borderColor: "transparent" }}
          type="button"
        >
          {L("eDocChecklistAddItem")}
        </Button>

        {/* 실행모드에서 사용자 체크 허용 여부 */}
        <label className="flex items-center mt-3 mb-2">
          <input
            type="checkbox"
            checked={component.runtime_data?.editable ?? true}
            onChange={(e) => updateRuntimeData("editable", e.target.checked)}
            className="mr-2"
          />
          {L("eDocEditable")}
        </label>

        {renderWidthProperty()}
        {renderForceNewLineProperty()}
        {renderPositionAlignProperty()}

        <EDocTextStyleEditor
          fontFamily={component.runtime_data?.fontFamily || "Arial"}
          fontSize={component.runtime_data?.fontSize || 12}
          fontWeight={component.runtime_data?.fontWeight || "normal"}
          underline={component.runtime_data?.underline || false}
          fontColor={component.runtime_data?.fontColor || "#000000"}
          backgroundColor={component.runtime_data?.backgroundColor || "#ffffff"}
          onChange={(updatedProps) => {
            Object.entries(updatedProps).forEach(([key, value]) => {
              updateRuntimeData(key, value);
            });
          }}
        />

        <label>{L("eDocContentAlign")}</label>
        <Select
          value={component.runtime_data?.textAlign || "left"}
          onChange={(value) => updateRuntimeData("textAlign", value)}
          className="w-full h-12 border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
        >
          <option value="left">{L("eDocAlignLeft")}</option>
          <option value="center">{L("eDocAlignCenter")}</option>
          <option value="right">{L("eDocAlignRight")}</option>
        </Select>
      </div>
    );
  };

  return renderComponentProperty(component);
}

export default function RenderComponent(props) {
  const {
    documentData,
    pageData,
    component,
    handleComponentClick,
    onRuntimeDataChange,
    selectedClass,
    alignmentClass,
    textAlign,
    isDesignMode,
  } = props;

  const style = {
    width: "100%",
    height: component.runtime_data?.height || "auto",
    textAlign, // 외부에서 전달되는 textAlign
    fontFamily: component.runtime_data?.fontFamily || "inherit",
    fontSize: component.runtime_data?.fontSize
      ? `${component.runtime_data.fontSize}px`
      : "inherit",
    fontWeight: component.runtime_data?.fontWeight || "normal",
    color: component.runtime_data?.fontColor || "#000000",
    backgroundColor: component.runtime_data?.backgroundColor || "transparent",
    textDecoration: component.runtime_data?.underline ? "underline" : "none",
  };

  const justifyMap = {
    left: "flex-start",
    center: "center",
    right: "flex-end",
  };

  const justifyContent =
    justifyMap[component.runtime_data?.textAlign || "left"];

  // 실행모드 + editable일 때만 사용자가 체크 가능. 디자인모드에선 클릭이 컴포넌트 선택으로 간다.
  const isEditable = component.runtime_data?.editable ?? true;
  const interactive = !isDesignMode && isEditable;
  const toggleChecked = (idx) => {
    const items = (component.runtime_data?.items || []).map((it, i) =>
      i === idx ? { ...it, checked: !it.checked } : it,
    );
    onRuntimeDataChange({ runtime_data: { ...component.runtime_data, items } });
  };

  return (
    <div
      className={`${selectedClass} ${alignmentClass} border p-2 cursor-pointer flex flex-col`}
      style={{
        ...style,
        justifyContent,
        alignItems: justifyContent,
      }}
      onClick={handleComponentClick}
    >
      {(component.runtime_data?.items || []).map((item, idx) => (
        <label
          key={idx}
          className="flex items-center space-x-2 mb-1"
          style={{
            justifyContent,
            fontFamily: style.fontFamily,
            fontSize: style.fontSize,
            fontWeight: style.fontWeight,
            color: style.color,
            textDecoration: style.textDecoration,
          }}
        >
          <input
            type="checkbox"
            checked={!!item.checked}
            onChange={() => { if (interactive) toggleChecked(idx); }}
            onClick={(e) => { if (interactive) e.stopPropagation(); }}
            style={{ cursor: interactive ? "pointer" : "default" }}
          />
          <span
            style={{
              fontFamily: style.fontFamily,
              fontSize: style.fontSize,
              fontWeight: style.fontWeight,
              color: style.color,
              textDecoration: style.textDecoration,
            }}
          >
            {item.label || `${L("eDocChecklistItemPrefix")} ${idx + 1}`}
          </span>
        </label>
      ))}
    </div>
  );
}
