"use strict";

import React, { useMemo } from "react";
import dynamic from "next/dynamic";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

const Lottie = dynamic(() => import("lottie-react"), { ssr: false });

export const initDefaultRuntimeData = (defaultRuntimeData) => {
  defaultRuntimeData.jsonString = constants.emptyString;
  defaultRuntimeData.positionAlign = "center";
  defaultRuntimeData.loop = true;
  defaultRuntimeData.autoplay = true;
  defaultRuntimeData.width = 200;
  defaultRuntimeData.height = 200;
  return defaultRuntimeData;
};

export const getBindingValue = (component) => {
  return component.runtime_data?.jsonString || null;
};

export const setBindingValue = (component, value, updateRuntimeData) => {
  if (!component.runtime_data?.bindingKey) return;

  updateRuntimeData("jsonString", value);
};

export const getNewRuntimeData = (component, { key, value }) => {
  return {
    ...(component.runtime_data || {}),
    [key]: value,
  };
};

export function renderProperty(
  component,
  updateRuntimeData,
  renderWidthProperty,
  renderForceNewLineProperty,
  renderPositionAlignProperty,
) {
  return (
    <div>
      <label className="block mb-1">Binding Key:</label>
      <input
        type="text"
        value={component.runtime_data?.bindingKey || constants.emptyString}
        onChange={(e) => updateRuntimeData("bindingKey", e.target.value)}
        className="w-full border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
      />

      <label className="block mb-1">Lottie JSON:</label>
      <textarea
        value={component.runtime_data?.jsonString || constants.emptyString}
        onChange={(e) => updateRuntimeData("jsonString", e.target.value)}
        placeholder={L("eDocLottieJsonPlaceholder")}
        className="w-full border border-gray-300 dark:border-gray-600 rounded p-2 mb-4 h-32"
      />

      {renderWidthProperty()}
      {renderForceNewLineProperty()}
      {renderPositionAlignProperty()}
    </div>
  );
}

export default function RenderComponent({
  component,
  handleComponentClick,
  selectedClass,
  alignmentClass,
}) {
  const animationData = useMemo(() => {
    try {
      return JSON.parse(component.runtime_data?.jsonString || null);
    } catch (e) {
      console.error("Invalid Lottie JSON:", e);
      return null;
    }
  }, [component.runtime_data?.jsonString]);

  const style = {
    width: component.runtime_data?.width || 200,
    height: component.runtime_data?.height || 200,
    textAlign: component.runtime_data?.positionAlign,
  };

  return (
    <div
      className={`${selectedClass} ${alignmentClass} cursor-pointer inline-block`}
      onClick={handleComponentClick}
      style={{ width: "100%" }}
    >
      {animationData ? (
        <Lottie
          animationData={animationData}
          loop={component.runtime_data?.loop}
          autoplay={component.runtime_data?.autoplay}
          style={style}
        />
      ) : (
        <div className="w-full h-48 bg-gray-200 flex items-center justify-center text-gray-500">
          {L("eDocLottieNoneOrError")}
        </div>
      )}
    </div>
  );
}
