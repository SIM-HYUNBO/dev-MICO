"use strict";

import React from "react";
import EDocTextStyleEditor from "@/components/core/client/eDoc/eDocTextStyleEditor";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { Select } from "antd";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

/**
 * 데이터 구조 (통일):
 *   runtime_data.columns : [{ header, width, align }, ...]  ← 열 정의
 *   runtime_data.rows    : [["셀값", ...], ...]              ← 2차원 배열 (행×열)
 */

/* ───────────────────────────────────────────────
   초기 RuntimeData
─────────────────────────────────────────────── */
export const initDefaultRuntimeData = (defaultRuntimeData) => {
  defaultRuntimeData.columns = [
    { header: "Header1", width: "auto", align: "center" },
    { header: "Header2", width: "auto", align: "center" },
    { header: "Header3", width: "auto", align: "center" },
  ];
  defaultRuntimeData.rows = [
    ["", "", ""],
    ["", "", ""],
    ["", "", ""],
  ];
  defaultRuntimeData.positionAlign = "left";
  defaultRuntimeData.fontFamily = "Arial";
  defaultRuntimeData.fontSize = 12;
  defaultRuntimeData.underline = false;
  defaultRuntimeData.fontColor = "#000000";
  defaultRuntimeData.backgroundColor = "#ffffff";
  defaultRuntimeData.fontWeight = "normal";
  // 실행(뷰어)모드에서 사용자가 셀에 값을 입력할 수 있는지 (기본값: true). 디자인모드에선 항상 편집 가능.
  defaultRuntimeData.editable = true;
  return defaultRuntimeData;
};

/* ───────────────────────────────────────────────
   바인딩
─────────────────────────────────────────────── */
export const getBindingValue = (component) => {
  if (!component?.runtime_data?.bindingKey) return null;
  const { rows, columns } = component.runtime_data;
  if (!Array.isArray(rows) || !Array.isArray(columns)) return [];
  return rows.map((row) => {
    const rowObj = {};
    columns.forEach((col, idx) => {
      rowObj[col.header] = row[idx] ?? null;
    });
    return rowObj;
  });
};

export const setBindingValue = (component, value, updateRuntimeData) => {
  if (!component?.runtime_data?.bindingKey) return;
  if (!Array.isArray(value)) return;
  const { columns } = component.runtime_data;
  if (!Array.isArray(columns) || columns.length === 0) return;
  const nextRows = value.map((rowObj) =>
    columns.map((col) => {
      const key = col?.field || col?.header;
      return key ? (rowObj[key] ?? "") : "";
    }),
  );
  updateRuntimeData({ rows: nextRows });
};

/* ───────────────────────────────────────────────
   셀 값 변경
─────────────────────────────────────────────── */
export const getNewRuntimeData = (component, rowIdx, colIdx, newValue) => {
  const currentData = component.runtime_data || {};
  const oldRows = Array.isArray(currentData.rows) ? currentData.rows : [];
  const newRows = oldRows.map((row) => (Array.isArray(row) ? [...row] : []));
  if (newRows[rowIdx]) newRows[rowIdx][colIdx] = newValue;
  return { ...currentData, rows: newRows };
};

/* ───────────────────────────────────────────────
   헬퍼: 행/열 추가·삭제
─────────────────────────────────────────────── */
const addRow = (rd) => {
  const colCount = (rd.columns || []).length;
  return { ...rd, rows: [...(rd.rows || []), Array(colCount).fill("")] };
};

const deleteRow = (rd, rowIdx) => ({
  ...rd,
  rows: (rd.rows || []).filter((_, i) => i !== rowIdx),
});

const addColumn = (rd) => {
  const newCol = { header: `Header${(rd.columns || []).length + 1}`, width: "auto", align: "center" };
  return {
    ...rd,
    columns: [...(rd.columns || []), newCol],
    rows: (rd.rows || []).map((row) => [...row, ""]),
  };
};

const deleteColumn = (rd, colIdx) => ({
  ...rd,
  columns: (rd.columns || []).filter((_, i) => i !== colIdx),
  rows: (rd.rows || []).map((row) => row.filter((_, i) => i !== colIdx)),
});

/* ───────────────────────────────────────────────
   속성 편집 패널
─────────────────────────────────────────────── */
export function renderProperty(
  component,
  updateRuntimeData,
  renderWidthProperty,
  renderForceNewLineProperty,
  renderPositionAlignProperty,
) {
  const rd = component.runtime_data || {};

  return (
    <div>
      <label>Binding Key:</label>
      <input
        type="text"
        value={rd.bindingKey || ""}
        onChange={(e) => updateRuntimeData("bindingKey", e.target.value)}
        className="w-full border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
      />

      <label className="block mt-3 mb-1 font-semibold">{L("eDocTableColumnSettings")}</label>
      {(rd.columns || []).map((col, idx) => (
        <div key={idx} className="flex gap-1 mb-1 items-center">
          <input
            type="text"
            value={col.header || ""}
            onChange={(e) => {
              const newColumns = [...rd.columns];
              newColumns[idx] = { ...newColumns[idx], header: e.target.value };
              updateRuntimeData("columns", newColumns);
            }}
            className="flex-1 border border-gray-300 dark:border-gray-600 rounded p-1 text-xs"
            placeholder={`${L("eDocTableHeaderPlaceholder")} ${idx + 1}`}
          />
          <input
            type="text"
            value={col.width || ""}
            onChange={(e) => {
              const newColumns = [...rd.columns];
              newColumns[idx] = { ...newColumns[idx], width: e.target.value };
              updateRuntimeData("columns", newColumns);
            }}
            className="w-16 border border-gray-300 dark:border-gray-600 rounded p-1 text-xs"
            placeholder={L("eDocTableWidthPlaceholder")}
          />
          <Select
            value={col.align || "center"}
            onChange={(value) => {
              const newColumns = [...rd.columns];
              newColumns[idx] = { ...newColumns[idx], align: value };
              updateRuntimeData("columns", newColumns);
            }}
            size="small"
            className="w-20"
          >
            <Select.Option value="left">{L("eDocAlignLeft")}</Select.Option>
            <Select.Option value="center">{L("eDocAlignCenter")}</Select.Option>
            <Select.Option value="right">{L("eDocAlignRight")}</Select.Option>
          </Select>
        </div>
      ))}

      {/* 실행모드에서 사용자 셀 입력 허용 여부 */}
      <label className="flex items-center mt-3 mb-2">
        <input
          type="checkbox"
          checked={rd.editable ?? true}
          onChange={(e) => updateRuntimeData("editable", e.target.checked)}
          className="mr-2"
        />
        {L("eDocEditable")}
      </label>

      {renderWidthProperty()}
      {renderForceNewLineProperty()}
      {renderPositionAlignProperty()}

      <EDocTextStyleEditor
        fontFamily={rd.fontFamily || "Arial"}
        fontSize={rd.fontSize || 12}
        fontWeight={rd.fontWeight || "normal"}
        underline={rd.underline || false}
        fontColor={rd.fontColor || "#000000"}
        backgroundColor={rd.backgroundColor || "#ffffff"}
        onChange={(updatedProps) => {
          Object.entries(updatedProps).forEach(([key, value]) => {
            updateRuntimeData(key, value);
          });
        }}
      />
    </div>
  );
}

/* ───────────────────────────────────────────────
   컴포넌트 렌더링
─────────────────────────────────────────────── */
export default function RenderComponent(props) {
  const {
    component: comp,
    handleComponentClick,
    onRuntimeDataChange,
    selectedClass,
    alignmentClass,
    textAlign,
    isDesignMode,
  } = props;

  const rd = comp.runtime_data || {};
  const rows = Array.isArray(rd.rows) ? rd.rows : [];
  const columns = Array.isArray(rd.columns) ? rd.columns : [];
  // 디자인모드에선 항상 셀 편집(내용 작성), 실행모드에선 editable일 때만 사용자 입력 허용.
  const cellReadOnly = !isDesignMode && !(rd.editable ?? true);

  const style = {
    fontFamily: rd.fontFamily || "inherit",
    fontSize: rd.fontSize ? `${rd.fontSize}px` : "inherit",
    fontWeight: rd.fontWeight || "normal",
    color: rd.fontColor || "#000000",
    textDecoration: rd.underline ? "underline" : "none",
  };

  const updateRd = (newRd) =>
    onRuntimeDataChange({ ...comp, runtime_data: newRd });

  return (
    <div className={`${selectedClass} ${alignmentClass} w-full`} onClick={handleComponentClick}>
      {/* 넓은 표는 컨테이너 안에서 가로 스크롤 — 모바일/좁은 캔버스에서 열이 뭉개지지 않게 */}
      <div className="w-full overflow-x-auto">
      <table
        style={{ borderCollapse: "collapse", tableLayout: "auto", minWidth: "100%" }}
        className="border border-gray-400"
      >
        <colgroup>
          {columns.map((col, i) => (
            <col key={i} style={{ width: col.width || "auto" }} />
          ))}
          {/* 디자인 모드: 열 삭제 버튼 열 */}
          {isDesignMode && <col style={{ width: "28px" }} />}
        </colgroup>

        {/* 헤더 */}
        <thead>
          <tr>
            {columns.map((col, colIdx) => (
              <th
                key={colIdx}
                className="border border-gray-300 dark:border-gray-600 px-2 py-1 bg-gray-100"
                style={{ textAlign: col.align || "center", ...style }}
              >
                {isDesignMode ? (
                  <div className="flex items-center justify-between gap-1">
                    <span className="flex-1 text-center">{col.header}</span>
                    {columns.length > 1 && (
                      <button
                        onClick={(e) => { e.stopPropagation(); updateRd(deleteColumn(rd, colIdx)); }}
                        className="text-red-400 hover:text-red-600 text-xs leading-none"
                        title={L("eDocTableDeleteColumn")}
                      >✕</button>
                    )}
                  </div>
                ) : (
                  col.header
                )}
              </th>
            ))}
            {/* 열 추가 버튼 */}
            {isDesignMode && (
              <th className="border border-gray-300 dark:border-gray-600 bg-gray-50 px-1">
                <button
                  onClick={(e) => { e.stopPropagation(); updateRd(addColumn(rd)); }}
                  className="text-blue-500 hover:text-blue-700 font-bold text-sm w-full"
                  title={L("eDocTableAddColumn")}
                >+</button>
              </th>
            )}
          </tr>
        </thead>

        {/* 데이터 행 */}
        <tbody>
          {rows.map((row, rowIdx) => (
            <tr key={rowIdx} className="hover:bg-gray-50">
              {columns.map((col, colIdx) => (
                <td
                  key={colIdx}
                  className="border border-gray-300 dark:border-gray-600"
                  style={{ textAlign: col.align || "center", verticalAlign: "middle" }}
                >
                  {cellReadOnly ? (
                    // 읽기 전용일 때는 input 이 아니라 텍스트로 그린다.
                    // input 은 한 줄짜리라 내용이 길면 그냥 잘려서 읽을 수 없었다.
                    <div
                      className="w-full whitespace-pre-wrap break-words px-1 py-0.5"
                      style={{ ...style, textAlign: col.align || "center" }}
                    >
                      {row[colIdx] ?? ""}
                    </div>
                  ) : (
                    <input
                      type="text"
                      className="w-full border-none outline-none bg-transparent px-1 py-0.5"
                      style={{ ...style, textAlign: col.align || "center" }}
                      value={row[colIdx] ?? ""}
                      onChange={(e) =>
                        onRuntimeDataChange({
                          ...comp,
                          runtime_data: getNewRuntimeData(comp, rowIdx, colIdx, e.target.value),
                        })
                      }
                    />
                  )}
                </td>
              ))}
              {/* 행 삭제 버튼 */}
              {isDesignMode && (
                <td className="border border-gray-300 dark:border-gray-600 text-center px-1">
                  {rows.length > 1 && (
                    <button
                      onClick={(e) => { e.stopPropagation(); updateRd(deleteRow(rd, rowIdx)); }}
                      className="text-red-400 hover:text-red-600 text-xs"
                      title={L("eDocTableDeleteRow")}
                    >🗑</button>
                  )}
                </td>
              )}
            </tr>
          ))}

          {/* 행 추가 버튼 */}
          {isDesignMode && (
            <tr>
              <td
                colSpan={columns.length + 1}
                className="border border-gray-300 dark:border-gray-600 text-center py-1"
              >
                <button
                  onClick={(e) => { e.stopPropagation(); updateRd(addRow(rd)); }}
                  className="text-blue-500 hover:text-blue-700 text-xs font-bold w-full"
                  title={L("eDocTableAddRow")}
                >+ {L("eDocTableAddRow")}</button>
              </td>
            </tr>
          )}
        </tbody>
      </table>
      </div>
    </div>
  );
}
