"use client";

import React from "react";
import { Input, Select } from "antd";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

/* =========================
   1. 초기 RuntimeData
========================= */
export const initDefaultRuntimeData = (defaultRuntimeData) => {
  defaultRuntimeData.title = "Enterprise Operations Bench";
  defaultRuntimeData.description =
    "IBM Research · Research Benchmark\nEvaluates LLMs...";

  defaultRuntimeData.titleFontSize = 16;
  defaultRuntimeData.descriptionFontSize = 12;

  defaultRuntimeData.titleAlign = "left";
  defaultRuntimeData.descriptionAlign = "left";

  defaultRuntimeData.imageUrl = "";
  defaultRuntimeData.imageSize = 40;
  defaultRuntimeData.imagePosition = "우상";

  defaultRuntimeData.width = 300;
  defaultRuntimeData.height = 120;

  defaultRuntimeData.linkType = "internal";
  defaultRuntimeData.linkPageId = "";
  defaultRuntimeData.linkUrl = "";

  defaultRuntimeData.fontFamily = "Arial";
  defaultRuntimeData.fontWeight = "normal";
  defaultRuntimeData.fontColor = "#000000";
  defaultRuntimeData.backgroundColor = "#ffffff";

  return defaultRuntimeData;
};

/* =========================
   2. Binding
========================= */
export const getBindingValue = (component) => {
  return component.runtime_data || null;
};

export const setBindingValue = (component, value, updateRuntimeData) => {
  if (!component.runtime_data?.bindingKey) return;
  if (!value) return;

  // runtime_data 전체를 merge
  Object.entries(value).forEach(([key, val]) => {
    updateRuntimeData(key, val);
  });
};

export const getNewRuntimeData = (component, newData) => {
  return { ...component.runtime_data, ...newData };
};

/* =========================
   3. Property Editor
========================= */
export function renderProperty(
  component,
  updateRuntimeData,
  renderWidthProperty,
  renderForceNewLineProperty,
  renderPositionAlignProperty,
) {
  const rd = component.runtime_data || {};

  return (
    <div>
      <label>{L("eDocCardTitle")}</label>
      <Input
        value={rd.title}
        onChange={(e) => updateRuntimeData("title", e.target.value)}
        className="mb-2"
      />

      <label>{L("eDocCardTitleFontSize")}</label>
      <Input
        type="number"
        value={rd.titleFontSize}
        onChange={(e) =>
          updateRuntimeData("titleFontSize", Number(e.target.value))
        }
        className="mb-2"
      />

      <label>{L("eDocCardTitleAlign")}</label>
      <Select
        value={rd.titleAlign}
        onChange={(v) => updateRuntimeData("titleAlign", v)}
        className="w-full mb-2"
      >
        <Select.Option value="left">{L("eDocAlignLeft")}</Select.Option>
        <Select.Option value="center">{L("eDocAlignCenter")}</Select.Option>
        <Select.Option value="right">{L("eDocAlignRight")}</Select.Option>
      </Select>

      <label>{L("eDocCardContent")}</label>
      <Input.TextArea
        value={rd.description}
        onChange={(e) => updateRuntimeData("description", e.target.value)}
        className="mb-2"
      />

      <label>{L("eDocCardContentFontSize")}</label>
      <Input
        type="number"
        value={rd.descriptionFontSize}
        onChange={(e) =>
          updateRuntimeData("descriptionFontSize", Number(e.target.value))
        }
        className="mb-2"
      />

      <label>{L("eDocCardContentAlign")}</label>
      <Select
        value={rd.descriptionAlign}
        onChange={(v) => updateRuntimeData("descriptionAlign", v)}
        className="w-full mb-2"
      >
        <Select.Option value="left">{L("eDocAlignLeft")}</Select.Option>
        <Select.Option value="center">{L("eDocAlignCenter")}</Select.Option>
        <Select.Option value="right">{L("eDocAlignRight")}</Select.Option>
      </Select>

      <label>{L("eDocCardImageUrl")}</label>
      <Input
        value={rd.imageUrl}
        onChange={(e) => updateRuntimeData("imageUrl", e.target.value)}
        className="mb-2"
      />

      <label>{L("eDocCardImageSize")}</label>
      <Input
        type="number"
        value={rd.imageSize}
        onChange={(e) => updateRuntimeData("imageSize", Number(e.target.value))}
        className="mb-2"
      />

      <label>{L("eDocCardImagePosition")}</label>
      <Select
        value={rd.imagePosition}
        onChange={(v) => updateRuntimeData("imagePosition", v)}
        className="w-full mb-2"
      >
        <Select.Option value="좌상">{L("eDocPosTopLeft")}</Select.Option>
        <Select.Option value="우상">{L("eDocPosTopRight")}</Select.Option>
        <Select.Option value="좌하">{L("eDocPosBottomLeft")}</Select.Option>
        <Select.Option value="우하">{L("eDocPosBottomRight")}</Select.Option>
        <Select.Option value="좌중">{L("eDocPosMidLeft")}</Select.Option>
        <Select.Option value="우중">{L("eDocPosMidRight")}</Select.Option>
      </Select>

      <label>{L("eDocCardWidth")}</label>
      <Input
        type="number"
        value={rd.width}
        onChange={(e) => updateRuntimeData("width", Number(e.target.value))}
        className="mb-2"
      />

      <label>{L("eDocCardHeight")}</label>
      <Input
        type="number"
        value={rd.height}
        onChange={(e) => updateRuntimeData("height", Number(e.target.value))}
        className="mb-2"
      />

      <label>{L("eDocCardLinkType")}</label>
      <Select
        value={rd.linkType}
        onChange={(v) => updateRuntimeData("linkType", v)}
        className="w-full mb-2"
      >
        <Select.Option value="internal">{L("eDocCardLinkInternal")}</Select.Option>
        <Select.Option value="external">{L("eDocCardLinkExternal")}</Select.Option>
      </Select>

      {rd.linkType === "internal" && (
        <>
          <label>{L("eDocCardPageId")}</label>
          <Input
            value={rd.linkPageId}
            onChange={(e) => updateRuntimeData("linkPageId", e.target.value)}
            className="mb-2"
          />
        </>
      )}

      {rd.linkType === "external" && (
        <>
          <label>URL</label>
          <Input
            value={rd.linkUrl}
            onChange={(e) => updateRuntimeData("linkUrl", e.target.value)}
            className="mb-2"
          />
        </>
      )}

      {renderWidthProperty()}
      {renderForceNewLineProperty()}
      {renderPositionAlignProperty()}
    </div>
  );
}

/* =========================
   4. Render Component
========================= */
export default function RenderComponent(props) {
  const {
    component,
    handleComponentClick,
    selectedClass,
    alignmentClass,
    isDesignMode,
  } = props;

  const rd = component.runtime_data || {};

  const handleClick = (e) => {
    e.stopPropagation();

    if (isDesignMode) {
      handleComponentClick();
      return;
    }

    if (rd.linkType === "internal" && rd.linkPageId) {
      window.location.href = `/${rd.linkPageId}`;
    }

    if (rd.linkType === "external" && rd.linkUrl) {
      window.open(rd.linkUrl, "_blank");
    }
  };

  const isLeft = rd.imagePosition?.includes("좌");
  const isRight = rd.imagePosition?.includes("우");

  return (
    <div
      onClick={handleClick}
      className={`
        ${selectedClass}
        ${alignmentClass}
        general-text-bg-color
        border rounded-xl shadow-sm
        hover:shadow-md transition
        cursor-pointer
        flex gap-2 p-3
        ${isLeft ? "flex-row" : ""}
        ${isRight ? "flex-row-reverse" : ""}
        ${!isLeft && !isRight ? "flex-col" : ""}
      `}
      style={{
        width: rd.width,
        height: rd.height,
        minWidth: rd.width,
        maxWidth: rd.width,

        flex: "0 0 auto",
        alignSelf: "flex-start",

        backgroundColor: rd.backgroundColor,
        fontFamily: rd.fontFamily,
        color: rd.fontColor,
      }}
    >
      {/* 이미지 */}
      {rd.imageUrl && (
        <img
          src={rd.imageUrl}
          className="flex-shrink-0"
          style={{
            width: rd.imageSize,
            height: rd.imageSize,
            alignSelf: rd.imagePosition?.includes("중")
              ? "center"
              : rd.imagePosition?.includes("상")
              ? "flex-start"
              : "flex-end",
          }}
        />
      )}

      {/* 텍스트 */}
      <div className="flex flex-col justify-center overflow-hidden flex-1">
        <div
          className={`
            font-bold
            ${rd.titleAlign === "left" ? "text-left" : ""}
            ${rd.titleAlign === "center" ? "text-center" : ""}
            ${rd.titleAlign === "right" ? "text-right" : ""}
          `}
          style={{ fontSize: `${rd.titleFontSize}px` }}
        >
          {rd.title}
        </div>

        <div
          className={`
            mt-1 opacity-70 whitespace-pre-line
            ${rd.descriptionAlign === "left" ? "text-left" : ""}
            ${rd.descriptionAlign === "center" ? "text-center" : ""}
            ${rd.descriptionAlign === "right" ? "text-right" : ""}
          `}
          style={{ fontSize: `${rd.descriptionFontSize}px` }}
        >
          {rd.description}
        </div>
      </div>
    </div>
  );
}
