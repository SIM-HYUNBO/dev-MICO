import React from "react";

const TOKEN_RE = /(\*\*[^*\n][\s\S]*?[^*\n]\*\*|\*\*[^*\n]\*\*|\[([^\]\n]+)\]\((https?:\/\/[^)\s]+)\))/g;

export function renderInlineMarkdown(text, keyPrefix = "md") {
  const value = String(text ?? "");
  if (!value) return null;

  const nodes = [];
  let lastIndex = 0;
  let match;

  while ((match = TOKEN_RE.exec(value)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(value.slice(lastIndex, match.index));
    }

    const token = match[0];
    if (token.startsWith("**") && token.endsWith("**")) {
      const inner = token.slice(2, -2);
      nodes.push(
        <strong key={`${keyPrefix}-strong-${nodes.length}`} className="font-bold">
          {inner}
        </strong>,
      );
    } else if (match[2] && match[3]) {
      nodes.push(
        <a
          key={`${keyPrefix}-link-${nodes.length}`}
          href={match[3]}
          target="_blank"
          rel="noopener noreferrer"
          className="font-semibold text-[var(--brand-blue,#2563eb)] underline-offset-4 hover:underline"
        >
          {match[2]}
        </a>,
      );
    }

    lastIndex = TOKEN_RE.lastIndex;
  }

  if (lastIndex < value.length) {
    nodes.push(value.slice(lastIndex));
  }

  return nodes;
}
