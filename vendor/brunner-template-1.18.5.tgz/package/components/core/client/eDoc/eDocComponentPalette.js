import React from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { Input, Button, Table } from "antd";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

/*
 * EDocComponentPalette.js
 * 컴포넌트 템플릿을 보여주는 팔레트 컴포넌트
 */
export default function EDocComponentPalette({ templates, onAddComponent }) {
  if (!templates || templates.length === 0) {
    return <div>{L("eDocLoadingTemplates")}</div>;
  }

  return (
    <div className="flex flex-col justify-center items-center space-y-3 mr-1 min-w-20">
      <h5 className="flex mb-16 text-sm general-text-color">{L("eDocComponentsHeading")}</h5>
      {templates.map((template) => (
        <div
          key={template.id}
          draggable
          onDragStart={(e) => {
            e.dataTransfer.setData("edoc/palette", JSON.stringify(template));
            e.dataTransfer.effectAllowed = "copy";
          }}
          onClick={() => onAddComponent(template)}
          className="w-full cursor-grab active:cursor-grabbing"
        >
          <Button
            className="w-full text-center justify-center items-center rounded border border-gray-300 dark:border-gray-600 general-text-bg-color pointer-events-none"
          >
            {template.type}
          </Button>
        </div>
      ))}
    </div>
  );
}
