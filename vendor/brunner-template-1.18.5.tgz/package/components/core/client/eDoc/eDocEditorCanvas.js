"use strict";

import React, { useEffect, useRef, useState } from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import DocComponentRenderer from "@/components/core/client/eDoc/eDocComponentRenderer";
import { Input, Button, Table } from "antd";

export default function EDocEditorCanvas({
  documentData,
  pageData,
  isSelected,
  onSelect,
  selectedComponentId,
  onComponentSelect,
  onDeleteComponent,
  onMoveUp,
  onMoveDown,
  onUpdateComponent,
  isViewerMode = false,
  mode,
  copiedComponent,
  setCopiedComponent,
  pageId,
  setBindingData,
  scalable = false,
  onReorderComponent,    // (fromIdx, toIdx) 캔버스 내 순서 변경
  onDropPaletteItem,     // (template, insertIdx) 팔레트 → 캔버스 드롭
}) {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);
  const [scale, setScale] = useState(1);
  const [actualScaledHeight, setActualScaledHeight] = useState(null);
  const [dragOverIdx, setDragOverIdx] = useState(null); // 드래그 중 hover된 컴포넌트 idx
  useEffect(() => {
    const handleKeyDown = (e) => {
      // ESC: 선택 해제
      if (e.key === "Escape") {
        if (!isViewerMode && typeof onComponentSelect === "function") {
          onComponentSelect(null);
        }
        if (document.activeElement instanceof HTMLElement) {
          document.activeElement.blur();
        }
      }

      // Ctrl+C: 복사
      if (e.ctrlKey && e.key.toLowerCase() === "c") {
        if (!isViewerMode && selectedComponentId !== null) {
          const compToCopy = pageData.components[selectedComponentId];
          setCopiedComponent?.({ ...compToCopy });
          e.preventDefault();
        }
      }

      // Ctrl+V: 붙여넣기
      if (e.ctrlKey && e.key.toLowerCase() === "v") {
        if (!isViewerMode && copiedComponent) {
          const newComponent = {
            ...copiedComponent,
            id: `comp_${Date.now()}`, // 새 고유 id
            runtime_data: {
              ...copiedComponent.runtime_data,
              top: (copiedComponent.runtime_data?.top ?? 0) + 20,
              left: (copiedComponent.runtime_data?.left ?? 0) + 20,
            },
          };
          if (typeof onUpdateComponent === "function") {
            // 붙여넣는 페이지 ID도 전달
            onUpdateComponent(newComponent, "add", pageId);
          }
          e.preventDefault();
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [
    selectedComponentId,
    copiedComponent,
    isViewerMode,
    onComponentSelect,
    pageData.components,
    onUpdateComponent,
    pageId,
    setCopiedComponent,
  ]);

  function getPageDimensionsPx(pageSize) {
    switch (pageSize) {
      case "A3":
        return { width: 1123, height: 1587 };
      case "Letter":
        return { width: 816, height: 1056 };
      case "A4":
      default:
        return { width: 794, height: 1123 };
    }
  }

  const { width: pageWidthPx, height: pageHeightPx } = getPageDimensionsPx(
    pageData.runtime_data?.pageSize || "A4",
  );

  // 모바일 스케일링: 뷰포트 폭 기준으로 자동 축소
  // containerRef 자식(794px)이 부모 폭을 부풀리는 문제를 피하기 위해
  // window.innerWidth를 기준으로 scale 계산
  useEffect(() => {
    if (!scalable) return;
    const updateScale = () => {
      const availableWidth = containerRef.current?.offsetWidth ?? window.innerWidth;
      setScale(Math.min(1, availableWidth / pageWidthPx));
    };
    updateScale();
    window.addEventListener("resize", updateScale);
    return () => window.removeEventListener("resize", updateScale);
  }, [scalable, pageWidthPx]);

  // canvas 실제 높이를 측정해 container 높이를 동적으로 맞춤
  // (A4 넘는 콘텐츠가 overflow:hidden으로 잘리는 것 방지)
  useEffect(() => {
    if (!scalable || !canvasRef.current) return;
    const obs = new ResizeObserver(() => {
      if (canvasRef.current) {
        setActualScaledHeight(canvasRef.current.offsetHeight * scale);
      }
    });
    obs.observe(canvasRef.current);
    return () => obs.disconnect();
  }, [scalable, scale]);

  const updateRuntimeData = (componentIdx, newData) => {
    const component = pageData.components[componentIdx];
    const newRuntimeData = newData.runtime_data;

    const updatedComponent = {
      ...component,
      runtime_data: newRuntimeData,
    };

    if (typeof onUpdateComponent === "function") {
      onUpdateComponent(updatedComponent);
    }
  };

  const RenderComponents = () => {
    const comps =
      pageData.components.length > 0
        ? [
            {
              ...pageData.components[0],
              runtime_data: {
                ...pageData.components[0].runtime_data,
                forceNewLine: true, // 첫 번째 컴포넌트는 항상 새 줄 시작
              },
            },
            ...pageData.components.slice(1),
          ]
        : [];

    return (
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(12, 1fr)",
          gap: "8px",
          width: "100%",
        }}
      >
        {comps.map((comp, compIdx) => {
          const gridCol = comp.runtime_data?.gridCol ?? 12;
          const forceNewLine = comp.runtime_data?.forceNewLine ?? false;
          const gridColumn = forceNewLine
            ? `1 / span ${gridCol}`
            : `span ${gridCol}`;
          const isDragOver = dragOverIdx === compIdx;

          return (
            <div
              key={comp.id ?? compIdx}
              style={{ gridColumn }}
              // ── 드래그 이벤트 ──
              draggable={!isViewerMode && mode === "design"}
              onDragStart={(e) => {
                if (isViewerMode || mode !== "design") return;
                e.dataTransfer.setData("edoc/canvas-idx", compIdx.toString());
                e.dataTransfer.effectAllowed = "move";
              }}
              onDragOver={(e) => {
                if (isViewerMode || mode !== "design") return;
                e.preventDefault();
                e.stopPropagation();
                setDragOverIdx(compIdx);
              }}
              onDragLeave={() => setDragOverIdx(null)}
              onDrop={(e) => {
                if (isViewerMode || mode !== "design") return;
                e.stopPropagation();
                setDragOverIdx(null);
                const paletteData = e.dataTransfer.getData("edoc/palette");
                const canvasIdxStr = e.dataTransfer.getData("edoc/canvas-idx");
                if (paletteData) {
                  onDropPaletteItem?.(JSON.parse(paletteData), compIdx);
                } else if (canvasIdxStr !== "") {
                  const fromIdx = parseInt(canvasIdxStr);
                  if (!isNaN(fromIdx) && fromIdx !== compIdx)
                    onReorderComponent?.(fromIdx, compIdx);
                }
              }}
              className={`relative group rounded ${isViewerMode || mode !== "design" ? "cursor-auto" : "cursor-grab active:cursor-grabbing"} ${
                isViewerMode
                  ? constants.emptyString
                  : isDragOver
                  ? "outline outline-2 outline-blue-400 bg-blue-50"
                  : selectedComponentId === compIdx
                  ? "border-2 border-blue-500"
                  : "border border-transparent hover:border-gray-300 dark:border-gray-600"
              }`}
            >
              {!isViewerMode && selectedComponentId === compIdx && (
                <div
                  className="opacity-80
                              left-0
                              top-1/2
                              -translate-y-1/2
                              flex
                              flex-row
                              pointer-events-auto
                              text-sm
                              bg-[var(--surface)]
                              border border-[var(--border-color)]
                              rounded
                              shadow
                              items-center
                              justify-center
                              gap-1
                              absolute z-10"
                >
                  <Button
                    onClick={() => onMoveUp(compIdx)}
                    disabled={compIdx === 0}
                    className="hover:bg-[var(--surface-alt)] text-[var(--general-text-color)] text-sm px-1 py-0.5 transition-opacity duration-200"
                    style={{ width: "16px", height: "20px", opacity: 1 }}
                  >
                    ↑
                  </Button>
                  <Button
                    onClick={() => onMoveDown(compIdx)}
                    disabled={compIdx === comps.length - 1}
                    className="hover:bg-[var(--surface-alt)] text-[var(--general-text-color)] text-sm px-1 py-0.5 transition-opacity duration-200"
                    style={{ width: "16px", height: "20px", opacity: 1 }}
                  >
                    ↓
                  </Button>
                  <Button
                    onClick={() => onDeleteComponent(compIdx)}
                    className="hover:bg-[var(--surface-alt)] text-red-600 text-sm px-1 py-0.5 transition-opacity duration-200"
                    style={{ width: "16px", height: "20px", opacity: 1 }}
                  >
                    🗑
                  </Button>
                </div>
              )}

              <DocComponentRenderer
                component={comp}
                isSelected={!isViewerMode && selectedComponentId === compIdx}
                onSelect={() => {
                  if (!isViewerMode) {
                    onSelect?.();
                    onComponentSelect?.(compIdx);
                  }
                }}
                onRuntimeDataChange={(...args) =>
                  updateRuntimeData(
                    compIdx,
                    args.length === 1 ? args[0] : args,
                  )
                }
                mode={mode}
                pageData={pageData}
                documentData={documentData}
                setBindingData={setBindingData}
              />
            </div>
          );
        })}
      </div>
    );
  };

  // scalable 모드: canvas 실제 높이(측정값) × scale로 컨테이너 높이 확보
  // actualScaledHeight: ResizeObserver로 측정한 실제 높이 (null이면 pageHeightPx * scale로 초기값)
  const scaledHeight = (actualScaledHeight ?? pageHeightPx * scale);

  return (
    <div
      ref={containerRef}
      className={`w-full ${isSelected ? "outline outline-2 outline-offset-8 outline-[rgba(2,132,199,0.3)]" : constants.emptyString}`}
      style={{
        marginTop: `${pageData.runtime_data?.pageMargin ?? 0}px`,
        position: scalable ? "relative" : undefined,
        height: scalable ? `${scaledHeight}px` : undefined,
        overflow: scalable ? "hidden" : undefined,
      }}
    >
      <div
        style={{
          // scalable 모드에서 absolute로 배치 → 부모 너비에 영향 없음
          position: scalable ? "absolute" : undefined,
          top: 0,
          left: 0,
          transform: scalable && scale < 1 ? `scale(${scale})` : undefined,
          transformOrigin: "top left",
          width: `${pageWidthPx}px`,
        }}
      >
        <div
          ref={canvasRef}
          id={`editor-canvas-${pageData.id}`}
          className="border border-dashed border-[var(--border)] bg-white shadow-[var(--shadow-card)]"
          style={{
            width: `${pageWidthPx}px`,
            minHeight: pageData.runtime_data?.pageSize === "Auto" ? "auto" : `${pageHeightPx}px`,
            padding: `${pageData.runtime_data?.padding ?? 48}px`,
            boxSizing: "border-box",
            backgroundColor: pageData.runtime_data?.backgroundColor || "#f8f8f8",
            // 문서는 흰 종이 기준 — 다크모드에서도 캔버스 안 글자·기본 컨트롤이 밝은 상속색으로 사라지지 않게
            // 라이트 컬러 컨텍스트를 고정한다(컴포넌트가 지정한 fontColor는 그대로 우선).
            color: "#1f2937",
            colorScheme: "light",
          }}
          onClick={onSelect}
          // 팔레트 → 캔버스 빈 영역 드롭
          onDragOver={(e) => {
            if (isViewerMode || mode !== "design") return;
            e.preventDefault();
            e.dataTransfer.dropEffect = "copy";
          }}
          onDrop={(e) => {
            if (isViewerMode || mode !== "design") return;
            const paletteData = e.dataTransfer.getData("edoc/palette");
            if (paletteData) {
              e.stopPropagation();
              onDropPaletteItem?.(JSON.parse(paletteData), null); // null = 맨 뒤에 추가
            }
          }}
        >
          {pageData.components?.length === 0 ? (
            isViewerMode ? null : (
              <p className="text-center text-gray-400">
                {commonFunctions.getResourceByLanguage("edocCanvasEmpty", constants.resourceType.label, userInfo.getCurrentLanguageCode())}
              </p>
            )
          ) : (
            RenderComponents()
          )}
        </div>
      </div>
    </div>
  );
}
