"use client";

import * as constants from "@/lib/constants";
import { renderInlineMarkdown } from "@/components/core/client/eDoc/inlineMarkdown";

const alignClass = (value) =>
  ({ left: "text-left", center: "text-center", right: "text-right" })[value || "left"] || "text-left";

const imageAlignClass = (value) =>
  ({ left: "mr-auto", center: "mx-auto", right: "ml-auto" })[value || "center"] || "mx-auto";

const storyTextSize = (fontSize) => {
  const size = Number(fontSize || 0);
  if (size >= 22) return "text-2xl font-semibold leading-snug";
  if (size >= 18) return "text-xl font-semibold leading-snug";
  if (size <= 13) return "text-sm leading-7";
  return "text-base leading-8";
};

const safeJson = (value) => {
  if (typeof value !== "string") return value;
  const text = value.trim();
  if (!text) return value;
  try {
    return JSON.parse(text);
  } catch (_) {
    return value;
  }
};

const asArray = (value) => {
  const parsed = safeJson(value);
  return Array.isArray(parsed) ? parsed : [];
};

const resolvePages = (documentData) => {
  const doc = safeJson(documentData);
  if (!doc) return [];

  const directPages = asArray(doc.pages);
  if (directPages.length) return directPages;

  const snapshotPages = asArray(doc.documentSnapshot?.pages || doc.document_snapshot?.pages);
  if (snapshotPages.length) return snapshotPages;

  const nested = safeJson(doc.document || doc.data || doc.snapshot || doc.documentSnapshot || doc.document_snapshot);
  const nestedPages = asArray(nested?.pages);
  if (nestedPages.length) return nestedPages;

  const components = asArray(doc.components);
  if (components.length) return [{ id: "page-1", components }];

  return [];
};

const normalizeMediaSrc = (value) => String(value || "").trim().replace(/^["']|["']$/g, "");

const imageSource = (rd) =>
  normalizeMediaSrc(rd.src || rd.url || rd.imageUrl || rd.image_url || rd.mediaUrl || rd.media_url || rd.fileUrl || rd.file_url);

const renderInlineImage = (src, key, rd = {}, alt = "", seamless = false) => {
  const mediaSrc = normalizeMediaSrc(src);
  if (!mediaSrc) return null;

  // 웹툰: 컷을 전폭·간격0로 이어붙여 세로 스크롤로 읽히게 한다(카드처럼 따로 놀지 않게).
  if (seamless) {
    return (
      <figure key={key} className="m-0">
        <img src={mediaSrc} alt={alt} className="block w-full object-contain" />
      </figure>
    );
  }

  return (
    <figure key={key} className="my-6">
      <img
        src={mediaSrc}
        alt={alt}
        className={`block max-h-[42rem] max-w-full rounded-lg object-contain shadow-sm ${imageAlignClass(rd.positionAlign)}`}
      />
    </figure>
  );
};

const renderText = (component, key) => {
  const rd = component.runtime_data || {};
  const content = String(rd.content || rd.text || rd.value || "").trim();
  if (!content) return null;

  const imagePattern = /!\[([^\]]*)\]\(([^)]+)\)|<img\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi;
  const parts = [];
  let lastIndex = 0;
  let match;

  while ((match = imagePattern.exec(content)) !== null) {
    const textPart = content.slice(lastIndex, match.index).trim();
    if (textPart) {
      parts.push(
        <p
          key={`${key}-text-${parts.length}`}
          className={`whitespace-pre-wrap ${storyTextSize(rd.fontSize)} ${alignClass(rd.textAlign)} text-[var(--general-text-color)]`}
          style={{ fontWeight: rd.fontWeight || undefined }}
        >
          {renderInlineMarkdown(textPart, `${key}-text-${parts.length}`)}
        </p>,
      );
    }

    const alt = match[1] || "";
    const src = match[2] || match[3];
    const image = renderInlineImage(src, `${key}-image-${parts.length}`, rd, alt);
    if (image) parts.push(image);
    lastIndex = imagePattern.lastIndex;
  }

  const rest = content.slice(lastIndex).trim();
  if (parts.length) {
    if (rest) {
      parts.push(
        <p
          key={`${key}-text-${parts.length}`}
          className={`whitespace-pre-wrap ${storyTextSize(rd.fontSize)} ${alignClass(rd.textAlign)} text-[var(--general-text-color)]`}
          style={{ fontWeight: rd.fontWeight || undefined }}
        >
          {renderInlineMarkdown(rest, `${key}-text-${parts.length}`)}
        </p>,
      );
    }
    return <div key={key} className="space-y-4">{parts}</div>;
  }

  return (
    <p
      key={key}
      className={`whitespace-pre-wrap ${storyTextSize(rd.fontSize)} ${alignClass(rd.textAlign)} text-[var(--general-text-color)]`}
      style={{ fontWeight: rd.fontWeight || undefined }}
    >
      {renderInlineMarkdown(content, key)}
    </p>
  );
};

const renderImage = (component, key, seamless = false) => {
  const rd = component.runtime_data || {};
  return renderInlineImage(imageSource(rd), key, rd, "", seamless);
};

// autoPlay: 회차의 첫 영상만 바로 재생한다. 브라우저가 소리 있는 자동재생을 막으므로
// 음소거로 시작하고, 사용자가 컨트롤에서 소리를 켠다. 본문 중간의 나머지 영상까지
// 한꺼번에 재생되면 방해가 되므로 첫 영상에만 적용한다.
const renderVideo = (component, key, autoPlay = false) => {
  const rd = component.runtime_data || {};
  const src = normalizeMediaSrc(rd.url || rd.src);
  if (!src) return null;
  const title = String(rd.title || rd.caption || "").trim();
  const poster = normalizeMediaSrc(rd.poster || rd.posterUrl || rd.poster_url || rd.thumbnail || rd.thumbnailUrl || rd.thumbnail_url);

  return (
    <figure key={key} className="my-6">
      {title && (
        <figcaption className="mx-auto mb-3 max-w-md rounded-lg bg-[var(--surface-alt)] px-3 py-2 text-sm font-semibold leading-6 text-[var(--general-text-color)]">
          {title}
        </figcaption>
      )}
      <video
        src={src}
        controls
        playsInline
        autoPlay={autoPlay || undefined}
        muted={autoPlay || undefined}
        preload={autoPlay ? "auto" : "metadata"}
        poster={poster || undefined}
        className="mx-auto max-h-[42rem] w-full max-w-md rounded-lg bg-black shadow-sm"
      />
    </figure>
  );
};

const renderLink = (component, key) => {
  const rd = component.runtime_data || {};
  if (!rd.content && !rd.url) return null;

  return (
    <a
      key={key}
      href={rd.url || "#"}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex max-w-full items-center text-sm font-medium text-[var(--brand-blue)] underline-offset-4 hover:underline ${alignClass(rd.textAlign)}`}
    >
      {rd.content || rd.url}
    </a>
  );
};

const renderCard = (component, key) => {
  const rd = component.runtime_data || {};
  if (!rd.title && !rd.description && !rd.imageUrl) return null;

  return (
    <div key={key} className="my-5 rounded-lg border border-[var(--border-color)] bg-[var(--general-text-bg-color)] p-4">
      {rd.imageUrl && <img src={rd.imageUrl} alt="" className="mb-3 h-24 w-full rounded-md object-cover" />}
      {rd.title && <div className="text-base font-semibold text-[var(--general-text-color)]">{rd.title}</div>}
      {rd.description && <p className="mt-1 whitespace-pre-wrap text-sm leading-6 text-[var(--semi-text-color)]">{rd.description}</p>}
    </div>
  );
};

const componentText = (component) => {
  if (String(component?.type || "").toLowerCase() !== constants.edocComponentType._TEXT.toLowerCase()) return "";
  return String(component.runtime_data?.content || component.runtime_data?.text || component.runtime_data?.value || "")
    .trim()
    .replace(/\s+/g, " ");
};

const isImageComponent = (component) =>
  String(component?.type || "").toLowerCase() === constants.edocComponentType._IMAGE.toLowerCase();

const normalizeStoryComponents = (components = []) =>
  components.filter((component, index, list) => {
    const text = componentText(component);
    if (!text) return true;
    return !(isImageComponent(list[index + 1]) && componentText(list[index + 2]) === text);
  });

const renderComponent = (component, key, seamless = false, autoPlayVideo = false) => {
  const type = String(component.type || "").toLowerCase();
  switch (type) {
    case constants.edocComponentType._TEXT.toLowerCase():
    case "narration":
    case "narrator":
    case "caption":
    case "dialogue":
      return renderText(component, key);
    case constants.edocComponentType._IMAGE.toLowerCase():
      return renderImage(component, key, seamless);
    case constants.edocComponentType._VIDEO.toLowerCase():
      return renderVideo(component, key, autoPlayVideo);
    case constants.edocComponentType._LINKTEXT.toLowerCase():
      return renderLink(component, key);
    case constants.edocComponentType._CARD.toLowerCase():
      return renderCard(component, key);
    default:
      return null;
  }
};

export default function EDocStoryRenderer({ documentData, emptyText = "", seamless = false }) {
  const blocks = [];
  const pages = resolvePages(documentData);

  let videoSeen = false;
  pages.forEach((page, pageIndex) => {
    normalizeStoryComponents(page.components || []).forEach((component, componentIndex) => {
      const isVideo = String(component.type || "").toLowerCase() === constants.edocComponentType._VIDEO.toLowerCase();
      const autoPlayVideo = isVideo && !videoSeen;
      if (isVideo) videoSeen = true;
      const rendered = renderComponent(component, `${pageIndex}-${componentIndex}-${component.id || component.type}`, seamless, autoPlayVideo);
      if (rendered) blocks.push(rendered);
    });
  });

  if (!blocks.length) return <p className="text-sm text-[var(--semi-text-color)]">{emptyText}</p>;

  return <div className={seamless ? "space-y-0" : "space-y-4"}>{blocks}</div>;
}
