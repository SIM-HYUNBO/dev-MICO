import React from "react";
import Button from "@/components/core/client/ui/Button";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

const menuItems = (props) => [
  { key: "undo", label: "↩", fullLabel: `↩ ${L("edocMenuUndo")}`, onClick: props.onUndo, title: L("edocMenuUndoHint") },
  { key: "redo", label: "↪", fullLabel: `↪ ${L("edocMenuRedo")}`, onClick: props.onRedo, title: L("edocMenuRedoHint") },
  { key: "new", label: L("edocMenuNewShort"), fullLabel: L("edocMenuNew"), onClick: props.onNewDocument },
  { key: "open", label: L("edocMenuOpenShort"), fullLabel: L("edocMenuOpen"), onClick: props.onOpenDocument },
  { key: "save", label: L("edocMenuSaveShort"), fullLabel: L("edocMenuSave"), onClick: props.onSaveDocument },
  { key: "delete", label: L("edocMenuDeleteShort"), fullLabel: L("edocMenuDelete"), onClick: props.onDeleteDocument },
  { key: "addPage", label: L("edocMenuAddPageShort"), fullLabel: L("edocMenuAddPage"), onClick: props.onAddPage },
  { key: "deletePage", label: L("edocMenuDeletePageShort"), fullLabel: L("edocMenuDeletePage"), onClick: props.onDeleteCurrentPage },
  { key: "exportPdf", label: "PDF", fullLabel: L("edocMenuExportPdf"), onClick: props.onExportPdf },
  { key: "exportMd", label: "→MD", fullLabel: L("edocMenuExportMd"), onClick: props.onExportMd, title: L("edocMenuExportMdHint") },
  { key: "importMd", label: "MD→", fullLabel: L("edocMenuImportMd"), onClick: props.onImportMd, title: L("edocMenuImportMdHint") },
  { key: "ai", label: "AI", fullLabel: L("edocMenuAiGen"), onClick: () => props.setAIInputModalOpen(true) },
];

export default function EDocDesignerTopMenu(props) {
  const items = menuItems(props);
  return (
    <div className="sticky top-0 z-20 flex w-full flex-wrap items-center justify-center gap-1 border-b border-[var(--border)] bg-[var(--surface)] px-2 py-2">
      {items.map((item) => (
        <Button
          key={item.fullLabel}
          onClick={item.onClick}
          title={item.title || item.fullLabel}
          variant={item.key === "delete" || item.key === "deletePage" ? "danger" : item.key === "save" ? "success" : item.key === "undo" || item.key === "redo" ? "ghost" : "soft"}
          size="sm"
          className="text-center text-xs"
        >
          <span className="hidden md:inline">{item.fullLabel}</span>
          <span className="md:hidden">{item.label}</span>
        </Button>
      ))}
    </div>
  );
}
