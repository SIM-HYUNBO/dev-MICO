"use strict";

import { useState, useEffect, useRef } from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import { RequestServer } from "@/components/core/client/requestServer";

import EDocComponentPalette from "./eDocComponentPalette";
import EDocEditorCanvas from "./eDocEditorCanvas";
import EDocDesignerTopMenu from "./eDocDesignerTopMenu";
import EDocComponentPropertyEditor from "./eDocComponentPropertyEditor";
import EDocDocumentPropertyEditor from "./eDocDocumentPropertyEditor";
import EDocPagePropertyEditor from "./eDocPagePropertyEditor";

import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import AIInputModal from "@/components/core/client/aiInputModal";
import Loading from "@/components/core/client/loading";
import { downloadMarkdown, markdownToEDoc } from "@/lib/eDocMarkdown";
import { Input, Button, Table } from "antd";

import * as InputComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Input";
import * as TextComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Text";
import * as ImageComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Image";
import * as TableComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Table";
import * as CheckListComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_CheckList";
import * as ButtonComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Button";
import * as VideoComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Video";
import * as LinkTextComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_LinkText";
import * as LottieComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Lottie";
import * as CardComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Card";

// 컴포넌트 고유 id 생성 — 재정렬/삽입/삭제 시 React가 배열 위치가 아닌 정체성으로 상태·DOM을 추적하게 한다.
// (인덱스 key를 쓰면 순서가 바뀔 때 편집 내용·입력값이 엉뚱한 컴포넌트에 달라붙는 상태 꼬임이 생긴다.)
let __edocIdSeq = 0;
const genComponentId = () =>
  `comp_${Date.now().toString(36)}_${(__edocIdSeq++).toString(36)}_${Math.random().toString(36).slice(2, 6)}`;

// 문서 로드/임포트 시 id 없는 컴포넌트에 안정적 id를 백필한다(레거시·AI·마크다운 문서 대비).
const withComponentIds = (doc) => {
  if (!doc || !Array.isArray(doc.pages)) return doc;
  const runtimeData = doc.runtime_data || {};
  const rowTitle = typeof doc.title === "string" ? doc.title.trim() : "";
  const runtimeTitle = typeof runtimeData.title === "string" ? runtimeData.title.trim() : "";
  const shouldUseRowTitle =
    rowTitle &&
    (!runtimeTitle || runtimeTitle === "New Document" || runtimeTitle === "New document");
  return {
    ...doc,
    runtime_data: {
      ...runtimeData,
      title: shouldUseRowTitle ? rowTitle : runtimeData.title,
      description:
        shouldUseRowTitle && (!runtimeData.description || runtimeData.description === "신규 문서")
          ? rowTitle
          : runtimeData.description,
    },
    pages: doc.pages.map((page) => ({
      ...page,
      components: Array.isArray(page.components)
        ? page.components.map((c) => (c && c.id ? c : { ...c, id: genComponentId() }))
        : page.components,
    })),
  };
};

export default function EDocDesignerContainer({ documentId }) {
  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");

  const tl = (key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.label, currentLanguageCode);

  const { BrunnerMessageBox, openOkCancelModal, openOkModal, openInputModal } =
    useModal();

  const [loading, setLoading] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [mode, setMode] = useState("design");
  const [componentTemplates, setComponentTemplates] = useState([]);
  const [documentData, setDocumentData] = useState({
    id: documentId || null,
    runtime_data: {
      title: "New Document",
      description: "신규 문서",
      isPublic: false,
      backgroundColor: "#ffffff",
      padding: 1,
      menu_path: null, // 메뉴 경로는 나중에 설정
    },
    pages: [
      {
        id: "page-1",
        components: [],
        runtime_data: {
          padding: 24,
          alignment: "center",
          backgroundColor: "#ffffff",
          pageSize: "A4",
        },
      },
    ],
  });

  const [currentPageIdx, setCurrentPageIdx] = useState(0);
  const [selectedComponentId, setSelectedComponentId] = useState(null);
  const [documentList, setDocumentList] = useState([]);
  const [showDocumentListModal, setShowDocumentListModal] = useState(false);
  const [isLeftPanelOpen, setIsLeftPanelOpen] = useState(true);
  const [isRightPanelOpen, setIsRightPanelOpen] = useState(false);
  const [mobilePanel, setMobilePanel] = useState(null); // null | 'palette' | 'properties'
  const [isMobile, setIsMobile] = useState(false);

  // 우측 패널 리사이즈
  const [isResizing, setIsResizing] = useState(false);
  const [rightPanelWidth, setRightPanelWidth] = useState(240);
  const [resizeStartX, setResizeStartX] = useState(0);
  const [resizeStartWidth, setResizeStartWidth] = useState(0);

  // 좌측 패널 리사이즈
  const [isLeftResizing, setIsLeftResizing] = useState(false);
  const [leftPanelWidth, setLeftPanelWidth] = useState(120);
  const [leftResizeStartX, setLeftResizeStartX] = useState(0);
  const [leftResizeStartWidth, setLeftResizeStartWidth] = useState(0);
  const [aiInputModalOpen, setAIInputModalOpen] = useState(false);
  const [copiedComponent, setCopiedComponent] = useState(null);

  const [bindingData, setBindingData] = useState({});

  // Undo/Redo: 분리된 스택 방식
  // undoStack: 변경 전 상태들, redoStack: undo 후 복원 가능한 상태들
  const MAX_HISTORY = 50;
  const undoStackRef = useRef([]);
  const redoStackRef = useRef([]);
  const documentDataRef = useRef(documentData); // stale closure 방지용 ref

  useEffect(() => {
    const currentPage = documentData.pages?.[currentPageIdx];
    if (!currentPage) return;

    const components = currentPage.components;
    if (!Array.isArray(components)) return;

    commonFunctions.applyComponentsBindingValue(
      components,
      bindingData,
      (component, key, value) => {
        // 🔥 runtime_data 업데이트 연결
        setDocumentData((prev) => {
          const newPages = [...prev.pages];
          const newComponents = [...newPages[currentPageIdx].components];

          const targetIdx = newComponents.findIndex((c) => c === component);

          if (targetIdx === -1) return prev;

          newComponents[targetIdx] = {
            ...component,
            runtime_data: {
              ...component.runtime_data,
              [key]: value,
            },
          };

          newPages[currentPageIdx] = {
            ...newPages[currentPageIdx],
            components: newComponents,
          };

          return { ...prev, pages: newPages };
        });
      },
    );
  }, [bindingData]); // 🔥 components 넣지 마라 (루프 위험)

  // documentDataRef를 항상 최신 상태로 유지 (stale closure 방지)
  useEffect(() => {
    documentDataRef.current = documentData;
  }, [documentData]);

  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  useEffect(() => {
    const systemCode = userInfo.getCurrentSystemCode();
    const loginUserId = userInfo.getLoginUserId();
    const languageCode = userInfo.getCurrentLanguageCode();

    setCurrentSystemCode(systemCode);
    setCurrentLoginUserId(loginUserId);
    setCurrentLanguageCode(languageCode);

    async function fetchTemplates() {
      const jRequest = {
        commandName: constants.commands.EDOC_COMPONENT_TEMPLATES_SELECT_ALL,
                userId: loginUserId,
        languageCode: languageCode,
      };
      setLoading(true);
      const jResponse = await RequestServer(jRequest);
      setLoading(false);

      if (jResponse.error_code === constants.errorCode.Success) {
        setComponentTemplates(jResponse.templateList);
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    }
    fetchTemplates();
  }, []);

  useEffect(() => {
    if (documentId) {
      openDocumentById(documentId);
    }
  }, [documentId]);

  // 우측 패널 리사이즈 이벤트
  useEffect(() => {
    if (isResizing) {
      window.addEventListener("mousemove", handleMouseMove);
      window.addEventListener("mouseup", handleMouseUp);
    }
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isResizing]);

  // 좌측 패널 리사이즈 이벤트
  useEffect(() => {
    if (isLeftResizing) {
      window.addEventListener("mousemove", handleLeftMouseMove);
      window.addEventListener("mouseup", handleLeftMouseUp);
    }
    return () => {
      window.removeEventListener("mousemove", handleLeftMouseMove);
      window.removeEventListener("mouseup", handleLeftMouseUp);
    };
  }, [isLeftResizing]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      // Ctrl + Z : Undo
      if (e.ctrlKey && !e.shiftKey && e.key.toLowerCase() === "z") {
        e.preventDefault();
        handleUndo();
      }

      // Ctrl + Y 또는 Ctrl + Shift + Z : Redo
      if (
        (e.ctrlKey && e.key.toLowerCase() === "y") ||
        (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "z")
      ) {
        e.preventDefault();
        handleRedo();
      }

      // Ctrl + C
      if (e.ctrlKey && e.key.toLowerCase() === "c") {
        e.preventDefault();
        handleCopy();
      }

      // Ctrl + V
      if (e.ctrlKey && e.key.toLowerCase() === "v") {
        e.preventDefault();
        handlePaste();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentPageIdx, selectedComponentId]); // 의존성 배열은 빈 배열로, 컴포넌트 마운트/언마운트 시 한 번만

  const handleCopy = () => {
    if (selectedComponentId === null) return;

    // 현재 페이지에서 선택된 컴포넌트만 복사
    const currentPage = documentData.pages[currentPageIdx];
    if (!currentPage) return;

    const component = currentPage.components[selectedComponentId];
    if (!component) return;

    setCopiedComponent(JSON.parse(JSON.stringify(component))); // 깊은 복사
  };

  const handlePaste = () => {
    if (!copiedComponent) return;

    const newComponent = JSON.parse(JSON.stringify(copiedComponent));
    newComponent.runtime_data.top = (newComponent.runtime_data.top || 0) + 20;
    newComponent.runtime_data.left = (newComponent.runtime_data.left || 0) + 20;

    pushHistory();
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      newPages[currentPageIdx] = {
        ...newPages[currentPageIdx],
        components: [...newPages[currentPageIdx].components, newComponent],
      };
      return { ...prev, pages: newPages };
    });
  };

  // 우측 패널 리사이즈 핸들러
  const handleMouseDown = (e) => {
    setIsResizing(true);
    setResizeStartX(e.clientX);
    setResizeStartWidth(rightPanelWidth);
  };

  const handleMouseUp = () => {
    if (isResizing) setIsResizing(false);
  };

  const handleMouseMove = (e) => {
    if (isResizing) {
      const deltaX = resizeStartX - e.clientX;
      const newWidth = resizeStartWidth + deltaX;
      setRightPanelWidth(Math.max(150, Math.min(600, newWidth)));
    }
  };

  // 좌측 패널 리사이즈 핸들러
  const handleLeftMouseDown = (e) => {
    setIsLeftResizing(true);
    setLeftResizeStartX(e.clientX);
    setLeftResizeStartWidth(leftPanelWidth);
  };

  const handleLeftMouseUp = () => {
    if (isLeftResizing) setIsLeftResizing(false);
  };

  const handleLeftMouseMove = (e) => {
    if (isLeftResizing) {
      const deltaX = e.clientX - leftResizeStartX;
      const newWidth = leftResizeStartWidth + deltaX;
      setLeftPanelWidth(Math.max(120, Math.min(500, newWidth)));
    }
  };

  // ── Undo / Redo ──────────────────────────────────────────
  // 변경 직전에 호출: 현재 상태를 undoStack에 저장, redoStack 초기화
  const pushHistory = () => {
    const snapshot = JSON.parse(JSON.stringify(documentDataRef.current));
    undoStackRef.current.push(snapshot);
    if (undoStackRef.current.length > MAX_HISTORY) undoStackRef.current.shift();
    redoStackRef.current = []; // 새 변경이 생기면 redo 스택 제거
  };

  const handleUndo = () => {
    if (undoStackRef.current.length === 0) return;
    // 현재 상태를 redo 스택에 저장
    redoStackRef.current.push(
      JSON.parse(JSON.stringify(documentDataRef.current)),
    );
    // undo 스택에서 이전 상태 복원
    const snapshot = undoStackRef.current.pop();
    setDocumentData(snapshot);
    setSelectedComponentId(null);
  };

  const handleRedo = () => {
    if (redoStackRef.current.length === 0) return;
    // 현재 상태를 undo 스택에 저장
    undoStackRef.current.push(
      JSON.parse(JSON.stringify(documentDataRef.current)),
    );
    // redo 스택에서 미래 상태 복원
    const snapshot = redoStackRef.current.pop();
    setDocumentData(snapshot);
    setSelectedComponentId(null);
  };
  // ─────────────────────────────────────────────────────────

  const toggleMode = () =>
    setMode((prev) => (prev === "design" ? "runtime" : "design"));

  const handleNewDocument = async () => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `LOGIN_REQUIRED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    const result = await openOkModal(
      commonFunctions.getResourceByLanguage(
        `CONFIRM_SAVE_NEW_DOC`,
        constants.resourceType.message,
        currentLanguageCode,
      ),
      constants.messageCategory.Confirm,
    );
    if (result) {
      const title = await openInputModal(
        "Input the new document name",
        "New Document",
        "New document",
      );
      setDocumentData({
        id: documentId || null,
        runtime_data: {
          title: title,
          description: title,
          isPublic: false,
          backgroundColor: "#ffffff",
          padding: 1,
          menu_path: null, // 메뉴 경로는 나중에 설정
        },
        pages: [
          {
            id: "page-1",
            components: [],
            runtime_data: {
              padding: 24,
              alignment: "center",
              backgroundColor: "#ffffff",
              pageSize: "A4",
            },
          },
        ],
      });
      setCurrentPageIdx(0);
      setSelectedComponentId(null);
    }
  };

  const handleOpenDocument = async () => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `LOGIN_REQUIRED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    const jRequest = {
      commandName: constants.commands.EDOC_USER_DOCUMENT_SELECT_ALL,
            userId: currentLoginUserId,
      languageCode: currentLanguageCode,
    };
    setLoading(true);
    const jResponse = await RequestServer(jRequest);
    setLoading(false);

    if (jResponse.error_code === constants.errorCode.Success) {
      // AI 스튜디오 콘텐츠는 디자이너 문서 목록에서 제외 (서버 필터 이중 방어)
      const isAiContent = (doc) => {
        let rd = doc?.runtime_data;
        if (typeof rd === "string") { try { rd = JSON.parse(rd); } catch { rd = null; } }
        return rd?.source === "AI_STUDIO" || rd?.aiContent === true;
      };
      setDocumentList((jResponse.documentList || []).filter((doc) => !isAiContent(doc)));
      setShowDocumentListModal(true);
    } else
      openOkModal(jResponse.error_message, constants.messageCategory.Error);
  };

  const openDocumentById = async (id) => {
    setLoading(true);
    const loadedDocument = await commonFunctions.getDocumentData(
      currentSystemCode,
      currentLanguageCode,
      currentLoginUserId,
      id,
    );
    setLoading(false);

    setDocumentData(withComponentIds(loadedDocument));
    setCurrentPageIdx(0);
    setSelectedComponentId(null);
  };

  const handleSaveDocument = async () => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `LOGIN_REQUIRED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    if (
      !documentData.id &&
      documentData.runtime_data.title === "New Document"
    ) {
      const result = await openOkModal(
        commonFunctions.getResourceByLanguage(
          `CONFIRM_SAVE_DOCUMENT_WITHOUT_TITLE`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Confirm,
      );
      if (!result) return;
    }

    const jRequest = {
      commandName: constants.commands.EDOC_DOCUMENT_UPSERT_ONE,
            userId: currentLoginUserId,
      languageCode: currentLanguageCode,
      documentData: documentData,
    };
    setLoading(true);
    const jResponse = await RequestServer(jRequest);
    setLoading(false);

    if (jResponse.error_code === constants.errorCode.Success) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `SUCCESS_SAVED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Info,
      );
      setDocumentData(withComponentIds(jResponse.documentData));
      setCurrentPageIdx(0);
      window.dispatchEvent(new CustomEvent("menuChanged"));
    } else {
      await openOkModal(
        jResponse.error_message,
        constants.messageCategory.Error,
      );
    }
  };

  const handleDeleteDocument = async () => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `LOGIN_REQUIRED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    const result = await openOkModal(
      commonFunctions.getResourceByLanguage(
        `CONFIRM_DELETE_ITEM`,
        constants.resourceType.message,
        currentLanguageCode,
      ),
      constants.messageCategory.Confirm,
    );
    if (!result) return;

    const jRequest = {
      commandName: constants.commands.EDOC_DOCUMENT_DELETE_ONE,
            userId: currentLoginUserId,
      languageCode: currentLanguageCode,
      documentId: documentData.id,
    };
    setLoading(true);
    const jResponse = await RequestServer(jRequest);
    setLoading(false);

    if (jResponse.error_code === constants.errorCode.Success) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `SUCCESS_DELETED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Info,
      );
      window.dispatchEvent(new CustomEvent("menuChanged"));
      setDocumentData({
        id: null,
        pages: [
          {
            id: "page-1",
            components: [],
            runtime_data: {
              padding: 24,
              alignment: "center",
              backgroundColor: "#ffffff",
              pageSize: "A4",
            },
          },
        ],
        runtime_data: {
          title: "New Document",
          description: "신규 문서",
          isPublic: false,
          backgroundColor: "#ffffff",
          padding: 1,
          menu_path: null, // 메뉴 경로는 나중에 설정
        },
      });
      setCurrentPageIdx(0);
      setSelectedComponentId(null);
    } else
      openOkModal(jResponse.error_message, constants.messageCategory.Error);
  };

  const handleAddPage = async () => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `LOGIN_REQUIRED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    pushHistory();
    const newPageId = `page-${documentData.pages.length + 1}`;
    const newPage = {
      id: newPageId,
      components: [],
      runtime_data: { pageSize: "A4", padding: 24, backgroundColor: "white" },
    };

    setDocumentData((prev) => ({
      ...prev,
      pages: [...prev.pages, newPage],
    }));
    setCurrentPageIdx(documentData.pages.length);
  };

  const handleDeleteCurrentPage = async () => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `LOGIN_REQUIRED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    if (documentData.pages.length === 1) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `MINIUM_PAGE_COUNT`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }
    const confirm = await openOkModal(
      `The index ${currentPageIdx + 1}, ${commonFunctions.getResourceByLanguage(
        `CONFIRM_DELETE_SELECTED_PAGE`,
        constants.resourceType.message,
        currentLanguageCode,
      )}`,
      constants.messageCategory.Confirm,
    );
    if (!confirm) return;

    pushHistory();
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      newPages.splice(currentPageIdx, 1);
      return {
        ...prev,
        pages: newPages,
      };
    });
    setCurrentPageIdx(currentPageIdx > 0 ? currentPageIdx - 1 : 0);
  };

  const handleAddComponent = async (component, forceInsertIdx = null) => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `LOGIN_REQUIRED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    const baseComponent = { ...component, id: genComponentId() };

    const defaultRuntimeData = {
      gridCol: 12, // 기본값: 전체 폭 (12/12 = 100%)
      height: constants.emptyString,
      forceNewLine: true,
    };

    switch (component.template_json.type) {
      case constants.edocComponentType._TEXT:
        baseComponent.runtime_data =
          TextComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      case constants.edocComponentType._IMAGE:
        baseComponent.runtime_data =
          ImageComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      case constants.edocComponentType._INPUT:
        baseComponent.runtime_data =
          InputComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      case constants.edocComponentType._TABLE:
        baseComponent.runtime_data =
          TableComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      case constants.edocComponentType._CHECKLIST:
        baseComponent.runtime_data =
          CheckListComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      case constants.edocComponentType._BUTTON:
        baseComponent.runtime_data =
          ButtonComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      case constants.edocComponentType._VIDEO:
        baseComponent.runtime_data =
          VideoComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      case constants.edocComponentType._LINKTEXT:
        baseComponent.runtime_data =
          LinkTextComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      case constants.edocComponentType._LOTTIE:
        baseComponent.runtime_data =
          LottieComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      case constants.edocComponentType._CARD:
        baseComponent.runtime_data =
          CardComponent.initDefaultRuntimeData(defaultRuntimeData);
        break;
      default:
        break;
    }

    pushHistory();
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      const components = [...newPages[currentPageIdx].components];

      let insertIndex;

      if (forceInsertIdx !== null) {
        // 👉 드래그 드롭으로 특정 위치에 삽입
        insertIndex = forceInsertIdx;
        components.splice(insertIndex, 0, baseComponent);
      } else if (selectedComponentId !== null) {
        // 👉 선택된 컴포넌트 바로 아래
        insertIndex = selectedComponentId + 1;
        components.splice(insertIndex, 0, baseComponent);
      } else {
        // 👉 선택 없으면 맨 뒤
        insertIndex = components.length;
        components.push(baseComponent);
      }

      newPages[currentPageIdx] = {
        ...newPages[currentPageIdx],
        components,
      };

      // 👉 새로 추가된 컴포넌트 선택
      setSelectedComponentId(insertIndex);

      return { ...prev, pages: newPages };
    });
  };

  const handleComponentSelect = (idx) => {
    setSelectedComponentId(idx);
    if (isMobile) {
      setMobilePanel("properties");
    } else {
      setIsLeftPanelOpen(false);
      setIsRightPanelOpen(true);
    }
  };

  const handleUpdateComponent = (updatedComponent, mode = "update") => {
    pushHistory();

    if (mode === "add") {
      // 붙여넣기 등 새 컴포넌트 추가 — 선택 컴포넌트를 덮어쓰지 않고 바로 아래(선택 없으면 맨 뒤)에 삽입.
      const comps0 = documentData.pages[currentPageIdx]?.components || [];
      const insertAt = selectedComponentId !== null ? selectedComponentId + 1 : comps0.length;
      setDocumentData((prev) => {
        const newPages = [...prev.pages];
        const page = newPages[currentPageIdx];
        const components = [...page.components];
        components.splice(insertAt, 0, updatedComponent);
        newPages[currentPageIdx] = { ...page, components };
        return { ...prev, pages: newPages };
      });
      setSelectedComponentId(insertAt);
      return;
    }

    // 편집은 컴포넌트 id로 정확히 찾아 갱신 — 선택 인덱스가 stale이거나 선택이 없어도 올바른 컴포넌트에 반영.
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      const page = newPages[currentPageIdx];
      const components = [...page.components];
      let idx = updatedComponent?.id
        ? components.findIndex((c) => c.id === updatedComponent.id)
        : -1;
      if (idx < 0) idx = selectedComponentId; // 레거시(무 id) 폴백
      if (idx == null || idx < 0 || idx >= components.length) return prev;
      components[idx] = updatedComponent;
      newPages[currentPageIdx] = { ...page, components };
      return { ...prev, pages: newPages };
    });
  };

  const handleMoveComponentUp = () => {
    if (selectedComponentId === null || selectedComponentId <= 0) return;
    pushHistory();
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      const components = [...newPages[currentPageIdx].components];
      [components[selectedComponentId - 1], components[selectedComponentId]] = [
        components[selectedComponentId],
        components[selectedComponentId - 1],
      ];
      newPages[currentPageIdx].components = components;
      return { ...prev, pages: newPages };
    });
    setSelectedComponentId((prev) => prev - 1);
  };

  const handleMoveComponentDown = () => {
    const comps = documentData.pages[currentPageIdx].components;
    if (selectedComponentId === null || selectedComponentId >= comps.length - 1)
      return;
    pushHistory();
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      const components = [...newPages[currentPageIdx].components];
      [components[selectedComponentId + 1], components[selectedComponentId]] = [
        components[selectedComponentId],
        components[selectedComponentId + 1],
      ];
      newPages[currentPageIdx].components = components;
      return { ...prev, pages: newPages };
    });
    setSelectedComponentId((prev) => prev + 1);
  };

  const handleReorderComponent = (fromIdx, toIdx) => {
    if (fromIdx === toIdx) return;
    pushHistory();
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      const components = [...newPages[currentPageIdx].components];
      const [removed] = components.splice(fromIdx, 1);
      components.splice(toIdx, 0, removed);
      newPages[currentPageIdx] = { ...newPages[currentPageIdx], components };
      return { ...prev, pages: newPages };
    });
    setSelectedComponentId(toIdx);
  };

  const handleDeleteComponent = () => {
    if (selectedComponentId === null) return;
    pushHistory();
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      const components = [...newPages[currentPageIdx].components];
      components.splice(selectedComponentId, 1);
      newPages[currentPageIdx].components = components;
      return { ...prev, pages: newPages };
    });
    setSelectedComponentId(null);
  };

  const handleExportPdf = async () => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `LOGIN_REQUIRED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    setIsExportingPdf(true);
    const canvas = await html2canvas(
      document.querySelector(".edoc-designer-canvas"),
      { scale: 2 },
    );
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF("p", "mm", "a4");
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save(`${documentData.runtime_data.title || "document"}.pdf`);

    setIsExportingPdf(false);
  };

  const handleExportMd = () => {
    downloadMarkdown(documentData);
  };

  const handleImportMd = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".md,text/markdown,text/plain";
    input.onchange = async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const text = await file.text();
      const newDoc = markdownToEDoc(text, documentData);
      pushHistory();
      setDocumentData(withComponentIds(newDoc));
      setCurrentPageIdx(0);
      setSelectedComponentId(null);
    };
    input.click();
  };

  const handleAIResponse = async (aiResponse) => {
    // 서버가 성공으로 응답해도 AI가 만든 구조가 불완전할 수 있다(runtime_data/pages 누락).
    // 적용 전에 검증해 흰 화면 크래시 대신 브랜드 안내로 재시도를 유도한다.
    const doc = aiResponse?.documentData;
    const valid =
      doc &&
      doc.runtime_data &&
      Array.isArray(doc.pages) &&
      doc.pages.length > 0;
    if (!valid) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `AI_DOC_GENERATE_FAILED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    const newDoc = withComponentIds({
      ...doc,
      title: doc.runtime_data.title,
    });

    setDocumentData(newDoc);
    setCurrentPageIdx(0);
    await openOkModal(
      commonFunctions.getResourceByLanguage(
        `SUCCESS_CREATED`,
        constants.resourceType.message,
        currentLanguageCode,
      ),
      constants.messageCategory.Info,
    );
  };

  const handleDocumentListClick = (doc) => {
    setShowDocumentListModal(false);
    openDocumentById(doc.id);
  };

  const ModeToggleButton = () => {
    return (
      <Button
        onClick={toggleMode}
        className="flex 
                      flex-row 
                      justify-center 
                      rounded-lg 
                      hover:bg-gray-200 
                      dark:hover:bg-gray-700"
        title={mode === "design" ? "To Runtime Mode" : "To Design Mode"}
      >
        {mode === "design" ? (
          // 런타임 모드 아이콘 (▶ 플레이 버튼 느낌)
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="w-6 h-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M5 3l14 9-14 9V3z"
            />
          </svg>
        ) : (
          // 디자인 모드 아이콘 (연필 아이콘)
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="w-6 h-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M16.862 4.487l2.651 2.651a2 2 0 010 2.828l-9.9 9.9a4 4 0 01-1.414.94l-3.53 1.178a.5.5 0 01-.633-.633l1.178-3.53a4 4 0 01.94-1.414l9.9-9.9a2 2 0 012.828 0z"
            />
          </svg>
        )}
      </Button>
    );
  };

  // 현재 페이지를 위로 이동
  const handleMovePageUp = () => {
    if (currentPageIdx <= 0) return;
    pushHistory();
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      [newPages[currentPageIdx - 1], newPages[currentPageIdx]] = [
        newPages[currentPageIdx],
        newPages[currentPageIdx - 1],
      ];
      return { ...prev, pages: newPages };
    });
    setCurrentPageIdx((prev) => prev - 1);
  };

  // 현재 페이지를 아래로 이동
  const handleMovePageDown = () => {
    if (currentPageIdx >= documentData.pages.length - 1) return;
    pushHistory();
    setDocumentData((prev) => {
      const newPages = [...prev.pages];
      [newPages[currentPageIdx + 1], newPages[currentPageIdx]] = [
        newPages[currentPageIdx],
        newPages[currentPageIdx + 1],
      ];
      return { ...prev, pages: newPages };
    });
    setCurrentPageIdx((prev) => prev + 1);
  };

  return (
    <>
      <AIInputModal
        isOpen={aiInputModalOpen}
        onClose={() => setAIInputModalOpen(false)}
        commandName={constants.commands.EDOC_AI_GENERATE_DOCUMENT}
        onAIResponse={handleAIResponse}
      />

      {/* 문서 선택 모달 */}
      {showDocumentListModal && (
        <div
          className="fixed 
                     inset-0 
                     bg-black 
                     bg-opacity-50 
                     flex 
                     justify-center 
                     items-center 
                     z-50"
        >
          <div
            className="bg-white 
                       semi-bg-color 
                       rounded-xl 
                       shadow-xl 
                       w-96 
                       max-h-96 
                       overflow-auto 
                       p-4
                       border 
                       border-gray-200 
                       dark:border-slate-700"
          >
            <h3
              className="text-sm 
                         font-bold 
                         mb-4 
                         general-text-color"
            >
              문서 선택
            </h3>
            <ul>
              {documentList.map((doc) => (
                <li
                  key={doc.id}
                  className="cursor-pointer
                             border-b 
                             py-2 
                             px-3 
                             hover:medium-text-bg-color
                             rounded"
                  onClick={() => handleDocumentListClick(doc)}
                >
                  {(doc.runtime_data?.title || doc.title || constants.emptyString)} ({doc.id})
                </li>
              ))}
            </ul>
            <Button
              className="mt-4 
                        px-4 
                        py-2 
                        general-text-bg-color 
                        rounded 
                        hover:medium-bg-color 
                        dark:hover:medium-bg-color"
              onClick={() => setShowDocumentListModal(false)}
            >
              Close
            </Button>
          </div>
        </div>
      )}

      <div className="relative flex-1 overflow-auto bg-[var(--bg)]">
        {loading && <Loading />}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[var(--border)] bg-[var(--surface)] px-4 py-3">
        <h2 className="gradient-text text-xl font-extrabold">
          {commonFunctions.getResourceByLanguage("eDocDesignerTitle", constants.resourceType.label, currentLanguageCode)}
        </h2>
        <div className="flex items-center gap-2">
          <input
            className="max-w-[220px] rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-2 text-sm font-semibold text-[var(--text)]"
            value={documentData.runtime_data.title || ""}
            onChange={(e) => setDocumentData((prev) => ({ ...prev, runtime_data: { ...prev.runtime_data, title: e.target.value } }))}
            aria-label={commonFunctions.getResourceByLanguage("documentTitleLabel", constants.resourceType.label, currentLanguageCode)}
          />
          <span className="rounded-full bg-[rgba(5,150,105,0.10)] px-3 py-1 text-xs font-bold text-[var(--brand-emerald-dark)]">{tl("edocSavable")}</span>
        </div>
      </div>
      {/* 상단 메뉴 */}
      <EDocDesignerTopMenu
        mode={mode}
        toggleMode={toggleMode}
        onNewDocument={handleNewDocument}
        onOpenDocument={handleOpenDocument}
        onSaveDocument={handleSaveDocument}
        onDeleteDocument={handleDeleteDocument}
        onAddPage={handleAddPage}
        onDeleteCurrentPage={handleDeleteCurrentPage}
        onExportPdf={handleExportPdf}
        onExportMd={handleExportMd}
        onImportMd={handleImportMd}
        currentPageIdx={currentPageIdx}
        totalPageCount={documentData.pages?.length}
        setCurrentPageIdx={setCurrentPageIdx}
        setAIInputModalOpen={setAIInputModalOpen}
        onUndo={handleUndo}
        onRedo={handleRedo}
      />
      <div className="flex flex-row justify-center bg-[var(--bg)] py-3">
        <ModeToggleButton />
      </div>

      {/* ── PC 레이아웃 (md 이상) ── */}
      <div className="hidden h-screen flex-row bg-[var(--bg)] text-sm md:flex">
        {/* 좌측 컴포넌트 팔레트 */}
        <div className="flex flex-row items-stretch">
          <aside
            style={{ width: isLeftPanelOpen ? leftPanelWidth : 0 }}
            className="flex items-start overflow-auto border-r border-[var(--border)] bg-[var(--surface)]"
          >
            {isLeftPanelOpen && (
              <EDocComponentPalette
                templates={componentTemplates}
                onAddComponent={handleAddComponent}
              />
            )}
          </aside>
          {isLeftPanelOpen && (
            <div
              onMouseDown={handleLeftMouseDown}
              className="w-1 cursor-col-resize bg-[var(--border)] transition-colors hover:bg-[var(--brand-blue)]"
              style={{ userSelect: "none" }}
            />
          )}
          <Button
            onClick={() => setIsLeftPanelOpen((prev) => !prev)}
            className="z-10 flex items-center rounded-none bg-[var(--surface-alt)] px-1"
            title={isLeftPanelOpen ? tl("edocPanelClose") : tl("edocPanelOpen")}
          >
            {isLeftPanelOpen ? "◀" : "▶"}
          </Button>
        </div>

        {/* 중앙 편집 캔버스 */}
        <div className="flex-1 overflow-auto bg-[var(--bg)]">
          {documentData && (
            <h1 className="mx-4 mb-4 text-center text-xl font-bold text-[var(--text)]">
              {documentData.runtime_data.title || constants.emptyString}:{" "}
              {documentData.id}
            </h1>
          )}
          <main
            className="flex-grow pt-10 edoc-designer-canvas"
            style={{
              backgroundColor: documentData.runtime_data.backgroundColor || "#f8f8f8",
              padding: `${documentData.runtime_data.padding}px`,
            }}
          >
            {documentData.pages.map((page, idx) => (
              <div
                key={page.id}
                className="relative w-fit my-1 mx-auto"
                onClick={() => { setCurrentPageIdx(idx); setSelectedComponentId(null); }}
              >
                <div className="flex flex-row justify-around bg-[var(--surface-alt)]">
                  <div className="flex flex-row justify-center items-center gap-2 mt-2">
                    <Button onClick={handleMovePageUp} className="general-text-bg-color mb-1 px-2 py-1 rounded" disabled={currentPageIdx === 0}>▲</Button>
                    <div className="mb-1 font-bold text-[var(--text)]">P{idx + 1}</div>
                    <Button onClick={handleMovePageDown} className="general-text-bg-color mb-1 px-2 py-1 rounded" disabled={currentPageIdx === documentData.pages.length - 1}>▼</Button>
                  </div>
                </div>
                <EDocEditorCanvas
                  documentData={documentData} pageData={page}
                  isSelected={idx === currentPageIdx}
                  onSelect={() => { setCurrentPageIdx(idx); setSelectedComponentId(null); }}
                  selectedComponentId={selectedComponentId}
                  onComponentSelect={handleComponentSelect}
                  onMoveUp={handleMoveComponentUp} onMoveDown={handleMoveComponentDown}
                  onDeleteComponent={handleDeleteComponent} onUpdateComponent={handleUpdateComponent}
                  isViewerMode={isExportingPdf} mode={mode}
                  copiedComponent={copiedComponent} setCopiedComponent={setCopiedComponent}
                  setBindingData={setBindingData} onReorderComponent={handleReorderComponent}
                  onDropPaletteItem={(template, insertIdx) => handleAddComponent(template, insertIdx)}
                />
              </div>
            ))}
          </main>
        </div>

        {/* 오른쪽 속성 편집창 */}
        <div className="flex flex-row items-stretch">
          <Button
            onClick={() => setIsRightPanelOpen((prev) => !prev)}
            className="flex items-center semi-text-bg-color z-10 px-1"
            title={isRightPanelOpen ? tl("edocPanelClose") : tl("edocPanelOpen")}
          >
            {isRightPanelOpen ? "▶" : "◀"}
          </Button>
          {isRightPanelOpen && (
            <div
              onMouseDown={handleMouseDown}
            className="w-1 cursor-col-resize bg-[var(--border)] transition-colors hover:bg-[var(--brand-blue)]"
              style={{ userSelect: "none" }}
            />
          )}
          <aside
            style={{ width: isRightPanelOpen ? rightPanelWidth : 0 }}
            className="flex flex-col justify-start overflow-auto bg-[var(--surface)]"
          >
            {isRightPanelOpen && (
              <>
                <h5 className="mb-4 flex flex-col items-center text-sm font-bold text-[var(--text)]">{tl("edocProperties")}</h5>
                {selectedComponentId !== null && documentData.pages[currentPageIdx]?.components[selectedComponentId] ? (
                  <EDocComponentPropertyEditor
                    component={documentData.pages[currentPageIdx].components[selectedComponentId]}
                    handleUpdateComponent={handleUpdateComponent}
                  />
                ) : (
                  <>
                    <EDocDocumentPropertyEditor
                      runtimeData={documentData.runtime_data}
                      onChangeRuntimeData={(updatedRuntimeData) => setDocumentData((prev) => ({ ...prev, runtime_data: updatedRuntimeData }))}
                    />
                    <EDocPagePropertyEditor
                      runtimeData={documentData.pages[currentPageIdx]?.runtime_data || {}}
                      onChangeRuntimeData={(updatedPageRuntimeData) => setDocumentData((prev) => {
                        const updatedPages = [...prev.pages];
                        updatedPages[currentPageIdx] = { ...updatedPages[currentPageIdx], runtime_data: updatedPageRuntimeData };
                        return { ...prev, pages: updatedPages };
                      })}
                    />
                  </>
                )}
              </>
            )}
          </aside>
        </div>
      </div>

      {/* ── 모바일 레이아웃 (md 미만) ── */}
      <div className="flex min-h-0 flex-1 flex-col bg-[var(--bg)] text-sm md:hidden">
        {/* 캔버스 영역 */}
        <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain pb-4">
          {documentData && (
            <h1 className="mx-2 mb-2 text-center text-base font-bold text-[var(--text)]">
              {documentData.runtime_data.title || constants.emptyString}
            </h1>
          )}
          <main
            className="edoc-designer-canvas"
            style={{
              backgroundColor: documentData.runtime_data.backgroundColor || "#f8f8f8",
              padding: `${documentData.runtime_data.padding}px`,
            }}
          >
            {documentData.pages.map((page, idx) => (
              <div
                key={page.id}
                className="relative w-full my-1"
                onClick={() => { setCurrentPageIdx(idx); setSelectedComponentId(null); }}
              >
                <div className="flex flex-row justify-center gap-2 bg-[var(--surface-alt)] py-1">
                  <Button onClick={handleMovePageUp} className="general-text-bg-color px-2 py-0 rounded text-xs" disabled={currentPageIdx === 0}>▲</Button>
                  <span className="text-xs font-bold text-[var(--text)]">P{idx + 1}</span>
                  <Button onClick={handleMovePageDown} className="general-text-bg-color px-2 py-0 rounded text-xs" disabled={currentPageIdx === documentData.pages.length - 1}>▼</Button>
                </div>
                <EDocEditorCanvas
                  documentData={documentData} pageData={page}
                  isSelected={idx === currentPageIdx}
                  onSelect={() => { setCurrentPageIdx(idx); setSelectedComponentId(null); }}
                  selectedComponentId={selectedComponentId}
                  onComponentSelect={handleComponentSelect}
                  onMoveUp={handleMoveComponentUp} onMoveDown={handleMoveComponentDown}
                  onDeleteComponent={handleDeleteComponent} onUpdateComponent={handleUpdateComponent}
                  isViewerMode={isExportingPdf} mode={mode}
                  copiedComponent={copiedComponent} setCopiedComponent={setCopiedComponent}
                  setBindingData={setBindingData} onReorderComponent={handleReorderComponent}
                  onDropPaletteItem={(template, insertIdx) => handleAddComponent(template, insertIdx)}
                  scalable={true}
                />
              </div>
            ))}
          </main>
        </div>

        {/* 하단 탭바 */}
        <div className="flex shrink-0 flex-row border-t border-[var(--border)] bg-[var(--surface)]" style={{ paddingBottom: "env(safe-area-inset-bottom, 0px)" }}>
          <button
            onClick={() => setMobilePanel(mobilePanel === "palette" ? null : "palette")}
            className={`flex-1 py-2 text-xs font-bold ${mobilePanel === "palette" ? "bg-[image:var(--brand-gradient)] text-white" : "text-[var(--text)]"}`}
          >
            {tl("edocMobilePalette")}
          </button>
          <button
            onClick={() => setMobilePanel(null)}
            className={`flex-1 py-2 text-xs font-bold ${mobilePanel === null ? "bg-[image:var(--brand-gradient)] text-white" : "text-[var(--text)]"}`}
          >
            {tl("edocMobileEdit")}
          </button>
          <button
            onClick={() => setMobilePanel(mobilePanel === "properties" ? null : "properties")}
            className={`flex-1 py-2 text-xs font-bold ${mobilePanel === "properties" ? "bg-[image:var(--brand-gradient)] text-white" : "text-[var(--text)]"}`}
          >
            {tl("edocProperties")}
          </button>
        </div>

        {/* 모바일 오버레이 패널 */}
        {mobilePanel && (
          <div className="fixed inset-0 z-50 flex flex-col justify-end">
            <div className="absolute inset-0 bg-black bg-opacity-40" onClick={() => setMobilePanel(null)} />
            <div className="relative overflow-auto rounded-t-2xl bg-[var(--surface)]" style={{ maxHeight: "70vh" }}>
              <div className="flex items-center justify-between border-b border-[var(--border)] px-4 py-3">
                <span className="font-bold text-[var(--text)]">{mobilePanel === "palette" ? tl("edocComponentPalette") : tl("edocProperties")}</span>
                <button onClick={() => setMobilePanel(null)} className="text-xl font-bold text-[var(--text)]" aria-label={commonFunctions.getResourceByLanguage("close", constants.resourceType.label, currentLanguageCode)}>✕</button>
              </div>
              {mobilePanel === "palette" && (
                <EDocComponentPalette
                  templates={componentTemplates}
                  onAddComponent={(component) => { handleAddComponent(component); setMobilePanel(null); }}
                />
              )}
              {mobilePanel === "properties" && (
                <div className="p-2">
                  {selectedComponentId !== null && documentData.pages[currentPageIdx]?.components[selectedComponentId] ? (
                    <EDocComponentPropertyEditor
                      component={documentData.pages[currentPageIdx].components[selectedComponentId]}
                      handleUpdateComponent={handleUpdateComponent}
                    />
                  ) : (
                    <>
                      <EDocDocumentPropertyEditor
                        runtimeData={documentData.runtime_data}
                        onChangeRuntimeData={(updatedRuntimeData) => setDocumentData((prev) => ({ ...prev, runtime_data: updatedRuntimeData }))}
                      />
                      <EDocPagePropertyEditor
                        runtimeData={documentData.pages[currentPageIdx]?.runtime_data || {}}
                        onChangeRuntimeData={(updatedPageRuntimeData) => setDocumentData((prev) => {
                          const updatedPages = [...prev.pages];
                          updatedPages[currentPageIdx] = { ...updatedPages[currentPageIdx], runtime_data: updatedPageRuntimeData };
                          return { ...prev, pages: updatedPages };
                        })}
                      />
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 메시지 박스 */}
      <BrunnerMessageBox />
    </>
  );
}
