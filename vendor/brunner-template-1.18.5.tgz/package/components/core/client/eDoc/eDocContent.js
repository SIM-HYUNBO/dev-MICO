"use strict";
import { useState, useEffect } from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import EDocEditorCanvas from "@/components/core/client/eDoc/eDocEditorCanvas";
import BrunnerBoard from "@/components/core/client/brunnerBoard";

export default function EDocContent({
  argDocumentId,
  argDocumentData,
  argRuntimeData,
  isViewerMode = false,
}) {
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");

  const [documentData, setDocumentData] = useState(null);
  const [bindingData, setBindingData] = useState({});
  const [isDocReady, setIsDocReady] = useState(false);

  useEffect(() => {
    setCurrentLoginUserId(userInfo.getLoginUserId());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  /**
   * runtimeData → bindingData
   */
  useEffect(() => {
    if (argRuntimeData) {
      setBindingData(argRuntimeData);
    }
  }, [argRuntimeData]);

  /**
   * document 로딩
   */
  useEffect(() => {
    async function fetchDocData(documentId) {
      if (!documentId) return;
      const loginUserId = userInfo.getLoginUserId();
      const languageCode = userInfo.getCurrentLanguageCode();
      setCurrentLoginUserId(loginUserId);
      setCurrentLanguageCode(languageCode);

      const docData = await commonFunctions.getDocumentData(
          languageCode,
        loginUserId,
        documentId,
      );

      setDocumentData(docData);
    }

    if (!argDocumentData) fetchDocData(argDocumentId);
    else setDocumentData(argDocumentData);
  }, [argDocumentId, argDocumentData]);

  /**
   * document 준비 완료 플래그
   */
  useEffect(() => {
    if (documentData?.pages) {
      setIsDocReady(true);
    }
  }, [documentData]);

  /**
   * 🔥 binding → document 반영 (무한루프 방지)
   */
  useEffect(() => {
    if (!isDocReady) return;
    if (!bindingData || Object.keys(bindingData).length === 0) return;

    setDocumentData((prev) => {
      if (!prev?.pages) return prev;

      let changed = false;

      const newPages = prev.pages.map((page) => {
        const newComponents = page.components.map((component) => {
          const key = component?.runtime_data?.bindingKey;
          if (!key) return component;

          const value = bindingData[key];
          if (value === undefined) return component;

          let updatedRuntime = { ...component.runtime_data };
          let localChanged = false;

          /**
           * patch 방식 업데이트
           */
          const updateRuntime = (patchOrComponent, key, value) => {
            let patch = null;

            // ✅ 신 방식
            if (typeof patchOrComponent === "object" && key === undefined) {
              patch = patchOrComponent;
            }
            // ✅ 구 방식 대응
            else if (typeof key === "string") {
              patch = { [key]: value };
            }

            if (!patch) return;

            Object.entries(patch).forEach(([k, v]) => {
              const newValue = Array.isArray(v) ? [...v] : v;

              if (updatedRuntime[k] !== newValue) {
                updatedRuntime[k] = newValue;
                localChanged = true;
              }
            });
          };

          commonFunctions.setComponentBindingValue(
            component,
            value,
            updateRuntime,
          );

          if (!localChanged) return component;

          changed = true;

          return {
            ...component,
            runtime_data: updatedRuntime,
          };
        });

        return { ...page, components: newComponents };
      });

      if (!changed) return prev;
      return { ...prev, pages: newPages };
    });
  }, [bindingData, isDocReady]);

  /**
   * 로딩 상태
   */
  if (!documentData) {
    return (
      <div className="flex min-h-[80vh] items-center justify-center">
        No document loaded ...
      </div>
    );
  }

  /**
   * 렌더
   */
  return (
    <div className="w-full">
      <div
        className="w-full"
        style={{
          touchAction: "pan-y pinch-zoom",
          paddingBottom: "max(14rem, env(safe-area-inset-bottom) + 12rem)",
        }}
      >
        <div className="w-full">
          {documentData.pages?.map((page) => (
            <EDocEditorCanvas
              key={page.id}
              pageData={page}
              isViewerMode={isViewerMode}
              mode="runtime"
              scalable={true}
              documentData={documentData}
              onUpdateComponent={(updatedComponent) => {
                setDocumentData((prevDoc) => {
                  const newPages = prevDoc.pages.map((p) => {
                    const newComponents = p.components.map((comp) =>
                      comp.id === updatedComponent.id ? updatedComponent : comp,
                    );
                    return { ...p, components: newComponents };
                  });

                  return { ...prevDoc, pages: newPages };
                });
              }}
              setBindingData={setBindingData}
            />
          ))}
        </div>

        <div className="flex w-full mt-10 px-2">
          <BrunnerBoard boardType={`${documentData.id}`} />
        </div>
      </div>
    </div>
  );
}
