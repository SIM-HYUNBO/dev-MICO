import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { Input, Button, Select, Table } from "antd";

import * as TextComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Text";
import * as InputComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Input";
import * as ImageComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Image";
import * as TableComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Table";
import * as CheckListComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_CheckList";
import * as ButtonComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Button";
import * as VideoComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Video";
import * as LinkTextComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_LinkText";
import * as LottieComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Lottie";
import * as CardComponent from "@/components/core/client/eDoc/eDocComponent/eDocComponent_Card";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

/*
 * EDocPropertyEditor.js
 * EDoc 컴포넌트의 속성을 편집하는 컴포넌트
 */
export default function EDocComponentPropertyEditor({
  component,
  handleUpdateComponent,
}) {
  if (!component) return <p>{L("eDocSelectComponent")}</p>;

  const updateRuntimeDataByPropertyEeditor = (key, value) => {
    if (key === "runtime_data") {
      // 전체 runtime_data 교체
      handleUpdateComponent({
        ...component,
        runtime_data: value,
      });
    } else {
      const newRuntimeData = {
        ...component.runtime_data,
        [key]: value,
      };

      handleUpdateComponent({
        ...component,
        runtime_data: newRuntimeData,
      });
    }
  };

  const GRID_COL_OPTIONS = [
    { value: 1,  pct: 8   },
    { value: 2,  pct: 17  },
    { value: 3,  pct: 25  },
    { value: 4,  pct: 33  },
    { value: 5,  pct: 42  },
    { value: 6,  pct: 50  },
    { value: 7,  pct: 58  },
    { value: 8,  pct: 67  },
    { value: 9,  pct: 75  },
    { value: 10, pct: 83  },
    { value: 11, pct: 92  },
    { value: 12, pct: 100 },
  ];

  const renderWidthPropertyByPropertyEditor = () => (
    <>
      <label className="block mt-2 mb-1">{L("eDocWidthGridCols")}</label>
      <Select
        value={component.runtime_data?.gridCol ?? 12}
        onChange={(value) =>
          updateRuntimeDataByPropertyEeditor("gridCol", value)
        }
        className="w-full mb-2"
      >
        {GRID_COL_OPTIONS.map(({ value, pct }) => (
          <Select.Option key={value} value={value}>
            {`${value}${L("eDocColumnUnit")} (${pct}%)`}
          </Select.Option>
        ))}
      </Select>
    </>
  );

  const renderForceNewLinePropertyByPropertyEditor = () => (
    <div className="mt-2 mb-2">
      <label className="inline-flex items-center">
        <input
          type="checkbox"
          checked={!!component.runtime_data?.forceNewLine}
          onChange={(e) =>
            updateRuntimeDataByPropertyEeditor("forceNewLine", e.target.checked)
          }
          className="mr-2"
        />
        {L("eDocForceNewLine")}
      </label>
    </div>
  );

  const renderPositionAlignPropertyByPropertyEditor = () => (
    <>
      <label>{L("eDocAlign")}</label>
      <Select
        value={component.runtime_data?.positionAlign || "left"}
        onChange={(value) =>
          updateRuntimeDataByPropertyEeditor("positionAlign", value)
        }
        className="w-full h-12 border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
      >
        <option value="left">{L("eDocAlignLeft")}</option>
        <option value="center">{L("eDocAlignCenter")}</option>
        <option value="right">{L("eDocAlignRight")}</option>
      </Select>
    </>
  );

  const renderComponentProperty = (component) => {
    switch (component.type) {
      case constants.edocComponentType._TEXT:
        return TextComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );
      case constants.edocComponentType._TABLE:
        return TableComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );
      case constants.edocComponentType._INPUT:
        return InputComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );
      case constants.edocComponentType._IMAGE:
        return ImageComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );
      case constants.edocComponentType._CHECKLIST:
        return CheckListComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );
      case constants.edocComponentType._BUTTON:
        return ButtonComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );
      case constants.edocComponentType._VIDEO:
        return VideoComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );
      case constants.edocComponentType._LINKTEXT:
        return LinkTextComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );
      case constants.edocComponentType._LOTTIE:
        return LottieComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );
      case constants.edocComponentType._CARD:
        return CardComponent.renderProperty(
          component,
          updateRuntimeDataByPropertyEeditor,
          renderWidthPropertyByPropertyEditor,
          renderForceNewLinePropertyByPropertyEditor,
          renderPositionAlignPropertyByPropertyEditor,
        );

      default:
        return <p>{L("eDocPropertyNotSupported")}</p>;
    }
  };

  return renderComponentProperty(component);
}
