"use client";

import DropdownMenu from "@/components/core/client/frames/dropdownMenu";
import BrandWordmark from "@/components/core/client/ui/BrandWordmark";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const L = (key) =>
  commonFunctions.getResourceByLanguage(key, constants.resourceType.label, userInfo.getCurrentLanguageCode());

function BackIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M15 18l-6-6 6-6" />
    </svg>
  );
}

export default function AppHeader({ title, onBack, right, children }) {
  return (
    <header className="relative sticky top-0 z-40 hidden h-16 w-full items-center justify-between border-b bg-[var(--surface)] px-5 md:flex" style={{ borderColor: "var(--border)" }}>
      <div className="flex min-w-0 items-center gap-3">
        {onBack && (
          <button
            type="button"
            onClick={onBack}
            aria-label={L("back")}
            className="theme-icon-button inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--radius-md)] border transition hover:opacity-80 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-blue)]"
          >
            <BackIcon />
          </button>
        )}
        {title ? (
          <span className="truncate text-base font-bold text-[var(--text)]">{title}</span>
        ) : (
          <BrandWordmark className="text-xl font-extrabold" />
        )}
        {children}
      </div>

      <div className="flex shrink-0 items-center gap-2">
        {right}
        <DropdownMenu />
      </div>
    </header>
  );
}
