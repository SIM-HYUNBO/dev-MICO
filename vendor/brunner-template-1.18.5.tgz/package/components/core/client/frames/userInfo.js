"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import { useRouter } from "next/navigation";
import SignoutButton from "@/components/core/client/frames/signoutButton";
import { RequestServer } from "@/components/core/client/requestServer";

const readStoredUserInfo = () => {
  if (typeof window === "undefined") return null;
  try {
    const userInfoStr = localStorage.getItem("userInfo");
    if (!userInfoStr) return null;
    return JSON.parse(userInfoStr);
  } catch (e) {
    console.warn("[userInfo] invalid stored userInfo removed", e);
    localStorage.removeItem("userInfo");
    return null;
  }
};

// 로그아웃 시 지워야 할 세션 상태.
//
// adminMode 는 "지금 관리자 모드로 보고 있는지"라는 세션 설정인데, 예전에는
// userInfo 만 지우고 이 값은 남겨 뒀다. 그래서 관리자 모드를 한 번 끄면
// 로그아웃·재로그인을 해도 계속 꺼진 채였고, admin_flag 가 DB 에서 켜져
// 있어도 관리자 메뉴가 영영 나오지 않았다. 같은 브라우저에서 다른 사람이
// 로그인해도 그 사람 메뉴까지 숨어 버린다.
export const clearSessionState = () => {
  if (typeof window === "undefined") return;
  localStorage.removeItem("userInfo");
  localStorage.removeItem("adminMode");
};

// localStorage 의 userInfo 는 로그인 응답의 사본이라 DB 가 바뀌어도 따라가지 않는다.
// (관리자 권한을 DB 에서 켜도 재로그인 전까지 관리자 메뉴가 안 나오던 원인)
// 서버에서 계정 정보를 다시 읽어 덮어쓰고, 바뀐 게 있으면 메뉴를 다시 그리게 한다.
// 세션 토큰이 없는 예전 로그인이나 네트워크 실패에서는 아무것도 하지 않는다.
export const refreshUserInfo = async () => {
  if (typeof window === "undefined") return null;

  const stored = readStoredUserInfo();
  if (!stored?.userId || !stored?.sessionToken) return stored;

  const jResponse = await RequestServer({
    commandName: constants.commands.SECURITY_REFRESH_SESSION,
        userId: stored.userId,
    sessionToken: stored.sessionToken,
  });

  // 갱신에 실패하면 저장된 사본을 그대로 둔다.
  //
  // 한때 세션 검증 실패를 계정 삭제로 보고 여기서 로그아웃시켰는데, 그러면
  // 세션 조회가 어떤 이유로든 어긋나는 순간 권한만 사라지고 로그인 상태는
  // 남는 어중간한 화면이 된다. 갱신은 어디까지나 최신화이지 인증이 아니다.
  if (jResponse?.error_code !== constants.errorCode.Success) return stored;

  const merged = {
    ...stored,
    userName: jResponse.userName,
    emailId: jResponse.emailId,
    adminFlag: jResponse.adminFlag,
    userType: jResponse.userType,
    registerNo: jResponse.registerNo,
    registerName: jResponse.registerName,
    profileImageBase64: jResponse.profileImageBase64,
  };

  const changed = ["userName", "emailId", "adminFlag", "userType", "registerNo", "registerName"].some(
    (k) => stored[k] !== merged[k],
  );

  localStorage.setItem("userInfo", JSON.stringify(merged));
  if (changed) {
    window.dispatchEvent(new CustomEvent("userChanged", { detail: { refreshed: true } }));
    window.dispatchEvent(new CustomEvent("menuChanged"));
  }
  return merged;
};

export default function UserInfo({ handleLogout }) {
  const router = useRouter();

  const [currentSystemCode, setCurrentSystemCode] = useState(undefined);
  const [userName, setUserName] = useState(constants.emptyString);
  const [profileImage, setProfileImage] = useState(undefined);
  const [mounted, setMounted] = useState(false);
  const [userId, setUserId] = useState("");

  // 최초 렌더링 시 userInfo 로딩
  useEffect(() => {
    setMounted(true);

    const checkUserInfo = async () => {
      const userInfo = readStoredUserInfo();

      if (!userInfo) {
        forceLogout();
        return;
      }

      setUserId(userInfo?.userId || "");

      if (!userInfo?._txnId && !userInfo?.sessionToken) {
        forceLogout();
        return;
      }

      // ✅ 상태 업데이트만 수행
      setUserName(userInfo?.userName || constants.emptyString);
      setProfileImage(userInfo?.profileImageBase64);

      // 저장된 사본은 로그인 시점 기준이라 오래됐을 수 있다. 서버에서 다시 읽어
      // 맞춘다 — 권한이 바뀌었으면 여기서 메뉴가 다시 그려진다.
      try {
        const fresh = await refreshUserInfo();
        if (fresh) {
          setUserName(fresh.userName || constants.emptyString);
          setProfileImage(fresh.profileImageBase64);
        }
      } catch (e) {
        console.warn("[userInfo] 계정 정보 갱신 실패", e);
      }
    };

    checkUserInfo();
  }, []);

  // 프로필 업데이트 이벤트 감지 → 메뉴 즉시 반영
  useEffect(() => {
    const handleUserChanged = (e) => {
      // 로그아웃. 예전에는 forceLogout 이 처리한다며 그냥 넘겼는데, 정작
      // forceLogout 은 저장소만 비우고 화면 상태는 그대로 뒀다. 그래서
      // 로그아웃해도 메뉴에 이름이 남아 있었다.
      if (e.detail?.userId === null) {
        setUserId("");
        setUserName(constants.emptyString);
        setProfileImage(undefined);
        return;
      }
      const info = readStoredUserInfo();
      if (!info) return;
      setProfileImage(info?.profileImageBase64);
      setUserName(info?.userName || constants.emptyString);
    };
    window.addEventListener("userChanged", handleUserChanged);
    return () => window.removeEventListener("userChanged", handleUserChanged);
  }, []);

  const forceLogout = async () => {
    clearSessionState();
    setUserId("");
    setUserName(constants.emptyString);
    setProfileImage(undefined);
    window.dispatchEvent(
      new CustomEvent("userChanged", { detail: { userId: null } }),
    );
    try {
      await handleLogout?.();
    } catch (e) {
      console.warn("[userInfo] menu refresh failed after logout", e);
    }
    router.replace("/mainPages/signin");
  };

  function getElapsedSeconds(txnId) {
    if (!txnId) return 0;

    // 앞 14자리만 사용: YYYYMMDDHHMMSS
    const y = parseInt(txnId.slice(0, 4), 10);
    const m = parseInt(txnId.slice(4, 6), 10) - 1; // JS 월은 0~11
    const d = parseInt(txnId.slice(6, 8), 10);
    const h = parseInt(txnId.slice(8, 10), 10);
    const min = parseInt(txnId.slice(10, 12), 10);
    const s = parseInt(txnId.slice(12, 14), 10);

    const txnDateUTC = new Date(Date.UTC(y, m, d, h, min, s));
    const nowUTC = new Date(Date.now()); // 현재 시간
    const elapsedMs = nowUTC.getTime() - txnDateUTC.getTime();

    return Math.floor(elapsedMs / 1000); // 초 단위
  }

  if (!mounted) return null;

  return (
    <div className="relative mt-2 h-10 w-full">
      {/* 가운데 고정: 프로필 이미지 + 사용자 이름 */}
      <div className="absolute inset-y-0 left-1/2 flex max-w-[190px] -translate-x-1/2 items-center gap-2">
        {userId && (
          <Link
            href="/mainPages/userAccount"
            className="flex min-w-0 items-center gap-2 rounded-full px-2 py-1 text-center text-[var(--text)] transition hover:bg-[var(--surface)]"
          >
            {/* 프로필 이미지 */}
            {profileImage && (
              <img
                src={profileImage}
                alt="profile"
                className="h-7 w-7 shrink-0 rounded-full border border-[var(--border)] object-cover"
              />
            )}

            {/* 사용자 이름 */}
            <span className="truncate text-sm font-semibold">{userName}</span>
          </Link>
        )}
      </div>

      {/* 오른쪽 고정: 로그아웃 버튼 */}
      <div className="absolute inset-y-0 right-0 flex items-center pr-1">
        <SignoutButton handleLogout={handleLogout} />
      </div>
    </div>
  );
}

// helper 함수들

export const getLoginUserId = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.userId || constants.emptyString;
    } catch {
      return constants.emptyString;
    }
  }
  return constants.emptyString;
};

export const getLoginSessionToken = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.sessionToken || constants.emptyString;
    } catch {
      return constants.emptyString;
    }
  }
  return constants.emptyString;
};

export const getLoginUserName = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.userName || constants.emptyString;
    } catch {
      return constants.emptyString;
    }
  }
  return constants.emptyString;
};

export const getLoginEmailId = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.emailId || userInfo?.email_id || constants.emptyString;
    } catch {
      return constants.emptyString;
    }
  }
  return constants.emptyString;
};

export const getLoginUserType = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.userType || constants.emptyString;
    } catch {
      return constants.emptyString;
    }
  }
  return constants.emptyString;
};

export const getLoginUserRegisterNo = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.registerNo || constants.emptyString;
    } catch {
      return constants.emptyString;
    }
  }
  return constants.emptyString;
};

export const getLoginUserRegisterName = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.registerName || constants.emptyString;
    } catch {
      return constants.emptyString;
    }
  }
  return constants.emptyString;
};

// adminFlag: 관리자 겸용 계정 여부 (계정 속성)
// adminMode: 현재 관리자 모드로 동작 중인지 (세션 설정, localStorage "adminMode" 키)
export const isAdminUser = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      if (!userInfo?.adminFlag) return false;
      const mode = localStorage.getItem("adminMode");
      // adminMode 키가 없으면 최초 로그인 시 기본값 true (기존 동작 유지)
      return mode === null ? true : mode === "true";
    } catch {
      return false;
    }
  }
  return false;
};

export const isAdminCapable = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return !!userInfo?.adminFlag;
    } catch {
      return false;
    }
  }
  return false;
};

export const setAdminMode = (enabled) => {
  if (typeof window !== "undefined") {
    localStorage.setItem("adminMode", String(enabled));
    window.dispatchEvent(new CustomEvent("userChanged", { detail: { adminModeChanged: true } }));
  }
};

export const isLogin = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return !!userInfo?.userId;
    } catch {
      return false;
    }
  }
  return false;
};

export const getCurrentSystemCode = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.systemCode;
    } catch {
      return constants.emptyString;
    }
  }
  return constants.emptyString;
};

export const getCurrentSystemName = () => ``;

export const getUserParams = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return !!userInfo?.userParams ? userInfo.userParams : {};
    } catch {
      return false;
    }
  }
};

export const getMenuItems = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.menuItems;
    } catch {
      return undefined;
    }
  }
  return undefined;
};

export const getLoginProfileImage = () => {
  if (typeof window !== "undefined") {
    try {
      const userInfoStr = localStorage.getItem("userInfo");
      const userInfo = JSON.parse(userInfoStr);
      return userInfo?.profileImageBase64;
    } catch {
      return undefined;
    }
  }
  return undefined;
};

// Personal 유형이면 registerNo(생년월일 6자리 YYMMDD)로 만 19세 이상 여부 확인
export const hasBirthDate = () => {
  if (typeof window === "undefined") return false;
  try {
    const userInfoStr = localStorage.getItem("userInfo");
    const userInfo = JSON.parse(userInfoStr);
    if (userInfo?.userType !== constants.userType.Personal) return true;
    const raw = (userInfo?.registerNo || "").replace(/[^0-9]/g, "");
    if (raw.length < 6) return false;
    const mm = parseInt(raw.substring(2, 4), 10);
    const dd = parseInt(raw.substring(4, 6), 10);
    return mm >= 1 && mm <= 12 && dd >= 1 && dd <= 31;
  } catch {
    return false;
  }
};

export const isAdult = () => {
  if (typeof window === "undefined") return false;
  try {
    const userInfoStr = localStorage.getItem("userInfo");
    const userInfo = JSON.parse(userInfoStr);
    // Personal이 아닌 경우(법인 등)는 통과
    if (userInfo?.userType !== constants.userType.Personal) return true;

    const raw = (userInfo?.registerNo || "").replace(/[^0-9]/g, "");
    if (raw.length < 6) return false;

    const yy = parseInt(raw.substring(0, 2), 10);
    const mmRaw = parseInt(raw.substring(2, 4), 10);
    const ddRaw = parseInt(raw.substring(4, 6), 10);
    if (mmRaw < 1 || mmRaw > 12 || ddRaw < 1 || ddRaw > 31) return false;
    const mm = mmRaw - 1;
    const dd = parseInt(raw.substring(4, 6), 10);

    // 성별 자리 없이 연도만으로 세기 추정: 현재 연도 끝 2자리보다 크면 1900년대
    const currentYY = new Date().getFullYear() % 100;
    const century = yy > currentYY ? 1900 : 2000;

    const fullYear = century + yy;
    const birth = new Date(fullYear, mm, dd);
    if (isNaN(birth.getTime())) return false;

    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate()))
      age--;

    return age >= 19;
  } catch {
    return false;
  }
};

export const getCurrentLanguageCode = () => {
  if (typeof window !== "undefined") {
    try {
      const lang = navigator.language || navigator.userLanguage;
      if (lang.startsWith("ja")) return "ja-JP";
      if (lang.startsWith("ko")) return "ko-KR";
      // 중국어는 별도 선택 화면 없이 브라우저 언어로만 판별한다.
      // 아직 번역되지 않은 문구는 getResourceByLanguage가 en-US로 폴백한다.
      if (lang.startsWith("zh")) return "zh-CN";
      return "en-US";
    } catch {
      return "en-US";
    }
  }
};
