"use client";

import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

export function getIsDarkMode() {
  const { resolvedTheme } = useTheme();
  return resolvedTheme === "dark";
}

/**
 * 라이트·다크 전환 버튼.
 *
 * resolvedTheme 을 보는 이유
 *   next-themes 의 theme 은 기본값이 "system" 이다. 그것을 "dark" 와 비교하면
 *   시스템 설정이 다크라 화면이 새까만데도 비교는 거짓이 되어, 지금 켜져 있는
 *   것과 반대되는 아이콘이 떴다. resolvedTheme 은 실제로 적용된 값이라 화면과
 *   언제나 일치한다.
 *
 * 마운트 뒤에야 그리는 이유
 *   서버에서는 사용자의 테마를 알 수 없다. 마운트 전에 아이콘을 정하면 첫 그림이
 *   틀리고, 곧바로 바뀌면서 깜빡인다. 자리만 잡아 두고 값이 정해지면 그린다.
 *
 * 테두리를 두른 이유
 *   전에는 배경도 테두리도 없는 20px 아이콘이라 눌러도 되는 것으로 보이지 않았다.
 */
export default function DarkModeToggleButton() {
  const { resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  const isDark = resolvedTheme === "dark";
  const label = commonFunctions.getResourceByLanguage(
    "appearanceMode",
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

  const shell =
    "inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[var(--border)] bg-[var(--surface)] text-[var(--text-muted)] transition hover:border-[var(--border-strong)] hover:text-[var(--text)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-blue)]";

  // 값이 정해지기 전에는 자리만 잡는다. 크기가 같아야 레이아웃이 흔들리지 않는다.
  if (!mounted) return <span className={shell} aria-hidden="true" />;

  return (
    <button
      type="button"
      className={shell}
      onClick={() => setTheme(isDark ? "light" : "dark")}
      aria-label={label}
      title={label}
      aria-pressed={isDark}
    >
      {isDark ? (
        /* 달 — 지금 다크. 누르면 라이트로 간다. */
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.6"
          stroke="currentColor"
          className="h-5 w-5"
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M21.752 15.002A9.718 9.718 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 0 0 9.002-5.998z"
          />
        </svg>
      ) : (
        /* 해 — 지금 라이트. 누르면 다크로 간다. */
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.6"
          stroke="currentColor"
          className="h-5 w-5"
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M12 3v2.25m6.364.386-1.591 1.591M21 12h-2.25m-.386 6.364-1.591-1.591M12 18.75V21m-4.773-4.227-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0z"
          />
        </svg>
      )}
    </button>
  );
}
