"use client";

import { useRouter } from "next/router";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

function BackIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M15 18l-6-6 6-6" />
    </svg>
  );
}

export default function MTopBar({ title, back, right }) {
  const router = useRouter();

  const handleBack = () => {
    if (typeof back === "function") {
      back();
      return;
    }
    router.back();
  };

  return (
    <header className="sticky top-0 z-40 flex h-[54px] w-full items-center justify-between border-b bg-[var(--surface)] px-3 md:hidden" style={{ borderColor: "var(--border)" }}>
      <div className="flex min-w-0 items-center gap-2">
        {back && (
          <button
            type="button"
            onClick={handleBack}
            aria-label={commonFunctions.getResourceByLanguage("back", constants.resourceType.label, userInfo.getCurrentLanguageCode?.() || "ko-KR")}
            className="theme-icon-button inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-[var(--radius-md)] border transition hover:opacity-80"
          >
            <BackIcon />
          </button>
        )}
        <span className="truncate text-[15px] font-bold text-[var(--text)]">{title}</span>
      </div>
      <div className="flex shrink-0 items-center gap-2">{right}</div>
    </header>
  );
}
