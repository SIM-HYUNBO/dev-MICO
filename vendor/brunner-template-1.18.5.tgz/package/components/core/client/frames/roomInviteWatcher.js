"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/router";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";
import { getSocket } from "@/lib/socket";

// ChatClient(wsChatClient)가 자체 초대 모달을 처리하는 페이지 — 중복 표시 방지
const CHAT_CLIENT_PAGES = [
  "/mainPages/chatRoom",
  "/mainPages/userFriendManagement",
];

/**
 * 전역 채팅방 초대 감시 컴포넌트 (Layout에 마운트)
 * 채팅 화면이 아닌 모든 화면(홈 방 목록 포함)에서도
 * 소켓 연결 유지 + 초대 수신 + 수락/거절 모달 표시를 담당한다.
 */
export default function RoomInviteWatcher() {
  const router = useRouter();
  const [pendingInvites, setPendingInvites] = useState([]);
  const [languageCode, setLanguageCode] = useState(null);
  const [currentUserId, setCurrentUserId] = useState(null);
  // 비로그인 방문자는 소켓을 연결하지 않음 — 로그인 후 effect에서 lazy 연결
  const socketRef = useRef(null);

  const tl = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.label,
      languageCode,
    );
  const tm = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.message,
      languageCode,
    );

  // 로그인 상태 추적
  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode());
    setCurrentUserId(userInfo.getLoginUserId() || null);

    const handleUserChanged = ({ detail }) => {
      setCurrentUserId(detail?.userId || null);
    };
    window.addEventListener("userChanged", handleUserChanged);
    return () => window.removeEventListener("userChanged", handleUserChanged);
  }, []);

  // 미처리 초대 조회 + 소켓 identify + 실시간 초대 수신
  useEffect(() => {
    if (!currentUserId) {
      setPendingInvites([]);
      return;
    }
    if (!socketRef.current) socketRef.current = getSocket();
    const socket = socketRef.current;

    const systemCode = userInfo.getCurrentSystemCode();
    const cacheKey = `pendingInvites_${currentUserId}`;

    const fetchPendingInvites = () => {
      RequestServer({
        commandName: constants.commands.CHATROOM_GET_PENDING_INVITES,
                loginUserId: currentUserId,
      }).then((res) => {
        const invites = res.error_code === constants.errorCode.Success ? (res.invites || []) : [];
        try {
          localStorage.setItem(cacheKey, JSON.stringify(invites));
        } catch {}
        setPendingInvites(invites);
      });
    };

    fetchPendingInvites();

    // 방 입장 전에도 notifyInvited 수신 가능하도록 userId 등록
    const identify = () => socket.emit("identify", { userId: currentUserId });
    socket.on("connect", identify);
    if (socket.connected) identify();

    const onNewRoomInvite = ({ inviteId, roomId, roomName, inviterName }) => {
      if (!inviteId) return; // inviteId 없음 = 방 생성 알림 — 초대 팝업 불필요
      setPendingInvites((prev) => {
        if (prev.some((i) => String(i.invite_id) === String(inviteId)))
          return prev;
        return [
          ...prev,
          {
            invite_id: inviteId,
            room_id: roomId,
            room_name: roomName,
            inviter_name: inviterName,
          },
        ];
      });
    };
    socket.on(constants.websocketMessageType.newRoomInvite, onNewRoomInvite);

    // 푸시 알림 클릭 시 SW 메시지로 초대 데이터 수신
    const onSwMessage = (e) => {
      if (e.data?.type !== "NOTIFICATION_CLICK") return;
      const inv = e.data.inviteData;
      if (inv?.inviteId) {
        setPendingInvites((prev) => {
          if (prev.some((i) => String(i.invite_id) === String(inv.inviteId)))
            return prev;
          return [
            ...prev,
            {
              invite_id: inv.inviteId,
              room_id: inv.roomId,
              room_name: inv.roomName,
              inviter_id: inv.inviterId,
              inviter_name: inv.inviterName,
            },
          ];
        });
      }
      fetchPendingInvites();
    };
    navigator.serviceWorker?.addEventListener("message", onSwMessage);

    return () => {
      socket.off("connect", identify);
      socket.off(constants.websocketMessageType.newRoomInvite, onNewRoomInvite);
      navigator.serviceWorker?.removeEventListener("message", onSwMessage);
    };
  }, [currentUserId]);

  // 앱이 닫혀있다 열릴 때 SW가 URL 파라미터로 초대 데이터를 전달한 경우
  // (채팅 페이지에서는 wsChatClient가 직접 파라미터를 소비하므로 건드리지 않음)
  useEffect(() => {
    if (!currentUserId) return;
    if (CHAT_CLIENT_PAGES.includes(router.pathname)) return;
    const urlParams = new URLSearchParams(window.location.search);
    const inviteIdParam = urlParams.get("inviteId");
    if (!inviteIdParam) return;

    setPendingInvites((prev) => {
      if (prev.some((i) => String(i.invite_id) === String(inviteIdParam)))
        return prev;
      return [
        ...prev,
        {
          invite_id: inviteIdParam,
          room_id: urlParams.get("roomId"),
          room_name: urlParams.get("roomName"),
          inviter_id: urlParams.get("inviterId"),
          inviter_name: urlParams.get("inviterName"),
        },
      ];
    });
    // inviteId 관련 파라미터만 제거 (roomId 등 다른 파라미터 동작 보존)
    ["inviteId", "roomId", "roomName", "inviterId", "inviterName"].forEach(
      (k) => urlParams.delete(k),
    );
    const rest = urlParams.toString();
    window.history.replaceState(
      {},
      "",
      window.location.pathname + (rest ? `?${rest}` : ""),
    );
  }, [currentUserId, router.pathname]);

  // pendingInvites 변경 시 localStorage 동기화
  useEffect(() => {
    if (!currentUserId) return;
    try {
      localStorage.setItem(
        `pendingInvites_${currentUserId}`,
        JSON.stringify(pendingInvites),
      );
    } catch {}
  }, [pendingInvites, currentUserId]);

  const handleAccept = async (invite) => {
    const res = await RequestServer({
      commandName: constants.commands.CHATROOM_ACCEPT_INVITE,
            loginUserId: currentUserId,
      inviteId: invite.invite_id,
    });
    setPendingInvites((prev) =>
      prev.filter((i) => String(i.invite_id) !== String(invite.invite_id)),
    );
    if (res.error_code === constants.errorCode.Success) {
      // 참여 시스템 메시지 + 멤버 목록 갱신 브로드캐스트
      const socket = socketRef.current || getSocket();
      socket.emit(constants.websocketMessageType.systemMessage, {
        roomId: res.roomId,
        message: tm("ACCEPTED_ROOM_INVITE").replace(
          "{0}",
          userInfo.getLoginUserName?.() || currentUserId,
        ),
      });
      socket.emit(constants.websocketMessageType.memberUpdate, {
        roomId: res.roomId,
      });
      router.push(
        `/mainPages/chatRoom?roomId=${res.roomId}&roomName=${encodeURIComponent(invite.room_name || "")}`,
      );
    }
  };

  const handleReject = async (invite) => {
    await RequestServer({
      commandName: constants.commands.CHATROOM_REJECT_INVITE,
            loginUserId: currentUserId,
      inviteId: invite.invite_id,
    });
    setPendingInvites((prev) =>
      prev.filter((i) => String(i.invite_id) !== String(invite.invite_id)),
    );
  };

  // ChatClient가 마운트되는 페이지에서는 wsChatClient의 모달이 담당
  if (CHAT_CLIENT_PAGES.includes(router.pathname)) return null;
  if (!currentUserId || pendingInvites.length === 0) return null;

  return (
    <div className="fixed inset-0 z-[10000] flex items-end justify-center pb-8 sm:items-center">
      <div className="mx-4 w-full max-w-sm rounded-2xl border border-[var(--border-color)] bg-[var(--surface)] shadow-2xl">
        <div className="px-5 py-4 border-b border-[var(--border-color)]">
          <p className="font-semibold text-[var(--general-text-color)]">
            {tl("roomInviteReceived")}
          </p>
        </div>
        <div className="max-h-72 overflow-y-auto divide-y divide-[var(--border-color)]">
          {pendingInvites.map((inv) => (
            <div
              key={inv.invite_id}
              className="flex items-center gap-3 px-5 py-4"
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm text-[var(--general-text-color)] truncate">
                  <span className="font-medium">
                    {inv.inviter_name || inv.inviter_id}
                  </span>{" "}
                  {tl("roomInviteBody")}
                </p>
                <p className="text-sm font-semibold text-[var(--general-text-color)] truncate mt-0.5">
                  {inv.room_name || inv.room_id}
                </p>
              </div>
              <button
                onClick={() => handleReject(inv)}
                className="shrink-0 rounded-lg px-3 py-1.5 text-xs font-medium text-[var(--semi-text-color)] border border-[var(--border-color)] hover:bg-[var(--surface-alt)]"
              >
                {tl("roomInviteReject")}
              </button>
              <button
                onClick={() => handleAccept(inv)}
                className="shrink-0 rounded-lg px-3 py-1.5 text-xs font-medium text-white bg-[var(--brand-blue)] hover:opacity-90"
              >
                {tl("roomInviteAccept")}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
