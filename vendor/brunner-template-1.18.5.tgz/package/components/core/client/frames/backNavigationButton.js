"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

const BACK_AVAILABLE_KEY = "brunnerBackNavigationAvailable";
const VISITED_KEY = "brunnerVisitedPaths";

// 네비 스택이 바뀌면 뒤로/앞으로 버튼이 표시를 다시 계산하도록 알린다.
const notifyNavChanged = () => {
  try { window.dispatchEvent(new Event("brunnerNavChanged")); } catch {}
};

// 앱 안에서 실제로 거쳐온 화면 경로를 직접 쌓는다.
// history.back()만 쓰면 (1) 탭 전환처럼 replace로 이동한 화면은 이력에 없고
// (2) 배포 감지 새로고침이 끼면 스택이 어긋나서, 직전 화면이 아니라 홈으로 튀어나갔다.
const readVisited = () => {
  try { return JSON.parse(window.sessionStorage?.getItem(VISITED_KEY) || "[]"); } catch { return []; }
};
const writeVisited = (arr) => {
  try { window.sessionStorage?.setItem(VISITED_KEY, JSON.stringify(arr.slice(-30))); } catch {}
};

// 화면이 바뀔 때마다 호출된다. 어떤 수단으로 이동했든(헤더 버튼·브라우저 백·안드로이드
// 백 버튼·링크) 스택이 실제 위치를 따라가도록 이동 방향을 스스로 판별한다.
export function recordVisitedPath(path) {
  if (typeof window === "undefined" || !path) return;
  const arr = readVisited();
  if (arr[arr.length - 1] === path) return; // 같은 화면 → 변화 없음
  // 스택이 바뀌면 버튼 표시를 다시 계산하게 알린다.
  // (라우팅 직후 버튼 effect가 이 기록보다 먼저 돌아, 앞으로가기 버튼이 계속 숨겨져 있었다.)
  setTimeout(notifyNavChanged, 0);

  // 화면 내부 앞으로가기(채팅방 다시 열기 등)는 그 화면에서만 의미가 있다.
  // 다른 화면으로 이동하면 이미 사라진 화면의 복원 동작이 남아, 앞으로가기를 눌러도
  // 아무 일도 일어나지 않고 버튼 표시만 바뀌었다.
  clearInAppForward();

  // 뒤로 간 경우: 현재 경로가 스택의 직전 항목 → 마지막을 빼서 앞으로가기 스택에 쌓는다.
  if (arr.length >= 2 && arr[arr.length - 2] === path) {
    const leaving = arr.pop();
    writeVisited(arr);
    const fwd = readForward();
    fwd.push(leaving);
    writeForward(fwd);
    return;
  }

  // 앞으로 간 경우: 현재 경로가 앞으로가기 스택의 최상단 → 다시 방문 스택으로 옮긴다.
  const fwd = readForward();
  if (fwd.length && fwd[fwd.length - 1] === path) {
    fwd.pop();
    writeForward(fwd);
    arr.push(path);
    writeVisited(arr);
    return;
  }

  // 새 화면으로 이동 → 앞으로가기 이력 무효(브라우저와 동일)
  arr.push(path);
  writeVisited(arr);
  clearForwardPaths();
  clearInAppForward();
}

export function previousVisitedPath() {
  if (typeof window === "undefined") return null;
  const arr = readVisited();
  return arr.length >= 2 ? arr[arr.length - 2] : null;
}

// 뒤로가기로 빠져나온 화면들 — 앞으로가기용 스택
const FORWARD_KEY = "brunnerForwardPaths";
const readForward = () => {
  try { return JSON.parse(window.sessionStorage?.getItem(FORWARD_KEY) || "[]"); } catch { return []; }
};
const writeForward = (arr) => {
  try { window.sessionStorage?.setItem(FORWARD_KEY, JSON.stringify(arr.slice(-30))); } catch {}
};

export function nextForwardPath() {
  if (typeof window === "undefined") return null;
  const fwd = readForward();
  return fwd.length ? fwd[fwd.length - 1] : null;
}

// 새 화면으로 직접 이동하면 앞으로가기 이력은 무효가 된다(브라우저와 동일).
export function clearForwardPaths() {
  try { window.sessionStorage?.removeItem(FORWARD_KEY); } catch {}
}

function BackIcon({ size = 18 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M19 12H5" />
      <path d="M12 19l-7-7 7-7" />
    </svg>
  );
}

export function canUseBackNavigation() {
  if (typeof window === "undefined") return false;
  if (hasInAppBack()) return true; // 화면 안에서 뒤로 갈 곳이 있으면(채팅방 등) 항상 표시
  if (window.location.pathname === "/") return false; // 홈에서는 뒤로 갈 곳이 없다
  if (previousVisitedPath()) return true; // 앱 안에서 거쳐온 직전 화면이 있으면 표시
  if (window.sessionStorage?.getItem(BACK_AVAILABLE_KEY) === "1") return true;

  const historyIndex = window.history.state?.idx;
  if (typeof historyIndex === "number" && historyIndex > 0) return true;

  // Pages Router에서는 history.state.idx가 없고, SPA 이동 시 document.referrer도 갱신되지
  // 않아 예전 조건이 모두 false가 되면서 버튼이 아예 표시되지 않았다.
  // 되돌아갈 이력이 실제로 있으면(새 탭 직접 진입이 아니면) 표시한다.
  return window.history.length > 1;
}

// 화면 안에서 상태로만 깊어지는 곳(채팅방 목록→방, 편집기 등)을 위한 훅.
// URL이 바뀌지 않아 방문 스택에 안 남으므로, 그런 화면이 자기 "뒤로" 동작을 등록하면
// 헤더 뒤로가기가 라우트 이동보다 먼저 그것을 실행한다. true를 반환하면 처리된 것으로 본다.
let inAppBackHandler = null;
let inAppBackRestore = null; // 뒤로 간 화면을 다시 여는 함수(앞으로가기용)
let inAppForward = null;     // 실행 대기 중인 "화면 내부 앞으로"

// handler: 뒤로 동작(처리했으면 true 반환) / restore: 그 화면을 다시 여는 동작(앞으로가기용, 선택)
export function registerInAppBack(handler, restore = null) {
  inAppBackHandler = handler;
  inAppBackRestore = restore;
  notifyNavChanged(); // 버튼 표시 상태 즉시 갱신
  return () => {
    if (inAppBackHandler === handler) {
      inAppBackHandler = null;
      inAppBackRestore = null;
      notifyNavChanged();
    }
  };
}
export function hasInAppBack() {
  return typeof inAppBackHandler === "function";
}
export function hasInAppForward() {
  return typeof inAppForward === "function";
}
export function runInAppForward() {
  const fn = inAppForward;
  if (typeof fn !== "function") return false; // 화면 내부 복원이 없으면 아무것도 건드리지 않는다
  inAppForward = null;
  notifyNavChanged();
  fn();
  return true;
}
function clearInAppForward() {
  if (inAppForward) { inAppForward = null; notifyNavChanged(); }
}

export function markBackNavigationAvailable() {
  if (typeof window === "undefined") return;
  window.sessionStorage?.setItem(BACK_AVAILABLE_KEY, "1");
}

export default function BackNavigationButton({
  variant = "header",
  className = "",
  forceVisible = false,
  locationKey = "",
  bottomOffset = "calc(86px + env(safe-area-inset-bottom, 22px))",
  topOffset = null,
}) {
  const [languageCode, setLanguageCode] = useState("ko-KR");
  const [visible, setVisible] = useState(false);
  const router = useRouter();

  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode?.() || "ko-KR");
    const sync = () => setVisible(canUseBackNavigation());
    sync();
    window.addEventListener("brunnerNavChanged", sync);
    return () => window.removeEventListener("brunnerNavChanged", sync);
  }, [locationKey]);

  const label = commonFunctions.getResourceByLanguage(
    "back",
    constants.resourceType.label,
    languageCode,
  );

  const goBack = () => {
    if (typeof window === "undefined") return;
    // 화면 내부 뒤로(예: 채팅방 → 방 목록)가 등록돼 있으면 그것부터 처리한다.
    if (inAppBackHandler) {
      const restore = inAppBackRestore;
      if (inAppBackHandler() === true) {
        inAppForward = restore; // 복원 동작이 있으면 앞으로가기로 되돌아갈 수 있다
        notifyNavChanged();
        return;
      }
    }
    if (!canUseBackNavigation()) return;
    // 이동만 하고 스택 갱신은 recordVisitedPath가 방향을 판별해 처리한다(중복 처리 방지).
    const prev = previousVisitedPath();
    if (prev) { router.push(prev); return; }
    window.history.back();
  };

  if (!forceVisible && !visible) return null;

  const classes = {
    header:
      "theme-icon-button inline-flex h-9 shrink-0 items-center gap-1.5 rounded-[var(--radius-md)] border px-2.5 text-xs font-bold transition",
    footer:
      "theme-icon-button hidden h-7 shrink-0 items-center gap-1 rounded-[var(--radius-md)] border px-2.5 text-xs font-semibold transition md:inline-flex",
    floating:
      "theme-icon-button fixed left-3 z-[60] inline-flex h-11 w-11 items-center justify-center rounded-full border shadow-[var(--shadow-card)] transition md:hidden",
  };

  if (variant === "floating") {
    // topOffset이 오면 상단(헤더 아래)에 배치 — 하단 조작버튼이 있는 게임에서 겹침 방지.
    return (
      <button
        type="button"
        onClick={goBack}
        aria-label={label}
        title={label}
        className={`${classes.floating} ${className}`}
        style={topOffset ? { top: topOffset } : { bottom: bottomOffset }}
      >
        <BackIcon size={22} />
      </button>
    );
  }

  return (
    <button type="button" onClick={goBack} aria-label={label} title={label} className={`${classes[variant] || classes.header} ${className}`}>
      <BackIcon />
      <span className={variant === "header" ? "hidden sm:inline" : ""}>{label}</span>
    </button>
  );
}

function ForwardIcon({ size = 18 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.9"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M5 12h14" />
      <path d="M12 5l7 7-7 7" />
    </svg>
  );
}

// 앞으로가기 — 뒤로가기로 빠져나온 화면이 있을 때만 표시된다(브라우저와 동일한 동작).
export function ForwardNavigationButton({ className = "", locationKey = "" }) {
  const [languageCode, setLanguageCode] = useState("ko-KR");
  const [visible, setVisible] = useState(false);
  const router = useRouter();

  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode?.() || "ko-KR");
    const sync = () => setVisible(hasInAppForward() || Boolean(nextForwardPath()));
    sync();
    // 라우팅 직후 기록이 늦게 반영돼도 표시가 갱신되도록 이벤트를 구독한다.
    window.addEventListener("brunnerNavChanged", sync);
    return () => window.removeEventListener("brunnerNavChanged", sync);
  }, [locationKey]);

  const label = commonFunctions.getResourceByLanguage(
    "forward",
    constants.resourceType.label,
    languageCode,
  );

  if (!visible) return null;

  return (
    <button
      type="button"
      onClick={() => {
        if (runInAppForward()) return; // 화면 내부 앞으로(채팅방 다시 열기 등)
        const target = nextForwardPath();
        if (target) router.push(target); // 스택 갱신은 recordVisitedPath가 처리
      }}
      aria-label={label}
      title={label}
      className={`theme-icon-button inline-flex h-9 shrink-0 items-center gap-1.5 rounded-[var(--radius-md)] border px-2.5 text-xs font-bold transition ${className}`}
    >
      <ForwardIcon />
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}
