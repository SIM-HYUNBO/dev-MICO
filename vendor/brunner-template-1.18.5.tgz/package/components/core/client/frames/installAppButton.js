"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import {
  getInstallPrompt, clearInstallPrompt, subscribeInstallPrompt, isStandalone, isIos,
} from "@/lib/pwaInstall";

const L = (key) =>
  commonFunctions.getResourceByLanguage(key, constants.resourceType.label, userInfo.getCurrentLanguageCode());

// Safari 도구막대의 공유 아이콘 — 글로 "공유 버튼"이라고만 하면 어느 것인지 못 찾는다.
function ShareIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 15V3" />
      <path d="m8 7 4-4 4 4" />
      <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7" />
    </svg>
  );
}

// 공유 시트 안의 "홈 화면에 추가" 항목 아이콘
function AddBoxIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="3" y="3" width="18" height="18" rx="4" />
      <path d="M12 8v8M8 12h8" />
    </svg>
  );
}

// iOS 전용 안내 — 애플이 웹에서 홈 화면 추가를 실행할 방법을 열어두지 않았다.
// navigator.share로 여는 시트에는 "홈 화면에 추가"가 없다(그건 Safari 자체 공유 메뉴에만 있다).
// 그래서 실행 대신, 어느 버튼을 누르는지 그림으로 짚어 준다.
function IosGuide({ onClose }) {
  const steps = [
    { icon: <ShareIcon />, text: L("installAppIosStep1") },
    { icon: <AddBoxIcon />, text: L("installAppIosStep2") },
    { icon: null, text: L("installAppIosStep3") },
  ];
  const node = (
    <div
      data-brunner-modal
      className="fixed inset-0 flex items-end justify-center p-4 sm:items-center"
      style={{ zIndex: 1000002, backgroundColor: "rgba(0,0,0,0.5)" }}
    >
      <div className="w-full max-w-sm rounded-[var(--radius-xl)] border border-[var(--border)] bg-[var(--surface)] p-5 shadow-[var(--shadow-card-strong)]">
        <h2 className="text-base font-extrabold text-[var(--text)]">{L("installAppButton")}</h2>
        <p className="mt-1 text-xs leading-5 text-[var(--text-muted)]">{L("installAppIosIntro")}</p>

        <ol className="mt-4 flex flex-col gap-3">
          {steps.map((s, i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[var(--brand-blue)] text-[11px] font-bold text-white">
                {i + 1}
              </span>
              <span className="flex min-w-0 flex-1 items-center gap-2 text-sm leading-6 text-[var(--text)]">
                {s.icon && <span className="shrink-0 text-[var(--brand-blue)]">{s.icon}</span>}
                <span>{s.text}</span>
              </span>
            </li>
          ))}
        </ol>

        {/* 공유 버튼은 화면 '아래' 도구막대에 있다 — 위쪽을 찾다 못 찾는 일이 많다. */}
        <p className="mt-4 rounded-[var(--radius-md)] bg-[var(--surface-alt)] px-3 py-2 text-xs leading-5 text-[var(--text-muted)]">
          ↓ {L("installAppIosWhere")}
        </p>

        <button
          type="button"
          onClick={onClose}
          className="mt-4 w-full rounded-[var(--radius-md)] bg-[var(--brand-blue)] px-3 py-2.5 text-sm font-bold text-white"
        >
          {L("installAppGotIt")}
        </button>
      </div>
    </div>
  );
  if (typeof document === "undefined") return null;
  return createPortal(node, document.body);
}

// 다운로드 화살표 — 알약 버튼과 홈 카드가 같은 아이콘을 쓴다.
function DownloadIcon({ size = 22 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 3v12" />
      <path d="m7 10 5 5 5-5" />
      <path d="M5 21h14" />
    </svg>
  );
}

// variant="menu"  드롭다운 안의 알약 버튼
// variant="card"  홈 화면의 메뉴 카드와 같은 모양
//
// 설치 로직(프롬프트·iOS 안내·설치 여부 판정)은 여기 한 군데에만 둔다.
// 홈 카드로 옮기면서 로직을 복사하면 두 곳이 갈라진다.
export default function InstallAppButton({ className = "", variant = "menu" }) {
  const { BrunnerMessageBox: MessageBox, openOkModal } = useModal();
  const [ready, setReady] = useState(false);   // 브라우저 판정 전에는 그리지 않는다(깜빡임 방지)
  const [installed, setInstalled] = useState(false);
  const [iosGuide, setIosGuide] = useState(false);
  const [, setTick] = useState(0);             // 설치 프롬프트가 늦게 와도 다시 그리게

  useEffect(() => {
    setInstalled(isStandalone());
    setReady(true);
    return subscribeInstallPrompt(() => {
      setInstalled(isStandalone());
      setTick((n) => n + 1);
    });
  }, []);

  if (!ready || installed) return null;

  const onClick = async () => {
    const prompt = getInstallPrompt();
    if (prompt) {
      prompt.prompt();
      const choice = await prompt.userChoice.catch(() => null);
      clearInstallPrompt(); // 프롬프트는 한 번만 쓸 수 있다 — 거절하면 다음 방문 때 다시 받는다
      if (choice?.outcome === "accepted") setInstalled(true);
      return;
    }
    // 눌렀는데 아무 일도 안 일어나면 고장으로 보인다 — 이 브라우저에서 추가하는 방법을 보여준다.
    if (isIos()) { setIosGuide(true); return; }
    await openOkModal(L("installAppGenericGuide"), constants.messageCategory.Info);
  };

  const overlays = (
    <>
      <MessageBox />
      {iosGuide && <IosGuide onClose={() => setIosGuide(false)} />}
    </>
  );

  // 홈 메뉴 카드와 같은 모양. 색만 브랜드 파랑 계열로 둔다.
  if (variant === "card") {
    return (
      <>
        {overlays}
        <button
          type="button"
          onClick={onClick}
          className={`w-full rounded-2xl p-4 flex items-center gap-3 text-left transition active:scale-[0.98] ${className}`}
          style={{ background: "#E0F2FE", border: "1px solid rgba(3,105,161,0.2)", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}
        >
          <div
            className="h-10 w-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: "#BAE6FD", color: "#0369A1" }}
          >
            <DownloadIcon />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold truncate" style={{ color: "#0369A1" }}>{L("installAppButton")}</div>
            <div className="text-xs truncate mt-0.5" style={{ color: "var(--text-muted)" }}>{L("installAppCardSub")}</div>
          </div>
        </button>
      </>
    );
  }

  return (
    <>
      {overlays}
      <button
        type="button"
        onClick={onClick}
        className={`inline-flex w-full items-center justify-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--brand-blue)] bg-[var(--surface)] px-3 py-2 text-xs font-bold text-[var(--brand-blue)] transition hover:bg-[var(--brand-blue)] hover:text-white ${className}`}
      >
        <DownloadIcon size={14} />
        {L("installAppButton")}
      </button>
    </>
  );
}
