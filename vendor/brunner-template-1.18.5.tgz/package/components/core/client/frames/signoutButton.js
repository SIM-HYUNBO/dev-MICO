"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";

export default function SignoutButton({ handleLogout }) {
  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");

  const router = useRouter();
  const { BrunnerMessageBox, openOkCancelModal, openOkModal, openInputModal } =
    useModal();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setCurrentSystemCode(userInfo.getCurrentSystemCode());
    setCurrentLoginUserId(userInfo.getLoginUserId());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  const requestSignout = async () => {
    const jRequest = {
      commandName: constants.commands.SECURITY_SIGNOUT,
            userId: currentLoginUserId,
      sessionToken: userInfo.getLoginSessionToken(),
      languageCode: currentLanguageCode,
    };

    setLoading(true);
    let jResponse;
    try {
      jResponse = await RequestServer(jRequest);
    } finally {
      setLoading(false);
    }

    if (jResponse?.error_code === constants.errorCode.Success) {
      userInfo.clearSessionState();
      window.dispatchEvent(
        new CustomEvent("userChanged", { detail: { userId: null } }),
      );
      try {
        await handleLogout?.();
      } catch (e) {
        console.warn("[signout] menu refresh failed after logout", e);
      }
      router.replace("/mainPages/signin");
    } else {
      await openOkModal(
        jResponse?.error_message || "Sign-out failed.",
        constants.messageCategory.Error,
      );
    }
  };

  return (
    <>
      <BrunnerMessageBox />

      {currentLoginUserId && (
        <button
          type="button"
          className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[var(--border)] bg-[var(--surface)] text-[var(--danger)] transition hover:opacity-80 disabled:cursor-not-allowed disabled:opacity-50"
          onClick={requestSignout}
          disabled={loading}
          aria-label={commonFunctions.getResourceByLanguage("signOut", constants.resourceType.label, currentLanguageCode)}
        >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth="2"
              className="h-5 w-5"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h6a2 2 0 012 2v1"
              />
            </svg>
        </button>
      )}
    </>
  );
}
