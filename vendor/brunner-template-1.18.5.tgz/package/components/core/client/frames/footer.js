import Link from "next/link";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import React, { useState, useEffect } from "react";
import * as userInfo from "@/components/core/client/frames/userInfo";

export default function Footer() {
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);
  const [companyInfo, setCompanyInfo] = useState("");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const lang = userInfo.getCurrentLanguageCode();
    setCurrentLanguageCode(lang);
    setCompanyInfo(
      commonFunctions.getResourceByLanguage(
        `COMPANY_INFO`,
        constants.resourceType.message,
        lang,
      ),
    );
  }, []);

  const versionText = `v${process.env.NEXT_PUBLIC_APP_VERSION}${
    process.env.NEXT_PUBLIC_BUILD_TIME
      ? ` (${new Date(process.env.NEXT_PUBLIC_BUILD_TIME).toLocaleString("ko-KR", {
          year: "numeric", month: "2-digit", day: "2-digit",
          hour: "2-digit", minute: "2-digit", hour12: false,
        })})`
      : ""
  }`;

  return (
    <footer className="w-full border-t overflow-hidden">
      {/* 버전/빌드 일시 + 토글 — 항상 표시 */}
      {/* 화면에는 ▼만 두지만, 스크린 리더에는 무엇이 열리는지 알려 준다. */}
      <div className="flex items-center justify-center py-1 gap-2">
        <span className="text-xs text-gray-400 dark:text-gray-500">{versionText}</span>
        <button
          onClick={() => setOpen((prev) => !prev)}
          className="flex items-center gap-1 text-xs text-[var(--semi-text-color)] underline-offset-2 hover:underline"
          aria-expanded={open}
          aria-label={commonFunctions.getResourceByLanguage("footerBusinessInfo", constants.resourceType.label, currentLanguageCode)}
        >
          <span aria-hidden="true">{open ? "▲" : "▼"}</span>
        </button>
      </div>

      <div
        className={`
          max-w-7xl
          w-full
          mx-auto
          px-6
          py-2
          flex
          flex-col
          md:flex-row
          md:items-center
          md:justify-between
          ${open ? "flex" : "hidden"}
        `}
      >
        {/* 회사 정보 영역 */}
        <div className="text-xs min-w-0 break-words">
          <Link href="/" className="semi-text-bg-color transition break-words">
            ©2020 BLD Corp.
          </Link>

          <pre
            className="mt-1 font-sans leading-relaxed text-[var(--semi-text-color)]"
            style={{
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
              margin: 0,
            }}
          >
            {companyInfo}
          </pre>
        </div>

        {/* SNS 아이콘 영역 */}
        <div className="flex items-center justify-start md:justify-end space-x-3 shrink-0">
          {/* Facebook */}
          <a
            href="#"
            aria-label="Facebook"
            className="
              p-2 
              rounded-lg 
              bg-gray-100 
              dark:bg-gray-800
              text-gray-500 
              hover:text-gray-700
              dark:hover:text-gray-300
              hover:bg-gray-200 
              dark:hover:bg-gray-700
              transition
            "
          >
            <svg fill="currentColor" className="w-5 h-5" viewBox="0 0 24 24">
              <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z" />
            </svg>
          </a>

          {/* Twitter */}
          <a
            href="#"
            aria-label="Twitter"
            className="
              p-2 
              rounded-lg 
              bg-gray-100 
              dark:bg-gray-800
              text-gray-500 
              hover:text-gray-700
              dark:hover:text-gray-300
              hover:bg-gray-200 
              dark:hover:bg-gray-700
              transition
            "
          >
            <svg fill="currentColor" className="w-5 h-5" viewBox="0 0 24 24">
              <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z" />
            </svg>
          </a>

          {/* Instagram */}
          <a
            href="#"
            aria-label="Instagram"
            className="
              p-2 
              rounded-lg 
              bg-gray-100 
              dark:bg-gray-800
              text-gray-500 
              hover:text-gray-700
              dark:hover:text-gray-300
              hover:bg-gray-200 
              dark:hover:bg-gray-700
              transition
            "
          >
            <svg
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="w-5 h-5"
              viewBox="0 0 24 24"
            >
              <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
              <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z" />
            </svg>
          </a>

          {/* LinkedIn */}
          <a
            href="#"
            aria-label="LinkedIn"
            className="
              p-2 
              rounded-lg 
              bg-gray-100 
              dark:bg-gray-800
              text-gray-500 
              hover:text-gray-700
              dark:hover:text-gray-300
              hover:bg-gray-200 
              dark:hover:bg-gray-700
              transition
            "
          >
            <svg fill="currentColor" className="w-5 h-5" viewBox="0 0 24 24">
              <path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z" />
              <circle cx="4" cy="4" r="2" />
            </svg>
          </a>
        </div>
      </div>
    </footer>
  );
}
