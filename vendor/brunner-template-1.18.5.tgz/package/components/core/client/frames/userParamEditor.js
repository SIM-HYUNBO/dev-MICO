"use client";

import { useEffect, useState } from "react";
import { RequestServer } from "@/components/core/client/requestServer";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import Card from "@/components/core/client/ui/Card";
import Button from "@/components/core/client/ui/Button";
import Input from "@/components/core/client/ui/Input";

/**
 * 사용자 확장속성(User Params) 패널 — 사용자 정보 화면에 붙는다.
 *
 * 저장소: TB_COR_USER_PARAM_INFO (SYSTEM_CODE + USER_ID, 값은 JSONB)
 * 테넌트는 서버가 배포 환경변수로 정한다. 이 화면은 systemCode 를 보내지 않는다.
 *
 * 알림음(pushNotificationSound)처럼 다른 기능이 쓰는 값도 여기 함께 들어 있어,
 * 사용자가 직접 보고 고칠 수 있는 유일한 자리다.
 */
export function UserParamEditor() {
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");
  const [loading, setLoading] = useState(false);
  const { BrunnerMessageBox, openOkModal } = useModal();

  // 키-값 쌍 배열: [{ key: "", value: "" }, ...]
  const [rows, setRows] = useState([]);

  const tl = (key) =>
    commonFunctions.getResourceByLanguage(
      key,
      constants.resourceType.label,
      currentLanguageCode,
    );

  useEffect(() => {
    const userId = userInfo.getLoginUserId();
    const langCode = userInfo.getCurrentLanguageCode();
    setCurrentLoginUserId(userId);
    setCurrentLanguageCode(langCode);
    fetchRows(userId, langCode);
  }, []);

  const paramsToRows = (params) => {
    let obj = params;
    if (typeof obj === "string") {
      try { obj = JSON.parse(obj); } catch { return []; }
    }
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) return [];
    return Object.entries(obj).map(([key, value]) => ({
      key,
      value: typeof value === "object" ? JSON.stringify(value) : String(value),
    }));
  };

  const rowsToParams = (list) =>
    list.reduce((acc, { key, value }) => {
      if (key.trim()) acc[key.trim()] = value;
      return acc;
    }, {});

  const fetchRows = async (userId, langCode) => {
    try {
      setLoading(true);
      const jResponse = await RequestServer({
        commandName: constants.commands.SECURITY_USER_PARAM_SELECT_ONE,
        userId,
        languageCode: langCode,
      });

      if (jResponse.error_code === constants.errorCode.Success) {
        setRows(paramsToRows(jResponse.data?.user_params ?? {}));
      } else if (jResponse.error_code === constants.errorCode.DBValidationError) {
        // 데이터 없음 = 아직 저장한 적 없는 사용자. 오류가 아니다.
        setRows([]);
      } else {
        await openOkModal(jResponse.error_message, constants.messageCategory.Error);
        setRows([]);
      }
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    } finally {
      setLoading(false);
    }
  };

  const loadUserParamInfo = () => fetchRows(currentLoginUserId, currentLanguageCode);

  const saveUserParamInfo = async () => {
    try {
      setLoading(true);
      const jResponse = await RequestServer({
        commandName: constants.commands.SECURITY_USER_PARAM_UPSERT_ONE,
        userId: currentLoginUserId,
        languageCode: currentLanguageCode,
        jUserParams: rowsToParams(rows),
      });

      if (jResponse.error_code === constants.errorCode.Success) {
        await openOkModal(
          commonFunctions.getResourceByLanguage(
            "SUCCESS_FINISHED",
            constants.resourceType.message,
            currentLanguageCode,
          ),
          constants.messageCategory.Info,
        );
      } else {
        await openOkModal(jResponse.error_message, constants.messageCategory.Error);
      }
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    } finally {
      setLoading(false);
    }
  };

  const addRow = () => setRows((prev) => [...prev, { key: "", value: "" }]);
  const deleteRow = (idx) => setRows((prev) => prev.filter((_, i) => i !== idx));
  const updateRow = (idx, field, val) =>
    setRows((prev) => prev.map((row, i) => (i === idx ? { ...row, [field]: val } : row)));

  return (
    <Card className="mt-4 p-5">
      <BrunnerMessageBox />

      <h3 className="text-base font-extrabold text-[var(--text)]">
        {tl("additionalUserSettings")}
      </h3>
      <p className="mt-1 text-sm text-[var(--text-muted)]">
        {tl("additionalUserSettingsDesc")}
      </p>

      {rows.length === 0 ? (
        <p className="mt-5 text-sm text-[var(--text-subtle)]">
          {tl("additionalUserSettingsEmpty")}
        </p>
      ) : (
        <>
          {/* 데스크톱에서만 열 제목을 보여준다. 모바일은 placeholder 로 충분하다. */}
          <div className="mt-5 hidden gap-3 px-1 text-xs font-semibold text-[var(--text-subtle)] md:grid md:grid-cols-[1fr_1fr_auto]">
            <span>{tl("key")}</span>
            <span>{tl("value")}</span>
            <span />
          </div>

          <div className="mt-2 flex flex-col gap-3">
            {rows.map((row, idx) => (
              <div
                key={idx}
                className="grid grid-cols-1 gap-2 md:grid-cols-[1fr_1fr_auto] md:items-center md:gap-3"
              >
                <Input
                  type="text"
                  value={row.key}
                  onChange={(e) => updateRow(idx, "key", e.target.value)}
                  placeholder={tl("key")}
                  aria-label={tl("key")}
                />
                <Input
                  type="text"
                  value={row.value}
                  onChange={(e) => updateRow(idx, "value", e.target.value)}
                  placeholder={tl("value")}
                  aria-label={tl("value")}
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteRow(idx)}
                  className="justify-self-end md:justify-self-auto"
                >
                  {tl("delete")}
                </Button>
              </div>
            ))}
          </div>
        </>
      )}

      <div className="mt-5 flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <Button variant="soft" size="sm" onClick={addRow} disabled={loading}>
          + {tl("add")}
        </Button>
        <div className="flex flex-col gap-2 md:flex-row md:justify-end">
          <Button variant="ghost" onClick={loadUserParamInfo} disabled={loading}>
            {tl("refresh")}
          </Button>
          <Button onClick={saveUserParamInfo} disabled={loading}>
            {loading ? tl("saving") : tl("save")}
          </Button>
        </div>
      </div>
    </Card>
  );
}

export default UserParamEditor;
