"use client";

import React, { useEffect, useRef, useState } from "react";
import Script from "next/script";
import Head from "next/head";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import Header from "@/components/core/client/frames/header";
import Footer from "@/components/core/client/frames/footer";
import { markBackNavigationAvailable, recordVisitedPath } from "@/components/core/client/frames/backNavigationButton";
import { useRouter } from "next/router";
import BodySection from "@/components/core/client/frames/bodySection";
import RoomInviteWatcher from "@/components/core/client/frames/roomInviteWatcher";
import { RequestServer } from "@/components/core/client/requestServer";
import { useColorTheme } from "@/lib/hooks/useColorTheme";
import { DEFAULT_HOME_ACCENT, HOME_ACCENT_KEY, applyHomeAccent } from "@/lib/homeAccent";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import { usePathname } from "next/navigation";
import { refreshIfOutdatedBuild } from "@/lib/clientBuildRefresh";

const PUSH_PREF_KEY = "pushNotificationsEnabled";

// VAPID 공개키(base64url 문자열) → Uint8Array. applicationServerKey는 BufferSource여야
// iOS Safari 등 엄격한 브라우저에서 구독이 실패하지 않는다.
function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const output = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) output[i] = raw.charCodeAt(i);
  return output;
}

export default function Layout({ children, mobileFullScreen = false }) {
  const [mounted, setMounted] = useState(false);
  const [languageCode, setLanguageCode] = useState(null);
  const { BrunnerMessageBox, openOkCancelModal } = useModal();
  const pathname = usePathname();
  const isChatRoomPage = pathname === "/mainPages/chatRoom"; // overflow-hidden 및 푸터 숨김은 유지
  const prevPathRef = useRef(null);
  const [backNavigationKey, setBackNavigationKey] = useState("");
  const navRouter = useRouter();
  const mainRef = useRef(null);
  const scrollPositionsRef = useRef(new Map());
  const isBackNavigationRef = useRef(false);

  useColorTheme(); // localStorage에서 컬러 테마 로드 및 적용

  useEffect(() => {
    const applySavedAccent = () => {
      const saved = localStorage.getItem(HOME_ACCENT_KEY) || DEFAULT_HOME_ACCENT;
      applyHomeAccent(saved);
    };
    applySavedAccent();
    window.addEventListener("homeAccentChanged", applySavedAccent);
    return () => window.removeEventListener("homeAccentChanged", applySavedAccent);
  }, []);

  // 뒤로가기인지 표시해 둔다. 아래 스크롤 처리에서 맨 위로 올릴지
  // 보던 자리로 되돌릴지 가른다.
  useEffect(() => {
    navRouter.beforePopState(() => {
      isBackNavigationRef.current = true;
      return true;
    });
  }, [navRouter]);

  // 스크롤이 window가 아니라 아래 <main>에 걸려 있다. Next는 화면을 옮길 때
  // window를 맨 위로 올리는데 이 컨테이너는 건드리지 않으므로, 이전 화면의
  // 위치가 그대로 남는다. 홈 아래쪽 카드를 눌러 들어가면 새 화면이 그 깊이에서
  // 시작해 최상단이 안 보였다.
  //
  // 새 화면으로 갈 때는 맨 위, 뒤로 갈 때는 보던 자리로 되돌린다.
  // 정리 함수는 다음 효과보다 먼저, 떠나는 경로를 담은 채로 돈다.
  useEffect(() => {
    const el = mainRef.current;
    if (!el) return undefined;

    const saved = scrollPositionsRef.current.get(pathname);
    el.scrollTo({ top: isBackNavigationRef.current && saved != null ? saved : 0, left: 0 });
    isBackNavigationRef.current = false;

    return () => {
      scrollPositionsRef.current.set(pathname, el.scrollTop);
    };
  }, [pathname]);

  useEffect(() => {
    setMounted(true);
    setLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  // 앱 안에서 거쳐온 화면을 전 화면 공통으로 기록한다(뒤로가기가 직전 화면으로 정확히 가도록).
  // 쿼리까지 포함(asPath)해서 주식 탭처럼 query만 바뀌는 이동도 이력에 남는다.
  useEffect(() => {
    if (!mounted) return;
    const rec = () => recordVisitedPath(navRouter.asPath);
    rec();
    navRouter.events.on("routeChangeComplete", rec);
    return () => navRouter.events.off("routeChangeComplete", rec);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mounted]);

  // 페이지 이동 시 메뉴 갱신 (공용문서 등 DB 기반 항목 반영)
  useEffect(() => {
    if (!mounted || !pathname) return;
    if (prevPathRef.current !== null && prevPathRef.current !== pathname) {
      markBackNavigationAvailable();
      setBackNavigationKey(`${pathname}:${Date.now()}`);
      window.dispatchEvent(new Event("menuChanged"));
    }
    prevPathRef.current = pathname;
  }, [pathname, mounted]);

  // 서비스워커 PLAY_SOUND 메시지 처리 (푸시 알림음 + 생일축하곡 등)
  useEffect(() => {
    if (!mounted) return;
    // 푸시 알림음 매핑 — 기본값은 커피 따르는 소리(pour). 앱이 열려 있을 때 SW가 알림을 억제하고
    // 이 메시지로 소리 재생을 요청한다(백그라운드/앱 종료 시엔 OS 기본음 사용).
    const PUSH_SOUND_SRC = {
      default: "/sounds/pour.mp3",
      pour: "/sounds/pour.mp3",
      brunner_chime: "/sounds/push-brunner-chime.wav",
      cafe_bell: "/sounds/push-cafe-bell.wav",
      soft_pop: "/sounds/push-soft-pop.wav",
    };
    const playPushSound = (sound) => {
      if (!sound || sound === "silent") return;
      const src = PUSH_SOUND_SRC[sound] || PUSH_SOUND_SRC.default;
      try {
        const audio = new Audio(src);
        audio.volume = 0.5;
        audio.play().catch(() => {});
      } catch {}
    };
    const playBirthday = () => {
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        // Happy Birthday to You (C장조)
        const notes = [
          [261.6,0.28],[261.6,0.14],[293.7,0.42],[261.6,0.42],[349.2,0.42],[329.6,0.84],
          [261.6,0.28],[261.6,0.14],[293.7,0.42],[261.6,0.42],[392.0,0.42],[349.2,0.84],
          [261.6,0.28],[261.6,0.14],[523.3,0.42],[440.0,0.42],[349.2,0.42],[329.6,0.42],[293.7,0.84],
          [466.2,0.28],[466.2,0.14],[440.0,0.42],[349.2,0.42],[392.0,0.42],[349.2,1.1],
        ];
        let t = ctx.currentTime + 0.05;
        for (const [freq, dur] of notes) {
          const o = ctx.createOscillator();
          const g = ctx.createGain();
          o.type = "sine";
          o.frequency.setValueAtTime(freq, t);
          g.gain.setValueAtTime(0.28, t);
          g.gain.setValueAtTime(0.28, t + dur * 0.75);
          g.gain.linearRampToValueAtTime(0, t + dur);
          o.connect(g); g.connect(ctx.destination);
          o.start(t); o.stop(t + dur);
          t += dur + 0.02;
        }
      } catch {}
    };
    const onMessage = (e) => {
      if (e.data?.type !== "PLAY_SOUND") return;
      if (e.data.sound === "birthday") {
        playBirthday();
        return;
      }
      playPushSound(e.data.sound);
    };
    navigator.serviceWorker?.addEventListener("message", onMessage);
    return () => navigator.serviceWorker?.removeEventListener("message", onMessage);
  }, [mounted]);

  // 탭 포커스 복귀 시 새 배포 감지 → 자동 새로고침
  useEffect(() => {
    if (!mounted) return;
    const checkNewBuild = async () => {
      if (document.visibilityState !== "visible") return;
      try {
        const refreshed = await refreshIfOutdatedBuild();
        if (refreshed) return;
        const buildId = window.__NEXT_DATA__?.buildId;
        if (!buildId) return;
        const res = await fetch(`/_next/static/${buildId}/_buildManifest.js`, {
          method: "HEAD",
          cache: "no-store",
        });
        if (!res.ok) window.location.reload();
      } catch {}
    };
    window.addEventListener("focus", checkNewBuild);
    document.addEventListener("visibilitychange", checkNewBuild);
    return () => {
      window.removeEventListener("focus", checkNewBuild);
      document.removeEventListener("visibilitychange", checkNewBuild);
    };
  }, [mounted]);

  useEffect(() => {
    if (!mounted) return;

    let prompting = false;

    const subscribePushForCurrentDevice = async () => {
      const vapidKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
      const loginUserId = userInfo.getLoginUserId();
      if (!vapidKey || !loginUserId) return;

      const reg = await navigator.serviceWorker.ready;
      const existing = await reg.pushManager.getSubscription();
      const sub = existing || await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidKey),
      });

      await fetch("/api/push", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: loginUserId,
          subscription: sub.toJSON(),
        }),
      });
    };

    const ensurePushNotifications = async () => {
      if (prompting) return;
      if (!userInfo.isLogin()) return;
      if (localStorage.getItem(PUSH_PREF_KEY) === "false") return;
      if (!("serviceWorker" in navigator) || !("PushManager" in window)) return;

      prompting = true;
      try {
        const reg = await navigator.serviceWorker.register("/sw.js");
        reg.update?.().catch(() => {});

        if (Notification.permission === "granted") {
          await subscribePushForCurrentDevice();
          return;
        }
        if (Notification.permission !== "default") {
          return;
        }

        const confirmed = await openOkCancelModal(
          commonFunctions.getResourceByLanguage(
            "PUSH_ENABLE_PROMPT",
            constants.resourceType.message,
            userInfo.getCurrentLanguageCode(),
          ),
          "Confirm",
        ).catch(() => false);

        if (!confirmed) {
          localStorage.setItem(PUSH_PREF_KEY, "false");
          return;
        }

        const permission = await Notification.requestPermission();
        if (permission === "granted") {
          localStorage.setItem(PUSH_PREF_KEY, "true");
          await subscribePushForCurrentDevice();
        } else if (permission === "denied") {
          localStorage.setItem(PUSH_PREF_KEY, "false");
        }
      } catch (e) {
        console.error("[push layout]", e.message);
      } finally {
        prompting = false;
      }
    };

    ensurePushNotifications();
    window.addEventListener("userChanged", ensurePushNotifications);
    return () => window.removeEventListener("userChanged", ensurePushNotifications);
  }, [mounted]);

  const GoogleAdScript = () => {
    return (
      <>
        <Script
          async
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3879149687745447"
          crossOrigin="anonymous"
        />
        <Script
          async
          custom-element="amp-auto-ads"
          src="https://cdn.ampproject.org/v0/amp-auto-ads-0.1.js"
        ></Script>
      </>
    );
  };

  return (
    <div className="Layout">
      <BodySection>
        <BrunnerMessageBox />
        {mounted && <RoomInviteWatcher />}
        <Head>
          <title>{mounted ? `${commonFunctions.getResourceByLanguage(
            `LAYOUT_TITLE`,
            constants.resourceType.message,
            languageCode,
          )}` : ""}</title>
          <meta
            name="description"
            content={mounted ? `${commonFunctions.getResourceByLanguage(
              `SITE_DESCRIPTION`,
              constants.resourceType.message,
              languageCode,
            )}` : ""}
          />
          <meta
            name="keywords"
            content="Digital Document Innovation - Brunner-Next"
          ></meta>
          <meta
            name="google-adsense-account"
            content="ca-pub-3879149687745447"
          ></meta>
          <GoogleAdScript />
        </Head>
        <div className="flex flex-col h-full overflow-x-hidden w-full">
          <Header />

          {/* Main: fixed 헤더(56px) 아래부터 시작, 남은 높이 차지 */}
          <main ref={mainRef} className={`flex-1 min-h-0 overflow-x-hidden w-full ${isChatRoomPage ? "overflow-hidden" : mobileFullScreen ? "overflow-hidden md:overflow-y-auto" : "overflow-y-auto"}`} style={{ paddingTop: "var(--site-header-height, 56px)" }}>
            {React.Children.map(children, (child) =>
              React.isValidElement(child) ? React.cloneElement(child) : child,
            )}
          </main>

          <div className={isChatRoomPage || mobileFullScreen ? "hidden md:block" : ""}>
            <Footer />
          </div>
        </div>
      </BodySection>
    </div>
  );
}
