"use client";
// 공통 결제 모듈(클라) — 토스페이먼츠 결제창 호출. 기능 무관 재사용.

const CLIENT_KEY = process.env.NEXT_PUBLIC_TOSS_CLIENT_KEY;

export const isTossEnabled = () => !!CLIENT_KEY;

export const genOrderId = (prefix = "ord") =>
  `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

const loadToss = () =>
  new Promise((resolve, reject) => {
    if (typeof window === "undefined") return reject(new Error("no window"));
    if (window.TossPayments) return resolve(window.TossPayments);
    const s = document.createElement("script");
    s.src = "https://js.tosspayments.com/v1/payment";
    s.onload = () => resolve(window.TossPayments);
    s.onerror = () => reject(new Error("Toss SDK 로드 실패"));
    document.head.appendChild(s);
  });

/**
 * 결제창 호출 → 성공 시 successUrl로 리다이렉트(paymentKey/orderId/amount 쿼리 포함).
 * @param {object} p { amount, orderName, orderId?, successUrl, failUrl, method?, customerName? }
 */
export const requestTossPayment = async ({
  amount, orderName, orderId, successUrl, failUrl, method = "카드", customerName,
}) => {
  if (!CLIENT_KEY) throw new Error("NOT_READY");
  const TossPayments = await loadToss();
  const toss = TossPayments(CLIENT_KEY);
  await toss.requestPayment(method, {
    amount,
    orderId: orderId || genOrderId(),
    orderName,
    customerName,
    successUrl,
    failUrl,
  });
};
