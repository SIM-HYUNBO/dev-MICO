import { useEffect, useState } from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import { RequestServer } from "@/components/core/client/requestServer";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import { Select } from "antd";

const DEFAULT_MODELS = [
  { id: "free-auto", labelKey: "edocAiProviderFreeAuto" },
  { id: "user-key-auto", labelKey: "edocAiProviderUserKeyAuto" },
];

export default function AIModelSelector({ model, setAIModel }) {
  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");

  const [models, setModels] = useState(DEFAULT_MODELS);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(constants.emptyString);
  const { BrunnerMessageBox, openOkCancelModal, openOkModal, openInputModal } =
    useModal();

  useEffect(() => {
    setCurrentSystemCode(userInfo.getCurrentSystemCode());
    setCurrentLoginUserId(userInfo.getLoginUserId());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  const fetchModels = async () => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage(
          `LOGIN_REQUIRED`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Error,
      );
      return;
    }

    setLoading(true);
    setError(constants.emptyString);
    try {
      const jRequest = {
        commandName: constants.commands.EDOC_AI_GET_MODEL_LIST,
                userId: currentLoginUserId,
        languageCode: currentLanguageCode,
      };

      const jResponse = await RequestServer(jRequest);
      setModels(jResponse.models || []);
    } catch (e) {
      openOkModal(
        `${commonFunctions.getResourceByLanguage(
          `FAILED_TO_LOAD_DATA`,
          constants.resourceType.message,
          currentLanguageCode,
        )}: ${e}`,
        constants.messageCategory.Exception,
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <BrunnerMessageBox />

      <Select
        style={{ width: "100%" }}
        value={model || undefined}
        onChange={(value) => setAIModel(value)}
        onDropdownVisibleChange={(open) => {
          if (open) fetchModels();
        }}
        loading={loading}
        placeholder={commonFunctions.getResourceByLanguage("aiSelectModel", constants.resourceType.label, currentLanguageCode)}
        options={models.map((m) => ({
          label: m.labelKey
            ? commonFunctions.getResourceByLanguage(m.labelKey, constants.resourceType.label, currentLanguageCode)
            : m.id,
          value: m.id,
        }))}
        getPopupContainer={(trigger) => trigger.parentNode} // ← 추가!
      />

      {error && <div className="text-danger text-sm">{error}</div>}
    </div>
  );
}
