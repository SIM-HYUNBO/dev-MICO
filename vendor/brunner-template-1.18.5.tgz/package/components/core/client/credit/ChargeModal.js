"use client";

import { useState } from "react";
import { X } from "lucide-react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { requestTossPayment, isTossEnabled } from "@/components/core/client/payment/tossCheckout";
import { useModal } from "@/components/core/client/brunnerMessageBox";

const hexEncode = (str) =>
  Array.from(new TextEncoder().encode(str)).map((b) => b.toString(16).padStart(2, "0")).join("");

const L = (key) => {
  const value = commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode()
  );
  return value || key;
};

const PACKAGES = [1000, 3000, 5000, 10000];

export default function ChargeModal({ onClose }) {
  const { BrunnerMessageBox, openOkModal } = useModal();
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState(PACKAGES[0]);
  const enabled = isTossEnabled();
  const selectedCredits = Math.floor(selected / 10);

  // 현재 경로. 결제 결과 파라미터가 누적되지 않게 기존 쿼리는 떼어낸다.
  const currentPath = () => {
    if (typeof window === "undefined") return "/";
    const p = window.location.pathname || "/";
    return p.startsWith("/") ? p : "/";
  };

  const pay = async () => {
    if (!enabled) {
      openOkModal(L("creditChargeSoon"), constants.messageCategory.Warning);
      return;
    }

    const userId = userInfo.getLoginUserId();
    if (!userId) {
      openOkModal(L("creditLoginNeeded"), constants.messageCategory.Warning);
      return;
    }

    setBusy(true);
    try {
      const returnTo = currentPath();
      const orderId = `zicp_${hexEncode(userId)}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
      await requestTossPayment({
        amount: selected,
        orderId,
        orderName: L("creditChargeOrderName").replace("{credits}", selectedCredits),
        customerName: userInfo.getLoginUserName?.() || userId || "user",
        // 결제가 끝나면 충전을 시작한 화면으로 돌아온다. 예전에는 무조건
        // 계정정보 화면으로 보내서, 홈에서 충전해도 엉뚱한 데로 튕겼다.
        successUrl: `${window.location.origin}/api/payment/success?userId=${encodeURIComponent(userId)}&returnTo=${encodeURIComponent(returnTo)}`,
        failUrl: `${window.location.origin}${returnTo}${returnTo.includes("?") ? "&" : "?"}pay=fail`,
      });
    } catch (e) {
      const message = e?.message === "NOT_READY" ? L("creditChargeSoon") : e?.message || L("creditChargeStartFail");
      openOkModal(message, constants.messageCategory.Error);
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-slate-950/60 p-4" onClick={onClose}>
      <BrunnerMessageBox />
      <div
        className="w-full max-w-sm rounded-xl border border-[var(--border)] bg-[var(--surface)] p-5 text-[var(--text)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-[var(--text)]">{L("creditChargeTitle")}</h3>
            <p className="mt-1 text-sm text-[var(--text-muted)]">{L("creditChargeRate")}</p>
          </div>
          <button type="button" onClick={onClose} aria-label={L("close")} className="rounded-md p-1 text-[var(--text-muted)] transition hover:bg-[var(--surface-alt)] hover:text-[var(--text)]">
            <X size={18} />
          </button>
        </div>

        {!enabled && (
          <p className="mb-3 rounded-lg bg-amber-50 px-3 py-2 text-xs font-medium text-amber-700">
            {L("creditChargeSoon")}
          </p>
        )}

        <div className="grid grid-cols-2 gap-2">
          {PACKAGES.map((won) => {
            const credits = Math.floor(won / 10);
            const active = selected === won;
            return (
              <button
                key={won}
                type="button"
                onClick={() => setSelected(won)}
                className={`rounded-lg border p-3 text-left transition ${
                  active
                    ? "border-[var(--brand-blue,#2563eb)] bg-[var(--brand-blue,#2563eb)]/10 text-[var(--text)]"
                    : "border-[var(--border)] bg-[var(--surface)] text-[var(--text)] hover:bg-[var(--surface-alt)]"
                }`}
              >
                <div className="text-sm font-bold">{L("creditChargeCredits").replace("{n}", credits.toLocaleString())}</div>
                <div className="mt-1 text-xs text-[var(--text-muted)]">{L("creditChargeAmountWon").replace("{n}", won.toLocaleString())}</div>
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={pay}
          disabled={busy}
          className="mt-4 w-full rounded-lg bg-blue-600 px-4 py-3 text-sm font-bold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {busy ? L("creditChargeOpening") : `${L("creditChargeCredits").replace("{n}", selectedCredits.toLocaleString())} ${L("creditChargeGo")}`}
        </button>
      </div>
    </div>
  );
}
