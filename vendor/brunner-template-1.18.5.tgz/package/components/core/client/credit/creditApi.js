"use client";

/**
 * 크레딧 클라이언트 API.
 * 원본에서는 aiStudioApi 안에 섞여 있던 호출을 크레딧만 떼어냈다.
 */

import { RequestServer } from "@/components/core/client/requestServer";
import * as constants from "@/lib/constants";
import * as userInfo from "@/components/core/client/frames/userInfo";

const call = async (commandName, extra = {}) =>
  RequestServer({
    commandName,
        userId: userInfo.getLoginUserId?.(),
    ...extra,
  });

export const creditApi = {
  balance: () => call(constants.commands.CREDIT_BALANCE),
  ledger: () => call(constants.commands.CREDIT_LEDGER),
  payments: () => call(constants.commands.PAYMENT_HISTORY),
  cancelPayment: (orderId) => call(constants.commands.PAYMENT_CANCEL, { orderId }),
};
