"use client";

import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { creditApi } from "./creditApi";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useModal } from "@/components/core/client/brunnerMessageBox";

const fmt = (n) => Number(n ?? 0).toLocaleString();

const when = (v, languageCode) => {
  if (!v) return "";
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? String(v) : d.toLocaleString(languageCode || undefined);
};

// 원장의 reason 은 코드값이라 화면에서 라벨로 바꾼다. 모르는 값이면 원문을 그대로 둔다.
const REASON_KEY = {
  starter: "creditReasonStarter",
  purchase: "creditReasonPurchase",
  refund: "creditReasonRefund",
  gift: "creditReasonGift",
  grant: "creditReasonGrant",
  spend: "creditReasonSpend",
  refundRollback: "creditReasonRefundRollback",
};

const STATUS_KEY = {
  APPROVED: "paymentStatusApproved",
  CANCELED: "paymentStatusCanceled",
  PARTIAL_CANCELED: "paymentStatusPartialCanceled",
};

export default function CreditLedgerModal({ onClose }) {
  const { BrunnerMessageBox, openOkModal, openOkCancelModal } = useModal();
  const [languageCode, setLanguageCode] = useState("");
  const [canceling, setCanceling] = useState("");
  const [tab, setTab] = useState("ledger"); // ledger | payments
  const [rows, setRows] = useState([]);
  const [payments, setPayments] = useState([]);
  const [balance, setBalance] = useState(null);
  const [loading, setLoading] = useState(true);
  const [ledgerError, setLedgerError] = useState("");
  const [paymentError, setPaymentError] = useState("");

  const tl = (key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.label, languageCode) || key;

  const tm = (key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.message, languageCode) || key;

  // 취소 후에는 잔액·크레딧 내역·결제 내역이 한꺼번에 달라진다. 세 개를 같이 다시 받는다.
  const reload = async () => {
    const [b, l, p] = await Promise.all([
      creditApi.balance(),
      creditApi.ledger(),
      creditApi.payments(),
    ]);
    if (b?.error_code === constants.errorCode.Success) setBalance(b.balance);
    if (l?.error_code === constants.errorCode.Success) setRows(l.ledger || []);
    if (p?.error_code === constants.errorCode.Success) setPayments(p.payments || []);
  };

  const cancelPayment = async (payment) => {
    const confirmed = await openOkCancelModal(
      tm("PAYMENT_CANCEL_CONFIRM")
        .replace("{won}", fmt(payment.amount_won))
        .replace("{credits}", fmt(payment.credits_granted)),
      constants.messageCategory.Confirm,
    ).catch(() => false);
    if (!confirmed) return;

    setCanceling(payment.order_id);
    try {
      const res = await creditApi.cancelPayment(payment.order_id);
      if (res?.error_code === constants.errorCode.Success) {
        await reload();
        openOkModal(tm("PAYMENT_CANCEL_DONE"), constants.messageCategory.Info);
      } else {
        openOkModal(res?.error_message || tm("PAYMENT_CANCEL_FAILED"), constants.messageCategory.Warning);
      }
    } catch (e) {
      openOkModal(e?.message || tm("PAYMENT_CANCEL_FAILED"), constants.messageCategory.Warning);
    } finally {
      setCanceling("");
    }
  };

  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode());
    (async () => {
      try {
        // 결제 내역까지 한 번에 받아 둔다. 탭을 눌렀을 때 다시 기다리게 하지 않는다.
        const [b, l, p] = await Promise.all([
          creditApi.balance(),
          creditApi.ledger(),
          creditApi.payments(),
        ]);
        if (b?.error_code === constants.errorCode.Success) setBalance(b.balance);
        if (l?.error_code === constants.errorCode.Success) setRows(l.ledger || []);
        else setLedgerError(l?.error_message || tl("creditLedgerError"));
        // 한쪽이 실패해도 다른 탭은 그대로 보여야 한다. 예전에는 원장 오류가
        // 정상적으로 받아온 결제 내역까지 가렸다.
        if (p?.error_code === constants.errorCode.Success) setPayments(p.payments || []);
        else setPaymentError(p?.error_message || tl("creditLedgerError"));
      } catch (e) {
        setLedgerError(e?.message || "");
        setPaymentError(e?.message || "");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const TabButton = ({ id, label }) => (
    <button
      type="button"
      onClick={() => setTab(id)}
      className={`rounded-md px-3 py-1.5 text-xs font-bold transition ${
        tab === id
          ? "bg-[var(--brand-blue,#2563eb)] text-white"
          : "bg-[var(--surface-alt)] text-[var(--text-muted)] hover:text-[var(--text)]"
      }`}
    >
      {label}
    </button>
  );

  const emptyText = tab === "ledger" ? tl("creditLedgerEmpty") : tl("paymentHistoryEmpty");

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/60 p-4"
      onClick={onClose}
    >
      <BrunnerMessageBox />
      <div
        className="max-h-[82vh] w-full max-w-lg overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-3 border-b border-[var(--border)] px-5 py-4">
          <div className="min-w-0">
            <h3 className="text-base font-bold text-[var(--text)]">{tl("creditLedgerTitle")}</h3>
            {balance !== null && (
              <p className="mt-1 text-sm text-[var(--text-muted)]">
                {tl("creditLedgerBalance").replace("{n}", fmt(balance))}
              </p>
            )}
            <div className="mt-3 flex gap-2">
              <TabButton id="ledger" label={tl("creditTabLedger")} />
              <TabButton id="payments" label={tl("creditTabPayments")} />
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={tl("creditLedgerClose")}
            title={tl("creditLedgerClose")}
            className="shrink-0 rounded-md p-1 text-[var(--text-muted)] transition hover:bg-[var(--surface-alt)] hover:text-[var(--text)]"
          >
            <X size={18} />
          </button>
        </div>

        <div className="max-h-[58vh] overflow-y-auto px-5 py-4">
          {loading ? (
            <p className="py-10 text-center text-sm text-[var(--text-muted)]">{tl("creditLoading")}</p>
          ) : (tab === "ledger" ? ledgerError : paymentError) ? (
            <p className="rounded-lg bg-[var(--danger,#ef4444)]/10 px-3 py-3 text-sm font-semibold text-[var(--danger,#ef4444)]">
              {tab === "ledger" ? ledgerError : paymentError}
            </p>
          ) : (tab === "ledger" ? rows : payments).length === 0 ? (
            <p className="py-10 text-center text-sm text-[var(--text-muted)]">{emptyText}</p>
          ) : tab === "ledger" ? (
            <ul className="divide-y divide-[var(--border)]">
              {rows.map((r) => {
                const delta = Number(r.delta || 0);
                return (
                  <li
                    key={r.ledger_id || `${r.created_at}-${r.reason}-${r.delta}`}
                    className="flex items-center justify-between gap-4 py-3 text-sm"
                  >
                    <div className="min-w-0">
                      <div className="font-medium text-[var(--text)]">
                        {REASON_KEY[r.reason] ? tl(REASON_KEY[r.reason]) : r.reason || tl("creditTabLedger")}
                      </div>
                      <div className="mt-0.5 text-xs text-[var(--text-muted)]">{when(r.created_at, languageCode)}</div>
                    </div>
                    <div className="shrink-0 text-right">
                      <div className={delta >= 0 ? "font-bold text-[var(--brand-emerald,#059669)]" : "font-bold text-[var(--text)]"}>
                        {delta >= 0 ? "+" : ""}
                        {fmt(delta)}
                      </div>
                      <div className="mt-0.5 text-xs text-[var(--text-muted)]">
                        {tl("creditLedgerBalanceAfter").replace("{n}", fmt(r.balance_after))}
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : (
            <ul className="divide-y divide-[var(--border)]">
              {payments.map((p) => {
                const canceled = p.status !== "APPROVED";
                return (
                  <li key={p.order_id} className="flex items-start justify-between gap-4 py-3 text-sm">
                    <div className="min-w-0">
                      <div className="flex min-w-0 items-center gap-2">
                        <span className="font-medium text-[var(--text)]">
                          {tl("paymentAmountWon").replace("{n}", fmt(p.amount_won))}
                        </span>
                        {canceled && (
                          <span className="shrink-0 rounded bg-[var(--danger,#ef4444)]/10 px-1.5 py-0.5 text-[11px] font-bold text-[var(--danger,#ef4444)]">
                            {STATUS_KEY[p.status] ? tl(STATUS_KEY[p.status]) : p.status}
                          </span>
                        )}
                      </div>
                      <div className="mt-0.5 text-xs text-[var(--text-muted)]">
                        {when(p.approved_at, languageCode)}
                        {p.method ? ` · ${p.method}` : ""}
                      </div>
                      {/* 문의 시 주문번호를 불러 줘야 대조가 된다 */}
                      <div className="mt-0.5 truncate font-mono text-[11px] text-[var(--text-muted)]">{p.order_id}</div>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-1.5 text-right">
                      <div>
                        <div className="font-bold text-[var(--brand-emerald,#059669)]">
                          +{fmt(p.credits_granted)}
                        </div>
                        <div className="mt-0.5 text-xs text-[var(--text-muted)]">{tl("creditUnit")}</div>
                      </div>
                      {/* 취소는 아직 승인 상태인 결제에만 연다. 부분취소는 없고 전액만 다룬다. */}
                      {!canceled && (
                        <button
                          type="button"
                          onClick={() => cancelPayment(p)}
                          disabled={canceling === p.order_id}
                          className="rounded-md border border-[var(--border)] px-2 py-1 text-xs font-semibold text-[var(--text-muted)] transition hover:border-[var(--danger,#ef4444)] hover:text-[var(--danger,#ef4444)] disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          {canceling === p.order_id ? tl("paymentCancelWorking") : tl("paymentCancelAction")}
                        </button>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
