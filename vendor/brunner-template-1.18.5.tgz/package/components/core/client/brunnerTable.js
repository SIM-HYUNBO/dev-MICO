"use client";

import React, {
  useState,
  useEffect,
  useRef,
  useImperativeHandle,
  forwardRef,
  useMemo,
  useCallback,
} from "react";

import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

import { useTable, useSortBy } from "react-table";
import { FixedSizeList as List } from "react-window";
import { Button, Checkbox } from "antd";
import * as XLSX from "xlsx";

// 컬럼에 width 가 없을 때 쓰는 기본 폭. 정의가 없어 폭 미지정 컬럼에서 ReferenceError 가 났다.
const DEFAULT_COL_WIDTH = constants.gridColumnWidth.Standard;

const ROW_HEIGHT = 24;

const BrunnerTable = forwardRef((props, ref) => {
  const {
    initialAutoRefresh = false,
    tableTitle,
    FilteringConditions,
    columnHeaders,
    fetchTableDataHandler,
    addNewRowDataHandler,
    editRowDataHandler,
    deleteRowDataHandler,
    actionRowDataHandler,
    actionButtonTooltip,
    editButtonTooltip,
    deleteButtonTooltip,
    rowSelectable = false, // ✅ 체크박스 선택 가능 여부
  } = props;

  const [isMobile, setIsMobile] = useState(false);
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  const [tableData, setTableData] = useState([]);
  const [editingCell, setEditingCell] = useState(null);
  const [selectedRowIndexes, setSelectedRowIndexes] = useState([]); // ✅ 배열 기반 선택 관리

  const selectedRows = selectedRowIndexes.map((idx) => tableData[idx] || {}); // 선택된 행 배열

  /* =========================
     데이터 로딩
  ========================= */
  const refreshTableData = async () => {
    if (!fetchTableDataHandler) return;
    const data = await fetchTableDataHandler();
    setTableData(data || []);
    setSelectedRowIndexes([]);
  };

  useEffect(() => {
    if (initialAutoRefresh) refreshTableData();
  }, []);

  useImperativeHandle(ref, () => ({
    refreshTableData,
    getSelectedRows: () => selectedRows, // ✅ 선택된 행 배열 반환
  }));

  /* =========================
     컬럼 정의
  ========================= */
  const columns = useMemo(() => {
    const base = columnHeaders.map((c) => ({
      ...c,
      width: c.width ?? DEFAULT_COL_WIDTH,
    }));

    // ✅ rowSelectable 체크박스 컬럼 추가
    if (rowSelectable) {
      base.unshift({
        id: "__selection",
        Header: () => {
          const allSelected =
            tableData.length > 0 &&
            selectedRowIndexes.length === tableData.length;
          const someSelected =
            selectedRowIndexes.length > 0 &&
            selectedRowIndexes.length < tableData.length;

          return (
            <Checkbox
              checked={allSelected}
              indeterminate={someSelected}
              onChange={(e) => {
                const checked = e.target.checked;
                setSelectedRowIndexes(
                  checked ? tableData.map((_, idx) => idx) : [],
                );
              }}
            />
          );
        },
        Cell: ({ row }) => (
          <Checkbox
            checked={selectedRowIndexes.includes(row.index)}
            onChange={() => {
              setSelectedRowIndexes((prev) => {
                if (prev.includes(row.index)) {
                  return prev.filter((idx) => idx !== row.index); // 해제
                } else {
                  return [...prev, row.index]; // 선택
                }
              });
            }}
          />
        ),
        width: 40,
      });
    }

    if (editRowDataHandler || deleteRowDataHandler || actionRowDataHandler) {
      base.push({
        Header: "Action",
        id: "actions",
        width: constants.gridColumnWidth.Action,
        Cell: ({ row }) => (
          <div className="flex justify-center gap-1">
            {editRowDataHandler && (
              <Button
                size="small"
                onClick={() => editRowDataHandler(row)}
                title={editButtonTooltip ?? "Edit"}
              >
                ✏️
              </Button>
            )}
            {deleteRowDataHandler && (
              <Button
                size="small"
                danger
                onClick={() => deleteRowDataHandler(row)}
                title={deleteButtonTooltip ?? "Delete"}
              >
                🗑️
              </Button>
            )}
            {actionRowDataHandler && (
              <Button
                size="small"
                onClick={() => actionRowDataHandler(row)}
                title={actionButtonTooltip ?? "Action"}
              >
                ▶️
              </Button>
            )}
          </div>
        ),
      });
    }

    return base;
  }, [
    columnHeaders,
    editRowDataHandler,
    deleteRowDataHandler,
    actionRowDataHandler,
    rowSelectable,
    selectedRowIndexes,
    tableData,
  ]);

  const hiddenColumns = useMemo(
    () => columns.filter((c) => c.hidden).map((c) => c.accessor || c.id),
    [columns],
  );

  const tableInstance = useTable(
    {
      columns,
      data: tableData,
      initialState: { hiddenColumns },
    },
    useSortBy,
  );

  const { headerGroups, rows, prepareRow } = tableInstance;

  /* =========================
     셀 수정
  ========================= */
  const handleCellValueChange = useCallback((value, rowIndex, columnId) => {
    setTableData((prev) => {
      const next = [...prev];
      next[rowIndex] = { ...next[rowIndex], [columnId]: value };
      return next;
    });
  }, []);

  const TableInputDataArea = () => {
    const initialInputState = {};
    columnHeaders.forEach((header) => {
      switch (header.type) {
        case "number":
          initialInputState[header.accessor] = 0;
          break;
        case "checkbox":
          initialInputState[header.accessor] = false;
          break;
        case "datetime-local":
          initialInputState[header.accessor] = new Date()
            .toISOString()
            .slice(0, 16);
          break;
        default:
          initialInputState[header.accessor] = constants.emptyString;
          break;
      }
    });

    const [inputValues, setInputValues] = useState(initialInputState);

    const handleInputChange = (e, accessor) => {
      const { value, checked } = e.target;
      setInputValues((prevState) => ({
        ...prevState,
        [accessor]: e.target.type == "checkbox" ? checked : value,
      }));
    };

    return (
      <div className={`mb-2 table w-full border p-2 text-sm`}>
        {columnHeaders.map(
          (header) =>
            !header.input_hidden && (
              <div key={header.accessor} className="flex items-center mb-2">
                <label
                  className="w-32 
                             mr-1  
                             text-sm
                             medium-text-color"
                >
                  {header.Header}
                </label>
                <input
                  type={header.type}
                  name={header.accessor}
                  value={inputValues[header.accessor]}
                  onChange={(e) => handleInputChange(e, header.accessor)}
                  placeholder={header.Header}
                  className={`border 
                            rounded 
                            medium-text-color 
                            dark-bg-color 
                            flex-1 
                            ${
                              header.type === "number"
                                ? "text-right"
                                : "text-left"
                            } text-sm`}
                />
              </div>
            ),
        )}
        <Button
          onClick={() => {
            addNewRowDataHandler(inputValues);
          }}
          className="py-2 px-4 rounded mt-2"
          style={{ backgroundColor: "var(--success)", color: "#fff", borderColor: "transparent" }}
          style={{ alignSelf: "flex-end" }}
        >
          {commonFunctions.getResourceByLanguage(
            `add`,
            constants.resourceType.label,
            currentLanguageCode,
          )}
        </Button>
      </div>
    );
  };

  const EditableCell = React.memo(({ cell, row }) => {
    const { column, value } = cell;
    const isEditing =
      editingCell?.rowIndex === row.index &&
      editingCell?.columnId === column.id;

    if (!column.editable) return cell.render("Cell");

    if (column.type === "checkbox") {
      return (
        <input
          type="checkbox"
          checked={!!value}
          onChange={(e) =>
            handleCellValueChange(e.target.checked, row.index, column.id)
          }
        />
      );
    }

    if (isEditing) {
      return (
        <input
          autoFocus
          defaultValue={value}
          onBlur={(e) => {
            handleCellValueChange(e.target.value, row.index, column.id);
            setEditingCell(null);
          }}
          className="w-full border px-1"
        />
      );
    }

    return (
      <div
        onClick={() =>
          setEditingCell({ rowIndex: row.index, columnId: column.id })
        }
        className="truncate cursor-pointer"
      >
        {value ?? "\u00A0"}
      </div>
    );
  });

  /* =========================
     Row Renderer
  ========================= */
  const RenderRow = ({ index, style }) => {
    const row = rows[index];
    prepareRow(row);

    // 화면 크기에 따라 세로형/가로형 선택
    // const isMobile = window.innerWidth < 768; // md breakpoint 기준

    if (isMobile) {
      return (
        <div
          className="border rounded p-2 mb-2 general-text-bg-color shadow-sm w-full max-w-full break-words"
          style={{ wordWrap: "break-word" }}
        >
          {row.cells.map((cell) => (
            <div
              key={cell.column.id}
              className="flex justify-between mb-1 flex-wrap"
            >
              <span className="font-semibold text-sm w-1/3 break-words">
                {cell.column.Header}
              </span>
              <div className="w-2/3 break-words">
                <EditableCell cell={cell} row={row} />
              </div>
            </div>
          ))}
        </div>
      );
    }
    // 데스크탑 가로형
    return (
      <div
        style={{
          ...style,
          display: "flex",
          width: "100%",
        }}
        className="border-b"
      >
        {row.cells.map((cell) => {
          const width = cell.column.width;

          return (
            <div
              key={cell.column.id}
              style={{
                flex: `0 0 ${width}px`,
              }}
              className="px-2 flex items-center truncate text-sm"
            >
              <EditableCell cell={cell} row={row} />
            </div>
          );
        })}
      </div>
    );
  };

  /* =========================
     Excel
  ========================= */
  const handleExcelDownload = () => {
    // if (!tableData.length) return;

    const visibleCols = columns.filter(
      (c) => !c.hidden && c.id !== "actions" && c.id !== "__selection",
    );

    const header = visibleCols.map((c) => c.Header);
    const body = tableData.map((row) =>
      visibleCols.map((c) => row[c.accessor] ?? ""),
    );

    const ws = XLSX.utils.aoa_to_sheet([header, ...body]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, tableTitle || "Sheet1");
    XLSX.writeFile(wb, `${tableTitle || "Table"}.xlsx`);
  };

  /* =========================
     Render
  ========================= */
  return (
    <div className="w-full overflow-x-auto my-2 px-2 flex-wrap text-sm">
      {tableTitle && <h2 className="text-xl">{tableTitle}</h2>}

      <div className="flex flex-col md:flex-row md:items-end md:justify-between mb-2 gap-2 w-full">
        {/* 검색조건: 항상 상단 */}
        <div className="flex flex-wrap items-center gap-2 w-full">
          {FilteringConditions && <FilteringConditions />}
        </div>

        {/* 엑셀 다운로드 버튼: 모바일에서는 아래로, 데스크탑에서는 오른쪽 */}
        <div className="flex-shrink-0 w-full md:w-auto">
          <Button
            onClick={handleExcelDownload}
            className="px-4 rounded text-sm inline-flex w-auto"
            style={{ backgroundColor: "var(--brand-blue)", color: "#fff", borderColor: "transparent" }}
          >
            {commonFunctions.getResourceByLanguage(
              `excelDownload`,
              constants.resourceType.label,
              currentLanguageCode,
            )}
          </Button>
        </div>
      </div>
      {/* Header */}
      {/* 데스크탑용 가로 테이블 헤더 */}
      <div className="hidden md:flex border-b semi-text-bg-color font-semibold text-sm w-max min-w-full">
        {headerGroups.map((headerGroup) =>
          headerGroup.headers.map((col) => (
            <div
              {...col.getHeaderProps(col.getSortByToggleProps())}
              key={col.id}
              style={{
                flex: `0 0 ${col.width}px`,
                width: col.width,
                minWidth: col.width,
                maxWidth: col.width,
                boxSizing: "border-box",
              }}
              className="px-2 py-2 truncate flex items-center justify-between"
            >
              <span>{col.render("Header")}</span>
              {col.canSort && (
                <span className="ml-1 text-xs">
                  {col.isSorted ? (col.isSortedDesc ? "🔽" : "🔼") : "↕️"}
                </span>
              )}
            </div>
          )),
        )}
      </div>

      {/* Body */}
      {/* 데스크탑 가로형 테이블 */}
      <div className="hidden md:block">
        <List
          height={600}
          itemCount={rows.length}
          itemSize={ROW_HEIGHT}
          width="100%"
        >
          {RenderRow}
        </List>
      </div>

      {/* 모바일 세로형 카드 */}
      <div className="block md:hidden">
        {rows.map((_, idx) => (
          <RenderRow key={idx} index={idx} />
        ))}
      </div>

      {addNewRowDataHandler && <TableInputDataArea />}
    </div>
  );
});

export default BrunnerTable;
