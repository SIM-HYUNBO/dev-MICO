"use client";

import { useRef, useState, useEffect } from "react";
import { Button, Input } from "antd";

import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";

import { useModal } from "@/components/core/client/brunnerMessageBox";
import Loading from "@/components/core/client/loading";
import BrunnerTable from "@/components/core/client/brunnerTable";
import GoverningMessage from "@/components/core/client/governingMessage";

export const TransactionHistoryViewer = () => {
  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");

  const tableRef = useRef(null);
  const inputRef = useRef(null); // 검색어 Ref
  const { BrunnerMessageBox, openOkModal } = useModal();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setCurrentSystemCode(userInfo.getCurrentSystemCode());
    setCurrentLoginUserId(userInfo.getLoginUserId());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  const columns = [
    {
      Header: "생성일시",
      accessor: "create_time",
      width: constants.gridColumnWidth.DateTime,
    },
    {
      Header: "요청 메시지",
      accessor: "request_message_content",
      width: constants.gridColumnWidth.MessageLong,
    },
    {
      Header: "응답 메시지",
      accessor: "reply_message_content",
      width: constants.gridColumnWidth.MessageShort,
    },
    {
      Header: "요청 IP",
      accessor: "request_ip",
      width: constants.gridColumnWidth.IPAddress,
    },
    {
      Header: "트랜잭션 ID",
      accessor: "transaction_id",
      width: constants.gridColumnWidth.TxnId,
    },
  ];

  const FilteringConditions = () => {
    return (
      <div className="flex flex-wrap items-center gap-2 mt-5">
        <Input
          placeholder={commonFunctions.getResourceByLanguage(
            "inputKeyword",
            constants.resourceType.label,
            currentLanguageCode,
          )}
          allowClear
          style={{ width: 240 }}
          ref={inputRef}
          onPressEnter={() => tableRef.current?.refreshTableData()}
        />

        <Button
          onClick={() => tableRef.current?.refreshTableData()}
          className="px-4 py-2 rounded"
          style={{ backgroundColor: "var(--brand-blue)", color: "#fff", borderColor: "transparent" }}
        >
          {commonFunctions.getResourceByLanguage(
            "view",
            constants.resourceType.label,
            currentLanguageCode,
          )}
        </Button>
      </div>
    );
  };

  const fetchTableData = async () => {
    const keyword = inputRef.current?.input?.value || "";

    const jRequest = {
      commandName: constants.commands.TXN_HISTORY_SELECT_ALL,
            userId: currentLoginUserId,
      languageCode: currentLanguageCode,
      keyword,
    };

    try {
      setLoading(true);
      const jResponse = await RequestServer(jRequest);
      setLoading(false);

      if (jResponse.error_code !== constants.errorCode.Success) {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
        return [];
      }

      return (jResponse.data || []).map((row) => ({
        ...row,
        create_time: row.create_time
          ? new Date(row.create_time).toLocaleString()
          : "",
      }));
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
      return [];
    }
  };

  return (
    <>
      {loading && <Loading />}
      <BrunnerMessageBox />

      <div className="w-full items-start text-left text-sm">
        <BrunnerTable
          ref={tableRef}
          FilteringConditions={FilteringConditions}
          columnHeaders={columns}
          fetchTableDataHandler={fetchTableData}
          initialAutoRefresh={false}
          rowSelectable={false}
        />
      </div>
    </>
  );
};
