import { useState, useRef, useEffect, useMemo } from "react";
import { useDeviceType } from "@/lib/commonFunctions";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import { RequestServer } from "@/components/core/client/requestServer";
import { useRouter } from "next/navigation";
import { useMounted } from "@/lib/hooks/useMounted";
import MTopBar from "@/components/core/client/frames/mTopBar";
import MTabBar from "@/components/core/client/frames/mTabBar";
import Button from "@/components/core/client/ui/Button";
import Input from "@/components/core/client/ui/Input";
import Card from "@/components/core/client/ui/Card";
import Chip from "@/components/core/client/ui/Chip";
import Avatar from "@/components/core/client/ui/Avatar";

const KAKAO_SDK_URL = "https://t1.kakaocdn.net/kakao_js_sdk/2.7.5/kakao.min.js";
let kakaoSdkPromise = null;

const loadKakaoSdk = () => {
  if (typeof window === "undefined") return Promise.resolve(null);
  if (window.Kakao) return Promise.resolve(window.Kakao);

  if (!kakaoSdkPromise) {
    kakaoSdkPromise = new Promise((resolve, reject) => {
      const existing = document.querySelector(`script[src="${KAKAO_SDK_URL}"]`);
      if (existing) {
        existing.addEventListener("load", () => resolve(window.Kakao));
        existing.addEventListener("error", reject, { once: true });
        return;
      }

      const script = document.createElement("script");
      script.src = KAKAO_SDK_URL;
      script.async = true;
      script.onload = () => resolve(window.Kakao);
      script.onerror = (error) => {
        script.remove();
        reject(error);
      };
      document.head.appendChild(script);
    }).catch((error) => {
      kakaoSdkPromise = null;
      throw error;
    });
  }

  return kakaoSdkPromise;
};

export default function UserFriendContent({ onStartChat, onStartSecretChat, hideTitle = false }) {
  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");

  const mounted = useMounted();
  const { isMobile, isTablet } = useDeviceType();
  const tl = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.label,
      currentLanguageCode,
    );
  const tm = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.message,
      currentLanguageCode,
    );
  const router = useRouter();
  const { BrunnerMessageBox, openInputModal, openOkModal, openOkCancelModal } =
    useModal();
  const [userFriends, setUserFriends] = useState([]);
  const [searchKeyword, setSearchKeyword] = useState("");
  const [searchResult, setSearchResult] = useState([]);
  const [inviteLoading, setInviteLoading] = useState(false);
  const [activeFilter, setActiveFilter] = useState("all");
  const [recentInvites, setRecentInvites] = useState([]);
  const inviteRefreshTimerRef = useRef(null);

  useEffect(() => {
    if (mounted) setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, [mounted]);

  /* -------------------- 친구 목록 -------------------- */

  const loadFriends = async () => {
    const res = await RequestServer({
      commandName: constants.commands.FRIEND_LIST_BY_USER,
            userId: userInfo.getLoginUserId(),
    });

    if (res.error_code === constants.errorCode.Success) {
      setUserFriends(res.data || []);
    }
  };

  useEffect(() => {
    setCurrentSystemCode(userInfo.getCurrentSystemCode());
    setCurrentLoginUserId(userInfo.getLoginUserId());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());

    loadFriends();
    loadMyInvites();
  }, []);

  const loadMyInvites = async () => {
    const res = await RequestServer({
      commandName: constants.commands.FRIEND_LIST_MY_INVITES,
            userId: userInfo.getLoginUserId(),
    });
    if (res.error_code !== constants.errorCode.Success || !res.invites?.length) return;

    const toneMap = { accepted: "success", expired: "neutral", pending: "warn" };
    setRecentInvites(
      res.invites.map((inv) => ({
        id: inv.invite_code,
        label: inv.invite_code.slice(0, 8),
        tone: toneMap[inv.status] || "warn",
        statusKey: inv.status, // render 시 tl()로 번역
      }))
    );
  };

  useEffect(() => {
    const refreshOnVisible = () => {
      if (!document.hidden) loadFriends();
    };
    const refreshOnFocus = () => loadFriends();

    document.addEventListener("visibilitychange", refreshOnVisible);
    window.addEventListener("focus", refreshOnFocus);

    return () => {
      document.removeEventListener("visibilitychange", refreshOnVisible);
      window.removeEventListener("focus", refreshOnFocus);
      if (inviteRefreshTimerRef.current) {
        clearInterval(inviteRefreshTimerRef.current);
      }
    };
  }, []);

  /* -------------------- 친구 초대 링크 -------------------- */

  const startInviteRefreshPolling = () => {
    if (inviteRefreshTimerRef.current) {
      clearInterval(inviteRefreshTimerRef.current);
    }

    let count = 0;
    inviteRefreshTimerRef.current = setInterval(() => {
      count += 1;
      loadFriends();

      if (count >= 12) {
        clearInterval(inviteRefreshTimerRef.current);
        inviteRefreshTimerRef.current = null;
      }
    }, 5000);
  };

  const createFriendInvitePayload = async () => {
    const systemCode = currentSystemCode || userInfo.getCurrentSystemCode();
    const loginUserId = currentLoginUserId || userInfo.getLoginUserId();

    if (!systemCode || !loginUserId) {
      throw new Error(tm("LOGIN_REQUIRED"));
    }

    const res = await RequestServer({
      commandName: constants.commands.FRIEND_GENERATE_INVITE,
            userId: loginUserId,
    });

    if (res.error_code !== constants.errorCode.Success || !res.inviteCode) {
      throw new Error(res.error_message || tm("FAILED_TO_ADD_FRIEND"));
    }

    const url = `${window.location.origin}/invite/${res.inviteCode}`;
    setRecentInvites((prev) => [
      { id: res.inviteCode, label: res.inviteCode.slice(0, 8), tone: "warn", status: tl("friendsPending") },
      ...prev,
    ].slice(0, 3));

    return {
      url,
      title: tl("friendInviteShareTitle"),
      text: tl("friendInviteShareText"),
    };
  };

  const shareInviteLink = async () => {
    setInviteLoading(true);
    try {
      const { title, text, url } = await createFriendInvitePayload();
      const kakaoJsKey = process.env.NEXT_PUBLIC_KAKAO_JAVASCRIPT_KEY;

      if (kakaoJsKey) {
        let Kakao = null;
        try {
          Kakao = await loadKakaoSdk();
        } catch {
          Kakao = null;
        }

        if (Kakao?.Share?.sendDefault) {
          if (!Kakao.isInitialized()) Kakao.init(kakaoJsKey);
          Kakao.Share.sendDefault({
            objectType: "feed",
            content: {
              title,
              description: text,
              imageUrl: `${window.location.origin}/icon-512.png`,
              link: {
                mobileWebUrl: url,
                webUrl: url,
              },
            },
            buttons: [
              {
                title: tl("kakaoFriendAdd"),
                link: {
                  mobileWebUrl: url,
                  webUrl: url,
                },
              },
            ],
          });
          startInviteRefreshPolling();
          return;
        }
      }

      if (navigator.share) {
        await navigator.share({ title, text, url });
        startInviteRefreshPolling();
      } else {
        await navigator.clipboard.writeText(url);
        startInviteRefreshPolling();
        await openOkModal(tl("friendInviteCopied"), constants.messageCategory.Info);
      }
    } catch (e) {
      if (e?.name !== "AbortError") {
        await openOkModal(e.message, constants.messageCategory.Error);
      }
    } finally {
      setInviteLoading(false);
    }
  };

  const copyInviteLink = async () => {
    setInviteLoading(true);
    try {
      const { url } = await createFriendInvitePayload();
      await navigator.clipboard.writeText(url);
      startInviteRefreshPolling();
      await openOkModal(tl("friendInviteCopied"), constants.messageCategory.Info);
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Error);
    } finally {
      setInviteLoading(false);
    }
  };

  /* -------------------- 사용자 검색 -------------------- */

  const searchUser = async () => {
    if (!searchKeyword) return;

    const res = await RequestServer({
      commandName: constants.commands.FRIEND_SEARCH_USER_BY_KEYWORD,
            userId: currentLoginUserId,
      keyword: searchKeyword,
    });

    if (res.error_code === constants.errorCode.Success) {
      setSearchResult(res.data || []);
    } else {
      await openOkModal(res.error_message, constants.messageCategory.Error);
    }
  };

  /* -------------------- 친구 추가 -------------------- */

  const addFriend = async (targetId) => {
    const res = await RequestServer({
      commandName: constants.commands.FRIEND_ADD_FRIEND,
            userId: currentLoginUserId,
      friendId: targetId,
    });

    if (res.error_code === constants.errorCode.Success) {
      loadFriends();
    } else {
      openOkModal(res.error_message || tm("FAILED_TO_ADD_FRIEND"));
    }
  };

  /* -------------------- 친구 삭제 -------------------- */

  const deleteFriend = async (friend) => {
    const friendId = getFriendId(friend);
    const displayName = getFriendDisplayName(friend);
    const confirmed = await openOkCancelModal(
      tm("CONFIRM_DELETE_FRIEND")
        .replace("{0}", displayName)
        .replace("{1}", friendId),
      constants.messageCategory.Info,
    );
    if (!confirmed) return;

    const res = await RequestServer({
      commandName: constants.commands.FRIEND_DELETE_FRIEND,
            userId: currentLoginUserId,
      friendId,
    });

    if (res.error_code === constants.errorCode.Success) {
      loadFriends();
    } else {
      openOkModal(
        res.error_message || tm("FAILED_TO_DELETE_FRIEND"),
        constants.messageCategory.Error,
      );
    }
  };

  /* -------------------- 차단 -------------------- */

  const blockFriend = async (friendId) => {
    const res = await RequestServer({
      commandName: constants.commands.FRIEND_BLOCK_FRIEND,
            userId: currentLoginUserId,
      friendId,
    });

    if (res.error_code === constants.errorCode.Success) {
      loadFriends();
    }
  };

  const unblockFriend = async (friendId) => {
    const res = await RequestServer({
      commandName: constants.commands.FRIEND_UNBLOCK_FRIEND,
            userId: currentLoginUserId,
      friendId,
    });

    if (res.error_code === constants.errorCode.Success) {
      loadFriends();
    }
  };

  /* -------------------- 1:1 채팅 -------------------- */

  const startChat = async (friend) => {
    if (friend.status === "BLOCKED") {
      openOkModal(tm("BLOCKED_USER_CHAT_RESTRICTED"));
      return;
    }

    const res = await RequestServer({
      commandName: constants.commands.FRIEND_CHECK_CHATROOM_WITH_FRIEND,
            userId: currentLoginUserId,
      userName: userInfo.getLoginUserName(),
      friendId: friend.friend_id,
    });

    if (res.error_code === constants.errorCode.Success) {
      // jResponse.roomId가 null이 아니면 기존 채팅방으로 이동, null이면 새 채팅방 생성 후 이동

      // 👉 채팅 페이지 이동 (기존 구조 맞게 수정)
      onStartChat(res.roomId, res.roomName); // 🔥 여기로 넘김
    } else {
      openOkModal(res.error_message || tm("FAILED_TO_CREATE_CHATROOM"));
    }
  };

  const startSecretChat = async (friend) => {
    if (friend.status === "BLOCKED") {
      openOkModal(tm("BLOCKED_USER_CHAT_RESTRICTED"));
      return;
    }
    if (!onStartSecretChat) return;

    const res = await RequestServer({
      commandName: constants.commands.FRIEND_CHECK_SECRET_CHATROOM,
            userId: currentLoginUserId,
      userName: userInfo.getLoginUserName(),
      friendId: friend.friend_id,
    });

    if (res.error_code === constants.errorCode.Success) {
      onStartSecretChat(res.roomId, res.roomName, friend.friend_id);
    } else {
      openOkModal(res.error_message || tm("FAILED_TO_CREATE_CHATROOM"));
    }
  };

  const getFriendId = (friend) =>
    String(friend?.friend_id || friend?.friendId || friend?.user_id || friend?.userId || friend?.id || "").trim();

  const getFriendDisplayName = (friend) => {
    const friendId = getFriendId(friend);
    const candidates = [
      friend?.friend_name,
      friend?.friendName,
      friend?.friend_user_name,
      friend?.friendUserName,
      friend?.friend_register_name,
      friend?.register_name,
      friend?.user_name,
      friend?.userName,
      friend?.name,
      friend?.nickname,
    ];
    const name = candidates.find((value) => typeof value === "string" && value.trim().length > 0)?.trim();
    if (!name) return friendId || "BRUNNER";
    return name.length <= 1 && friendId ? `${name} / ${friendId}` : name;
  };

  const isFriendOnline = (friend) =>
    friend?.is_online === true ||
    friend?.online === true ||
    friend?.online_yn === "Y" ||
    friend?.onlineYn === "Y" ||
    friend?.connection_status === "ONLINE" ||
    friend?.presence === "ONLINE";

  const filteredFriends = useMemo(() => {
    const keyword = searchKeyword.trim().toLowerCase();
    return userFriends.filter((friend) => {
      const status = friend.status || "ACTIVE";
      const friendId = getFriendId(friend);
      const name = `${getFriendDisplayName(friend)} ${friendId}`.toLowerCase();
      if (keyword && !name.includes(keyword)) return false;
      if (activeFilter === "online") return isFriendOnline(friend);
      if (activeFilter === "blocked") return status === "BLOCKED";
      if (activeFilter === "secret") return status !== "BLOCKED";
      return true;
    });
  }, [activeFilter, searchKeyword, userFriends]);

  const filters = [
    { key: "all", label: tl("friendsFilterAll") },
    { key: "online", label: tl("friendsFilterOnline") },
    { key: "secret", label: tl("friendsFilterSecret") },
    { key: "blocked", label: tl("friendsFilterBlocked") },
  ];

  if (!mounted) return null;

  const statusLabelMap = { accepted: tl("friendsAccepted"), expired: tl("friendsExpired"), pending: tl("friendsPending") };
  const inviteItems = recentInvites.length > 0
    ? recentInvites.map((inv) => ({ ...inv, status: inv.statusKey ? (statusLabelMap[inv.statusKey] || inv.statusKey) : inv.status }))
    : null;

  const renderInvitePanel = (compact = false) => (
    <div className="space-y-4">
      <Card strong className="relative overflow-hidden border-0 bg-[image:var(--brand-gradient)] text-white">
        <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-white/15" />
        <div className="relative">
          <h3 className="text-lg font-extrabold text-white">{tl("friendsInviteTitle")}</h3>
          <p className="mt-2 text-sm leading-6 text-white/90">{tl("friendsInviteDesc")}</p>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            <Button variant="ghost" size="sm" disabled={inviteLoading} onClick={copyInviteLink} className="border-white/30 bg-white/15 text-white hover:opacity-90">
              {tl("copy")}
            </Button>
            <button
              type="button"
              onClick={shareInviteLink}
              disabled={inviteLoading}
              className="inline-flex items-center justify-center rounded-[var(--radius-md)] bg-[#FEE500] px-3 py-1.5 text-[13px] font-bold text-[#191919] transition hover:opacity-90 disabled:opacity-50"
            >
              {tl("kakaoFriendAdd")}
            </button>
          </div>
        </div>
      </Card>

      {!compact && inviteItems && (
        <Card>
          <h3 className="mb-3 text-xs font-bold uppercase tracking-[0.05em] text-[var(--text-muted)]">{tl("friendsRecentInvites")}</h3>
          <div className="space-y-2">
            {inviteItems.map((item) => (
              <div key={item.id} className="flex items-center justify-between gap-3 border-t border-[var(--border)] pt-2 first:border-t-0 first:pt-0">
                <span className="truncate text-sm text-[var(--text)]">{item.label}</span>
                <Chip tone={item.tone}>{item.status}</Chip>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );

  const renderFriendRow = (friend) => {
    const friendId = getFriendId(friend);
    const blocked = friend.status === "BLOCKED";
    const online = isFriendOnline(friend);
    const displayName = getFriendDisplayName(friend);
    const actionFriend = { ...friend, friend_id: friendId };
    return (
      <div key={friendId || displayName} className="flex flex-col gap-3 border-b border-[var(--border)] py-3 last:border-b-0 md:flex-row md:items-center">
        <div className="flex min-w-0 flex-1 items-center gap-3">
          <Avatar src={friend.profile_image_src || undefined} initial={displayName} size={44} color={(friendId || displayName || "B").length * 31} online={online} />
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-bold text-[var(--text)]">{displayName}</div>
            {friendId && <div className="mt-0.5 truncate text-xs font-medium text-[var(--text-subtle)]">@{friendId}</div>}
            <div className="mt-1 text-xs text-[var(--text-muted)]">{blocked ? tl("block") : online ? tl("friendsOnline") : tl("userFriendManagement")}</div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 pl-[56px] md:shrink-0 md:justify-end md:pl-0">
          {onStartSecretChat && (
            <Button variant="soft" size="sm" disabled={blocked} onClick={() => startSecretChat(actionFriend)}>{tl("friendsSecretChat")}</Button>
          )}
          <Button variant="soft" size="sm" disabled={blocked} onClick={() => startChat(actionFriend)}>{tl("chat")}</Button>
          {friend.status === "ACTIVE" ? (
            <Button variant="ghost" size="sm" onClick={() => blockFriend(friendId)}>{tl("block")}</Button>
          ) : (
            <Button variant="ghost" size="sm" onClick={() => unblockFriend(friendId)}>{tl("unblock")}</Button>
          )}
          <Button variant="ghost" size="sm" onClick={() => deleteFriend(actionFriend)}>{tl("delete")}</Button>
        </div>
      </div>
    );
  };

  return (
    <>
      <BrunnerMessageBox />
      <div className="min-h-full bg-[var(--bg)] text-[var(--text)]">
        {!hideTitle && <MTopBar title={tl("userFriendManagement")} />}
        <div className="tab-bar-pb mx-auto grid max-w-6xl gap-5 p-4 md:grid-cols-[1fr_320px] md:p-6">
          <section className="min-w-0">
            {!hideTitle && (
              <h2 className="page-title hidden md:block">
                {tl("userFriendManagement")}
              </h2>
            )}

            <div className="mb-4 md:hidden">{renderInvitePanel(true)}</div>

            <div className="mb-4 flex gap-2">
              <Input
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") searchUser(); }}
                placeholder={tl("friendsSearchPlaceholder")}
                aria-label={tl("friendsSearchPlaceholder")}
              />
              <Button onClick={searchUser}>{tl("search")}</Button>
            </div>

            <div className="mb-4 flex flex-wrap gap-2">
              {filters.map((filter) => (
                <button
                  key={filter.key}
                  type="button"
                  onClick={() => setActiveFilter(filter.key)}
                  className={`rounded-[var(--radius-pill)] border px-3 py-1.5 text-xs font-semibold transition ${
                    activeFilter === filter.key
                      ? "border-[rgba(2,132,199,0.30)] bg-[rgba(2,132,199,0.10)] text-[var(--brand-blue)]"
                      : "border-[var(--border)] text-[var(--text-muted)]"
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>

            {searchResult.length > 0 && (
              <Card className="mb-4">
                <div className="space-y-2">
                  {searchResult.map((u) => (
                    <div key={u.user_id} className="flex items-center justify-between gap-3 rounded-[var(--radius-md)] bg-[var(--surface-alt)] px-3 py-2">
                      <span className="truncate text-sm font-semibold text-[var(--text)]">{u.user_name} @{u.user_id}</span>
                      <Button size="sm" variant="success" onClick={() => addFriend(u.user_id)}>{tl("add")}</Button>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            <Card className="p-0">
              <div className="border-b border-[var(--border)] px-4 py-3">
                <h3 className="text-sm font-bold text-[var(--text)]">{tl("friendList")}</h3>
              </div>
              <div className="px-4">
                {filteredFriends.map(renderFriendRow)}
              </div>
            </Card>
          </section>

          <aside className="hidden md:block">
            {renderInvitePanel(false)}
          </aside>
        </div>
        {!hideTitle && <MTabBar />}
      </div>
    </>
  );
}
