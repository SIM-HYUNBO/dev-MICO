"use client";

import { useState, useEffect, useRef } from "react";
import { useMounted } from "@/lib/hooks/useMounted";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

// 설정의 컬러 테마를 그대로 따르는 스킨. 고정 스킨 하나를 기본값으로 두면
// 사용자가 고른 테마와 계산기만 따로 논다.
const AUTO_THEME_ID = "auto";

const readVar = (name, fallback) => {
  if (typeof window === "undefined") return fallback;
  const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return value || fallback;
};

// 배경이 밝은지 어두운지에 따라 글자색을 정한다. 브랜드색은 테마마다 명도가
// 달라서(예: 흑백 테마의 강조색은 흰색) 한쪽으로 고정하면 글씨가 사라진다.
const relativeLuminance = (color) => {
  const hex = String(color || "").trim().replace("#", "");
  const full = hex.length === 3 ? hex.split("").map((c) => c + c).join("") : hex;
  if (full.length !== 6) return 0;
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(full.slice(i, i + 2), 16) / 255);
  const lin = (c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
  return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
};

const readableOn = (background) => (relativeLuminance(background) > 0.45 ? "#111111" : "#ffffff");

const mixWithBlack = (color, ratio = 0.35) => {
  const hex = String(color || "").trim().replace("#", "");
  const full = hex.length === 3 ? hex.split("").map((c) => c + c).join("") : hex;
  if (full.length !== 6) return "#000000";
  const parts = [0, 2, 4].map((i) => Math.round(parseInt(full.slice(i, i + 2), 16) * (1 - ratio)));
  return `#${parts.map((v) => v.toString(16).padStart(2, "0")).join("")}`;
};

const buildAutoTheme = (isKo) => {
  const dark = typeof document !== "undefined" && document.documentElement.classList.contains("dark");
  const pageBg = dark ? readVar("--theme-dark-bg", "#0d0d0d") : readVar("--theme-light-bg", "#ffffff");
  const pageText = dark ? readVar("--theme-dark-text", "#f2f2f2") : readVar("--theme-light-text", "#111111");
  const surface = readVar("--theme-semi-bg", dark ? "#141414" : "#f7f6f4");
  const keyBg = readVar("--theme-medium-bg", dark ? "#2a2a2a" : "#e5e5e5");
  const muted = readVar("--theme-medium-text", dark ? "#9a9a9a" : "#8a8a8a");
  const border = readVar("--theme-border", dark ? "#2a2a2a" : "#e0ddd8");
  const accent = readVar("--brand-blue", dark ? "#4f8cff" : "#2563eb");
  const positive = readVar("--brand-emerald", dark ? "#34d399" : "#059669");
  const danger = dark ? "#b3352f" : "#cc3333";

  return {
    id: AUTO_THEME_ID,
    nameKo: "설정 테마 따름", nameEn: "Match app theme",
    sound: "topre", soundKo: "토프레", soundEn: "Topre",
    wrapBg: surface, displayBg: pageBg, displayText: pageText, displayMuted: muted,
    numBg: keyBg, numText: readableOn(keyBg), numDepth: border,
    opBg: accent, opText: readableOn(accent), opDepth: mixWithBlack(accent),
    clrBg: danger, clrText: readableOn(danger), clrDepth: mixWithBlack(danger),
    bksBg: positive, bksText: readableOn(positive), bksDepth: mixWithBlack(positive),
    eqBg: accent, eqText: readableOn(accent), eqDepth: mixWithBlack(accent),
    sciBg: surface, sciText: muted, sciDepth: border,
  };
};

const THEMES = [
  {
    id: "carbon", nameKo: "카본", nameEn: "Carbon",
    sound: "buckling_spring", soundKo: "버클링 스프링", soundEn: "Buckling Spring",
    wrapBg: "#0d0d0d", displayBg: "#111", displayText: "#e8e8e8", displayMuted: "#666",
    numBg: "#2a2a2a", numText: "#f0f0f0", numDepth: "#000",
    opBg: "#e07020", opText: "#fff", opDepth: "#803010",
    clrBg: "#cc2222", clrText: "#fff", clrDepth: "#881111",
    bksBg: "#22aa44", bksText: "#fff", bksDepth: "#117722",
    eqBg: "#00aabb", eqText: "#fff", eqDepth: "#007a88",
    sciBg: "#333", sciText: "#aaa", sciDepth: "#111",
  },
  {
    id: "retro_terminal", nameKo: "레트로 터미널", nameEn: "Retro Terminal",
    sound: "alps", soundKo: "빈티지 알프스", soundEn: "Vintage Alps",
    wrapBg: "#030f03", displayBg: "#000d00", displayText: "#00ff41", displayMuted: "#007a20",
    numBg: "#052e05", numText: "#00ff41", numDepth: "#000",
    opBg: "#0a5a0a", opText: "#88ff88", opDepth: "#021a02",
    clrBg: "#2a0000", clrText: "#ff4444", clrDepth: "#0a0000",
    bksBg: "#003a14", bksText: "#00ff88", bksDepth: "#001008",
    eqBg: "#004d1a", eqText: "#00ff44", eqDepth: "#001808",
    sciBg: "#031503", sciText: "#009a28", sciDepth: "#000",
  },
  {
    id: "amber", nameKo: "앰버", nameEn: "Amber",
    sound: "dome", soundKo: "돔 스위치", soundEn: "Dome Switch",
    wrapBg: "#1a1000", displayBg: "#0e0900", displayText: "#ffb347", displayMuted: "#aa7020",
    numBg: "#2a1a00", numText: "#ffb347", numDepth: "#0a0600",
    opBg: "#b36000", opText: "#fff8e8", opDepth: "#5a2c00",
    clrBg: "#8b0000", clrText: "#ffd0a0", clrDepth: "#3a0000",
    bksBg: "#2e4400", bksText: "#c8ff80", bksDepth: "#0e1800",
    eqBg: "#7a4800", eqText: "#ffe0a0", eqDepth: "#3c2200",
    sciBg: "#1e1200", sciText: "#cc8830", sciDepth: "#080400",
  },
  {
    id: "midnight", nameKo: "미드나이트", nameEn: "Midnight Blue",
    sound: "cherry_blue", soundKo: "체리 MX 블루", soundEn: "Cherry MX Blue",
    wrapBg: "#050a18", displayBg: "#080f22", displayText: "#a0c4ff", displayMuted: "#5a7faa",
    numBg: "#111e3e", numText: "#c0d8ff", numDepth: "#020814",
    opBg: "#1a4aaa", opText: "#fff", opDepth: "#0a2260",
    clrBg: "#880030", clrText: "#ffc0cc", clrDepth: "#400010",
    bksBg: "#0a5a2a", bksText: "#a0ffcc", bksDepth: "#022a12",
    eqBg: "#2244cc", eqText: "#e0eeff", eqDepth: "#0a2066",
    sciBg: "#0d1830", sciText: "#6688cc", sciDepth: "#020810",
  },
  {
    id: "sakura", nameKo: "벚꽃", nameEn: "Cherry Blossom",
    sound: "romer_g", soundKo: "로머-G", soundEn: "Romer-G",
    wrapBg: "#fff0f5", displayBg: "#ffe4ef", displayText: "#7a1a38", displayMuted: "#c088a8",
    numBg: "#ffd0e0", numText: "#7a1a38", numDepth: "#cc9ab0",
    opBg: "#e05080", opText: "#fff", opDepth: "#902040",
    clrBg: "#cc2244", clrText: "#fff", clrDepth: "#881122",
    bksBg: "#60aa70", bksText: "#fff", bksDepth: "#2a6840",
    eqBg: "#dd3366", eqText: "#fff", eqDepth: "#aa1144",
    sciBg: "#f0d0dc", sciText: "#aa6080", sciDepth: "#d0b0bc",
  },
  {
    id: "walnut", nameKo: "월넛", nameEn: "Walnut",
    sound: "topre", soundKo: "토프레", soundEn: "Topre",
    wrapBg: "#3a2210", displayBg: "#2a180a", displayText: "#f0ddb0", displayMuted: "#a08050",
    numBg: "#5a3820", numText: "#f5e8c8", numDepth: "#2a1808",
    opBg: "#c87830", opText: "#fff5e0", opDepth: "#703800",
    clrBg: "#882200", clrText: "#ffe8d0", clrDepth: "#440e00",
    bksBg: "#386030", bksText: "#d0ffcc", bksDepth: "#1a3018",
    eqBg: "#9a5518", eqText: "#fff8e8", eqDepth: "#4a2808",
    sciBg: "#4a2e18", sciText: "#c0a070", sciDepth: "#280e04",
  },
  {
    id: "neon_cyber", nameKo: "네온 사이버", nameEn: "Neon Cyber",
    sound: "optical", soundKo: "광축 스위치", soundEn: "Optical Switch",
    wrapBg: "#080010", displayBg: "#050008", displayText: "#ff44ff", displayMuted: "#aa00aa",
    numBg: "#150020", numText: "#ee88ff", numDepth: "#050008",
    opBg: "#aa00cc", opText: "#ffccff", opDepth: "#440055",
    clrBg: "#cc0055", clrText: "#ffaadd", clrDepth: "#550022",
    bksBg: "#005544", bksText: "#00ffcc", bksDepth: "#002a20",
    eqBg: "#8800cc", eqText: "#ffccff", eqDepth: "#380055",
    sciBg: "#100018", sciText: "#aa44cc", sciDepth: "#030008",
  },
  {
    id: "chalk", nameKo: "초크", nameEn: "Chalk",
    sound: "silent_red", soundKo: "사일런트 레드", soundEn: "Silent Red",
    wrapBg: "#f4f4f0", displayBg: "#eaeae4", displayText: "#2a2a2a", displayMuted: "#888880",
    numBg: "#e0e0d8", numText: "#222220", numDepth: "#b8b8b0",
    opBg: "#5a5a8a", opText: "#fff", opDepth: "#2a2a5a",
    clrBg: "#cc3333", clrText: "#fff", clrDepth: "#881111",
    bksBg: "#339944", bksText: "#fff", bksDepth: "#1a5522",
    eqBg: "#4466aa", eqText: "#fff", eqDepth: "#1a3366",
    sciBg: "#d8d8d0", sciText: "#666660", sciDepth: "#b0b0a8",
  },
  {
    id: "honey", nameKo: "허니", nameEn: "Honey",
    sound: "box_white", soundKo: "박스 화이트", soundEn: "Box White",
    wrapBg: "#1a1000", displayBg: "#100a00", displayText: "#ffd040", displayMuted: "#cc9020",
    numBg: "#2e1e00", numText: "#ffe090", numDepth: "#0e0a00",
    opBg: "#cc7700", opText: "#fff8e0", opDepth: "#663a00",
    clrBg: "#990000", clrText: "#ffe0a0", clrDepth: "#440000",
    bksBg: "#2a6600", bksText: "#ccff88", bksDepth: "#0e2a00",
    eqBg: "#dd9900", eqText: "#fff", eqDepth: "#885500",
    sciBg: "#221600", sciText: "#bb8822", sciDepth: "#080400",
  },
  {
    id: "ocean", nameKo: "오션", nameEn: "Ocean",
    sound: "creamy", soundKo: "크리미 리니어", soundEn: "Creamy Linear",
    wrapBg: "#030d1a", displayBg: "#020810", displayText: "#70d8f0", displayMuted: "#3888aa",
    numBg: "#0a1e30", numText: "#a0e8ff", numDepth: "#010810",
    opBg: "#0077aa", opText: "#e0f8ff", opDepth: "#003355",
    clrBg: "#883300", clrText: "#ffcc88", clrDepth: "#441500",
    bksBg: "#004433", bksText: "#88ffdd", bksDepth: "#001a14",
    eqBg: "#0055cc", eqText: "#d0eeff", eqDepth: "#002266",
    sciBg: "#061828", sciText: "#3a88aa", sciDepth: "#010608",
  },
];

function playSwitchSound(type, audioCtxRef) {
  try {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || window.webkitAudioContext)();
    }
    const ctx = audioCtxRef.current;
    if (ctx.state === "suspended") ctx.resume();
    const t = ctx.currentTime;

    const osc = (freq, oscType, vol, dur, delay = 0) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = oscType;
      o.frequency.setValueAtTime(freq, t + delay);
      g.gain.setValueAtTime(vol, t + delay);
      g.gain.exponentialRampToValueAtTime(0.001, t + delay + dur);
      o.connect(g); g.connect();
      o.start(t + delay); o.stop(t + delay + dur + 0.01);
    };

    const noise = (vol, dur, cutoff, delay = 0) => {
      const sz = Math.ceil(ctx.sampleRate * dur);
      const buf = ctx.createBuffer(1, sz, ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < sz; i++) data[i] = Math.random() * 2 - 1;
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const filt = ctx.createBiquadFilter();
      filt.type = "lowpass";
      filt.frequency.setValueAtTime(cutoff, t + delay);
      const g = ctx.createGain();
      g.gain.setValueAtTime(vol, t + delay);
      g.gain.exponentialRampToValueAtTime(0.001, t + delay + dur);
      src.connect(filt); filt.connect(g); g.connect();
      src.start(t + delay);
    };

    switch (type) {
      case "buckling_spring":
        osc(900, "square", 0.3, 0.04);
        osc(1400, "sine", 0.15, 0.02, 0.012);
        noise(0.22, 0.05, 3000);
        break;
      case "alps":
        osc(1200, "square", 0.35, 0.03);
        noise(0.3, 0.03, 5000);
        break;
      case "dome":
        osc(180, "sine", 0.4, 0.08);
        noise(0.15, 0.06, 800);
        break;
      case "cherry_blue":
        osc(700, "square", 0.25, 0.04);
        osc(1100, "sine", 0.1, 0.02, 0.01);
        noise(0.18, 0.04, 2500);
        break;
      case "romer_g":
        osc(500, "triangle", 0.2, 0.05);
        noise(0.12, 0.04, 2000);
        break;
      case "topre":
        osc(120, "sine", 0.5, 0.12);
        osc(240, "sine", 0.2, 0.08, 0.01);
        noise(0.1, 0.08, 600);
        break;
      case "optical": {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = "sine";
        o.frequency.setValueAtTime(2000, t);
        o.frequency.exponentialRampToValueAtTime(200, t + 0.06);
        g.gain.setValueAtTime(0.2, t);
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
        o.connect(g); g.connect();
        o.start(t); o.stop(t + 0.08);
        break;
      }
      case "silent_red":
        osc(150, "sine", 0.1, 0.06);
        noise(0.05, 0.04, 400);
        break;
      case "box_white":
        osc(650, "square", 0.28, 0.035);
        noise(0.2, 0.035, 3500);
        break;
      case "creamy":
        osc(260, "sine", 0.35, 0.09);
        osc(520, "sine", 0.1, 0.05, 0.01);
        noise(0.08, 0.07, 1000);
        break;
      default:
        break;
    }
  } catch (_) { /* AudioContext unavailable */ }
}

function CalcButton({ bg, depth, textColor, onPress, className = "", children }) {
  const [pressed, setPressed] = useState(false);
  const activeRef = useRef(false);

  const down = () => { activeRef.current = true; setPressed(true); };
  const up = () => {
    if (!activeRef.current) return;
    activeRef.current = false;
    setPressed(false);
    onPress?.();
  };
  const cancel = () => { activeRef.current = false; setPressed(false); };

  return (
    <button
      style={{
        backgroundColor: bg,
        color: textColor,
        boxShadow: pressed
          ? `0 1px 0 ${depth}, 0 1px 3px rgba(0,0,0,0.25)`
          : `0 5px 0 ${depth}, 0 6px 12px rgba(0,0,0,0.3)`,
        transform: pressed ? "translateY(4px)" : "translateY(0)",
        transition: "box-shadow 0.07s ease, transform 0.07s ease",
        WebkitTapHighlightColor: "transparent",
        touchAction: "manipulation",
      }}
      className={`select-none rounded-xl outline-none ${className}`}
      onMouseDown={down}
      onMouseUp={up}
      onMouseLeave={cancel}
      onTouchStart={(e) => { e.preventDefault(); down(); }}
      onTouchEnd={(e) => { e.preventDefault(); up(); }}
      onTouchCancel={cancel}
    >
      {children}
    </button>
  );
}

export default function CalculatorContent() {
  const mounted = useMounted();
  const [langCode, setLangCode] = useState("ko-KR");
  const [input, setInput] = useState("");
  const [result, setResult] = useState(null);
  const [justCalculated, setJustCalculated] = useState(false);
  const [theme, setTheme] = useState(THEMES[0]);
  const [autoTheme, setAutoTheme] = useState(null);
  const usingAutoRef = useRef(true);
  const audioCtxRef = useRef(null);

  const isKo = langCode.startsWith("ko");

  // 스킨을 직접 고르지 않은 사용자는 앱의 라이트/다크 설정을 따라야 한다.
  // 기본값이 어두운 스킨으로 고정돼 있어 라이트 모드에서도 계산기만 검게 보였다.
  useEffect(() => {
    if (!mounted) return;
    setLangCode(userInfo.getCurrentLanguageCode?.() || "ko-KR");
    let savedId = null;
    try {
      savedId = localStorage.getItem("calc_theme");
    } catch (_) {}
    const fixed = savedId && savedId !== AUTO_THEME_ID ? THEMES.find((t) => t.id === savedId) : null;
    usingAutoRef.current = !fixed;
    if (fixed) setTheme(fixed);

    // 라이트/다크 전환과 컬러 테마 변경 둘 다 따라가야 한다. 전자는 class,
    // 후자는 documentElement 의 인라인 CSS 변수로 들어온다. 고정 스킨을 쓰는
    // 중에도 목록의 "설정 테마 따름" 미리보기는 갱신해야 하므로 항상 계산한다.
    const follow = () => {
      const built = buildAutoTheme();
      setAutoTheme(built);
      if (usingAutoRef.current) setTheme(built);
    };
    follow();
    const observer = new MutationObserver(follow);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class", "style"] });
    return () => observer.disconnect();
  }, [mounted]);

  const selectTheme = (t) => {
    usingAutoRef.current = t.id === AUTO_THEME_ID;
    setTheme(t.id === AUTO_THEME_ID ? buildAutoTheme() : t);
    try { localStorage.setItem("calc_theme", t.id); } catch (_) {}
  };

  const sound = () => playSwitchSound(theme.sound, audioCtxRef);

  const handleClick = (value) => {
    sound();
    if (justCalculated) {
      setInput((result?.toString() ?? "") + value);
      setResult(null);
      setJustCalculated(false);
    } else {
      setInput((prev) => prev + value);
    }
  };

  const handleClear = () => { sound(); setInput(""); setResult(null); setJustCalculated(false); };
  const handleBackspace = () => { sound(); setInput((prev) => prev.slice(0, -1)); };

  const handleCalculate = () => {
    sound();
    try {
      // eslint-disable-next-line no-eval
      const r = eval(input);
      setResult(r); setInput(r.toString()); setJustCalculated(true);
    } catch {
      setResult("Error"); setJustCalculated(false);
    }
  };

  const factorial = (n) => {
    if (n < 0) return NaN;
    if (n === 0) return 1;
    return n * factorial(n - 1);
  };

  const handleAdvanced = (fn) => {
    sound();
    try {
      // eslint-disable-next-line no-eval
      const val = eval(input || "0");
      const ops = {
        sqrt: () => Math.sqrt(val),
        pow2: () => Math.pow(val, 2),
        log: () => Math.log10(val),
        ln: () => Math.log(val),
        sin: () => Math.sin(val),
        cos: () => Math.cos(val),
        tan: () => Math.tan(val),
        percent: () => val / 100,
        fact: () => factorial(Math.floor(val)),
      };
      const r = ops[fn]?.() ?? val;
      setResult(r); setInput(r.toString()); setJustCalculated(true);
    } catch {
      setResult("Error"); setJustCalculated(false);
    }
  };

  const formatNumber = (s) => {
    if (!s) return "0";
    const n = Number(s);
    return isNaN(n) ? s : n.toLocaleString();
  };

  if (!mounted) return null;

  const T = theme;

  return (
    <div
      className="mx-auto flex min-h-[calc(100dvh-5rem)] w-full max-w-md flex-col justify-center px-4 pb-16"
      style={{ backgroundColor: T.wrapBg }}
    >
      <h2 className="page-title" style={{ color: T.displayText }}>
        {commonFunctions.getResourceByLanguage("calculator", constants.resourceType.label, langCode)}
      </h2>

      {/* Theme selector */}
      <div className="mb-3 flex gap-2 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
        {(autoTheme ? [autoTheme, ...THEMES] : THEMES).map((t) => (
          <button
            key={t.id}
            onClick={() => selectTheme(t)}
            className="flex shrink-0 flex-col items-center rounded-xl px-3 py-2 transition-all"
            style={{
              backgroundColor: t.numBg,
              color: t.numText,
              opacity: theme.id === t.id ? 1 : 0.45,
              outline: theme.id === t.id ? `2px solid ${t.opBg}` : "none",
              outlineOffset: "2px",
              transform: theme.id === t.id ? "scale(1.05)" : "scale(1)",
              transition: "opacity 0.2s, transform 0.2s",
            }}
          >
            <span className="whitespace-nowrap text-[11px] font-bold leading-tight">
              {isKo ? t.nameKo : t.nameEn}
            </span>
            <span className="mt-0.5 whitespace-nowrap text-[9px] leading-tight" style={{ opacity: 0.7 }}>
              {isKo ? t.soundKo : t.soundEn}
            </span>
          </button>
        ))}
      </div>

      {/* Calculator body */}
      <div
        className="rounded-2xl p-4"
        style={{
          backgroundColor: T.displayBg,
          boxShadow: "0 10px 40px rgba(0,0,0,0.5)",
          border: "1px solid rgba(128,128,128,0.12)",
        }}
      >
        {/* Display */}
        <div
          className="mb-4 rounded-xl p-4 text-right"
          style={{
            backgroundColor: T.wrapBg,
            border: "1px solid rgba(128,128,128,0.15)",
            minHeight: "5rem",
          }}
        >
          <div className="min-h-5 break-all font-mono text-sm" style={{ color: T.displayMuted }}>
            {input || "0"}
          </div>
          <div className="mt-2 min-h-9 break-all font-mono text-3xl font-extrabold" style={{ color: T.displayText }}>
            {result !== null ? formatNumber(result.toString()) : "0"}
          </div>
        </div>

        {/* Main button grid */}
        <div className="grid grid-cols-4 gap-2">
          <CalcButton bg={T.clrBg} depth={T.clrDepth} textColor={T.clrText} onPress={handleClear} className="min-h-14 text-xl font-bold">C</CalcButton>
          <CalcButton bg={T.numBg} depth={T.numDepth} textColor={T.numText} onPress={() => handleClick("(")} className="min-h-14 text-xl font-bold">()</CalcButton>
          <CalcButton bg={T.numBg} depth={T.numDepth} textColor={T.numText} onPress={() => handleAdvanced("percent")} className="min-h-14 text-xl font-bold">%</CalcButton>
          <CalcButton bg={T.opBg} depth={T.opDepth} textColor={T.opText} onPress={() => handleClick("/")} className="min-h-14 text-xl font-bold">÷</CalcButton>

          {[["7","8","9","*"],["4","5","6","-"],["1","2","3","+"]].map((row) =>
            row.map((v, i) =>
              i === 3 ? (
                <CalcButton key={v} bg={T.opBg} depth={T.opDepth} textColor={T.opText} onPress={() => handleClick(v)} className="min-h-14 text-xl font-bold">
                  {v === "*" ? "×" : v}
                </CalcButton>
              ) : (
                <CalcButton key={v} bg={T.numBg} depth={T.numDepth} textColor={T.numText} onPress={() => handleClick(v)} className="min-h-14 text-xl font-bold">
                  {v}
                </CalcButton>
              )
            )
          )}

          <CalcButton bg={T.numBg} depth={T.numDepth} textColor={T.numText} onPress={() => handleClick("0")} className="min-h-14 text-xl font-bold">0</CalcButton>
          <CalcButton bg={T.numBg} depth={T.numDepth} textColor={T.numText} onPress={() => handleClick("00")} className="min-h-14 text-xl font-bold">00</CalcButton>
          <CalcButton bg={T.numBg} depth={T.numDepth} textColor={T.numText} onPress={() => handleClick(".")} className="min-h-14 text-xl font-bold">.</CalcButton>
          <CalcButton bg={T.bksBg} depth={T.bksDepth} textColor={T.bksText} onPress={handleBackspace} className="min-h-14 text-xl font-bold">⌫</CalcButton>

          <CalcButton bg={T.eqBg} depth={T.eqDepth} textColor={T.eqText} onPress={handleCalculate} className="col-span-4 min-h-14 text-2xl font-extrabold">=</CalcButton>
        </div>

        {/* Scientific row */}
        <div className="mt-3 grid grid-cols-4 gap-2">
          {[["√","sqrt"],["x²","pow2"],["log","log"],["ln","ln"],["sin","sin"],["cos","cos"],["tan","tan"],["n!","fact"]].map(([label, fn]) => (
            <CalcButton key={fn} bg={T.sciBg} depth={T.sciDepth} textColor={T.sciText} onPress={() => handleAdvanced(fn)} className="min-h-10 text-sm font-semibold">
              {label}
            </CalcButton>
          ))}
        </div>
      </div>
    </div>
  );
}
