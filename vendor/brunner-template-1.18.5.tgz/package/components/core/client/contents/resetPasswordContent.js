"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/router";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

import { RequestServer } from "@/components/core/client/requestServer";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import Loading from "@/components/core/client/loading";
import Button from "@/components/core/client/ui/Button";
import Input from "@/components/core/client/ui/Input";
import Card from "@/components/core/client/ui/Card";

export default function ResetPasswordContent() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const { BrunnerMessageBox, openOkCancelModal, openOkModal, openInputModal } =
    useModal();
  const [userId, setUserId] = useState(constants.emptyString);
  const [phoneNumber, setPhoneNumber] = useState(constants.emptyString);
  const [email, setEmail] = useState(constants.emptyString);
  const [authCode, setAuthCode] = useState(constants.emptyString);
  const [newPassword, setNewPassword] = useState(constants.emptyString);
  const [confirmPassword, setConfirmPassword] = useState(constants.emptyString);
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);
  const [step, setStep] = useState(0);
  const [cooldown, setCooldown] = useState(0);
  const otpRefs = useRef([]);

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  const tl = (k) => commonFunctions.getResourceByLanguage(k, constants.resourceType.label, currentLanguageCode);
  const tm = (k) => commonFunctions.getResourceByLanguage(k, constants.resourceType.message, currentLanguageCode);
  const changeUserIdValue = (e) => setUserId(e.target.value);
  const changePhoneNumberValue = (e) => setPhoneNumber(e.target.value);
  const changeEMailValue = (e) => setEmail(e.target.value);
  const changeAuthCode = (e) => setAuthCode(e.target.value);
  const changePasswordValue = (e) => setNewPassword(e.target.value);
  const changeConfirmPasswordValue = (e) => setConfirmPassword(e.target.value);

  const sendEMailAuthCode = async () => {
    const jRequest = {
      commandName: constants.commands.SECURITY_SEND_EMAIL_AUTHCODE,
            languageCode: userInfo.getCurrentLanguageCode(),
      userId,
      phoneNumber,
      email,
    };

    try {
      setLoading(true);
      const jResponse = await RequestServer(jRequest);
      setLoading(false);
      await openOkModal(
        jResponse.error_message,
        jResponse.error_code === constants.errorCode.Success
          ? constants.messageCategory.Info
          : constants.messageCategory.Error,
      );
      if (jResponse.error_code === constants.errorCode.Success) {
        setStep(1);
        setCooldown(300);
      }
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  useEffect(() => {
    if (cooldown <= 0) return undefined;
    const timer = setInterval(() => setCooldown((prev) => Math.max(0, prev - 1)), 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const handleOtpChange = (index, value) => {
    const digit = value.replace(/\D/g, "").slice(-1);
    const next = authCode.padEnd(6, " ").split("");
    next[index] = digit || " ";
    const merged = next.join("").replace(/\s/g, "");
    setAuthCode(merged);
    if (digit && index < 5) otpRefs.current[index + 1]?.focus();
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !authCode[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const formatCountdown = (seconds) => {
    const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
    const ss = String(seconds % 60).padStart(2, "0");
    return `${mm}:${ss}`;
  };

  const requestResetPassword = async () => {
    const jRequest = {
      commandName: constants.commands.SECURITY_RESET_PASSWORD,
            languageCode: userInfo.getCurrentLanguageCode(),
      userId,
      phoneNumber,
      email,
      authCode,
      newPassword,
      confirmPassword,
    };

    try {
      setLoading(true);
      const jResponse = await RequestServer(jRequest);
      setLoading(false);

      if (jResponse.error_code === constants.errorCode.Success) {
        const result = await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Info,
        );
        if (result) router.push("/mainPages/signin");
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  const requestDeleteAccount = async () => {
    const jRequest = {
      commandName: constants.commands.SECURITY_DELETE_ACCOUNT,
            languageCode: userInfo.getCurrentLanguageCode(),
      userId,
      phoneNumber,
      email,
      authCode,
      newPassword,
      confirmPassword,
    };

    try {
      setLoading(true);
      const jResponse = await RequestServer(jRequest);
      setLoading(false);
      const result = await openOkModal(
        jResponse.error_message,
        constants.messageCategory.Info,
      );
      if (jResponse.error_code === constants.errorCode.Success && result) {
        router.push("/mainPages/signin");
      }
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  return (
    <>
      {loading && <Loading />}
      <BrunnerMessageBox />

      <div className="min-h-[calc(100dvh-5rem)] bg-[var(--bg)] px-5 py-8 text-[var(--text)]">
        <Card className="mx-auto max-w-xl p-5 md:p-7">
          <h1 className="text-2xl font-extrabold">{tl("pageTitle_resetPasswordContent")}</h1>
          <p className="mt-2 text-sm leading-6 text-[var(--text-muted)]">{tm("GOVERNING_MESSAGE_RESET_PASSWORD_CONTENT")}</p>

          <div className="my-7 flex items-center gap-2">
            {[tl("resetStepEmail"), tl("resetStepOtp"), tl("resetStepPassword")].map((label, index) => (
              <div key={label} className="flex flex-1 items-center gap-2">
                <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${index <= step ? "bg-[image:var(--brand-gradient)] text-white" : "bg-[var(--surface-alt)] text-[var(--text-muted)]"}`}>{index + 1}</span>
                <span className={`hidden text-xs font-semibold sm:inline ${index === step ? "text-[var(--text)]" : "text-[var(--text-muted)]"}`}>{label}</span>
                {index < 2 && <span className="h-px flex-1 bg-[var(--border)]" />}
              </div>
            ))}
          </div>

          {step === 0 && (
            <div className="space-y-4">
<div>
                <label htmlFor="id" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("loginId")}</label>
                <Input id="id" name="Id" value={userId} onChange={changeUserIdValue} />
              </div>
              <div>
                <label htmlFor="phone-number" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("phoneNumber")}</label>
                <Input id="phone-number" value={phoneNumber} onChange={changePhoneNumberValue} />
              </div>
              <div>
                <label htmlFor="email" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("email")}</label>
                <Input id="email" type="email" value={email} onChange={changeEMailValue} />
              </div>
              <Button className="w-full" onClick={sendEMailAuthCode}>{tl("resetSendCode")}</Button>
            </div>
          )}

          {step === 1 && (
            <div>
              <div className="mb-4 flex justify-center gap-2">
                {Array.from({ length: 6 }).map((_, index) => (
                  <input
                    key={index}
                    ref={(el) => { otpRefs.current[index] = el; }}
                    value={authCode[index] || ""}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(index, e)}
                    aria-label={`${tl("resetStepOtp")} ${index + 1}`}
                    inputMode="numeric"
                    maxLength={1}
                    className="h-12 w-10 rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] text-center font-mono-data text-lg font-bold text-[var(--text)] outline-none focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-[var(--brand-blue)]"
                  />
                ))}
              </div>
              <div className="mb-5 flex items-center justify-center gap-3 text-sm">
                <span className="font-mono-data font-bold text-[var(--brand-blue)]">{formatCountdown(cooldown)}</span>
                <button type="button" className="font-semibold text-[var(--brand-blue)] disabled:text-[var(--text-subtle)]" disabled={cooldown > 240} onClick={sendEMailAuthCode}>
                  {tl("resetResend")}
                </button>
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                <Button variant="danger" onClick={requestDeleteAccount}>{tl("resetAccountDelete")}</Button>
                <Button onClick={() => setStep(2)} disabled={authCode.length !== 6}>{tl("signupNext")}</Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label htmlFor="new-password" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("resetStepPassword")}</label>
                <Input id="new-password" type="password" value={newPassword} onChange={changePasswordValue} />
              </div>
              <div>
                <label htmlFor="confirm-password" className="mb-1.5 block text-xs font-semibold text-[var(--text-muted)]">{tl("password")}</label>
                <Input id="confirm-password" type="password" value={confirmPassword} onChange={changeConfirmPasswordValue} />
              </div>
              <Button className="w-full" onClick={requestResetPassword}>{tl("resetPassword")}</Button>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
