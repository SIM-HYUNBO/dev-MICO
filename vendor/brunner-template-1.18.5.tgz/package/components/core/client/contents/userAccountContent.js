import { useEffect, useMemo, useState } from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import Loading from "@/components/core/client/loading";
import Card from "@/components/core/client/ui/Card";
import Chip from "@/components/core/client/ui/Chip";
import Avatar from "@/components/core/client/ui/Avatar";
import Button from "@/components/core/client/ui/Button";
import Input from "@/components/core/client/ui/Input";
import MTabBar from "@/components/core/client/frames/mTabBar";
import PageContainer from "@/components/core/client/ui/PageContainer";
import { UserParamEditor } from "@/components/core/client/frames/userParamEditor";


export default function UserAccountContent() {
  const { BrunnerMessageBox, openOkModal, openInputModal } = useModal();
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);
  const [userData, setUserData] = useState(null);
  const [profilePreview, setProfilePreview] = useState(null);
  const [profileFile, setProfileFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const isAdmin = userInfo.isAdminUser();

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  const tl = (key) => commonFunctions.getResourceByLanguage(key, constants.resourceType.label, currentLanguageCode);

  const displayName = userData?.user_name || userInfo.getLoginUserName?.() || userInfo.getLoginUserRegisterName?.() || userInfo.getLoginUserId?.() || "BRUNNER";
  const loginId = userData?.user_id || userInfo.getLoginUserId?.() || "";
  const profileImage = profilePreview || userData?.profile_image_src || userInfo.getLoginProfileImage?.();

  const fields = useMemo(() => [
    { key: "user_name", label: tl("name"), value: userData?.user_name || "", type: "text" },
    { key: "email_id", label: tl("email"), value: userData?.email_id || "", type: "email" },
    { key: "phone_number", label: tl("phoneNumber"), value: userData?.phone_number || "", type: "tel" },
    { key: "address", label: tl("address"), value: userData?.address || "", type: "text" },
    { key: "register_no", label: tl("registerNo"), value: userData?.register_no || "", type: "text" },
    { key: "expire_time", label: tl("expireTime"), value: userData?.expire_time ? String(userData.expire_time).substring(0, 10) : "", type: "date", readOnly: !isAdmin },
    { key: "register_name", label: tl("registerName"), value: userData?.register_name || userInfo.getLoginUserRegisterName?.() || "", type: "text", readOnly: true },
  ], [currentLanguageCode, userData, isAdmin]);

  const loadUserAccount = async () => {
    const systemCode = userInfo.getCurrentSystemCode();
    const userId = userInfo.getLoginUserId();
    if (!systemCode || !userId) return;

    setLoading(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.SECURITY_USER_INFO_SELECT_ONE,
                userId,
        languageCode: userInfo.getCurrentLanguageCode(),
      });

      if (res.error_code === constants.errorCode.Success) {
        const data = res.data?.[0] || null;
        setUserData(data);
        setProfilePreview(data?.profile_image_src || null);
      } else {
        await openOkModal(res.error_message, constants.messageCategory.Error);
      }
    } catch (e) {
      await openOkModal(e.message || String(e), constants.messageCategory.Exception);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUserAccount();
  }, []);

  const updateField = (key, value) => {
    setUserData((prev) => ({ ...(prev || {}), [key]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setProfileFile(file);

    const reader = new FileReader();
    reader.onload = () => setProfilePreview(reader.result);
    reader.readAsDataURL(file);
  };

  const saveAccount = async () => {
    if (!userData) return;

    setSaving(true);
    try {
      let base64Image = profilePreview || userData.profile_image_src || null;
      if (profileFile) {
        base64Image = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.readAsDataURL(profileFile);
        });
      }

      const res = await RequestServer({
        commandName: constants.commands.SECURITY_USER_INFO_UPDATE_ONE,
                loginUserId: userInfo.getLoginUserId(),
        languageCode: userInfo.getCurrentLanguageCode(),
        userId: userData.user_id,
        userName: userData.user_name,
        address: userData.address,
        phoneNumber: userData.phone_number,
        emailId: userData.email_id,
        expireTime: userData.expire_time,
        registerNo: userData.register_no || null,
        profileImageBase64: base64Image,
      });

      await openOkModal(res.error_message, constants.messageCategory.Info);

      if (res.error_code === constants.errorCode.Success) {
        const stored = localStorage.getItem("userInfo");
        if (stored) {
          const parsed = JSON.parse(stored);
          parsed.userName = userData.user_name;
          parsed.registerNo = userData.register_no;
          parsed.profileImageBase64 = base64Image;
          localStorage.setItem("userInfo", JSON.stringify(parsed));
          window.dispatchEvent(new CustomEvent("userChanged", { detail: { userId: parsed.userId } }));
        }
        setProfileFile(null);
        await loadUserAccount();
      }
    } catch (e) {
      await openOkModal(e.message || String(e), constants.messageCategory.Exception);
    } finally {
      setSaving(false);
    }
  };

  const linkKakaoAccount = () => {
    const userId = userInfo.getLoginUserId();
    if (!userId) return;
    const state = `linkKakao:${userId}`;
    window.location.href = `/api/auth/kakao-start?state=${encodeURIComponent(state)}`;
  };

  return (
    <>
      {loading && <Loading />}
      <BrunnerMessageBox />
      <PageContainer variant="reading" className="tab-bar-pb bg-[var(--bg)] text-[var(--text)] md:pb-16">
        <h2 className="page-title">{tl("userAccountTitle")}</h2>

        <section className="mt-4 rounded-[var(--radius-xl)] bg-[image:var(--brand-gradient-soft)] p-5 md:p-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex min-w-0 items-center gap-4">
              <Avatar src={profileImage} initial={displayName} size={72} />
              <div className="min-w-0">
                <h1 className="truncate text-2xl font-extrabold text-[var(--text)]">{displayName}</h1>
                <p className="mt-1 truncate text-sm text-[var(--text-muted)]">@{loginId}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Chip tone="brand">Brunner</Chip>
                  {userData?.user_type && <Chip tone="neutral">{userData.user_type}</Chip>}
                </div>
              </div>
            </div>
            <label className="inline-flex cursor-pointer items-center justify-center rounded-[var(--radius-md)] border border-[var(--border-strong)] px-4 py-2 text-sm font-semibold text-[var(--text)] transition hover:opacity-90">
              {tl("profileImage")}
              <input type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
            </label>
          </div>
        </section>

        <Card className="mt-4 p-5">
          <div className="grid gap-4 md:grid-cols-2">
            {fields.map((field) => (
              <label key={field.key} className="flex min-w-0 flex-col gap-2">
                <span className="text-xs font-semibold text-[var(--text-subtle)]">{field.label}</span>
                <div className="flex gap-2">
                  <Input
                    type={field.type}
                    value={field.value}
                    readOnly={field.readOnly}
                    onChange={(e) => updateField(field.key, e.target.value)}
                    aria-label={field.label}
                    className={field.readOnly ? "opacity-80" : ""}
                  />
                </div>
              </label>
            ))}
          </div>

          <div className="mt-5 flex flex-col gap-2 md:flex-row md:justify-end">
            <Button variant="ghost" onClick={linkKakaoAccount} disabled={saving || loading}>
              {tl("linkKakaoAccount")}
            </Button>
            <Button onClick={saveAccount} disabled={saving || loading || !userData}>
              {saving ? tl("saving") : tl("save")}
            </Button>
          </div>
        </Card>

        {/* 사용자 확장속성 — 내가 쓰는 설정을 키/값으로 직접 보고 고치는 자리 */}
        <UserParamEditor />
      </PageContainer>
      <MTabBar />
    </>
  );
}
