"use client";

import { useState, useEffect } from "react";
import { THEMES } from "@/lib/themes";
import { useColorTheme } from "@/lib/hooks/useColorTheme";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import * as constants from "@/lib/constants";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import DarkModeToggleButton from "@/components/core/client/frames/darkModeToggleButton";
import Card from "@/components/core/client/ui/Card";
import Chip from "@/components/core/client/ui/Chip";
import Avatar from "@/components/core/client/ui/Avatar";
import Button from "@/components/core/client/ui/Button";
import Toggle from "@/components/core/client/ui/Toggle";
import Input from "@/components/core/client/ui/Input";
import { RequestServer } from "@/components/core/client/requestServer";
import { DEFAULT_HOME_ACCENT, HOME_ACCENT_KEY, HOME_ACCENT_PRESETS, applyHomeAccent } from "@/lib/homeAccent";
import PageContainer from "@/components/core/client/ui/PageContainer";

const L = (key) =>
  commonFunctions.getResourceByLanguage(key, constants.resourceType.label, userInfo.getCurrentLanguageCode());

// VAPID 공개키(base64url 문자열) → Uint8Array. pushManager.subscribe의 applicationServerKey는 BufferSource여야 한다.
function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const output = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) output[i] = raw.charCodeAt(i);
  return output;
}

const PUSH_PREF_KEY = constants.pushPreferenceStorageKey;
const PUSH_SOUND_PREF_KEY = "pushNotificationSound";
const PUSH_SOUND_OPTIONS = [
  { id: "default", labelKey: "pushSoundDefault", descKey: "pushSoundDefaultDesc", previewSrc: "/sounds/pour.mp3" },
  { id: "brunner_chime", labelKey: "pushSoundBrunnerChime", descKey: "pushSoundBrunnerChimeDesc", previewSrc: "/sounds/push-brunner-chime.wav" },
  { id: "cafe_bell", labelKey: "pushSoundCafeBell", descKey: "pushSoundCafeBellDesc", previewSrc: "/sounds/push-cafe-bell.wav" },
  { id: "soft_pop", labelKey: "pushSoundSoftPop", descKey: "pushSoundSoftPopDesc", previewSrc: "/sounds/push-soft-pop.wav" },
  { id: "silent", labelKey: "pushSoundSilent", descKey: "pushSoundSilentDesc" },
];
const FONT_SIZE_KEY = "appFontScale";
const FONT_STEPS = [
  { key: "fontSizeSmall",   scale: 0.875 },
  { key: "fontSizeDefault", scale: 1.0   },
  { key: "fontSizeLarge",   scale: 1.125 },
  { key: "fontSizeXLarge",  scale: 1.25  },
  { key: "fontSizeXXLarge", scale: 1.5   },
];

export const applyFontScale = (scale) => {
  document.documentElement.style.setProperty("--chat-font-scale", String(scale));
};

function HomeAccentColorPicker() {
  const [current, setCurrent] = useState(DEFAULT_HOME_ACCENT);
  useEffect(() => {
    const saved = localStorage.getItem(HOME_ACCENT_KEY) || DEFAULT_HOME_ACCENT;
    setCurrent(saved);
    applyHomeAccent(saved);
  }, []);
  const select = (value) => {
    setCurrent(value);
    localStorage.setItem(HOME_ACCENT_KEY, value);
    applyHomeAccent(value);
    window.dispatchEvent(new CustomEvent("homeAccentChanged", { detail: { value } }));
  };
  return (
    <div className="flex flex-wrap gap-3">
      {HOME_ACCENT_PRESETS.map((p) => {
        const isActive = current === p.value;
        return (
          <button
            key={p.value}
            onClick={() => select(p.value)}
            className={`flex flex-col items-center gap-1.5 rounded-[var(--radius-lg)] border-2 p-2 transition ${
              isActive ? "border-[var(--brand-blue)]" : "border-[var(--border)] hover:border-[var(--border-strong)]"
            }`}
          >
            {/* 치수와 색을 전부 인라인으로 준다. 유틸리티 클래스가 한 자락이라도
                안 만들어지면 견본이 0 높이로 접혀 색 이름만 남는다. */}
            <div
              style={{
                width: 56,
                height: 40,
                borderRadius: 10,
                background: p.gradient,
                border: "1px solid rgba(127,127,127,0.35)",
              }}
            />
            <span className="text-xs font-medium text-[var(--text-muted)]">{L(p.labelKey)}</span>
            {isActive && <span className="text-[10px] text-[var(--brand-blue)] font-semibold">✓ {L("accentApplied")}</span>}
          </button>
        );
      })}
    </div>
  );
}

export default function SettingsContent() {
  const { BrunnerMessageBox, openOkModal, openOkCancelModal } = useModal();
  const { themeId, changeTheme } = useColorTheme();
  const [languageCode, setLanguageCode] = useState(null);
  const [isDark, setIsDark] = useState(false);
  const [pushSupported, setPushSupported] = useState(false);
  const [pushEnabled, setPushEnabled] = useState(true);
  const [pushSubscribed, setPushSubscribed] = useState(false);
  const [pushBusy, setPushBusy] = useState(false);
  const [pushSound, setPushSound] = useState("default");
  const [pushSoundBusy, setPushSoundBusy] = useState(false);
  const [diagPermission, setDiagPermission] = useState("default");
  const [diagSubscribed, setDiagSubscribed] = useState(false);
  const [diagLastPush, setDiagLastPush] = useState(null);
  const [diagStandalone, setDiagStandalone] = useState(true);
  const [diagIsIOS, setDiagIsIOS] = useState(false);
  const [diagLoading, setDiagLoading] = useState(false);
  const [pushTestBusy, setPushTestBusy] = useState(false);
  const [localNotificationBusy, setLocalNotificationBusy] = useState(false);
  const [pushResetBusy, setPushResetBusy] = useState(false);
  const [fontScale, setFontScale] = useState(1.0);
  const [showPwModal, setShowPwModal] = useState(false);
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [pwError, setPwError] = useState("");
  const [pwLoading, setPwLoading] = useState(false);
  const [isAdminCapable, setIsAdminCapable] = useState(false);
  const [accountUserId, setAccountUserId] = useState("");
  const [accountAdminFlag, setAccountAdminFlag] = useState(false);
  const [accountAdminMode, setAccountAdminMode] = useState(null);
  const [adminMode, setAdminModeState] = useState(true);

  useEffect(() => {
    const syncAdminModeState = () => {
      setIsAdminCapable(userInfo.isAdminCapable());
      const stored = localStorage.getItem("adminMode");
      setAdminModeState(stored === null ? true : stored === "true");
      setAccountUserId(userInfo.getLoginUserId());
      setAccountAdminFlag(userInfo.isAdminCapable());
      setAccountAdminMode(stored === null ? null : stored === "true");
    };

    syncAdminModeState();
    userInfo.refreshUserInfo?.().then(syncAdminModeState).catch(() => {});
    window.addEventListener("userChanged", syncAdminModeState);
    return () => window.removeEventListener("userChanged", syncAdminModeState);
  }, []);

  // Toggle 이 넘겨주는 값을 그대로 쓴다. 여기서 !adminMode 로 다시 계산하면
  // 클로저에 잡힌 옛 state 를 보게 되어, 한 번의 조작이 두 번 전달됐을 때
  // 값이 되돌아간다.
  const handleAdminModeToggle = (next) => {
    setAdminModeState(next);
    userInfo.setAdminMode(next);
  };

  const loadDiagnostics = async () => {
    setDiagLoading(true);
    try {
      // iOS는 홈 화면에 설치한 앱(standalone)으로 열 때만 웹푸시가 전달된다. Safari 탭이면 201을 받아도 안 온다.
      const ua = navigator.userAgent || "";
      const isIOS = /iP(hone|ad|od)/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
      const standalone = window.matchMedia?.("(display-mode: standalone)")?.matches || window.navigator.standalone === true;
      setDiagIsIOS(isIOS);
      setDiagStandalone(standalone);
      setDiagPermission("Notification" in window ? Notification.permission : "denied");
      if ("serviceWorker" in navigator && "PushManager" in window) {
        try {
          const reg = await navigator.serviceWorker.ready;
          const sub = await reg.pushManager.getSubscription();
          setDiagSubscribed(Boolean(sub));
        } catch { setDiagSubscribed(false); }
      } else {
        setDiagSubscribed(false);
      }
      const lastPush = await new Promise((resolve) => {
        try {
          const req = indexedDB.open("brunner_prefs", 1);
          req.onsuccess = (e) => {
            try {
              const tx = e.target.result.transaction("muted_rooms", "readonly");
              const get = tx.objectStore("muted_rooms").get("last_push_time");
              get.onsuccess = (ev) => resolve(ev.target.result?.value || null);
              get.onerror = () => resolve(null);
            } catch { resolve(null); }
          };
          req.onerror = () => resolve(null);
        } catch { resolve(null); }
      });
      setDiagLastPush(lastPush);
    } finally {
      setDiagLoading(false);
    }
  };

  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode());
    const savedScale = parseFloat(localStorage.getItem(FONT_SIZE_KEY) || "1.0");
    setFontScale(savedScale);
    applyFontScale(savedScale);
    const check = () => setIsDark(document.documentElement.classList.contains("dark"));
    check();
    const obs = new MutationObserver(check);
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });

    const pushPreferenceEnabled = localStorage.getItem(PUSH_PREF_KEY) !== "false";
    const savedPushSound = localStorage.getItem(PUSH_SOUND_PREF_KEY) || userInfo.getUserParams()?.pushNotificationSound || "default";
    setPushSound(savedPushSound);
    loadPushSoundPreference();

    if ("serviceWorker" in navigator && "PushManager" in window) {
      setPushSupported(true);
      navigator.serviceWorker.register("/sw.js")
        .then((reg) => reg.update?.().catch(() => {}))
        .catch(() => {});
      navigator.serviceWorker.ready
        .then((reg) => reg.pushManager.getSubscription())
        .then((sub) => {
          setPushSubscribed(Boolean(sub));
          setPushEnabled(pushPreferenceEnabled && (sub ? true : Notification.permission !== "denied"));
        })
        .catch(() => {
          setPushSubscribed(false);
          setPushEnabled(pushPreferenceEnabled && Notification.permission !== "denied");
        });
    } else {
      setPushEnabled(false);
    }

    loadDiagnostics();
    return () => obs.disconnect();
  }, []);

  const persistLocalUserParams = (nextParams) => {
    try {
      const raw = localStorage.getItem("userInfo");
      if (!raw) return;
      const parsed = JSON.parse(raw);
      localStorage.setItem("userInfo", JSON.stringify({ ...parsed, userParams: nextParams }));
    } catch {}
  };

  const loadPushSoundPreference = async () => {
    const systemCode = userInfo.getCurrentSystemCode();
    const userId = userInfo.getLoginUserId();
    if (!systemCode || !userId) return;
    try {
      const res = await RequestServer({
        commandName: constants.commands.SECURITY_USER_PARAM_SELECT_ONE,
                userId,
        languageCode: userInfo.getCurrentLanguageCode(),
      });
      if (res.error_code === constants.errorCode.Success) {
        const params = res.data?.user_params || {};
        const sound = params.pushNotificationSound || "default";
        setPushSound(sound);
        localStorage.setItem(PUSH_SOUND_PREF_KEY, sound);
        persistLocalUserParams(params);
      }
    } catch {}
  };

  const savePushSoundPreference = async (soundId) => {
    const systemCode = userInfo.getCurrentSystemCode();
    const userId = userInfo.getLoginUserId();
    const nextParams = { ...(userInfo.getUserParams?.() || {}), pushNotificationSound: soundId };
    setPushSound(soundId);
    localStorage.setItem(PUSH_SOUND_PREF_KEY, soundId);
    persistLocalUserParams(nextParams);
    if (!systemCode || !userId) return;
    setPushSoundBusy(true);
    try {
      await RequestServer({
        commandName: constants.commands.SECURITY_USER_PARAM_UPSERT_ONE,
                userId,
        languageCode: userInfo.getCurrentLanguageCode(),
        jUserParams: nextParams,
        userParams: nextParams,
      });
    } catch (e) {
      console.error("[push sound settings]", e.message);
    } finally {
      setPushSoundBusy(false);
    }
  };

  const previewPushSound = (src) => {
    if (!src) return;
    const audio = new Audio(src);
    audio.volume = 0.65;
    audio.play().catch(() => {});
  };

  const tl = (k) => commonFunctions.getResourceByLanguage(k, constants.resourceType.label, languageCode);
  const tm = (k) => commonFunctions.getResourceByLanguage(k, constants.resourceType.message, languageCode);

  const enablePushNotifications = async () => {
    const permission = await Notification.requestPermission();
    if (permission !== "granted") return;

    const vapidKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
    if (!vapidKey) {
      openOkModal(tm("PUSH_VAPID_KEY_MISSING"), constants.messageCategory.Warning);
      return;
    }

    const reg = await navigator.serviceWorker.ready;
    const existing = await reg.pushManager.getSubscription();
    // applicationServerKey는 BufferSource여야 함 — base64url 문자열을 그대로 넘기면
    // iOS Safari 등 엄격한 브라우저에서 구독 실패/키 불일치로 푸시가 안 온다.
    const sub = existing || await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(vapidKey),
    });

    const res = await fetch("/api/push", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: userInfo.getLoginUserId(),
        subscription: sub.toJSON(),
      }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || res.status);
    }

    setPushEnabled(true);
    setPushSubscribed(true);
    localStorage.setItem(PUSH_PREF_KEY, "true");
  };

  const disablePushNotifications = async () => {
    localStorage.setItem(PUSH_PREF_KEY, "false");
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.getSubscription();
    if (!sub) {
      setPushEnabled(false);
      setPushSubscribed(false);
      return;
    }

    await fetch("/api/push", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: userInfo.getLoginUserId(),
        endpoint: sub.endpoint,
      }),
    });
    await sub.unsubscribe();
    setPushSubscribed(false);
    setPushEnabled(false);
  };

  const handlePushToggle = async (checked) => {
    if (!pushSupported || pushBusy) return;
    setPushBusy(true);
    try {
      if (checked) {
        await enablePushNotifications();
      } else {
        await disablePushNotifications();
      }
    } catch (e) {
      console.error("[push settings]", e.message);
      openOkModal(tm("PUSH_SUBSCRIPTION_ERROR").replace("{0}", e.message), constants.messageCategory.Error);
    } finally {
      setPushBusy(false);
    }
  };

  const handlePushCheckboxClick = async (e) => {
    if (!pushSupported || pushBusy) return;
    if (pushEnabled && !pushSubscribed) {
      e.preventDefault();
      await handlePushToggle(true);
    }
  };

  // 푸시 실패는 상태코드·사유가 있어야 원인을 좁힐 수 있다. 사용자에게는 다국어 안내로,
  // 기술 정보(status/reason)는 괄호에 붙여 그대로 보여준다.
  const describePushTestFailure = (body, httpStatus) => {
    const status = Number(body?.statusCode);
    const detail =
      [Number.isFinite(status) && status ? `status ${status}` : null, body?.reason || body?.configError || null]
        .filter(Boolean)
        .join(" · ") || body?.error || `HTTP ${httpStatus}`;

    let key = null;
    if (body?.code === "PUSH_CONFIG") key = "PUSH_TEST_SERVER_CONFIG";
    else if (body?.code === "PUSH_EXPIRED") key = "PUSH_TEST_EXPIRED";
    else if (body?.code === "PUSH_NOT_REGISTERED") key = "PUSH_TEST_NOT_REGISTERED";
    else if (status === 400 || status === 401 || status === 403) key = "PUSH_TEST_REJECTED_AUTH";
    else if (status === 404 || status === 410) key = "PUSH_TEST_EXPIRED";
    else if (status === 413) key = "PUSH_TEST_REJECTED_TOO_LARGE";
    else if (status === 429) key = "PUSH_TEST_REJECTED_RATE";
    else if (status >= 500) key = "PUSH_TEST_REJECTED_SERVICE";

    return key ? tm(key).replace("{0}", detail) : detail;
  };

  const handlePushTest = async () => {
    if (!pushSupported || pushTestBusy) return;
    setPushTestBusy(true);
    try {
      // 구독 재설정 후 테스트
      const registrations = await navigator.serviceWorker.getRegistrations();
      for (const reg of registrations) {
        const sub = await reg.pushManager?.getSubscription?.();
        if (sub) {
          await fetch("/api/push", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userId: userInfo.getLoginUserId(), endpoint: sub.endpoint }),
          }).catch(() => {});
          await sub.unsubscribe().catch(() => {});
        }
      }
      await enablePushNotifications();
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (!sub) throw new Error(tm("PUSH_TEST_NO_SUBSCRIPTION"));

      const res = await fetch("/api/push-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: userInfo.getLoginUserId(), endpoint: sub.endpoint }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(describePushTestFailure(body, res.status));
      // iOS는 PWA가 포그라운드면 배너를 안 띄운다 → 전송 성공 후 화면을 잠그거나 홈으로 나가야 배너가 뜬다.
      const codePart = body.statusCode ? ` (${body.statusCode})` : "";
      openOkModal(tm("PUSH_TEST_SENT").replace("{0}", codePart), constants.messageCategory.Info);
      setTimeout(loadDiagnostics, 2500);
    } catch (e) {
      openOkModal(tm("PUSH_TEST_FAILED").replace("{0}", e.message), constants.messageCategory.Error);
    } finally {
      setPushTestBusy(false);
    }
  };

  const handleLocalNotificationTest = async () => {
    if (!pushSupported || localNotificationBusy) return;
    setLocalNotificationBusy(true);
    try {
      const permission = await Notification.requestPermission();
      if (permission !== "granted") throw new Error(tm("PUSH_LOCAL_TEST_NO_PERMISSION"));

      const reg = await navigator.serviceWorker.ready;
      await reg.showNotification(tm("PUSH_LOCAL_TEST_TITLE"), {
        body: tm("PUSH_LOCAL_TEST_BODY"),
        icon: "/pwa-icon-192.png",
        badge: "/pwa-icon-192.png",
        tag: `brunner-local-notification-test-${Date.now()}`,
        data: { url: "/", roomId: "local-test" },
        renotify: true,
      });
      openOkModal(tm("PUSH_LOCAL_TEST_SHOWN"), constants.messageCategory.Info);
    } catch (e) {
      openOkModal(tm("PUSH_LOCAL_TEST_FAILED").replace("{0}", e.message), constants.messageCategory.Error);
    } finally {
      setLocalNotificationBusy(false);
    }
  };

  const handlePushSubscriptionReset = async () => {
    if (!pushSupported || pushResetBusy) return;
    const ok = await openOkCancelModal(tm("PUSH_SUBSCRIPTION_RESET_CONFIRM"), constants.messageCategory.Confirm).catch(() => false);
    if (!ok) return;

    setPushResetBusy(true);
    try {
      const registrations = await navigator.serviceWorker.getRegistrations();
      for (const reg of registrations) {
        const sub = await reg.pushManager?.getSubscription?.();
        if (sub) {
          await fetch("/api/push", {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              userId: userInfo.getLoginUserId(),
              endpoint: sub.endpoint,
            }),
          }).catch(() => {});
          await sub.unsubscribe().catch(() => {});
        }
        await reg.unregister().catch(() => {});
      }
      localStorage.setItem(PUSH_PREF_KEY, "true");
      openOkModal(tm("PUSH_SUBSCRIPTION_RESET_DONE"), constants.messageCategory.Info);
      window.location.reload();
    } catch (e) {
      openOkModal(tm("PUSH_SUBSCRIPTION_RESET_FAILED").replace("{0}", e.message), constants.messageCategory.Error);
    } finally {
      setPushResetBusy(false);
    }
  };

  useEffect(() => {
    if (!pushSupported || pushBusy || !pushEnabled || Notification.permission !== "granted") return;

    let cancelled = false;
    const ensureSubscription = async () => {
      try {
        const reg = await navigator.serviceWorker.ready;
        const sub = await reg.pushManager.getSubscription();
        if (!sub && !cancelled) {
          await enablePushNotifications();
        }
      } catch (e) {
        console.error("[push settings auto-enable]", e.message);
      }
    };

    ensureSubscription();
    return () => { cancelled = true; };
  }, [pushSupported, pushEnabled]);

  const openPwModal = () => {
    setCurrentPw("");
    setNewPw("");
    setConfirmPw("");
    setPwError("");
    setShowPwModal(true);
  };

  const handleChangePassword = async () => {
    if (!currentPw || !newPw || !confirmPw) {
      setPwError(tm("REQUIRED_FIELD"));
      return;
    }
    if (newPw !== confirmPw) {
      setPwError(tm("PASSWORD_MISMATCH"));
      return;
    }
    setPwLoading(true);
    setPwError("");
    try {
      const res = await RequestServer({
        commandName: constants.commands.SECURITY_CHANGE_PASSWORD,
                userId: userInfo.getLoginUserId(),
        languageCode: userInfo.getCurrentLanguageCode(),
        currentPassword: currentPw,
        newPassword: newPw,
        confirmPassword: confirmPw,
      });
      if (res.error_code === constants.errorCode.Success) {
        setShowPwModal(false);
        openOkModal(res.error_message || tm("SUCCESS_CHANGED"), constants.messageCategory.Info);
      } else {
        setPwError(res.error_message || tm("CHANGE_PASSWORD_FAILED"));
      }
    } catch (e) {
      setPwError(e.message);
    } finally {
      setPwLoading(false);
    }
  };

  return (
    <PageContainer className="bg-[var(--bg)] pb-16 text-[var(--text)]">
      <BrunnerMessageBox />
      <div className="flex items-center justify-between gap-2">
        <h2 className="page-title">{tl("settings")}</h2>
      </div>

      <Card strong className="mt-4 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-4">
          <Avatar initial={(userInfo.getLoginUserName?.() || userInfo.getLoginUserId?.() || "B").charAt(0)} size={56} online />
          <div>
            <div className="text-xl font-extrabold text-[var(--text)]">{userInfo.getLoginUserName?.() || userInfo.getLoginUserId?.()}</div>
            <div className="text-sm text-[var(--text-muted)]">@{userInfo.getLoginUserId?.()}</div>
          </div>
        </div>
        <Button variant="ghost" onClick={() => window.location.href = "/mainPages/userAccount"}>{tl("edit")}</Button>
      </Card>

      <Card className="mt-4 p-5">
        <h3 className="text-base font-extrabold text-[var(--text)]">{tl("fontSize")}</h3>
        <div className="mt-4 grid grid-cols-5 gap-2">
          {FONT_STEPS.map(({ key, scale }) => {
            const isActive = Math.abs(fontScale - scale) < 0.01;
            return (
              <button
                key={key}
                type="button"
                onClick={() => {
                  setFontScale(scale);
                  applyFontScale(scale);
                  localStorage.setItem(FONT_SIZE_KEY, String(scale));
                }}
                className={`flex flex-col items-center gap-1.5 rounded-[var(--radius-md)] border px-2 py-3 transition ${isActive ? "border-[var(--brand-blue)] bg-[image:var(--brand-gradient-soft)] text-[var(--brand-blue)]" : "border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-muted)] hover:border-[var(--brand-blue)]"}`}
              >
                <span style={{ fontSize: `${scale * 18}px`, fontWeight: 700, lineHeight: 1 }}>{tl("fontSizeSampleChar")}</span>
                <span className="text-xs font-medium">{tl(key)}</span>
              </button>
            );
          })}
        </div>
      </Card>

      {isAdminCapable && (
        <Card className="mt-4 p-5">
          <h3 className="text-base font-extrabold text-[var(--text)]">{tl("adminModeSettings")}</h3>
          <div className="mt-4">
            <label className="flex cursor-pointer items-center justify-between gap-4 rounded-[var(--radius-lg)] border border-[var(--border)] bg-[var(--surface-alt)] p-4">
              <span className="flex flex-col">
                <span className="text-sm font-semibold text-[var(--text)]">{tl("adminModeSettings")}</span>
                <span className="text-xs text-[var(--text-muted)]">{tl("adminModeSettingsDesc")}</span>
              </span>
              <Toggle checked={adminMode} onChange={handleAdminModeToggle} />
            </label>
          </div>
        </Card>
      )}

      <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1.2fr]">
        <Card className="p-5">
          <h3 className="text-base font-extrabold text-[var(--text)]">{tl("notificationSettings")}</h3>
          <div className="mt-4 grid gap-3">
            <label className={`flex items-center justify-between gap-4 rounded-[var(--radius-lg)] border border-[var(--border)] bg-[var(--surface-alt)] p-4 ${pushSupported ? "cursor-pointer" : "opacity-60"}`}>
              <span className="flex flex-col">
                <span className="text-sm font-semibold text-[var(--text)]">{tl("pushNotifications")}</span>
                <span className="text-xs text-[var(--text-muted)]">{tl("pushNotificationsDesc")}</span>
              </span>
              <Toggle
                checked={pushEnabled}
                disabled={!pushSupported || pushBusy}
                onClick={handlePushCheckboxClick}
                onChange={handlePushToggle}
              />
            </label>
            <div className="rounded-[var(--radius-lg)] border border-[var(--border)] bg-[var(--surface-alt)] p-4">
              <div className="flex items-start justify-between gap-4">
                <span className="flex flex-col">
                  <span className="text-sm font-semibold text-[var(--text)]">{tl("pushNotificationSound")}</span>
                  <span className="text-xs text-[var(--text-muted)]">{tl("pushNotificationSoundDesc")}</span>
                </span>
                {pushSoundBusy && <span className="text-xs text-[var(--text-muted)]">{tl("saving")}</span>}
              </div>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                {PUSH_SOUND_OPTIONS.map((option) => {
                  const selected = pushSound === option.id;
                  return (
                    <div
                      key={option.id}
                      className={`rounded-[var(--radius-md)] border px-3 py-2 text-left transition ${selected ? "border-[var(--brand-blue)] bg-[image:var(--brand-gradient-soft)]" : "border-[var(--border)] bg-[var(--surface)] hover:border-[var(--brand-blue)]"}`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => savePushSoundPreference(option.id)}
                          className="min-w-0 flex-1 text-left"
                          aria-pressed={selected}
                        >
                          <span className="block text-sm font-bold text-[var(--text)]">{tl(option.labelKey)}</span>
                          <span className="mt-0.5 block text-xs text-[var(--text-muted)]">{tl(option.descKey)}</span>
                        </button>
                        {option.previewSrc && (
                          <button
                            type="button"
                            onClick={() => previewPushSound(option.previewSrc)}
                            className="shrink-0 rounded-full border border-[var(--border)] bg-[var(--surface)] px-2 py-1 text-[11px] font-bold text-[var(--text)] hover:border-[var(--brand-blue)] hover:text-[var(--brand-blue)]"
                            title={tl("preview")}
                            aria-label={`${tl(option.labelKey)} ${tl("preview")}`}
                          >
                            ▶ {tl("preview")}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
              <p className="mt-3 text-xs leading-5 text-[var(--text-muted)]">{tl("pushNotificationSoundNativeNotice")}</p>
            </div>
            <label className="flex items-center justify-between gap-4 rounded-[var(--radius-lg)] border border-[var(--border)] bg-[var(--surface-alt)] p-4">
              <span className="text-sm font-semibold text-[var(--text)]">{tl("vibration")}</span>
              <Toggle checked onChange={() => {}} />
            </label>
          </div>
          {!pushSupported && <p className="mt-2 text-xs text-[var(--text-muted)]">{tm("BROWSER_NO_PUSH")}</p>}
        </Card>

        <Card className="p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-base font-extrabold text-[var(--text)]">{tl("notifDiagTitle")}</h3>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePushTest}
                disabled={pushTestBusy || !pushSupported}
                className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-1 text-xs font-semibold text-[var(--text-muted)] hover:border-[var(--brand-blue)] hover:text-[var(--brand-blue)] disabled:opacity-50"
              >
                {pushTestBusy ? "..." : tl("notifTestPush")}
              </button>
              <button
                type="button"
                onClick={handleLocalNotificationTest}
                disabled={localNotificationBusy || !pushSupported}
                className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-1 text-xs font-semibold text-[var(--text-muted)] hover:border-[var(--brand-blue)] hover:text-[var(--brand-blue)] disabled:opacity-50"
              >
                {localNotificationBusy ? "..." : tl("notifTestDisplay")}
              </button>
            </div>
          </div>
          <div className="grid gap-2">
            {[
              // 계정 상태. 관리자 토글은 adminFlag 가 참일 때만 그려지는데, 안 보일
              // 때 원인이 계정 속성인지 화면인지 알 길이 없어 브라우저 콘솔을
              // 열어야 했다. 여기에 값을 그대로 보여 준다.
              {
                label: "로그인 ID",
                value: accountUserId || "(없음)",
                ok: !!accountUserId,
                warn: false,
              },
              {
                label: "관리자 계정",
                value: accountAdminFlag ? "예" : "아니오",
                ok: accountAdminFlag,
                warn: false,
              },
              {
                label: "관리자 모드",
                value: accountAdminMode === null ? "기본(켜짐)" : accountAdminMode ? "켜짐" : "꺼짐",
                ok: accountAdminMode !== false,
                warn: accountAdminMode === false,
              },
              {
                label: tl("notifRunMode"),
                value: diagStandalone ? tl("notifRunModeInstalled") : tl("notifRunModeBrowser"),
                // iOS는 설치앱(standalone)이 아니면 푸시가 아예 안 온다 → 브라우저탭이면 빨간 경고
                ok: diagStandalone,
                warn: !diagStandalone && !diagIsIOS,
              },
              {
                label: tl("notifPermission"),
                value: diagPermission === "granted" ? tl("notifPermissionGranted") : diagPermission === "denied" ? tl("notifPermissionDenied") : tl("notifPermissionDefault"),
                ok: diagPermission === "granted",
                warn: diagPermission === "default",
              },
              {
                label: tl("notifGlobalSetting"),
                value: pushEnabled ? tl("notifEnabled") : tl("notifDisabled"),
                ok: pushEnabled,
                warn: false,
              },
              {
                label: tl("notifSubscription"),
                value: diagSubscribed ? tl("notifSubscribed") : tl("notifNotSubscribed"),
                ok: diagSubscribed,
                warn: false,
              },
              {
                label: tl("notifLastReceived"),
                value: diagLastPush ? new Date(diagLastPush).toLocaleString() : tl("notifNever"),
                ok: Boolean(diagLastPush),
                warn: !diagLastPush,
              },
            ].map(({ label, value, ok, warn }) => (
              <div key={label} className="flex items-center justify-between rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-2.5">
                <span className="text-sm text-[var(--text-muted)]">{label}</span>
                <span className={`flex items-center gap-1.5 text-sm font-semibold ${ok ? "text-[var(--success)]" : warn ? "text-[var(--warn)]" : "text-[var(--danger)]"}`}>
                  <span className="text-xs">{ok ? "●" : warn ? "◐" : "●"}</span>
                  {value}
                </span>
              </div>
            ))}
          </div>
          {diagIsIOS && !diagStandalone && (
            <p className="mt-3 rounded-[var(--radius-md)] border border-[var(--danger)] bg-danger/10 px-4 py-2.5 text-xs font-semibold text-[var(--danger)]">
              {tl("notifRunModeIosWarn")}
            </p>
          )}
        </Card>

        <Card className="p-5">
          <h3 className="text-base font-extrabold text-[var(--text)] mb-1">{tl("homeAccentTitle")}</h3>
          <p className="text-sm text-[var(--text-muted)] mb-4">{tl("homeAccentDesc")}</p>
          <HomeAccentColorPicker />
        </Card>

        <Card className="p-5">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <h3 className="text-base font-extrabold text-[var(--text)]">{tl("colorTheme")}</h3>
              <p className="mt-1 text-sm text-[var(--text-muted)]">{tm("COLOR_THEME_DESC")}</p>
            </div>
            <DarkModeToggleButton />
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {Object.entries(THEMES).map(([id, theme]) => {
              const isActive = themeId === id;
              return (
                <button
                  key={id}
                  onClick={() => changeTheme(id)}
                  className={`relative flex flex-col items-start gap-2 rounded-[var(--radius-lg)] border-2 bg-[var(--surface)] p-3 text-left transition ${
                    isActive ? "border-[var(--brand-blue)] shadow-[var(--shadow-card)]" : "border-[var(--border)] hover:border-[var(--border-strong)]"
                  }`}
                  aria-pressed={isActive}
                  aria-label={`${theme.name} ${tl("colorTheme")}`}
                >
                  {(() => {
                    const bg = isDark ? theme.previewDark : (theme.previewLight || theme.previewDark);
                    const accent = isDark ? theme.previewAccent : (theme.lightAccent || theme.previewAccent);
                    return (
                      <div className="flex h-12 w-full overflow-hidden rounded-[var(--radius-md)]" style={{ background: bg }}>
                        <div className="h-full w-1/4 opacity-70" style={{ background: accent }} />
                        <div className="flex flex-1 flex-col justify-center gap-1 px-2">
                          <div className="h-1.5 w-3/4 rounded-full opacity-40" style={{ background: accent }} />
                          <div className="h-1.5 w-1/2 rounded-full bg-[var(--text)] opacity-15" />
                        </div>
                      </div>
                    );
                  })()}
                  <div className="flex w-full items-center justify-between">
                    <span className="text-sm font-semibold text-[var(--text-muted)]">{theme.emoji} {theme.name}</span>
                    {isActive && <Chip tone="brand">{tl("themeApplied")}</Chip>}
                  </div>
                </button>
              );
            })}
          </div>
        </Card>
      </div>

      <Card className="mt-4 p-5">
        <h3 className="text-base font-extrabold text-[var(--text)]">{tl("account")}</h3>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="soft" onClick={openPwModal}>{tl("changePassword")}</Button>
        </div>
      </Card>

      {showPwModal && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/50" onClick={(e) => { if (!pwLoading && e.target === e.currentTarget) setShowPwModal(false); }}>
          <div className="w-full md:max-w-sm rounded-t-[var(--radius-lg)] md:rounded-[var(--radius-lg)] bg-[var(--surface)] p-6 shadow-[var(--shadow-card)] max-h-[85dvh] overflow-y-auto" style={{ paddingBottom: "max(1.5rem, env(safe-area-inset-bottom))" }}>
            <h3 className="mb-5 text-base font-extrabold text-[var(--text)]">{tl("changePassword")}</h3>
            <div className="flex flex-col gap-3">
              <div>
                <label className="mb-1 block text-xs font-semibold text-[var(--text-muted)]">{tl("currentPassword")}</label>
                <Input type="password" value={currentPw} onChange={(e) => setCurrentPw(e.target.value)} autoComplete="current-password" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-[var(--text-muted)]">{tl("newPassword")}</label>
                <Input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} autoComplete="new-password" />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold text-[var(--text-muted)]">{tl("confirmNewPassword")}</label>
                <Input type="password" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} autoComplete="new-password" />
              </div>
              {pwError && <p className="text-xs text-[var(--danger)]">{pwError}</p>}
            </div>
            <div className="mt-5 flex gap-2">
              <Button variant="ghost" className="flex-1" onClick={() => setShowPwModal(false)} disabled={pwLoading}>{tl("cancel")}</Button>
              <Button variant="primary" className="flex-1" onClick={handleChangePassword} disabled={pwLoading}>{pwLoading ? "..." : tl("save")}</Button>
            </div>
          </div>
        </div>
      )}
    </PageContainer>
  );
}
