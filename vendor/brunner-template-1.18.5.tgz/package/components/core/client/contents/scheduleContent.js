import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { createPortal, flushSync } from "react-dom";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import { RequestServer } from "@/components/core/client/requestServer";
import { Solar } from "lunar-javascript";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useModal } from "@/components/core/client/brunnerMessageBox";

import { registerInAppBack } from "@/components/core/client/frames/backNavigationButton";
const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#06b6d4"];
const SCHEDULE_TYPES_RAW = [
  { value: "admission",   label: "입학",    labelEn: "Admission",     labelJa: "入学" },
  { value: "anniversary", label: "기념일",  labelEn: "Anniversary",   labelJa: "記念日" },
  { value: "birthday",    label: "생일",    labelEn: "Birthday",      labelJa: "誕生日" },
  { value: "bizvisit",    label: "업무",    labelEn: "Business",      labelJa: "業務" },
  { value: "checkup",     label: "검진",    labelEn: "Checkup",       labelJa: "検診" },
  { value: "event",       label: "행사",    labelEn: "Event",         labelJa: "イベント" },
  { value: "exam",        label: "시험",    labelEn: "Exam",          labelJa: "試験" },
  { value: "family",      label: "가족행사", labelEn: "Family Event",  labelJa: "家族行事" },
  { value: "funeral",     label: "장례식",  labelEn: "Funeral",       labelJa: "葬儀" },
  { value: "graduation",  label: "졸업",    labelEn: "Graduation",    labelJa: "卒業" },
  { value: "holiday",     label: "휴일",    labelEn: "Holiday",       labelJa: "休日" },
  { value: "hospital",    label: "병원",    labelEn: "Hospital",      labelJa: "病院" },
  { value: "interview",   label: "면접",    labelEn: "Interview",     labelJa: "面接" },
  { value: "jesa",        label: "제사",    labelEn: "Memorial Rite", labelJa: "法事" },
  { value: "meeting",     label: "회의",    labelEn: "Meeting",       labelJa: "会議" },
  { value: "moving",      label: "이사",    labelEn: "Moving",        labelJa: "引っ越し" },
  { value: "etc",         label: "기타",    labelEn: "Other",         labelJa: "その他" },
  { value: "travel",      label: "여행",    labelEn: "Travel",        labelJa: "旅行" },
  { value: "wedding",     label: "결혼",    labelEn: "Wedding",       labelJa: "結婚" },
];
function getScheduleTypes() {
  const code = userInfo.getCurrentLanguageCode?.() || "ko-KR";
  const lang = code.startsWith("ko") ? "ko" : code.startsWith("ja") ? "ja" : "en";
  const pick = (t) => (lang === "ko" ? t.label : lang === "ja" ? t.labelJa : t.labelEn);
  const collator = lang === "ja" ? "ja" : lang === "ko" ? "ko" : "en";
  return [...SCHEDULE_TYPES_RAW]
    .sort((a, b) => pick(a).localeCompare(pick(b), collator))
    .map((t) => ({ value: t.value, label: pick(t) }));
}
const REMINDER_OPTIONS = [
  { label: "없음", labelEn: "None", labelJa: "なし", value: null },
  { label: "5분 전", labelEn: "5 min before", labelJa: "5分前", value: 5 },
  { label: "10분 전", labelEn: "10 min before", labelJa: "10分前", value: 10 },
  { label: "30분 전", labelEn: "30 min before", labelJa: "30分前", value: 30 },
  { label: "1시간 전", labelEn: "1 hour before", labelJa: "1時間前", value: 60 },
  { label: "1일 전", labelEn: "1 day before", labelJa: "1日前", value: 1440 },
];
function getReminderOptions() {
  const code = userInfo.getCurrentLanguageCode?.() || "ko-KR";
  const lang = code.startsWith("ko") ? "ko" : code.startsWith("ja") ? "ja" : "en";
  return REMINDER_OPTIONS.map((o) => ({
    value: o.value,
    label: lang === "ko" ? o.label : lang === "ja" ? o.labelJa : o.labelEn,
  }));
}

const KR_HOLIDAYS = {
  "01-01": "신정", "03-01": "삼일절", "05-05": "어린이날", "06-06": "현충일",
  "08-15": "광복절", "10-03": "개천절", "10-09": "한글날", "12-25": "크리스마스",
  "2024-02-09": "설날 전날", "2024-02-10": "설날", "2024-02-11": "설날 다음날",
  "2024-05-15": "부처님오신날",
  "2024-09-16": "추석 전날", "2024-09-17": "추석", "2024-09-18": "추석 다음날",
  "2025-01-28": "설날 전날", "2025-01-29": "설날", "2025-01-30": "설날 다음날",
  "2025-05-05": "부처님오신날",
  "2025-10-05": "추석 전날", "2025-10-06": "추석", "2025-10-07": "추석 다음날",
  "2026-02-16": "설날 전날", "2026-02-17": "설날", "2026-02-18": "설날 다음날",
  "2026-05-24": "부처님오신날",
  "2026-09-24": "추석 전날", "2026-09-25": "추석", "2026-09-26": "추석 다음날",
  "2027-02-06": "설날 전날", "2027-02-07": "설날", "2027-02-08": "설날 다음날",
  "2027-05-13": "부처님오신날",
  "2027-09-14": "추석 전날", "2027-09-15": "추석", "2027-09-16": "추석 다음날",
  "2028-01-25": "설날 전날", "2028-01-26": "설날", "2028-01-27": "설날 다음날",
  "2028-05-02": "부처님오신날",
  "2028-10-02": "추석 전날", "2028-10-03": "추석", "2028-10-04": "추석 다음날",
};

// 한국 공휴일 영어 표기 — 한국어가 아니면 영어로 보여준다(일본어 사용자도 영어).
const HOLIDAY_EN = {
  "신정": "New Year's Day",
  "삼일절": "Independence Movement Day",
  "어린이날": "Children's Day",
  "현충일": "Memorial Day",
  "광복절": "Liberation Day",
  "개천절": "National Foundation Day",
  "한글날": "Hangeul Day",
  "크리스마스": "Christmas",
  "설날": "Lunar New Year",
  "설날 전날": "Lunar New Year's Eve",
  "설날 다음날": "Day After Lunar New Year",
  "부처님오신날": "Buddha's Birthday",
  "추석": "Chuseok",
  "추석 전날": "Day Before Chuseok",
  "추석 다음날": "Day After Chuseok",
};
function getHolidayName(dateStr) {
  const ko = KR_HOLIDAYS[dateStr] || KR_HOLIDAYS[dateStr.slice(5)] || null;
  if (!ko) return null;
  const isKo = (userInfo.getCurrentLanguageCode?.() || "ko-KR").startsWith("ko");
  return isKo ? ko : (HOLIDAY_EN[ko] || ko);
}

function getCalDays(year, month) {
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const days = [];
  for (let i = 0; i < firstDay; i++) days.push(null);
  for (let d = 1; d <= daysInMonth; d++) days.push(d);
  while (days.length % 7 !== 0) days.push(null);
  return days;
}

function buildMonthList(centerYear, centerMonth, before, after) {
  const list = [];
  for (let i = -before; i <= after; i++) {
    const d = new Date(centerYear, centerMonth + i);
    list.push({ year: d.getFullYear(), month: d.getMonth() });
  }
  return list;
}

function tl(key) {
  return commonFunctions.getResourceByLanguage(key, constants.resourceType.label, userInfo.getCurrentLanguageCode?.() || "ko-KR");
}
function pad2(n) { return String(n).padStart(2, "0"); }
function toLocalDateStr(date) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}
function toLocalDateTimeStr(date) {
  return `${toLocalDateStr(date)}T${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
}
function roundTo10Min(date) {
  const d = new Date(date);
  d.setMinutes(Math.ceil(d.getMinutes() / 10) * 10, 0, 0);
  if (d.getMinutes() === 60) { d.setMinutes(0); d.setHours(d.getHours() + 1); }
  return d;
}

const WEEKDAYS_BY_LANG = {
  ko: ["일", "월", "화", "수", "목", "금", "토"],
  en: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  ja: ["日", "月", "火", "水", "木", "金", "土"],
};
function getWeekdays() {
  const code = userInfo.getCurrentLanguageCode?.() || "ko-KR";
  const lang = code.startsWith("ko") ? "ko" : code.startsWith("ja") ? "ja" : "en";
  return WEEKDAYS_BY_LANG[lang];
}
const EXTEND_SIZE = 6;

// 음력 변환 — Intl API (Chinese calendar = 한국 음력과 동일 체계)
const _lunarFmt = typeof Intl !== "undefined"
  ? new Intl.DateTimeFormat("ko-u-ca-chinese", { month: "numeric", day: "numeric" })
  : null;
function getLunar(year, month, day) {
  if (!_lunarFmt) return null;
  try {
    const parts = _lunarFmt.formatToParts(new Date(year, month, day));
    const m = parseInt(parts.find(p => p.type === "month")?.value || "0", 10);
    const d = parseInt(parts.find(p => p.type === "day")?.value || "0", 10);
    if (!m || !d) return null;
    return { month: m, day: d };
  } catch { return null; }
}

export default function ScheduleContent() {
  const { BrunnerMessageBox, openOkModal, openOkCancelModal } = useModal();
  const loginUserId = userInfo.getLoginUserId?.();

  const today = new Date();
  const todayYear = today.getFullYear();
  const todayMonth = today.getMonth();
  const todayStr = toLocalDateStr(today);

  // 무한 스크롤 월 목록 — 이번달부터 시작 (scrollTop=0이 곧 이번달)
  const [months, setMonths] = useState(() => buildMonthList(todayYear, todayMonth, 0, 24));
  // 헤더에 표시되는 현재 보이는 월
  const [viewYear, setViewYear] = useState(todayYear);
  const [viewMonth, setViewMonth] = useState(todayMonth);
  const [selectedDate, setSelectedDate] = useState(todayStr);
  const [schedules, setSchedules] = useState([]);
  const [friends, setFriends] = useState([]);
  const [showForm, setShowForm] = useState(false);
  // 화면 안에서 열린 상세/폼은 URL이 바뀌지 않으므로, 열려 있는 동안
  // 뒤로가기를 '닫기'로 처리한다(홈으로 빠져나가지 않게).
  useEffect(() => {
    if (!showForm) return undefined;
    return registerInAppBack(
      () => { setShowForm(false); return true; },
      () => { setShowForm(true); }, // 앞으로가기 → 다시 열기
    );
  }, [showForm]);
  const [formReadOnly, setFormReadOnly] = useState(false); // 참여자(비소유자) 일정은 읽기전용으로 연다
  const [showParticipantPicker, setShowParticipantPicker] = useState(false);
  const [participantKeyword, setParticipantKeyword] = useState("");
  const [form, setForm] = useState(null);
  const [zoomPos, setZoomPos] = useState(null);
  const [scrollToTodayFlag, setScrollToTodayFlag] = useState(0);
  const [repeatDeleteTarget, setRepeatDeleteTarget] = useState(null);

  const scrollRef = useRef(null);  // mount 후 실제 스크롤 컨테이너(main)로 교체됨
  const contentRef = useRef(null); // 달력 content div (querySelector용)
  const loadTimerRef = useRef(null);
  const topSentinelRef = useRef(null);
  const bottomSentinelRef = useRef(null);
  const topCooldownRef = useRef(false);
  const bottomCooldownRef = useRef(false);

  const loadSchedules = useCallback(async (yr, mo) => {
    const rangeStart = new Date(yr, mo - 3, 1).toISOString();
    const rangeEnd = new Date(yr, mo + 4, 0, 23, 59, 59).toISOString();
    const res = await RequestServer({
      commandName: constants.commands.SCHEDULE_LIST,
      loginUserId, rangeStart, rangeEnd,
    });
    if (res.error_code === constants.errorCode.Success) setSchedules(res.schedules || []);
  }, [loginUserId]);

  // scrollRef를 실제 스크롤 컨테이너(layout의 main 요소)로 교체
  useEffect(() => {
    const main = contentRef.current?.closest('main');
    if (main) {
      scrollRef.current = main;
      // 마운트 시 오늘 날짜 셀이 보이도록 스크롤
      requestAnimationFrame(() => {
        const todayCell = contentRef.current?.querySelector(`[data-cal-date="${todayStr}"]`);
        if (!todayCell) return;
        todayCell.scrollIntoView({ block: "center", behavior: "instant" });
      });
    }
  }, []);

  // 뷰 변경 시 일정 로드 (400ms 디바운스)
  useEffect(() => {
    clearTimeout(loadTimerRef.current);
    loadTimerRef.current = setTimeout(() => loadSchedules(viewYear, viewMonth), 400);
    return () => clearTimeout(loadTimerRef.current);
  }, [viewYear, viewMonth, loadSchedules]);

  useEffect(() => {
    RequestServer({ commandName: constants.commands.FRIEND_LIST_BY_USER, userId: loginUserId })
      .then((res) => { if (res.error_code === constants.errorCode.Success) setFriends(res.data || []); });
  }, [loginUserId]);

  useEffect(() => {
    if (!selectedDate || typeof document === "undefined") { setZoomPos(null); return; }
    const el = document.querySelector(`[data-cal-date="${selectedDate}"]`);
    if (!el) { setZoomPos(null); return; }
    const r = el.getBoundingClientRect();
    const popW = 115;
    const margin = 4;
    const left = Math.max(margin, Math.min(r.left + r.width / 2 - popW / 2, window.innerWidth - popW - margin));
    setZoomPos({ top: r.bottom + 2, left });
  }, [selectedDate]);

  // 오늘 버튼: flag 변경 → useEffect에서 스크롤
  useEffect(() => {
    if (scrollToTodayFlag === 0) return;
    const container = scrollRef.current;
    const content = contentRef.current;
    if (!container || !content) return;
    const section = content.querySelector(`[data-sy="${todayYear}"][data-sm="${todayMonth}"]`);
    if (!section) return;
    const cRect = container.getBoundingClientRect();
    const sRect = section.getBoundingClientRect();
    container.scrollTop += sRect.top - cRect.top;
  }, [scrollToTodayFlag, todayYear, todayMonth]);

// 스크롤 이벤트: 헤더 월 라벨 업데이트만 담당
  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;
    let timer;
    const onScroll = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        const cRect = container.getBoundingClientRect();
        const targetY = cRect.top + cRect.height * 0.3;
        const el = document.elementFromPoint(cRect.left + cRect.width / 2, targetY);
        const best = el?.closest("[data-sy]");
        if (best) {
          setViewYear(Number(best.dataset.sy));
          setViewMonth(Number(best.dataset.sm));
        }
      }, 80);
    };
    container.addEventListener("scroll", onScroll, { passive: true });
    return () => { container.removeEventListener("scroll", onScroll); clearTimeout(timer); };
  }, []);

  // sentinel IntersectionObserver — months 배열과 무관하게 한 번만 생성 (루프 없음)
  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        if (entry.target === topSentinelRef.current && !topCooldownRef.current) {
          topCooldownRef.current = true;
          const prevScrollHeight = container.scrollHeight;
          flushSync(() => {
            setMonths((prev) => {
              const first = prev[0];
              const toAdd = [];
              for (let i = EXTEND_SIZE; i >= 1; i--) {
                const d = new Date(first.year, first.month - i);
                toAdd.push({ year: d.getFullYear(), month: d.getMonth() });
              }
              return [...toAdd, ...prev];
            });
          });
          container.scrollTop += container.scrollHeight - prevScrollHeight;
          setTimeout(() => { topCooldownRef.current = false; }, 2000);
        } else if (entry.target === bottomSentinelRef.current && !bottomCooldownRef.current) {
          bottomCooldownRef.current = true;
          setTimeout(() => { bottomCooldownRef.current = false; }, 2000);
          setMonths((prev) => {
            const last = prev[prev.length - 1];
            const toAdd = [];
            for (let i = 1; i <= EXTEND_SIZE; i++) {
              const d = new Date(last.year, last.month + i);
              toAdd.push({ year: d.getFullYear(), month: d.getMonth() });
            }
            return [...prev, ...toAdd];
          });
        }
      });
    }, { root: null, rootMargin: "400px 0px", threshold: 0 });
    if (topSentinelRef.current) observer.observe(topSentinelRef.current);
    if (bottomSentinelRef.current) observer.observe(bottomSentinelRef.current);
    return () => observer.disconnect();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleDateClick = (dateStr) => {
    setSelectedDate((prev) => (prev === dateStr ? null : dateStr));
  };

  const openForm = (dateStr) => {
    const base = new Date(dateStr + "T00:00:00");
    const start = roundTo10Min(dateStr === todayStr ? new Date() : base);
    const end = new Date(start.getTime() + 30 * 60 * 1000);
    setForm({
      editingId: null, title: "", description: "",
      startTime: toLocalDateTimeStr(start), endTime: toLocalDateTimeStr(end),
      isAllDay: false, scheduleType: null, color: COLORS[0], reminderMinutes: null, participantIds: [],
      repeatType: null, repeatUntil: "", repeatLunar: false,
    });
    setFormReadOnly(false);
    setShowForm(true);
  };

  const openEditForm = async (s, readOnly = false) => {
    const parseLocalTime = (str) => new Date(String(str).replace("Z", "").replace(" ", "T"));
    const start = parseLocalTime(s.start_time);
    const end = parseLocalTime(s.end_time);
    const isAllDay = s.is_all_day === "Y";
    const pRes = await RequestServer({ commandName: constants.commands.SCHEDULE_GET_PARTICIPANTS, scheduleId: s.schedule_id });
    const participantIds = pRes.error_code === constants.errorCode.Success ? (pRes.participants || []).map((p) => p.user_id) : [];
    setForm({
      editingId: s.schedule_id, title: s.title, description: s.description || "",
      startTime: isAllDay ? toLocalDateStr(start) + "T00:00" : toLocalDateTimeStr(start),
      endTime: isAllDay ? toLocalDateStr(end) + "T23:59" : toLocalDateTimeStr(end),
      isAllDay, scheduleType: s.schedule_type || null, color: s.color || COLORS[0], reminderMinutes: s.reminder_minutes ?? null, participantIds,
      repeatType: s.repeat_type || null,
      repeatUntil: s.repeat_until ? String(s.repeat_until).slice(0, 10) : "",
      repeatLunar: s.repeat_lunar === true || s.repeat_lunar === "true",
    });
    setFormReadOnly(readOnly);
    setShowForm(true);
  };

  const saveForm = async () => {
    if (!form.title.trim()) { await openOkModal?.("제목을 입력해 주세요.", "error"); return; }
    const startTime = form.isAllDay ? form.startTime.split("T")[0] + "T00:00:00" : form.startTime;
    const endTime = form.isAllDay ? form.endTime.split("T")[0] + "T23:59:59" : form.endTime;
    if (new Date(endTime) <= new Date(startTime)) { await openOkModal?.("종료 시간이 시작 시간보다 늦어야 합니다.", "error"); return; }
    const isEdit = !!form.editingId;
    const res = await RequestServer({
      commandName: isEdit ? constants.commands.SCHEDULE_UPDATE : constants.commands.SCHEDULE_CREATE,
      loginUserId,
      ...(isEdit ? { scheduleId: form.editingId } : {}),
      title: form.title, description: form.description,
      startTime, endTime, isAllDay: form.isAllDay,
      scheduleType: form.scheduleType || null,
      color: form.color, reminderMinutes: form.reminderMinutes,
      participantIds: form.participantIds,
      repeatType: form.repeatType || null,
      repeatUntil: form.repeatType && form.repeatUntil ? form.repeatUntil : null,
      repeatLunar: form.repeatType === "yearly" && form.repeatLunar === true,
    });
    if (res.error_code === constants.errorCode.Success) {
      setShowForm(false);
      await loadSchedules(viewYear, viewMonth);
    } else {
      await openOkModal?.(res.error_message, "error");
    }
  };

  const deleteSchedule = async (s) => {
    if (s.repeat_type) {
      setRepeatDeleteTarget(s);
    } else {
      try { await openOkCancelModal(tl("scheduleDeleteConfirm")); } catch { return; }
      const res = await RequestServer({ commandName: constants.commands.SCHEDULE_DELETE, loginUserId, scheduleId: s.schedule_id });
      if (res.error_code === constants.errorCode.Success) {
        await loadSchedules(viewYear, viewMonth);
      } else {
        await openOkModal?.(res.error_message, "error");
      }
    }
  };

  const handleRepeatDelete = async (choice) => {
    const s = repeatDeleteTarget;
    setRepeatDeleteTarget(null);
    if (!choice || !s) return;
    const occurrenceDate = String(s.start_time).slice(0, 10);
    const res = await RequestServer(
      choice === "this"
        ? { commandName: constants.commands.SCHEDULE_DELETE_OCCURRENCE, loginUserId, scheduleId: s.schedule_id, occurrenceDate }
        : { commandName: constants.commands.SCHEDULE_DELETE, loginUserId, scheduleId: s.schedule_id }
    );
    if (res.error_code === constants.errorCode.Success) {
      await loadSchedules(viewYear, viewMonth);
    } else {
      await openOkModal?.(res.error_message, "error");
    }
  };

  const scheduleByDate = useMemo(() => {
    const map = {};
    schedules.forEach((s) => {
      const parseLocalTime = (str) => new Date(String(str).replace("Z", "").replace(" ", "T"));
      const start = parseLocalTime(s.start_time);
      const end = parseLocalTime(s.end_time);
      for (let d = new Date(start.getFullYear(), start.getMonth(), start.getDate());
           d <= new Date(end.getFullYear(), end.getMonth(), end.getDate());
           d.setDate(d.getDate() + 1)) {
        const key = toLocalDateStr(d);
        if (!map[key]) map[key] = [];
        map[key].push(s);
      }
    });
    return map;
  }, [schedules]);

  const selectedDateSchedules = useMemo(() => {
    if (!selectedDate) return [];
    return (scheduleByDate[selectedDate] || []).sort((a, b) => {
      const pa = (str) => new Date(String(str).replace("Z", "").replace(" ", "T"));
      return pa(a.start_time) - pa(b.start_time);
    });
  }, [scheduleByDate, selectedDate]);

  const goToToday = () => {
    setViewYear(todayYear);
    setViewMonth(todayMonth);
    setSelectedDate(todayStr);
    setMonths((prev) => {
      if (prev.some((m) => m.year === todayYear && m.month === todayMonth)) return prev;
      return buildMonthList(todayYear, todayMonth, 6, 18);
    });
    setScrollToTodayFlag((f) => f + 1);
  };

  return (
    <div ref={contentRef} className="flex flex-col bg-[var(--general-bg-color)]">
      <BrunnerMessageBox />

      {/* 헤더 + 요일 묶음 sticky 컨테이너 */}
      <div className="sticky top-0 z-[50] bg-[var(--general-bg-color)]">
      {/* 헤더 */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--border-color)]">
        <span className="font-semibold text-lg text-[var(--general-text-color)] px-1 tracking-tight">
          {viewYear}년 <span className="text-[var(--brand-blue)]">{viewMonth + 1}월</span>
        </span>
        <div className="flex items-center gap-1">
          <button onClick={goToToday} title={tl("scheduleToday")}
            className="w-8 h-8 flex items-center justify-center rounded-full border border-[var(--border-color)] text-[var(--semi-text-color)] hover:bg-[var(--surface-alt)] transition-colors">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/><circle cx="12" cy="16" r="1.5" fill="currentColor" stroke="none"/></svg>
          </button>
          <button onClick={() => openForm(selectedDate || todayStr)} title={tl("scheduleAdd")}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-[var(--brand-blue)] text-white shadow-sm hover:opacity-90 transition-opacity text-xl leading-none">
            +
          </button>
        </div>
      </div>

      {/* 요일 헤더 */}
      <div className="grid grid-cols-7 border-b border-gray-300 dark:border-gray-600 shadow-sm">
        {getWeekdays().map((w, i) => (
          <div key={w} className={`text-center text-[11px] font-medium py-2
            ${i === 0 ? "text-red-400" : i === 6 ? "text-blue-400" : "text-[var(--semi-text-color)]"}`}>{w}</div>
        ))}
      </div>
      </div>{/* /sticky wrapper */}

      {/* 상단 sentinel — 이 요소가 뷰포트에 가까워지면 과거 월 추가 */}
      <div ref={topSentinelRef} style={{ height: 1 }} />

      {months.map(({ year, month }, idx) => {
        const monthPrefix = `${year}-${pad2(month + 1)}`;
        const mCalDays = getCalDays(year, month);
        const isCurrent = year === viewYear && month === viewMonth;
        return (
          <div key={`${year}-${month}`} data-sidx={idx} data-sy={year} data-sm={month}>
            {/* 월 구분 바 */}
            <div className={`text-center py-1.5 text-xs font-semibold border-b border-dashed border-gray-200 dark:border-gray-700
              ${isCurrent ? "text-[var(--brand-blue)] bg-brand-blue/5" : "text-[var(--semi-text-color)]"}`}>
              {year}년 {month + 1}월
            </div>

            {/* 달력 그리드 */}
            <div className="grid grid-cols-7" style={{ gridAutoRows: "86px" }}>
              {mCalDays.map((d, i) => {
                if (!d) return (
                  <div key={`e-${year}-${month}-${i}`} className={`border-r border-b border-dashed border-gray-200 dark:border-gray-700 ${(i + 1) % 7 === 0 ? "border-r-0" : ""}`} />
                );
                const dateStr = `${year}-${pad2(month + 1)}-${pad2(d)}`;
                const isToday = dateStr === todayStr;
                const isSelected = dateStr === selectedDate;
                const holiday = getHolidayName(dateStr);
                const daySchedules = scheduleByDate[dateStr] || [];
                const dow = new Date(year, month, d).getDay();
                const isColLast = (i + 1) % 7 === 0;
                const isWeekend = dow === 0 || dow === 6;
                return (
                  <button
                    key={dateStr}
                    data-cal-date={dateStr}
                    onClick={() => handleDateClick(dateStr)}
                    className={`relative flex flex-col items-stretch px-1 pt-2 pb-1 text-left transition-all duration-150
                      border-b border-dashed border-gray-200 dark:border-gray-700
                      ${isColLast ? "" : "border-r border-dashed border-gray-200 dark:border-gray-700"}
                      ${isSelected
                        ? "bg-brand-blue/15 outline outline-2 outline-[var(--brand-blue)] outline-offset-[-2px] z-20 scale-[1.13] shadow-lg rounded-xl"
                        : isWeekend ? "bg-gray-50/60 dark:bg-gray-800/30 hover:bg-gray-100/80 dark:hover:bg-gray-700/30"
                        : "hover:bg-gray-50/80 dark:hover:bg-gray-800/20"}`}
                  >
                    <span className={`self-center text-[15px] font-semibold leading-none w-[30px] h-[30px] flex items-center justify-center rounded-full transition-all
                      ${isToday || isSelected ? "bg-[var(--brand-blue)] text-white"
                        : holiday || dow === 0 ? "text-red-500"
                        : dow === 6 ? "text-blue-500"
                        : "text-[var(--general-text-color)]"}`}>
                      {d}
                    </span>
                    {(() => {
                      const lunar = getLunar(year, month, d);
                      if (!lunar) return null;
                      return (
                        <span className={`text-[8px] leading-none text-center w-full ${lunar.day === 1 ? "text-amber-500 font-semibold" : "text-[var(--semi-text-color)]"}`}>
                          {lunar.day === 1 ? `음${lunar.month}월` : lunar.day}
                        </span>
                      );
                    })()}
                    {holiday && (
                      <span className="text-[8px] leading-tight text-red-400 font-medium truncate w-full text-center">{holiday}</span>
                    )}
                    <div className="flex flex-col gap-[2px] w-full mt-auto px-0.5">
                      {daySchedules.slice(0, 2).map((s) => (
                        <span key={`${s.schedule_id}-${s.start_time}`}
                          className="truncate rounded text-[9px] leading-[14px] px-1.5 text-white font-medium flex items-center gap-0.5"
                          style={{ backgroundColor: s.color || "#3b82f6" }}>
                          {s.repeat_type && <span className="shrink-0">↻</span>}
                          <span className="truncate">{s.title}</span>
                        </span>
                      ))}
                      {daySchedules.length > 2 && (
                        <span className="text-[9px] leading-tight text-[var(--semi-text-color)] pl-1">+{daySchedules.length - 2}</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* 선택 날짜 일정 목록 */}
            {selectedDate && selectedDate.startsWith(monthPrefix) && (
              <div className="mx-4 mt-3 mb-2 rounded-2xl bg-[var(--surface)] border border-[var(--border-color)] shadow-sm overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-[var(--border-color)]">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-sm text-[var(--general-text-color)]">
                      {selectedDate.slice(5).replace("-", "월 ")}일
                    </span>
                    {selectedDate === todayStr && <span className="text-xs font-medium text-[var(--brand-blue)] bg-brand-blue/10 px-2 py-0.5 rounded-full">{tl("schedToday")}</span>}
                    {getHolidayName(selectedDate) && <span className="text-xs text-red-400 font-medium">{getHolidayName(selectedDate)}</span>}
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button onClick={() => openForm(selectedDate)} className="text-xs font-semibold text-[var(--brand-blue)] px-2 py-1 rounded-lg hover:bg-brand-blue/10 transition-colors">+ {tl("schedAdd")}</button>
                    <button onClick={() => setSelectedDate(null)} className="w-6 h-6 flex items-center justify-center rounded-full text-[var(--semi-text-color)] hover:bg-[var(--surface-alt)] transition-colors text-xs">✕</button>
                  </div>
                </div>
                <div className="px-4 py-3 flex flex-col gap-2">
                  {selectedDateSchedules.length === 0 ? (
                    <div className="py-3 text-center text-sm text-[var(--semi-text-color)]">{tl("scheduleNoEvents")}</div>
                  ) : (
                    selectedDateSchedules.map((s) => {
                      const parseLocalTime = (str) => new Date(String(str).replace("Z", "").replace(" ", "T"));
                      const start = parseLocalTime(s.start_time);
                      const end = parseLocalTime(s.end_time);
                      const isAllDay = s.is_all_day === "Y";
                      const typeLabel = s.schedule_type
                        ? getScheduleTypes().find((t) => t.value === s.schedule_type)?.label
                        : null;
                      const timeLabel = isAllDay
                        ? (typeLabel ? `종일 · ${typeLabel}` : "종일")
                        : (typeLabel ? `${pad2(start.getHours())}:${pad2(start.getMinutes())} – ${pad2(end.getHours())}:${pad2(end.getMinutes())} · ${typeLabel}` : `${pad2(start.getHours())}:${pad2(start.getMinutes())} – ${pad2(end.getHours())}:${pad2(end.getMinutes())}`);
                      const isOwner = s.user_id === loginUserId;
                      return (
                        <div key={s.schedule_id} className="flex items-stretch gap-2 rounded-xl bg-[var(--surface-alt)] border border-[var(--border-color)] overflow-hidden">
                          <button onClick={() => openEditForm(s, !isOwner)}
                            className="flex items-stretch gap-2 flex-1 min-w-0 p-3 text-left hover:bg-[var(--surface)] transition-colors cursor-pointer">
                            <div className="w-1 rounded-full shrink-0" style={{ backgroundColor: s.color || "#3b82f6" }} />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-[var(--general-text-color)] truncate">{s.title}</p>
                              <p className="text-xs text-[var(--semi-text-color)] mt-0.5">{timeLabel}</p>
                              {s.repeat_type && (
                                <p className="text-xs text-[var(--brand-blue)] mt-0.5">
                                  ↻ {s.repeat_type === "daily" ? "매일" : s.repeat_type === "weekly" ? "매주" : s.repeat_type === "monthly" ? "매월" : `매년${s.repeat_lunar ? "(음력)" : ""}`}
                                  {s.repeat_until ? ` · ~${String(s.repeat_until).slice(0, 10)}` : " · 무기한"}
                                </p>
                              )}
                              {s.description && <p className="text-xs text-[var(--semi-text-color)] mt-1 truncate">{s.description}</p>}
                            </div>
                          </button>
                          {isOwner && (
                            <button onClick={() => deleteSchedule(s)} className="shrink-0 self-stretch px-3 text-[var(--semi-text-color)] hover:text-[var(--danger)] hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors">
                              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                              </svg>
                            </button>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}
          </div>
        );
      })}

      {/* 하단 sentinel — 이 요소가 뷰포트에 가까워지면 미래 월 추가 */}
      <div ref={bottomSentinelRef} style={{ height: 1 }} />

      {/* 줌 뷰어 portal */}
      {selectedDate && zoomPos && !showForm && typeof document !== "undefined" && createPortal(
        <div className="fixed z-[9960] bg-[var(--surface)] border border-[var(--brand-blue)] rounded-xl shadow-lg overflow-hidden"
          style={{ top: zoomPos.top, left: zoomPos.left, width: 115 }}>
          <div className="px-2 py-1.5 flex flex-col gap-1 max-h-[180px] overflow-y-auto">
            {selectedDateSchedules.length === 0 ? (
              <p className="text-[10px] text-[var(--semi-text-color)] py-1 text-center">{tl("scheduleNoEvents")}</p>
            ) : (
              selectedDateSchedules.map((s) => {
                const parseLocalTime = (str) => new Date(String(str).replace("Z", "").replace(" ", "T"));
                const start = parseLocalTime(s.start_time);
                const end = parseLocalTime(s.end_time);
                const timeLabel = s.is_all_day === "Y" ? "종일"
                  : `${pad2(start.getHours())}:${pad2(start.getMinutes())}–${pad2(end.getHours())}:${pad2(end.getMinutes())}`;
                return (
                  <div key={s.schedule_id} className="flex items-start gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full mt-[3px] shrink-0" style={{ backgroundColor: s.color || "#3b82f6" }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-medium text-[var(--general-text-color)] break-words leading-snug">{s.title}</p>
                      <p className="text-[9px] text-[var(--semi-text-color)]">{timeLabel}</p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>,
        document.body
      )}

      {/* 반복 일정 삭제 선택 다이얼로그 */}
      {repeatDeleteTarget && typeof document !== "undefined" && createPortal(
        <div className="fixed inset-0 z-[9990] flex items-end sm:items-center justify-center bg-black/50"
          onClick={() => handleRepeatDelete(null)}>
          <div className="w-full max-w-sm rounded-t-2xl sm:rounded-2xl bg-[var(--surface)] shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}>
            <div className="px-5 pt-5 pb-2">
              <p className="font-semibold text-[var(--general-text-color)] text-center mb-1">{tl("schedDeleteRecurring")}</p>
              <p className="text-xs text-[var(--semi-text-color)] text-center">
                {String(repeatDeleteTarget.start_time).slice(0, 10)} · {repeatDeleteTarget.title}
              </p>
            </div>
            <div className="flex flex-col gap-2 px-5 pb-5 pt-3">
              <button onClick={() => handleRepeatDelete("this")}
                className="w-full rounded-xl border border-[var(--border-color)] py-3 text-sm font-medium text-[var(--general-text-color)] hover:bg-[var(--surface-alt)] transition-colors">
                {tl("scheduleDeleteThisOnly")}
              </button>
              <button onClick={() => handleRepeatDelete("all")}
                className="w-full rounded-xl bg-red-500 py-3 text-sm font-medium text-white hover:bg-red-600 transition-colors">
                {tl("scheduleDeleteAll")}
              </button>
              <button onClick={() => handleRepeatDelete(null)}
                className="w-full rounded-xl border border-[var(--border-color)] py-2.5 text-sm text-[var(--semi-text-color)] hover:bg-[var(--surface-alt)] transition-colors">
                {tl("scheduleCancel")}
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* 일정 등록/수정 모달 portal */}
      {showForm && form && typeof document !== "undefined" && createPortal(
        <div className="fixed inset-0 z-[9980] flex items-end sm:items-center justify-center bg-black/50">
          <div className="w-full max-w-md rounded-t-2xl sm:rounded-2xl bg-[var(--surface)] shadow-2xl max-h-[90vh] flex flex-col">
            <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-3 border-b border-[var(--border-color)] bg-[var(--surface)] shrink-0">
              <span className="font-semibold text-[var(--general-text-color)]">{formReadOnly ? tl("scheduleReadOnly") : form.editingId ? tl("scheduleEdit") : tl("scheduleAdd")}</span>
              <button onClick={() => setShowForm(false)} className="text-[var(--semi-text-color)] text-xl leading-none">✕</button>
            </div>
            <div className="px-4 py-3 flex flex-col gap-2.5 overflow-y-auto flex-1">
              <fieldset disabled={formReadOnly} style={{ display: "contents" }}>
              <input
                className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-2 text-sm text-[var(--general-text-color)] placeholder:text-[var(--semi-text-color)] outline-none focus:border-[var(--brand-blue)]"
                placeholder={tl("scheduleFieldTitle")} value={form.title}
                onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
              <textarea
                className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-1.5 text-sm text-[var(--general-text-color)] placeholder:text-[var(--semi-text-color)] outline-none focus:border-[var(--brand-blue)] resize-none"
                placeholder={tl("scheduleFieldMemo")} rows={1} value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
              {/* 종일 + 일정 유형 한 줄 */}
              <div className="grid grid-cols-2 gap-2.5 items-center">
                <label className="flex items-center gap-2 cursor-pointer">
                  <div onClick={() => !formReadOnly && setForm((f) => ({ ...f, isAllDay: !f.isAllDay }))}
                    className={`relative w-10 h-5 rounded-full transition-colors shrink-0 ${form.isAllDay ? "bg-[var(--brand-blue)]" : "bg-[var(--surface-alt)] border border-[var(--border-color)]"}`}>
                    <div className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${form.isAllDay ? "translate-x-5" : ""}`} />
                  </div>
                  <span className="text-sm text-[var(--general-text-color)]">{tl("scheduleAllDay")}</span>
                </label>
                <select className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-2 py-1.5 text-sm text-[var(--general-text-color)] outline-none"
                  value={form.scheduleType ?? ""}
                  onChange={(e) => setForm((f) => ({ ...f, scheduleType: e.target.value || null }))}>
                  <option value="">{tl("schedTypeOptional")}</option>
                  {getScheduleTypes().map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
              {form.isAllDay ? (
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-xs text-[var(--semi-text-color)] mb-0.5 block">{tl("schedStartDate")}</label>
                    <input type="date" className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-1.5 text-sm text-[var(--general-text-color)] outline-none"
                      value={form.startTime.split("T")[0]} onChange={(e) => setForm((f) => ({ ...f, startTime: e.target.value + "T00:00" }))} />
                  </div>
                  <div>
                    <label className="text-xs text-[var(--semi-text-color)] mb-0.5 block">{tl("schedEndDate")}</label>
                    <input type="date" className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-1.5 text-sm text-[var(--general-text-color)] outline-none"
                      value={form.endTime.split("T")[0]} onChange={(e) => setForm((f) => ({ ...f, endTime: e.target.value + "T23:59" }))} />
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-xs text-[var(--semi-text-color)] mb-0.5 block">{tl("schedStart")}</label>
                    <input type="datetime-local" step={600} className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-1.5 text-sm text-[var(--general-text-color)] outline-none"
                      value={form.startTime} onChange={(e) => setForm((f) => ({ ...f, startTime: e.target.value }))} />
                  </div>
                  <div>
                    <label className="text-xs text-[var(--semi-text-color)] mb-0.5 block">{tl("schedEnd")}</label>
                    <input type="datetime-local" step={600} className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-1.5 text-sm text-[var(--general-text-color)] outline-none"
                      value={form.endTime} onChange={(e) => setForm((f) => ({ ...f, endTime: e.target.value }))} />
                  </div>
                </div>
              )}
              {/* 색상 + 미리 알림 한 줄 */}
              <div className="flex items-center gap-3">
                <div className="flex gap-1.5 flex-wrap flex-1">
                  {COLORS.map((c) => (
                    <button key={c} onClick={() => setForm((f) => ({ ...f, color: c }))}
                      className={`w-6 h-6 rounded-full border-2 transition-transform ${form.color === c ? "border-[var(--general-text-color)] scale-110" : "border-transparent"}`}
                      style={{ backgroundColor: c }} />
                  ))}
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-0.5">
                  <label className="text-xs text-[var(--semi-text-color)]">{tl("scheduleReminder")}</label>
                  {form.reminderMinutes != null && (
                    <button
                      type="button"
                      onClick={async () => {
                        if (form.scheduleType === "birthday") {
                          try {
                            const ctx = new (window.AudioContext || window.webkitAudioContext)();
                            const notes = [
                              [261.6,0.28],[261.6,0.14],[293.7,0.42],[261.6,0.42],[349.2,0.42],[329.6,0.84],
                              [261.6,0.28],[261.6,0.14],[293.7,0.42],[261.6,0.42],[392.0,0.42],[349.2,0.84],
                              [261.6,0.28],[261.6,0.14],[523.3,0.42],[440.0,0.42],[349.2,0.42],[329.6,0.42],[293.7,0.84],
                              [466.2,0.28],[466.2,0.14],[440.0,0.42],[349.2,0.42],[392.0,0.42],[349.2,1.1],
                            ];
                            let t = ctx.currentTime + 0.05;
                            for (const [freq, dur] of notes) {
                              const o = ctx.createOscillator(); const g = ctx.createGain();
                              o.type = "sine"; o.frequency.setValueAtTime(freq, t);
                              g.gain.setValueAtTime(0.28, t); g.gain.setValueAtTime(0.28, t + dur * 0.75); g.gain.linearRampToValueAtTime(0, t + dur);
                              o.connect(g); g.connect(ctx.destination); o.start(t); o.stop(t + dur);
                              t += dur + 0.02;
                            }
                          } catch (err) { openOkModal?.(`소리를 재생할 수 없습니다.\n(${err.message})`, "error"); }
                          return;
                        }
                        const soundId = (typeof localStorage !== "undefined" && localStorage.getItem("pushNotificationSound")) || "default";
                        if (soundId === "silent") { await openOkModal?.("무음으로 설정되어 있습니다.\n설정 화면에서 알림음을 변경하세요.", "info"); return; }
                        const SOUND_MAP = {
                          brunner_chime: "/sounds/push-brunner-chime.wav",
                          cafe_bell: "/sounds/push-cafe-bell.wav",
                          soft_pop: "/sounds/push-soft-pop.wav",
                        };
                        const src = SOUND_MAP[soundId] || SOUND_MAP["brunner_chime"];
                        const audio = new Audio(src);
                        audio.volume = 0.7;
                        audio.play().catch((err) => {
                          openOkModal?.(`소리를 재생할 수 없습니다.\n(${err.message})`, "error");
                        });
                      }}
                      className="flex items-center gap-1 text-xs text-[var(--brand-blue)] hover:opacity-70 transition-opacity"
                    >
                      {form.scheduleType === "birthday" ? "🎂" : "🔔"} {tl("previewSound")}
                    </button>
                  )}
                </div>
                <select className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-1.5 text-sm text-[var(--general-text-color)] outline-none"
                  value={form.reminderMinutes ?? ""}
                  onChange={(e) => setForm((f) => ({ ...f, reminderMinutes: e.target.value === "" ? null : Number(e.target.value) }))}>
                  {getReminderOptions().map((o) => <option key={String(o.value)} value={o.value ?? ""}>{o.label}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-[var(--semi-text-color)] mb-0.5 block">↻ {tl("scheduleRepeat")}</label>
                <select className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-1.5 text-sm text-[var(--general-text-color)] outline-none"
                  value={form.repeatType ?? ""}
                  onChange={(e) => setForm((f) => ({ ...f, repeatType: e.target.value || null, repeatUntil: "" }))}>
                  <option value="">{tl("scheduleRepeatNone")}</option>
                  <option value="daily">{tl("scheduleRepeatDaily")}</option>
                  <option value="weekly">{tl("scheduleRepeatWeekly")}</option>
                  <option value="monthly">{tl("scheduleRepeatMonthly")}</option>
                  <option value="yearly">{tl("scheduleRepeatYearly")}</option>
                </select>
                {form.repeatType === "yearly" && (() => {
                  const [y, m, d] = form.startTime.split("T")[0].split("-").map(Number);
                  let lunarStr = "";
                  try { const l = Solar.fromYmd(y, m, d).getLunar(); lunarStr = `음력 ${l.getMonth()}월 ${l.getDay()}일`; } catch {}
                  return (
                    <label className="flex items-center gap-2 mt-1.5 cursor-pointer select-none">
                      <input type="checkbox" checked={!!form.repeatLunar}
                        onChange={(e) => setForm((f) => ({ ...f, repeatLunar: e.target.checked }))}
                        className="w-4 h-4 rounded accent-[var(--brand-blue)]" />
                      <span className="text-sm text-[var(--general-text-color)]">{tl("scheduleRepeatLunar")}</span>
                      {form.repeatLunar && lunarStr && (
                        <span className="text-xs text-[var(--brand-blue)] ml-1">({lunarStr} 기준)</span>
                      )}
                    </label>
                  );
                })()}
                {form.repeatType && (
                  <div className="mt-1.5 grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-xs text-[var(--semi-text-color)] mb-0.5 block">{tl("schedRepeatStartDate")}</label>
                      <div className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-1.5 text-sm text-[var(--semi-text-color)]">
                        {form.startTime.split("T")[0]}
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-[var(--semi-text-color)] mb-0.5 block">{tl("schedRepeatEndDate")} <span className="text-amber-500">{tl("schedNoEndHint")}</span></label>
                      <input type="date" className="w-full rounded-xl border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-1.5 text-sm text-[var(--general-text-color)] outline-none"
                        value={form.repeatUntil}
                        min={form.startTime.split("T")[0]}
                        onChange={(e) => setForm((f) => ({ ...f, repeatUntil: e.target.value }))} />
                    </div>
                  </div>
                )}
              </div>
              <div>
                <label className="text-xs text-[var(--semi-text-color)] mb-1 block">{tl("scheduleParticipants")}</label>
                <div className="flex flex-wrap gap-2 items-center">
                  {form.participantIds.map((uid) => {
                    const f = friends.find((fr) => (fr.friend_id || fr.user_id) === uid);
                    return (
                      <span key={uid} className="flex items-center gap-1 rounded-full bg-brand-blue/10 border border-brand-blue/30 px-3 py-1 text-xs text-[var(--brand-blue)]">
                        {f?.user_name || uid}
                        <button onClick={() => setForm((frm) => ({ ...frm, participantIds: frm.participantIds.filter((id) => id !== uid) }))}
                          className="ml-0.5 text-[var(--brand-blue)] hover:text-[var(--danger)] leading-none">✕</button>
                      </span>
                    );
                  })}
                  {friends.length > 0 && (
                    <div className="relative">
                      <button onClick={() => { setShowParticipantPicker((v) => !v); setParticipantKeyword(""); }}
                        className="flex items-center gap-1 rounded-full border border-dashed border-[var(--border-color)] px-3 py-1 text-xs text-[var(--semi-text-color)] hover:border-[var(--brand-blue)] hover:text-[var(--brand-blue)]">
                        + 추가
                      </button>
                      {showParticipantPicker && (
                        <div className="absolute left-0 bottom-full mb-1 z-50 w-52 rounded-xl border border-[var(--border-color)] bg-[var(--surface)] shadow-xl overflow-hidden">
                          <input autoFocus placeholder={tl("scheduleSearchParticipant")} value={participantKeyword}
                            onChange={(e) => setParticipantKeyword(e.target.value)}
                            className="w-full px-3 py-2 text-xs border-b border-[var(--border-color)] bg-[var(--surface-alt)] text-[var(--general-text-color)] outline-none" />
                          <div className="max-h-40 overflow-y-auto">
                            {friends
                              .filter((f) => {
                                const uid = f.friend_id || f.user_id;
                                const name = f.user_name || uid;
                                return !form.participantIds.includes(uid) && name.toLowerCase().includes(participantKeyword.toLowerCase());
                              })
                              .map((f) => {
                                const uid = f.friend_id || f.user_id;
                                return (
                                  <button key={uid} onClick={() => { setForm((frm) => ({ ...frm, participantIds: [...frm.participantIds, uid] })); setShowParticipantPicker(false); }}
                                    className="w-full text-left px-3 py-2 text-xs text-[var(--general-text-color)] hover:bg-[var(--surface-alt)]">
                                    {f.user_name || uid}
                                  </button>
                                );
                              })}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
              </fieldset>
            </div>
            <div className="shrink-0 flex gap-2.5 px-4 border-t border-[var(--border-color)] bg-[var(--surface)]" style={{ paddingTop: "0.75rem", paddingBottom: "max(0.75rem, env(safe-area-inset-bottom, 0.75rem))" }}>
              <button onClick={() => setShowForm(false)}
                className="flex-1 rounded-xl border border-[var(--border-color)] py-2 text-sm font-medium text-[var(--semi-text-color)]">
                {formReadOnly ? tl("scheduleClose") : tl("scheduleCancel")}
              </button>
              {!formReadOnly && (
                <button onClick={saveForm}
                  className="flex-1 rounded-xl bg-[var(--brand-blue)] py-2 text-sm font-medium text-white">
                  {tl("scheduleSave")}
                </button>
              )}
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
