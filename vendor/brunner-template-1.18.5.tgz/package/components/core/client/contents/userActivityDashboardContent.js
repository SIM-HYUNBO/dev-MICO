"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";
import Card from "@/components/core/client/ui/Card";
import Chip from "@/components/core/client/ui/Chip";
import Button from "@/components/core/client/ui/Button";

import { registerInAppBack } from "@/components/core/client/frames/backNavigationButton";
const ACTIVITY_TYPE_LABEL_KEYS = {
  account: "userActivityFeatureAccount",
  admin: "userActivityFeatureAdmin",
  ai_meeting: "userActivityFeatureAiMeeting",
  ai_studio: "userActivityFeatureAiStudio",
  android_tester: "userActivityFeatureAndroidTester",
  board: "userActivityFeatureBoard",
  chat: "userActivityFeatureChat",
  complaint: "userActivityFeatureComplaint",
  document: "userActivityFeatureDocument",
  friend: "userActivityFeatureFriend",
  game: "userActivityFeatureGame",
  schedule: "userActivityFeatureSchedule",
  stock: "userActivityFeatureStock",
  unknown: "userActivityFeatureUnknown",
};

// 명령 접두사 → 기능 분류 (서버 userActivity.js ACTIVITY_LABEL_BY_PREFIX와 동기화)
const CMD_PREFIX_TO_TYPE = {
  chatroom: "chat",
  openchat: "chat",
  friend: "friend",
  schedule: "schedule",
  stockMarket: "stock",
  meetingRoom: "ai_meeting",
  edocDocument: "document",
  edocCustom: "document",
  edocComponentTemplate: "document",
  postInfo: "board",
  postCommentInfo: "board",
  aiContent: "ai_studio",
  game: "game",
  complaint: "complaint",
  dynamicSql: "admin",
  txnHistory: "admin",
  userActivity: "admin",
  security: "account",
  androidTester: "android_tester",
};

const formatNumber = (value) => Number(value || 0).toLocaleString();

// 회원 정보에 없는 ID(로그인 시도 등) — is_registered=false 이며 guest/system 특수계정은 제외
const isUnknownUser = (u) =>
  u && u.is_registered === false && u.user_id !== "guest" && u.user_id !== "system";

const UnknownBadge = ({ languageCode }) => (
  <span
    title={tl("userActivityUnregisteredHint", languageCode)}
    className="ml-1.5 inline-block whitespace-nowrap rounded-full border border-[var(--border-strong)] bg-[var(--surface-alt)] px-1.5 py-0.5 text-[10px] font-medium text-[var(--text-muted)] align-middle"
  >
    {tl("userActivityUnregistered", languageCode)}
  </span>
);

const formatDateTime = (value) => {
  if (!value) return "-";
  // TIMESTAMP WITHOUT TIME ZONE로 저장된 UTC 값 — Z suffix 붙여 UTC로 파싱
  const str = String(value).endsWith("Z") || /[+-]\d{2}:?\d{2}$/.test(String(value)) ? value : `${value}Z`;
  const date = new Date(str);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString();
};

const tl = (key, languageCode) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    languageCode,
  );

export default function UserActivityDashboardContent({ variant = "full" }) {
  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [userListModal, setUserListModal] = useState(null); // { label, days, users } | null
  const [userListLoading, setUserListLoading] = useState(false);
  const [detail, setDetail] = useState(null); // { title, note, rows } | null
  // 상세 패널은 URL이 바뀌지 않으므로, 열려 있는 동안 뒤로가기를 '닫기'로 처리한다.
  useEffect(() => {
    if (!detail) return undefined;
    const prevVal = detail;
    return registerInAppBack(
      () => { setDetail(null); return true; },
      () => { setDetail(prevVal); }, // 앞으로가기 → 다시 열기
    );
  }, [detail]);
  const usersRef = useRef(null); // 30일 사용자·기능 목록 캐시

  useEffect(() => {
    setCurrentSystemCode(userInfo.getCurrentSystemCode());
    setCurrentLoginUserId(userInfo.getLoginUserId());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  useEffect(() => {
    if (!currentSystemCode || !currentLoginUserId) return;

    const fetchDashboard = async () => {
      setLoading(true);
      setErrorMessage("");

      const response = await RequestServer({
        commandName: constants.commands.USER_ACTIVITY_DASHBOARD,
                userId: currentLoginUserId,
        languageCode: currentLanguageCode,
      });

      setLoading(false);

      if (response.error_code !== constants.errorCode.Success) {
        setErrorMessage(response.error_message || "Failed to load dashboard.");
        return;
      }

      setDashboard(response.data || {});
    };

    fetchDashboard();
  }, [currentSystemCode, currentLoginUserId, currentLanguageCode]);
  const dailyActive = useMemo(
    () => Array.isArray(dashboard?.daily_active) ? dashboard.daily_active : [],
    [dashboard],
  );
  const activityByType = useMemo(
    () => Array.isArray(dashboard?.activity_by_type) ? dashboard.activity_by_type : [],
    [dashboard],
  );
  const recentUsers = useMemo(
    () => Array.isArray(dashboard?.recent_users) ? dashboard.recent_users : [],
    [dashboard],
  );
  const topCommands = useMemo(
    () => Array.isArray(dashboard?.top_commands) ? dashboard.top_commands : [],
    [dashboard],
  );
  const maxDailyActive = Math.max(
    1,
    ...dailyActive.map((row) => Number(row.active_users || 0)),
  );

  const metrics = [
    ["userActivityMetricDau", dashboard?.dau, 0],
    ["userActivityMetricWau", dashboard?.wau, 6],
    ["userActivityMetricMau", dashboard?.mau, 29],
    ["userActivityMetricTodayHits", dashboard?.today_hits, null],
  ];

  const openUserList = async (labelKey, days) => {
    setUserListModal({ label: tl(labelKey, currentLanguageCode), days, users: null });
    setUserListLoading(true);
    const response = await RequestServer({
      commandName: constants.commands.USER_ACTIVITY_USER_LIST,
            userId: currentLoginUserId,
      languageCode: currentLanguageCode,
      days,
    });
    setUserListLoading(false);
    if (response.error_code === constants.errorCode.Success) {
      setUserListModal((prev) => prev ? { ...prev, users: response.users || [] } : null);
    } else {
      setUserListModal((prev) => prev ? { ...prev, users: [] } : null);
    }
  };

  // ── 카드 클릭 상세 ──
  const featLabel = (t) => tl(ACTIVITY_TYPE_LABEL_KEYS[t] || "userActivityFeatureUnknown", currentLanguageCode);
  const getUsers = async () => {
    if (usersRef.current) return usersRef.current;
    const res = await RequestServer({
      commandName: constants.commands.USER_ACTIVITY_USER_LIST,
      userId: currentLoginUserId, languageCode: currentLanguageCode, days: 30,
    });
    const users = res.error_code === constants.errorCode.Success ? (res.users || []) : [];
    usersRef.current = users;
    return users;
  };
  const openFeatureDetail = async (row) => {
    setDetail({ title: featLabel(row.activity_type), note: `${tl("userActivityActiveUsers", currentLanguageCode)} ${formatNumber(row.active_users)} · ${tl("userActivityHits", currentLanguageCode)} ${formatNumber(row.hits)}`, rows: null });
    const users = await getUsers();
    const rows = users
      .map((u) => { const f = (u.features || []).find((x) => x.activity_type === row.activity_type); return f ? { name: u.user_name || u.user_id, value: Number(f.hits || 0), sub: formatDateTime(u.last_seen_at) } : null; })
      .filter(Boolean).sort((a, b) => b.value - a.value);
    setDetail((p) => (p ? { ...p, rows } : null));
  };
  const openUserDetail = async (row) => {
    setDetail({ title: row.user_name || row.user_id, note: `${tl("userActivityActiveDays", currentLanguageCode)} ${formatNumber(row.active_days)} · ${tl("userActivityHits", currentLanguageCode)} ${formatNumber(row.hits)} · ${formatDateTime(row.last_seen_at)}`, rows: null });
    const users = await getUsers();
    const u = users.find((x) => x.user_id === row.user_id);
    const rows = (u?.features || []).map((f) => ({ name: featLabel(f.activity_type), value: Number(f.hits || 0) })).sort((a, b) => b.value - a.value);
    setDetail((p) => (p ? { ...p, rows } : null));
  };
  const openCommandDetail = async (row) => {
    const type = CMD_PREFIX_TO_TYPE[String(row.command_name).split(".")[0]] || "unknown";
    setDetail({ title: row.command_name, note: `${featLabel(type)} · ${tl("userActivityActiveUsers", currentLanguageCode)} ${formatNumber(row.active_users)} · ${tl("userActivityHits", currentLanguageCode)} ${formatNumber(row.hits)}`, rows: null });
    const users = await getUsers();
    const rows = users
      .map((u) => { const f = (u.features || []).find((x) => x.activity_type === type); return f ? { name: u.user_name || u.user_id, value: Number(f.hits || 0), sub: formatDateTime(u.last_seen_at) } : null; })
      .filter(Boolean).sort((a, b) => b.value - a.value);
    setDetail((p) => (p ? { ...p, rows } : null));
  };

  const shellClass =
    variant === "summary"
      ? "w-full"
      : "min-h-[calc(100dvh-4rem)] bg-[var(--bg)] px-4 py-5 text-[var(--text)]";
  const innerClass = variant === "summary" ? "w-full" : "mx-auto max-w-7xl";

  return (
    <div className={shellClass}>
      <div className={innerClass}>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <Chip tone="danger">{tl("adminMenuSection", currentLanguageCode)}</Chip>
            <h1 className="mt-2 text-2xl font-extrabold">
              {tl("userActivityDashboard", currentLanguageCode)}
            </h1>
            {variant === "full" && (
              <p className="mt-2 max-w-3xl text-sm text-[var(--text-muted)]">
                {tl("userActivityDashboardDefinition", currentLanguageCode)}
              </p>
            )}
          </div>
          {variant === "summary" && (
            <Link href="/mainPages/userActivityDashboard">
              <Button>{tl("userActivityDetailLink", currentLanguageCode)}</Button>
            </Link>
          )}
        </div>

        {errorMessage && (
          <div className="mt-4 rounded-[var(--radius-md)] border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/60 dark:bg-red-950/40 dark:text-red-200">
            {errorMessage}
          </div>
        )}

        <div className="mt-4 grid grid-cols-4 gap-2 sm:gap-3">
          {metrics.map(([labelKey, value, days]) => (
            <Card key={labelKey} className="p-3 sm:p-4">
              <div className="text-[11px] font-semibold leading-tight text-[var(--text-muted)] sm:text-xs">
                {tl(labelKey, currentLanguageCode)}
              </div>
              {days !== null ? (
                <button
                  onClick={() => openUserList(labelKey, days)}
                  className="font-mono-data mt-1.5 text-xl font-extrabold text-[var(--brand-blue)] hover:underline sm:mt-2 sm:text-2xl"
                >
                  {loading ? "-" : formatNumber(value)}
                </button>
              ) : (
                <div className="font-mono-data mt-1.5 text-xl font-extrabold sm:mt-2 sm:text-2xl">
                  {loading ? "-" : formatNumber(value)}
                </div>
              )}
            </Card>
          ))}
        </div>

        {userListModal && (
          <div
            className="fixed inset-0 z-[60] flex items-center justify-center p-4"
            style={{ background: "rgba(0,0,0,0.45)" }}
            onClick={() => setUserListModal(null)}
          >
            <div
              className="w-full max-w-lg max-h-[85dvh] overflow-y-auto rounded-2xl bg-[var(--surface)] p-5 shadow-xl"
              style={{ paddingBottom: "max(1.25rem, env(safe-area-inset-bottom))" }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-base font-extrabold">{userListModal.label} — 사용자별 기능 사용</h2>
                <button onClick={() => setUserListModal(null)} className="text-[var(--text-muted)] hover:text-[var(--text)] text-xl leading-none">✕</button>
              </div>
              {userListLoading && <div className="text-sm text-[var(--text-muted)]">{tl("loadingInProgress", currentLanguageCode)}</div>}
              {!userListLoading && userListModal.users?.length === 0 && (
                <div className="text-sm text-[var(--text-muted)]">{tl("userActivityNoData", currentLanguageCode)}</div>
              )}
              {!userListLoading && userListModal.users?.map((user) => (
                <div key={user.user_id} className="mb-3 rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface-alt)] p-3">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="min-w-0 truncate font-semibold text-sm">{user.user_name || user.user_id}{user.user_name ? <span className="ml-1.5 text-[11px] font-normal text-[var(--text-muted)]">{user.user_id}</span> : null}{isUnknownUser(user) ? <UnknownBadge languageCode={currentLanguageCode} /> : null}</span>
                    <span className="shrink-0 text-xs text-[var(--text-muted)]">{formatDateTime(user.last_seen_at)}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {(user.features || []).map((f) => (
                      <span key={f.activity_type} className="rounded-full px-2 py-0.5 text-[11px] font-medium bg-[var(--surface)] border border-[var(--border)]">
                        {tl(ACTIVITY_TYPE_LABEL_KEYS[f.activity_type] || "userActivityFeatureUnknown", currentLanguageCode)} {formatNumber(f.hits)}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {detail && (
          <div
            className="fixed inset-0 z-[60] flex items-center justify-center p-4"
            style={{ background: "rgba(0,0,0,0.45)" }}
            onClick={() => setDetail(null)}
          >
            <div
              className="w-full max-w-lg max-h-[85dvh] overflow-y-auto rounded-2xl bg-[var(--surface)] p-5 shadow-xl"
              style={{ paddingBottom: "max(1.25rem, env(safe-area-inset-bottom))" }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="min-w-0">
                  <h2 className="truncate text-base font-extrabold">{detail.title}</h2>
                  {detail.note && (
                    <p className="mt-1 text-xs text-[var(--text-muted)]">{detail.note}</p>
                  )}
                </div>
                <button onClick={() => setDetail(null)} className="shrink-0 text-[var(--text-muted)] hover:text-[var(--text)] text-xl leading-none">✕</button>
              </div>
              {detail.rows === null ? (
                <div className="text-sm text-[var(--text-muted)]">{tl("loadingInProgress", currentLanguageCode)}</div>
              ) : detail.rows.length === 0 ? (
                <div className="text-sm text-[var(--text-muted)]">{tl("userActivityNoData", currentLanguageCode)}</div>
              ) : (
                <DetailBars rows={detail.rows} />
              )}
            </div>
          </div>
        )}

        {variant === "full" && (
          <>
            <div className="mt-4 grid gap-4 lg:grid-cols-[1.4fr_1fr]">
              <Card className="p-5">
                <h2 className="text-base font-extrabold">
                  {tl("userActivityDailyTrend", currentLanguageCode)}
                </h2>
                {dailyActive.length === 0 ? (
                  <EmptyState languageCode={currentLanguageCode} />
                ) : (
                  <div className="mt-4 flex h-48 items-end gap-1">
                    {dailyActive.map((row) => {
                      const activeUsers = Number(row.active_users || 0);
                      const height = Math.max(4, (activeUsers / maxDailyActive) * 100);
                      return (
                        <div
                          key={row.activity_date}
                          className="flex min-w-0 flex-1 flex-col items-center gap-2"
                          title={`${row.activity_date}: ${activeUsers}`}
                        >
                          <div className="flex h-36 w-full items-end rounded-sm bg-[var(--surface-alt)]">
                            <div
                              className="w-full rounded-sm bg-emerald-500"
                              style={{ height: `${height}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </Card>

              <Card className="p-5">
                <h2 className="text-base font-extrabold">
                  {tl("userActivityByFeature", currentLanguageCode)}
                </h2>
                <MetricList
                  rows={activityByType}
                  nameKey="activity_type"
                  nameFormatter={(name) =>
                    tl(ACTIVITY_TYPE_LABEL_KEYS[name] || "userActivityFeatureUnknown", currentLanguageCode)
                  }
                  currentLanguageCode={currentLanguageCode}
                  onRowClick={openFeatureDetail}
                />
              </Card>
            </div>

            <div className="mt-4 grid gap-4 lg:grid-cols-2">
              <Card className="p-5">
                <h2 className="text-base font-extrabold">
                  {tl("userActivityRecentUsers", currentLanguageCode)}
                </h2>
                <RecentUsers rows={recentUsers} currentLanguageCode={currentLanguageCode} onRowClick={openUserDetail} />
              </Card>

              <Card className="p-5">
                <h2 className="text-base font-extrabold">
                  {tl("userActivityTopCommands", currentLanguageCode)}
                </h2>
                <MetricList
                  rows={topCommands}
                  nameKey="command_name"
                  currentLanguageCode={currentLanguageCode}
                  onRowClick={openCommandDetail}
                />
              </Card>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function EmptyState({ languageCode }) {
  return (
    <div className="mt-4 rounded-[var(--radius-md)] bg-[var(--surface-alt)] p-4 text-sm text-[var(--text-muted)]">
      {tl("userActivityNoData", languageCode)}
    </div>
  );
}

// 지불 의향 지표 — "언제 실제 결제모듈을 붙일지" 판단하는 선행 지표 패널.
// 핵심 신호는 소진율과 소진 후 재방문(=지불 의향). 신호들을 목표치 대비 가중합산해 수익화 준비도 %로 요약한다.
function MetricList({ rows, nameKey, nameFormatter = (name) => name, currentLanguageCode, onRowClick }) {
  if (!rows.length) return <EmptyState languageCode={currentLanguageCode} />;

  const clickable = typeof onRowClick === "function";
  return (
    <div className="mt-4 space-y-3">
      {rows.map((row) => {
        const body = (
          <>
            <div className="flex items-center justify-between gap-3">
              <div className="truncate text-sm font-semibold">{nameFormatter(row[nameKey])}</div>
              <div className="font-mono-data text-sm">{formatNumber(row.hits)}</div>
            </div>
            <div className="mt-1 text-xs text-[var(--text-muted)]">
              {tl("userActivityActiveUsers", currentLanguageCode)} {formatNumber(row.active_users)}
              {" | "}
              {tl("userActivityHits", currentLanguageCode)} {formatNumber(row.hits)}
            </div>
          </>
        );
        if (clickable) {
          return (
            <button
              key={row[nameKey]}
              type="button"
              onClick={() => onRowClick(row)}
              className="w-full rounded-[var(--radius-md)] bg-[var(--surface-alt)] p-3 text-left transition hover:bg-[var(--surface)] hover:ring-1 hover:ring-[var(--brand-blue)]"
            >
              {body}
            </button>
          );
        }
        return (
          <div key={row[nameKey]} className="rounded-[var(--radius-md)] bg-[var(--surface-alt)] p-3">
            {body}
          </div>
        );
      })}
    </div>
  );
}

function RecentUsers({ rows, currentLanguageCode, onRowClick }) {
  if (!rows.length) return <EmptyState languageCode={currentLanguageCode} />;

  const clickable = typeof onRowClick === "function";
  return (
    <div className="mt-4 overflow-x-auto rounded-[var(--radius-md)] border border-[var(--border)]">
      <table className="w-full min-w-[560px] table-fixed text-left text-sm">
        <colgroup>
          <col className="w-[180px]" />
          <col className="w-[160px]" />
          <col className="w-[100px]" />
          <col className="w-[100px]" />
        </colgroup>
        <thead className="bg-[var(--surface-alt)] text-xs text-[var(--text-muted)]">
          <tr>
            <th className="whitespace-nowrap px-3 py-2">{tl("userActivityUser", currentLanguageCode)}</th>
            <th className="whitespace-nowrap px-3 py-2">{tl("userActivityLastSeen", currentLanguageCode)}</th>
            <th className="whitespace-nowrap px-3 py-2">{tl("userActivityActiveDays", currentLanguageCode)}</th>
            <th className="whitespace-nowrap px-3 py-2">{tl("userActivityHits", currentLanguageCode)}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr
              key={row.user_id}
              className={`border-t border-[var(--border)] ${clickable ? "cursor-pointer transition hover:bg-[var(--surface-alt)]" : ""}`}
              onClick={clickable ? () => onRowClick(row) : undefined}
            >
              <td className="px-3 py-2 font-semibold">
                <div className="min-w-0">
                  <div className="flex min-w-0 items-center gap-1.5">
                    <span className="min-w-0 truncate">{row.user_name || row.user_id}</span>
                    {isUnknownUser(row) ? <UnknownBadge languageCode={currentLanguageCode} /> : null}
                  </div>
                  {row.user_name ? <div className="truncate text-[11px] font-normal text-[var(--text-muted)]">{row.user_id}</div> : null}
                </div>
              </td>
              <td className="whitespace-nowrap px-3 py-2 text-xs text-[var(--text-muted)]">
                {formatDateTime(row.last_seen_at)}
              </td>
              <td className="whitespace-nowrap px-3 py-2 font-mono-data">{formatNumber(row.active_days)}</td>
              <td className="whitespace-nowrap px-3 py-2 font-mono-data">{formatNumber(row.hits)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function DetailBars({ rows }) {
  const max = Math.max(1, ...rows.map((r) => Number(r.value || 0)));
  return (
    <div className="space-y-2">
      {rows.map((r) => (
        <div key={r.name} className="rounded-[var(--radius-md)] bg-[var(--surface-alt)] p-2.5">
          <div className="flex items-center justify-between gap-3">
            <span className="truncate text-sm font-semibold">{r.name}</span>
            <span className="font-mono-data text-sm shrink-0">{formatNumber(r.value)}</span>
          </div>
          <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-[var(--surface)]">
            <div
              className="h-full rounded-full bg-[var(--brand-blue)]"
              style={{ width: `${Math.max(4, (Number(r.value || 0) / max) * 100)}%` }}
            />
          </div>
          {r.sub && <div className="mt-1 text-[11px] text-[var(--text-muted)]">{r.sub}</div>}
        </div>
      ))}
    </div>
  );
}
