import { useState, useRef, useEffect } from "react";
import { useDeviceType } from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import PdfViewer from "@/components/core/client/pdfViewer";
import Button from "@/components/core/client/ui/Button";
import Card from "@/components/core/client/ui/Card";
import Chip from "@/components/core/client/ui/Chip";
import PageContainer from "@/components/core/client/ui/PageContainer";

export default function UserManualContent() {
  const { isMobile, isTablet } = useDeviceType();
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  const tl = (key) => commonFunctions.getResourceByLanguage(key, constants.resourceType.label, currentLanguageCode);

  return (
    <PageContainer className="bg-[var(--bg)] pb-16 text-[var(--text)]">
      <div className="flex flex-col gap-3 py-4 md:flex-row md:items-center md:justify-between">
        <div>
          <Chip tone="brand">PDF</Chip>
          <h2 className="page-title">{tl("brunnerUserManual")}</h2>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={() => window.open("/BrunnerUserManual.pdf", "_blank")}>{tl("download")}</Button>
          <Button onClick={() => window.location.href = "/"}>{tl("TAB_CHAT")}</Button>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-[240px_minmax(0,1fr)]">
        <Card className="hidden h-fit p-4 md:block">
          {["Intro", "Chat", "Friends", "Stocks", "Docs", "Settings"].map((item, index) => (
            <a
              key={item}
              href="#manual"
              className={`block rounded-[var(--radius-md)] px-3 py-2 text-sm font-semibold ${index === 0 ? "bg-[image:var(--brand-gradient-soft)] text-[var(--brand-blue)]" : "text-[var(--text-muted)]"}`}
            >
              {item}
            </a>
          ))}
        </Card>
        <Card className="overflow-hidden p-0">
          <div id="manual" className="h-[calc(100dvh-12rem)] min-h-[620px] bg-white">
            <PdfViewer fileUrl="/BrunnerUserManual.pdf" />
          </div>
        </Card>
      </div>
      <div className="safe-area-bottom fixed inset-x-0 bottom-0 z-30 flex justify-center gap-2 border-t border-[var(--border)] bg-[var(--surface)] p-2 md:hidden">
        <Button variant="ghost" size="sm">‹</Button>
        <Chip tone="neutral">1 / PDF</Chip>
        <Button variant="ghost" size="sm">›</Button>
      </div>
    </PageContainer>
  );
}
