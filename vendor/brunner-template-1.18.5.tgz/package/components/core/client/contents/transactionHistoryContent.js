"use client";

import { useState, useRef, useEffect } from "react";
import { useDeviceType } from "@/lib/commonFunctions";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

import GoverningMessage from "@/components/core/client/governingMessage";
import { TransactionHistoryViewer } from "@/components/core/client/transactionHistoryViewer";

export default function TransactionHistoryContent() {
  const { isMobile, isTablet } = useDeviceType();
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  return (
    <>
      <div>
        <div className={`w-full items-start text-left text-sm`}>
          <h2 className="page-title">
            {" "}
            {commonFunctions.getResourceByLanguage(
              "transactionHistoryTitle",
              constants.resourceType.label,
              currentLanguageCode,
            )}
          </h2>
          <GoverningMessage
            governingMessage={`${commonFunctions.getResourceByLanguage(
              `GOVERNING_MESSAGE_TRANSACTION_HISTORY_CONTENT`,
              constants.resourceType.message,
              currentLanguageCode,
            )}`}
          />
          <div className={`flex justify-center mt-5`}>
            <TransactionHistoryViewer />
          </div>
        </div>
      </div>
    </>
  );
}
