"use client";

import { useState, useRef, useEffect } from "react";
import { useDeviceType } from "@/lib/commonFunctions";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useMounted } from "@/lib/hooks/useMounted";

import GoverningMessage from "@/components/core/client/governingMessage";
import ChatClient from "@/components/core/client/wsChatClient";

export default function ChatRoomContent({
  initialRoomId,
  initialRoomName,
  onLeaveRoom,
  roomTypeFilter,
}) {
  const { isMobile, isTablet } = useDeviceType();
  const mounted = useMounted();
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);

  useEffect(() => {
    if (mounted && typeof userInfo !== "undefined") {
      setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
    }
  }, [mounted]);

  if (!mounted) return null;

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="hidden w-full shrink-0 items-start text-left text-sm md:block">
        <h2 className="page-title">
          {commonFunctions.getResourceByLanguage(
            "brunnerCafe",
            constants.resourceType.label,
            currentLanguageCode,
          )}
        </h2>
      </div>
      <div className="flex-1 min-h-0 overflow-hidden">
        <ChatClient
          externalRoomId={initialRoomId}
          externalRoomName={initialRoomName}
          onLeaveRoom={onLeaveRoom}
          roomTypeFilter={roomTypeFilter}
        />
      </div>
    </div>
  );
}
