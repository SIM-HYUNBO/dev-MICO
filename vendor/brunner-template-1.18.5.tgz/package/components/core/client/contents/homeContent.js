"use client";

/**
 * 홈 화면 — 템플릿 기본형.
 *
 * 원본(brunner-next)의 홈은 게임·주식·AI 스튜디오 카드로 채워진 brunner 전용
 * 랜딩이었다. 템플릿에서는 그 자리를 비우고, 남아 있는 범용 기능으로 가는
 * 입구만 둔다. 파생 프로젝트는 이 파일을 자기 홈으로 갈아끼우면 된다.
 *
 * MENU 배열에 항목을 넣고 빼는 것만으로 카드가 늘고 준다.
 */

import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import Card from "@/components/core/client/ui/Card";
import Button from "@/components/core/client/ui/Button";
import MTabBar from "@/components/core/client/frames/mTabBar";
import CreditLedgerModal from "@/components/core/client/credit/CreditLedgerModal";
import ChargeModal from "@/components/core/client/credit/ChargeModal";
import { creditApi } from "@/components/core/client/credit/creditApi";
import { homeMenu } from "@/lib/menuManifest";

export default function HomeContent() {
  const router = useRouter();
  const [languageCode, setLanguageCode] = useState("ko-KR");
  const [userId, setUserId] = useState(null);
  const [balance, setBalance] = useState(null);
  const [ledgerOpen, setLedgerOpen] = useState(false);
  const [chargeOpen, setChargeOpen] = useState(false);

  const L = (key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.label, languageCode);

  // 로그인 정보는 클라이언트에서만 읽을 수 있어 마운트 후에 채운다.
  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode() || "ko-KR");
    setUserId(userInfo.getLoginUserId());
  }, []);

  useEffect(() => {
    if (!userId) return;
    (async () => {
      const r = await creditApi.balance();
      if (r?.error_code === 0) setBalance(r.balance);
    })();
  }, [userId]);

  return (
    <>
      <div className="mx-auto w-full max-w-3xl px-4 py-6">
        {/*
          홈 강조색이 실제로 보이는 자리.

          왜 이 패널이 있나
            설정의 "홈 강조색" 은 원래 로그인한 사람의 메뉴 카드 배경에만 6~14%
            알파로 깔렸다. 로그아웃 상태에는 카드 자체가 없고, 기본값(#111111)은
            알파가 6% 라 무엇을 골라도 화면이 그대로였다. 고르는 값이 어디에도
            안 보이면 설정이 고장 난 것으로 읽힌다. 로그인 여부와 상관없이 뜨는
            이 패널에 그 색을 그대로 칠한다.

          검은 겹칠을 왜 얹나
            고를 수 있는 색에는 금색처럼 밝은 것도 있다. 흰 글씨가 어느 색에서도
            읽히도록 어둡게 한 겹 깐다. 색은 그대로 보이고 글자만 살아난다.
        */}
        <section
          className="relative mb-6 overflow-hidden rounded-[var(--radius-lg)] p-6 text-white"
          style={{ background: "var(--home-accent-gradient, var(--brand-gradient))" }}
        >
          <div
            className="absolute inset-0"
            style={{ background: "linear-gradient(100deg, rgba(0,0,0,0.58), rgba(0,0,0,0.18))" }}
          />
          <div className="relative">
            <h1 className="text-xl font-extrabold sm:text-2xl">
              {userId
                ? L("homeHeroTitleUser").replace("{name}", userInfo.getLoginUserName?.() || userId)
                : L("homeHeroTitleGuest")}
            </h1>
            <p className="mt-1.5 text-sm leading-6 text-white/85">
              {userId ? L("homeHeroDescUser") : L("homeHeroDescGuest")}
            </p>
          </div>
        </section>

        {userId && balance !== null && (
          <Card className="mb-6 flex items-center justify-between p-4">
            <div>
              <div className="text-xs text-[var(--fg-3)]">{L("homeCreditLabel")}</div>
              <div className="text-lg font-bold text-[var(--general-text-color)]">
                {Number(balance).toLocaleString()}
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="soft" size="sm" onClick={() => setLedgerOpen(true)}>
                {L("homeCreditHistory")}
              </Button>
              <Button size="sm" onClick={() => setChargeOpen(true)}>
                {L("homeCreditCharge")}
              </Button>
            </div>
          </Card>
        )}

        {userId ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {homeMenu.map(({ key, href, icon }) => (
              <button
                key={href}
                type="button"
                onClick={() => router.push(href)}
                className="flex flex-col items-start gap-2 rounded-[var(--radius-md)] border border-[var(--border-1)] bg-[var(--bg-1)] p-4 text-left transition hover:opacity-90"
                style={{
                  background: "var(--home-accent-soft,var(--bg-1))",
                  borderColor: "var(--home-accent,var(--border-1))",
                }}
              >
                <span className="text-2xl">{icon}</span>
                <span className="text-sm font-semibold text-[var(--general-text-color)]">
                  {L(key)}
                </span>
              </button>
            ))}
          </div>
        ) : (
          <div className="flex gap-2">
            <Button onClick={() => router.push("/mainPages/signin")}>{L("homeSignin")}</Button>
            <Button variant="soft" onClick={() => router.push("/mainPages/signup")}>
              {L("homeSignup")}
            </Button>
          </div>
        )}

        <MTabBar />
      </div>

      {ledgerOpen && <CreditLedgerModal onClose={() => setLedgerOpen(false)} />}
      {chargeOpen && <ChargeModal onClose={() => setChargeOpen(false)} />}
    </>
  );
}
