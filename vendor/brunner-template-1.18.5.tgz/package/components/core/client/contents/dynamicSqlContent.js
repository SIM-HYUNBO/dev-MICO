import { useState, useRef, useEffect } from "react";
import { Input, Button, Table } from "antd";
import { useDeviceType } from "@/lib/commonFunctions";

import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

import DynamicSQL from "@/components/core/client/dynamicSQL";

export default function DynamicSqlContent() {
  const { isMobile, isTablet } = useDeviceType();
  const [mounted, setMounted] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);

  useEffect(() => {
    setMounted(true);
    setIsAdmin(userInfo.isAdminUser());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  if (!mounted) return null;

  return (
    <>
      <div className="w-full relative flex-col text-sm">
        {isAdmin && (
          <>
            <h2 className={`page-title`}>
              {commonFunctions.getResourceByLanguage(
                "dynamicSql",
                constants.resourceType.label,
                currentLanguageCode,
              )}
            </h2>
            <div className={`flex justify-center w-full`}>
              <DynamicSQL />
            </div>
          </>
        )}
      </div>
    </>
  );
}
