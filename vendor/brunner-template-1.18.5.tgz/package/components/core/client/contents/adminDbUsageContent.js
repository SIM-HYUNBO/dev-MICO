"use client";

import { useEffect, useMemo, useState } from "react";
import { ChevronDown, Database, Download, HardDrive, History, Play, RefreshCw, RotateCcw, Rows3, Save, ShieldCheck, Table2, X } from "lucide-react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";
import Card from "@/components/core/client/ui/Card";

const DEFAULT_RETENTION_KEY = "adminDbRetentionDefault";
const DEFAULT_RETENTION_VALUE = 10;
const DEFAULT_RETENTION_UNIT = "year";
const RETENTION_UNITS = [
  { value: "year", labelKey: "adminDbRetentionUnitYear", days: 365 },
  { value: "month", labelKey: "adminDbRetentionUnitMonth", days: 30 },
  { value: "week", labelKey: "adminDbRetentionUnitWeek", days: 7 },
  { value: "day", labelKey: "adminDbRetentionUnitDay", days: 1 },
];

const unitDays = (unit) => RETENTION_UNITS.find((u) => u.value === unit)?.days || 365;
const toRetentionDays = (value, unit) => Math.max(1, Math.round((Number(value) || 1) * unitDays(unit)));
const fromRetentionDays = (days) => {
  const n = Number(days || 0);
  if (n > 0) {
    const unit = RETENTION_UNITS.find((u) => n % u.days === 0) || RETENTION_UNITS[3];
    return { retentionValue: Math.max(1, Math.round(n / unit.days)), retentionUnit: unit.value };
  }
  return { retentionValue: DEFAULT_RETENTION_VALUE, retentionUnit: DEFAULT_RETENTION_UNIT };
};

const formatBytes = (n) => {
  const b = Number(n || 0);
  if (b < 1024) return `${b} B`;
  const kb = b / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  return `${(mb / 1024).toFixed(2)} GB`;
};

// 아주 작은 테이블이 "0%"로 뭉개지지 않게 한 자리까지 살린다.
const formatShare = (pct) => {
  const n = Number(pct) || 0;
  if (n <= 0) return "0%";
  if (n < 0.1) return "<0.1%";
  return `${n < 10 ? n.toFixed(1) : Math.round(n)}%`;
};

const formatRetention = (tl, days) => {
  const input = fromRetentionDays(days);
  const unit = RETENTION_UNITS.find((u) => u.value === input.retentionUnit);
  return `${input.retentionValue} ${tl(unit?.labelKey || "adminDbRetentionUnitDay")}`;
};

const toDateTime = (value) => {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleString();
};

const browserTimezoneOffset = () => -new Date().getTimezoneOffset();
const timezoneLabel = (offsetMinutes) => {
  const sign = offsetMinutes >= 0 ? "+" : "-";
  const abs = Math.abs(Number(offsetMinutes) || 0);
  return `UTC${sign}${String(Math.floor(abs / 60)).padStart(2, "0")}:${String(abs % 60).padStart(2, "0")}`;
};
const minutesOfDay = (hhmm) => {
  const [h, m] = String(hhmm || "03:30").split(":").map(Number);
  return (Number.isFinite(h) ? h : 3) * 60 + (Number.isFinite(m) ? m : 30);
};
const hhmmFromMinutes = (minutes) => {
  const normalized = ((Math.round(minutes) % 1440) + 1440) % 1440;
  return `${String(Math.floor(normalized / 60)).padStart(2, "0")}:${String(normalized % 60).padStart(2, "0")}`;
};
const scheduleTimeForBrowser = (runAt, savedOffset, browserOffset) =>
  hhmmFromMinutes(minutesOfDay(runAt) + (Number(browserOffset) - Number(savedOffset || 0)));

const StatTile = ({ icon, label, value }) => (
  <div className="flex items-center gap-3 rounded-[var(--radius-lg,12px)] border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-3">
    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[var(--brand-blue,#2563eb)]/10 text-[var(--brand-blue,#2563eb)]">
      {icon}
    </span>
    <span className="flex min-w-0 flex-col">
      <span className="truncate text-[11px] font-medium text-[var(--text-muted)]">{label}</span>
      <span className="truncate text-base font-extrabold text-[var(--text)]">{value}</span>
    </span>
  </div>
);

const CapacityGauge = ({ tl, dbSizeBytes, capacityBytes, alertPercent }) => {
  const hasCap = capacityBytes > 0;
  const pctRaw = hasCap ? (dbSizeBytes / capacityBytes) * 100 : 0;
  const pct = Math.min(100, Math.round(pctRaw));
  const danger = hasCap && pctRaw >= alertPercent;
  const warn = hasCap && !danger && pctRaw >= alertPercent * 0.75;
  const barColor = danger ? "var(--danger,#ef4444)" : warn ? "var(--warning,#f59e0b)" : "var(--brand-emerald,#059669)";
  const pctColor = danger ? "var(--danger,#ef4444)" : "var(--text)";

  return (
    <div className="mb-4 rounded-[var(--radius-lg,12px)] border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-4">
      <div className="mb-2 flex items-end justify-between gap-3">
        <div className="flex flex-col">
          <span className="text-[11px] font-medium text-[var(--text-muted)]">{tl("adminDbUsageVolumeTitle", "Volume usage")}</span>
          <span className="text-2xl font-extrabold" style={{ color: pctColor }}>
            {formatBytes(dbSizeBytes)}
            {hasCap && <span className="ml-1.5 text-sm font-bold text-[var(--text-muted)]">/ {formatBytes(capacityBytes)}</span>}
          </span>
        </div>
        {hasCap && <span className="text-3xl font-black tabular-nums" style={{ color: pctColor }}>{pct}%</span>}
      </div>
      {/* 볼륨 한도 대비 사용량 — 용량 미설정이어도 막대 자리는 항상 유지한다.
          이 화면에서 "남은 용량"을 뜻하는 막대는 이것 하나뿐이므로 사라지면 안 된다. */}
      <span className="relative block h-3 w-full overflow-hidden rounded-full bg-line/60">
        {hasCap && (
          <>
            <span className="block h-full rounded-full transition-all" style={{ width: `${Math.max(2, pct)}%`, background: barColor }} />
            {/* 경보 임계 눈금 */}
            <span
              className="absolute top-0 h-full w-0.5 bg-[var(--text)]/45"
              style={{ left: `${Math.min(100, alertPercent)}%` }}
            />
          </>
        )}
      </span>
      <div className="mt-1.5 flex flex-wrap items-center justify-between gap-x-3 gap-y-1 text-[11px] text-[var(--text-muted)]">
        {hasCap ? (
          <>
            <span>{tl("adminDbUsageVolumeAlert", "Alert at")} {alertPercent}%</span>
            {danger && <span className="font-bold text-[var(--danger,#ef4444)]">{tl("adminDbUsageVolumeOver", "Over threshold")}</span>}
          </>
        ) : (
          <span className="leading-relaxed">{tl("adminDbUsageVolumeUnset", "Set DB_CAPACITY_BYTES to show the usage rate.")}</span>
        )}
      </div>
    </div>
  );
};

// 이 화면은 정리 이력·테이블 목록·백업 이력이 세로로 이어져 스크롤이 길다.
// 각 패널을 접을 수 있게 하고, 접은 상태는 이 브라우저에만 기억한다.
const COLLAPSE_STORAGE_KEY = "brunner.adminDbUsage.collapsed";

const readCollapsed = () => {
  try {
    const raw = window.localStorage.getItem(COLLAPSE_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    // 사생활 보호 모드나 저장 차단 설정에서는 접근 자체가 예외를 던진다.
    return null;
  }
};

function PanelToggle({ collapsed, onToggle, label }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-expanded={!collapsed}
      title={label}
      className="ml-1 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text-muted)] transition hover:text-[var(--text)]"
    >
      <ChevronDown size={16} className={collapsed ? "-rotate-90 transition-transform" : "transition-transform"} />
    </button>
  );
}

export default function AdminDbUsageContent() {
  const [languageCode, setLanguageCode] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [ready, setReady] = useState(false);
  const [usage, setUsage] = useState(null);
  const [busy, setBusy] = useState(false);
  const [savingTable, setSavingTable] = useState("");
  const [runningTable, setRunningTable] = useState("");
  const [runSummary, setRunSummary] = useState("");
  const [loadError, setLoadError] = useState("");
  const [savingConfig, setSavingConfig] = useState(false);
  const [drafts, setDrafts] = useState({});
  const [defaultRetentionValue, setDefaultRetentionValue] = useState(DEFAULT_RETENTION_VALUE);
  const [defaultRetentionUnit, setDefaultRetentionUnit] = useState(DEFAULT_RETENTION_UNIT);
  const [retentionRunAt, setRetentionRunAt] = useState("03:30");
  const [retentionTimezoneOffset, setRetentionTimezoneOffset] = useState(540);
  const [sortKey, setSortKey] = useState("bytes");
  const [sortDir, setSortDir] = useState("desc");
  const [selectedTableName, setSelectedTableName] = useState("");
  // DB 백업 — 여부/주기/시각 설정, 이력, 지금 실행, 내려받기, 복원
  const [backupEnabled, setBackupEnabled] = useState(true);
  const [backupRunAt, setBackupRunAt] = useState("04:00");
  const [backupIntervalHours, setBackupIntervalHours] = useState(24);
  const [backupTimezoneOffset, setBackupTimezoneOffset] = useState(540);
  const [backupInfo, setBackupInfo] = useState(null);
  const [backupHistory, setBackupHistory] = useState([]);
  const [backupHistoryDays, setBackupHistoryDays] = useState(7);
  const [savingBackup, setSavingBackup] = useState(false);
  const [backupRunning, setBackupRunning] = useState(false);
  const [backupSummary, setBackupSummary] = useState("");
  const [restoreTarget, setRestoreTarget] = useState(null);
  const [restoreConfirm, setRestoreConfirm] = useState("");
  const [restoreBusy, setRestoreBusy] = useState(false);
  const [restoreNote, setRestoreNote] = useState("");
  // 목록이 길어 스크롤을 잡아먹는 세 패널만 접는다. 처음에는 접어 둔다.
  // 설정 패널은 한 줄짜리라 접을 이유가 없다.
  const [collapsed, setCollapsed] = useState({
    history: true,
    tables: true,
    backupHistory: true,
  });

  useEffect(() => {
    const saved = readCollapsed();
    if (saved) setCollapsed((prev) => ({ ...prev, ...saved }));
  }, []);

  const togglePanel = (key) =>
    setCollapsed((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      try {
        window.localStorage.setItem(COLLAPSE_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // 저장에 실패해도 접기 자체는 동작해야 한다.
      }
      return next;
    });

  const tl = (key, fallback = key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.label, languageCode) || fallback;

  // 추천 배지/사유는 서버가 라벨 키로 내려준다. label/reason 직접 값은 구버전 서버 응답 대비 fallback.
  const recommendationLabel = (rec) =>
    (rec?.labelKey ? tl(rec.labelKey, "") : "") || rec?.label || tl("adminDbPolicyLabelUnset");
  const recommendationReason = (rec) =>
    rec?.reason || (rec?.reasonKey ? tl(rec.reasonKey, "") : "") || "";

  const mergeDrafts = (tables, defaultValue = defaultRetentionValue, defaultUnit = defaultRetentionUnit) => {
    const defaultDays = toRetentionDays(defaultValue, defaultUnit);
    const next = {};
    tables.forEach((t) => {
      const p = t.retentionPolicy || {};
      const r = t.retentionRecommendation || {};
      const retentionInput = fromRetentionDays(p.retentionDays || defaultDays);
      next[t.table] = {
        enabled: Boolean(p.enabled),
        dateColumn: p.dateColumn || r.dateColumn || t.dateColumns?.[0] || "",
        retentionDays: p.retentionDays || defaultDays,
        ...retentionInput,
      };
    });
    setDrafts(next);
  };

  const load = async (defaultValue = defaultRetentionValue, defaultUnit = defaultRetentionUnit) => {
    setBusy(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.ADMIN_DB_USAGE,
                userId: userInfo.getLoginUserId(),
        languageCode: userInfo.getCurrentLanguageCode(),
      });
      if (res.error_code === constants.errorCode.Success) {
        setUsage(res.data || null);
        if (res.data?.retentionConfig) {
          const currentOffset = browserTimezoneOffset();
          setRetentionRunAt(scheduleTimeForBrowser(
            res.data.retentionConfig.runAt || "03:30",
            Number(res.data.retentionConfig.timezoneOffsetMinutes ?? currentOffset),
            currentOffset,
          ));
          setRetentionTimezoneOffset(currentOffset);
        }
        if (res.data?.backupConfig) {
          const cfg = res.data.backupConfig;
          const currentOffset = browserTimezoneOffset();
          setBackupEnabled(cfg.enabled !== false);
          setBackupRunAt(scheduleTimeForBrowser(
            cfg.runAt || "04:00",
            Number(cfg.timezoneOffsetMinutes ?? currentOffset),
            currentOffset,
          ));
          setBackupIntervalHours(Number(cfg.intervalHours) || 24);
          setBackupTimezoneOffset(currentOffset);
          setBackupInfo(cfg);
        }
        setBackupHistory(res.data?.backupHistory || []);
        setBackupHistoryDays(Number(res.data?.backupHistoryDays) || 7);
        mergeDrafts(res.data?.tables || [], defaultValue, defaultUnit);
        setLoadError("");
      } else {
        // 실패해도 화면이 "데이터 없음" 으로만 보이면 고장인지 권한 문제인지
        // 구분이 안 된다. 세션 만료·권한 없음 사유를 그대로 띄운다.
        setUsage(null);
        setLoadError(res.error_message || tl("adminDbLoadFailed"));
      }
    } catch (e) {
      setUsage(null);
      setLoadError(e?.message || tl("adminDbLoadFailed"));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode());
    setRetentionTimezoneOffset(browserTimezoneOffset());
    let defaultValue = DEFAULT_RETENTION_VALUE;
    let defaultUnit = DEFAULT_RETENTION_UNIT;
    try {
      const saved = JSON.parse(localStorage.getItem(DEFAULT_RETENTION_KEY) || "null");
      if (Number(saved?.value) > 0 && RETENTION_UNITS.some((u) => u.value === saved?.unit)) {
        defaultValue = Number(saved.value);
        defaultUnit = saved.unit;
        setDefaultRetentionValue(defaultValue);
        setDefaultRetentionUnit(defaultUnit);
      }
    } catch {}
    const admin = userInfo.isAdminUser();
    setIsAdmin(admin);
    setReady(true);
    if (admin) load(defaultValue, defaultUnit);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const patchDraft = (table, patch) =>
    setDrafts((prev) => ({ ...prev, [table]: { ...(prev[table] || {}), ...patch } }));

  const changeDefaultRetention = (value, unit = defaultRetentionUnit) => {
    const nextValue = Math.max(1, Math.min(10000, Number(value) || DEFAULT_RETENTION_VALUE));
    const nextUnit = RETENTION_UNITS.some((u) => u.value === unit) ? unit : DEFAULT_RETENTION_UNIT;
    const nextDays = toRetentionDays(nextValue, nextUnit);
    const retentionInput = fromRetentionDays(nextDays);
    setDefaultRetentionValue(nextValue);
    setDefaultRetentionUnit(nextUnit);
    localStorage.setItem(DEFAULT_RETENTION_KEY, JSON.stringify({ value: nextValue, unit: nextUnit }));
    // 기본값은 "정책이 아직 없는 테이블"에만 반영한다. 저장된 정책까지 덮으면
    // 그 행을 저장하는 순간 기존 보존기간이 조용히 바뀌어, 이 카드의 안내문
    // ("저장된 정책은 각 행을 저장하기 전까지 바뀌지 않아요")과 어긋난다.
    const savedTables = new Set(
      (usage?.tables || []).filter((t) => t.retentionPolicy?.retentionDays).map((t) => t.table),
    );
    setDrafts((prev) => {
      const next = {};
      for (const [table, draft] of Object.entries(prev)) {
        next[table] = savedTables.has(table)
          ? draft
          : { ...draft, retentionDays: nextDays, ...retentionInput };
      }
      return next;
    });
  };

  const toggleAutoRetention = (table, checked) => {
    const patch = { enabled: checked };
    if (checked && !table.retentionPolicy?.retentionDays) {
      const days = toRetentionDays(defaultRetentionValue, defaultRetentionUnit);
      patch.retentionDays = days;
      Object.assign(patch, fromRetentionDays(days));
    }
    patchDraft(table.table, patch);
  };

  const savePolicy = async (table) => {
    const draft = drafts[table.table] || {};
    const retentionDays = toRetentionDays(draft.retentionValue, draft.retentionUnit);
    if (!draft.dateColumn || !retentionDays) return;
    setSavingTable(table.table);
    try {
      const res = await RequestServer({
        commandName: constants.commands.ADMIN_DB_RETENTION_SAVE,
                userId: userInfo.getLoginUserId(),
        languageCode: userInfo.getCurrentLanguageCode(),
        tableName: table.table,
        dateColumn: draft.dateColumn,
        retentionDays,
        enabled: Boolean(draft.enabled),
      });
      if (res.error_code === constants.errorCode.Success) await load();
      else setRunSummary(res.error_message || tl("adminDbLoadFailed"));
    } finally {
      setSavingTable("");
    }
  };

  const runCleanup = async (table) => {
    setRunningTable(table.table);
    setRunSummary("");
    try {
      const res = await RequestServer({
        commandName: constants.commands.ADMIN_DB_RETENTION_RUN,
                userId: userInfo.getLoginUserId(),
        languageCode: userInfo.getCurrentLanguageCode(),
        tableName: table.table,
      });
      if (res.error_code === constants.errorCode.Success) {
        const deleted = Number(res.data?.totalDeleted || 0).toLocaleString();
        setRunSummary(tl("adminDbRunDeleted").replace("{table}", table.table).replace("{count}", deleted));
        await load();
      } else {
        setRunSummary(res.error_message || tl("adminDbLoadFailed"));
      }
    } finally {
      setRunningTable("");
    }
  };

  const saveRetentionConfig = async () => {
    setSavingConfig(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.ADMIN_DB_RETENTION_CONFIG_SAVE,
                userId: userInfo.getLoginUserId(),
        languageCode: userInfo.getCurrentLanguageCode(),
        runAt: retentionRunAt,
        timezoneOffsetMinutes: browserTimezoneOffset(),
      });
      if (res.error_code === constants.errorCode.Success) {
        setRetentionRunAt(res.data?.runAt || retentionRunAt);
        setRetentionTimezoneOffset(Number(res.data?.timezoneOffsetMinutes ?? browserTimezoneOffset()));
        setRunSummary(tl("adminDbRunScheduled").replace("{time}", res.data?.runAt || retentionRunAt));
        await load();
      } else {
        setRunSummary(res.error_message || tl("adminDbLoadFailed"));
      }
    } finally {
      setSavingConfig(false);
    }
  };

  const saveBackupConfig = async () => {
    setSavingBackup(true);
    setBackupSummary("");
    try {
      const res = await RequestServer({
        commandName: constants.commands.ADMIN_DB_BACKUP_CONFIG_SAVE,
        userId: userInfo.getLoginUserId(),
        languageCode: userInfo.getCurrentLanguageCode(),
        enabled: backupEnabled,
        runAt: backupRunAt,
        intervalHours: backupIntervalHours,
        timezoneOffsetMinutes: browserTimezoneOffset(),
      });
      if (res.error_code === constants.errorCode.Success) {
        setBackupSummary(
          res.data?.enabled === false
            ? tl("adminDbBackupSavedOff")
            : tl("adminDbBackupSaved").replace("{time}", res.data?.runAt || backupRunAt),
        );
        await load();
      } else {
        setBackupSummary(res.error_message || tl("adminDbBackupFailed"));
      }
    } finally {
      setSavingBackup(false);
    }
  };

  const runBackupNow = async () => {
    setBackupRunning(true);
    setBackupSummary("");
    try {
      const res = await RequestServer({
        commandName: constants.commands.ADMIN_DB_BACKUP_RUN,
        userId: userInfo.getLoginUserId(),
        languageCode: userInfo.getCurrentLanguageCode(),
      });
      if (res.error_code === constants.errorCode.Success) {
        setBackupSummary(
          tl("adminDbBackupDone")
            .replace("{size}", formatBytes(res.data?.sizeBytes))
            .replace("{rows}", Number(res.data?.rowCount || 0).toLocaleString()),
        );
        await load();
      } else {
        setBackupSummary(res.error_message || tl("adminDbBackupFailed"));
      }
    } finally {
      setBackupRunning(false);
    }
  };

  // 백업 파일은 테넌트 데이터 전부다. 공개 링크로 두지 않고 매번 짧게 유효한
  // 서명 URL 을 받아 새 탭으로 연다.
  const downloadBackup = async (entry) => {
    setBackupSummary("");
    const res = await RequestServer({
      commandName: constants.commands.ADMIN_DB_BACKUP_DOWNLOAD,
      userId: userInfo.getLoginUserId(),
      languageCode: userInfo.getCurrentLanguageCode(),
      objectKey: entry.objectKey,
    });
    if (res.error_code === constants.errorCode.Success && res.data?.url) {
      window.open(res.data.url, "_blank", "noopener,noreferrer");
    } else {
      setBackupSummary(res.error_message || tl("adminDbBackupFailed"));
    }
  };

  const callRestore = async (dryRun) => {
    if (!restoreTarget) return;
    setRestoreBusy(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.ADMIN_DB_BACKUP_RESTORE,
        userId: userInfo.getLoginUserId(),
        languageCode: userInfo.getCurrentLanguageCode(),
        objectKey: restoreTarget.objectKey,
        dryRun,
        confirm: dryRun ? "" : restoreConfirm,
      });
      if (res.error_code === constants.errorCode.Success) {
        const text = dryRun
          ? tl("adminDbBackupRestoreChecked")
              .replace("{tables}", Number(res.data?.tables || 0).toLocaleString())
              .replace("{inserts}", Number(res.data?.inserts || 0).toLocaleString())
          : tl("adminDbBackupRestoreDone")
              .replace("{tables}", Number(res.data?.tables || 0).toLocaleString())
              .replace("{inserts}", Number(res.data?.inserts || 0).toLocaleString());
        if (dryRun) {
          setRestoreNote(text);
        } else {
          setRestoreTarget(null);
          setRestoreConfirm("");
          setRestoreNote("");
          setBackupSummary(text);
          await load();
        }
      } else {
        setRestoreNote(res.error_message || tl("adminDbBackupFailed"));
      }
    } finally {
      setRestoreBusy(false);
    }
  };

  const toggleSort = (key) => {
    if (key === sortKey) setSortDir((d) => (d === "desc" ? "asc" : "desc"));
    else {
      setSortKey(key);
      setSortDir(key === "table" ? "asc" : "desc");
    }
  };

  const tables = usage?.tables || [];
  const totalBytes = useMemo(() => tables.reduce((a, t) => a + Number(t.bytes || 0), 0), [tables]);
  // 비중의 분모는 볼륨 사용량(pg_database_size)이다. 테이블 합계를 분모로 쓰면
  // 시스템 카탈로그·다른 스키마·미회수 공간이 빠져 실제보다 부풀려 보인다.
  const shareBase = Number(usage?.dbSizeBytes || 0) || totalBytes;
  const totalRows = useMemo(() => tables.reduce((a, t) => a + Number(t.rows || 0), 0), [tables]);
  const retentionHistory = usage?.retentionHistory || [];
  const retentionHistoryDays = Number(usage?.retentionHistoryDays || 7);

  const sortedTables = useMemo(() => {
    const list = [...tables];
    const dir = sortDir === "asc" ? 1 : -1;
    list.sort((a, b) => {
      if (sortKey === "table") return String(a.table).localeCompare(String(b.table)) * dir;
      const av = Number(sortKey === "rows" ? a.rows : a.bytes) || 0;
      const bv = Number(sortKey === "rows" ? b.rows : b.bytes) || 0;
      return (av - bv) * dir;
    });
    return list;
  }, [tables, sortKey, sortDir]);

  const selectedTable = useMemo(
    () => sortedTables.find((t) => t.table === selectedTableName) || null,
    [selectedTableName, sortedTables],
  );

  // 언어에 무관한 기호 — "down"/"up" 은 영어 그대로 노출됐다.
  const arrow = (key) => (sortKey === key ? (sortDir === "desc" ? "▼" : "▲") : "");
  const SortHead = ({ k, label, align = "left" }) => (
    <button
      type="button"
      onClick={() => toggleSort(k)}
      className={`flex items-center gap-1 text-[11px] font-bold uppercase transition ${
        align === "right" ? "ml-auto flex-row-reverse" : ""
      } ${sortKey === k ? "text-[var(--brand-blue,#2563eb)]" : "text-[var(--text-muted)] hover:text-[var(--text)]"}`}
    >
      <span>{label}</span>
      <span className="text-[9px]">{arrow(k)}</span>
    </button>
  );

  if (!ready) return null;

  if (!isAdmin) {
    return (
      <div className="mx-auto w-full max-w-4xl px-4 py-8">
        <Card className="p-6 text-center">
          <p className="text-sm font-semibold text-[var(--text)]">{tl("adminOnlyNoPermission", "Admin only")}</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--brand-blue,#2563eb)]/10 text-[var(--brand-blue,#2563eb)]">
            <Database size={22} />
          </span>
          <div className="flex flex-col">
            <h1 className="text-lg font-extrabold text-[var(--text)]">{tl("adminDbUsageTitle", "DB storage by table")}</h1>
            <span className="text-xs text-[var(--text-muted)]">
              {tl("adminDbUsageDesc", "Current size and row count per table.")}
            </span>
          </div>
        </div>
      </div>

      {usage && (
        <CapacityGauge
          tl={tl}
          dbSizeBytes={Number(usage.dbSizeBytes || usage.totalBytes || 0)}
          capacityBytes={Number(usage.capacityBytes || 0)}
          alertPercent={Number(usage.alertPercent || 80)}
        />
      )}

      <div className="mb-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <StatTile icon={<HardDrive size={18} />} label={tl("adminDbUsageStatSize", "Total size")} value={usage ? formatBytes(usage.totalBytes) : "-"} />
        <StatTile icon={<Rows3 size={18} />} label={tl("adminDbUsageStatRows", "Total rows")} value={usage ? totalRows.toLocaleString() : "-"} />
        <StatTile icon={<Table2 size={18} />} label={tl("adminDbUsageStatTables", "Tables")} value={usage ? tables.length.toLocaleString() : "-"} />
      </div>

      {runSummary && (
        <div className="mb-3 rounded-lg border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-2 text-sm font-semibold text-[var(--text)]">
          {runSummary}
        </div>
      )}

      <Card className="mb-4 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex min-w-0 flex-col">
            <span className="text-sm font-extrabold text-[var(--text)]">{tl("adminDbDefaultRetentionTitle")}</span>
            <span className="text-xs text-[var(--text-muted)]">
              {tl("adminDbDefaultRetentionDesc")}
              {" · "}
              {/* 목록은 전 시스템 합산인데 삭제는 자기 시스템만이라, 그 차이를 여기 밝힌다. */}
              {tl("adminDbRetentionScopeSelf", "Deletes only this system's rows")}
            </span>
          </div>
          <label className="flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
            <input
              type="number"
              min="1"
              max="10000"
              value={defaultRetentionValue}
              onChange={(e) => changeDefaultRetention(e.target.value)}
              className="w-24 rounded-md border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-right text-sm text-[var(--text)]"
            />
            <select
              value={defaultRetentionUnit}
              onChange={(e) => changeDefaultRetention(defaultRetentionValue, e.target.value)}
              className="rounded-md border border-[var(--border)] bg-[var(--surface)] px-2 py-2 text-sm text-[var(--text)]"
            >
              {RETENTION_UNITS.map((u) => <option key={u.value} value={u.value}>{tl(u.labelKey)}</option>)}
            </select>
          </label>
        </div>
      </Card>

      <Card className="mb-4 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex min-w-0 flex-col">
            <span className="text-sm font-extrabold text-[var(--text)]">{tl("adminDbScheduleTitle")}</span>
            <span className="text-xs text-[var(--text-muted)]">{tl("adminDbScheduleDesc")}</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <label className="flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
              <span className="text-xs text-[var(--text-muted)]">{tl("adminDbScheduleRunAt")}</span>
              <input
                type="time"
                value={retentionRunAt}
                onChange={(e) => setRetentionRunAt(e.target.value)}
                className="rounded-md border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--text)]"
              />
            </label>
            <span className="rounded-md border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-2 text-xs font-semibold text-[var(--text-muted)]">
              {tl("adminDbScheduleBrowser")} {timezoneLabel(retentionTimezoneOffset)}
            </span>
            <button
              type="button"
              onClick={saveRetentionConfig}
              disabled={savingConfig}
              className="inline-flex items-center gap-2 rounded-lg bg-[var(--brand-blue,#2563eb)] px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-50"
            >
              {savingConfig ? <RefreshCw size={15} className="animate-spin" /> : <Save size={15} />}
              {tl("adminDbSave")}
            </button>
          </div>
        </div>
      </Card>

      <Card className="mb-4 p-4">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div className="flex min-w-0 flex-col">
            <span className="text-sm font-extrabold text-[var(--text)]">{tl("adminDbHistoryTitle")}</span>
            <span className="text-xs font-semibold text-[var(--text-muted)]">
              {tl("adminDbHistoryCount")
                .replace("{days}", String(retentionHistoryDays))
                .replace("{count}", retentionHistory.length.toLocaleString())}
            </span>
          </div>
          <button
            type="button"
            onClick={() => load()}
            disabled={busy}
            className="inline-flex shrink-0 items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-xs font-bold text-[var(--text)] transition hover:bg-[var(--surface-alt)] disabled:opacity-50"
          >
            <RefreshCw size={14} className={busy ? "animate-spin" : ""} />
            {tl("adminDbRefresh")}
          </button>
          <PanelToggle collapsed={collapsed.history} onToggle={() => togglePanel("history")} label={tl("adminDbHistoryTitle")} />
        </div>
        {collapsed.history ? null : retentionHistory.length === 0 ? (
          <div className="rounded-md border border-dashed border-[var(--border)] bg-[var(--surface-alt)] px-3 py-4 text-sm text-[var(--text-muted)]">
            {tl("adminDbHistoryEmpty")}
          </div>
        ) : (
          <div className="grid max-h-[22rem] grid-cols-1 gap-2 overflow-y-auto lg:grid-cols-2">
            {/* 일주일치 전부 — 정책이 늘면 행이 많아지므로 카드 목록 안에서만 스크롤한다 */}
            {retentionHistory.map((h) => (
              <div key={h.runId || `${h.table}-${h.runStartedAt}`} className="min-w-0 rounded-md border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-2">
                <div className="flex min-w-0 items-center justify-between gap-3">
                  <span className="min-w-0 truncate font-mono text-xs font-bold text-[var(--text)]">{h.table}</span>
                  <span className="shrink-0 text-xs font-extrabold text-[var(--text)]">
                    {tl("adminDbHistoryRows").replace("{count}", Number(h.deletedCount || 0).toLocaleString())}
                  </span>
                </div>
                <div className="mt-1 flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-[var(--text-muted)]">
                  <span>{toDateTime(h.runStartedAt)}</span>
                  <span>{tl(h.triggerType === "manual" ? "adminDbTriggerManual" : "adminDbTriggerScheduled")}</span>
                  {h.limited && <span className="font-bold text-[var(--warning,#f59e0b)]">{tl("adminDbHistoryLimited")}</span>}
                  {h.errorMessage && <span className="min-w-0 truncate font-bold text-[var(--danger,#ef4444)]">{h.errorMessage}</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <div className="mb-3 flex flex-wrap items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-2">
        <span className="mr-1 text-[11px] font-bold uppercase text-[var(--text-muted)]">{tl("adminDbSort")}</span>
        <SortHead k="bytes" label={tl("adminDbUsageColSize", "Size")} />
        <SortHead k="rows" label={tl("adminDbUsageColRows", "Rows")} />
        <SortHead k="table" label={tl("adminDbUsageColTable", "Table")} />
      </div>

      {loadError ? (
        <Card className="px-4 py-8 text-center text-sm font-semibold text-[var(--danger,#ef4444)]">
          {loadError}
        </Card>
      ) : !usage ? (
        <Card className="px-4 py-10 text-center text-sm text-[var(--text-muted)]">
          {busy ? tl("adminDbUsageLoading", "Loading") : tl("adminDbUsageEmpty", "No data")}
        </Card>
      ) : tables.length === 0 ? (
        <Card className="px-4 py-10 text-center text-sm text-[var(--text-muted)]">{tl("adminDbUsageEmpty", "No data")}</Card>
      ) : (
        <>
          <div className="rounded-xl border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-3">
            <div className="mb-3 flex items-center justify-between gap-3 px-1">
              <div className="flex min-w-0 flex-col">
                <span className="text-sm font-extrabold text-[var(--text)]">{tl("adminDbTableListTitle")}</span>
                <span className="text-xs font-semibold text-[var(--text-muted)]">
                  {tl("adminDbTableListCount").replace("{count}", sortedTables.length.toLocaleString())}
                  {" · "}
                  {/* 스키마를 여러 시스템이 공유한다. 크기와 행수는 테이블 단위라 나눌 수 없다. */}
                  {tl("adminDbTableListScopeAll", "All systems combined")}
                </span>
              </div>
              <button
                type="button"
                onClick={() => load()}
                disabled={busy}
                className="inline-flex shrink-0 items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-xs font-bold text-[var(--text)] transition hover:bg-[var(--surface-alt)] disabled:opacity-50"
              >
                <RefreshCw size={14} className={busy ? "animate-spin" : ""} />
                {tl("adminDbRefresh")}
              </button>
              <PanelToggle collapsed={collapsed.tables} onToggle={() => togglePanel("tables")} label={tl("adminDbTableListTitle")} />
            </div>
            <div className={collapsed.tables ? "hidden" : "grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3"}>
              {sortedTables.map((t, i) => {
                // 막대는 전체 적재량 대비 실제 점유율이다. 예전엔 "가장 큰 테이블 대비"를
                // 로그 스케일로 그려서, 최대의 0.1%인 테이블도 막대가 3분의 2쯤 차 있었다.
                const bytes = Number(t.bytes || 0);
                const share = shareBase > 0 ? (bytes / shareBase) * 100 : 0;
                const top = i === 0 && sortKey === "bytes" && sortDir === "desc";
                const selected = selectedTableName === t.table;
                return (
                  <button
                    key={t.table}
                    type="button"
                    onClick={() => setSelectedTableName(t.table)}
                    className={`min-w-0 rounded-md border-l-4 border-y border-r bg-[var(--surface)] p-3 text-left transition hover:-translate-y-0.5 hover:shadow-sm ${
                      selected
                        ? "border-l-[var(--brand-blue,#2563eb)] border-y-[var(--brand-blue,#2563eb)]/40 border-r-[var(--brand-blue,#2563eb)]/40"
                        : "border-l-[var(--brand-emerald,#059669)] border-y-[var(--border)] border-r-[var(--border)]"
                    }`}
                  >
                    <div className="mb-2 flex min-w-0 items-start justify-between gap-3">
                      <span className="flex min-w-0 flex-col gap-0.5">
                        <span className="min-w-0 truncate font-mono text-[13px] font-bold text-[var(--text)]">{t.table}</span>
                        <span className="min-w-0 truncate text-xs text-[var(--text-muted)]">{t.description}</span>
                      </span>
                      <span className="flex shrink-0 flex-col items-end gap-0.5">
                        <span
                          className="rounded bg-[var(--surface-alt)] px-2 py-0.5 text-xs font-extrabold text-[var(--text)]"
                          title={tl("adminDbSizeHint")}
                        >
                          {t.size}
                        </span>
                        <span className="text-[11px] font-semibold tabular-nums text-[var(--text-muted)]" title={tl("adminDbShareOfTotal")}>
                          {formatShare(share)}
                        </span>
                      </span>
                    </div>
                    <span className="mb-2 block h-1.5 w-full overflow-hidden rounded-full bg-line/60" title={tl("adminDbShareOfTotal")}>
                      <span
                        className={`block h-full rounded-full ${top ? "bg-[var(--brand-emerald,#059669)]" : "bg-[var(--brand-emerald,#059669)]/55"}`}
                        // 볼륨 대비 비중은 0.x% 대가 흔하다. 폭은 실제 비율 그대로 두되
                        // 완전히 사라지지 않도록 최소 2px 만 보장한다.
                        style={{ width: `${share}%`, minWidth: bytes > 0 ? "2px" : 0 }}
                      />
                    </span>
                    <div className="mb-2 grid grid-cols-2 gap-2 text-xs">
                      <span className="text-[var(--text-muted)]">
                        {tl("adminDbUsageColRows")}{" "}
                        <b className="text-[var(--text)]" title={t.rowsExact ? undefined : tl("adminDbRowsApprox")}>
                          {t.rowsExact === false ? "~" : ""}
                          {Number(t.rows).toLocaleString()}
                        </b>
                      </span>
                      <span className="text-[var(--text-muted)]">
                        {tl("adminDbCardDates")} <b className="text-[var(--text)]">{Number(t.dateColumns?.length || 0).toLocaleString()}</b>
                      </span>
                    </div>
                    <div className="flex min-w-0 items-center gap-2 text-[11px]">
                      <span
                        className={`shrink-0 rounded px-1.5 py-0.5 font-bold ${
                          t.retentionRecommendation?.level === "recommended"
                            ? "bg-[var(--brand-blue,#2563eb)]/10 text-[var(--brand-blue,#2563eb)]"
                            : "bg-line/60 text-[var(--text-muted)]"
                        }`}
                      >
                        {recommendationLabel(t.retentionRecommendation)}
                      </span>
                      <span className="min-w-0 truncate text-[var(--text-muted)]">
                        {t.retentionRecommendation?.recommendedDays
                          ? `${formatRetention(tl, t.retentionRecommendation.recommendedDays)} · ${recommendationReason(t.retentionRecommendation)}`
                          : recommendationReason(t.retentionRecommendation)}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {selectedTable && (() => {
              const draft = drafts[selectedTable.table] || {};
              const disabled = !selectedTable.dateColumns?.length;
              return (
                <div
                  className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 px-4 py-6"
                  onClick={() => setSelectedTableName("")}
                >
                  <div className="w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
                    <Card className="max-h-[calc(100vh-48px)] w-full overflow-y-auto p-0 shadow-xl">
                      <div className="flex min-w-0 items-start justify-between gap-3 border-b border-[var(--border)] px-5 py-4">
                        <div className="flex min-w-0 flex-col gap-1">
                          <span className="text-[11px] font-bold uppercase text-[var(--text-muted)]">{tl("adminDbSelectedTable")}</span>
                          <span className="truncate font-mono text-sm font-extrabold text-[var(--text)]">{selectedTable.table}</span>
                          <span className="text-xs text-[var(--text-muted)]">{selectedTable.description}</span>
                          <span className="text-xs text-[var(--text-muted)]">
                            {tl("adminDbSizeRows")
                              .replace("{size}", selectedTable.size)
                              .replace("{rows}", Number(selectedTable.rows).toLocaleString())}
                          </span>
                        </div>
                        <button
                          type="button"
                          title={tl("adminDbClose")}
                          onClick={() => setSelectedTableName("")}
                          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] transition hover:bg-[var(--surface-alt)]"
                        >
                          <X size={16} />
                        </button>
                      </div>

                      <div className="flex flex-col gap-4 px-5 py-4">
                        <label className="inline-flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
                          <input
                            type="checkbox"
                            checked={Boolean(draft.enabled)}
                            disabled={disabled}
                            onChange={(e) => toggleAutoRetention(selectedTable, e.target.checked)}
                          />
                          {tl("adminDbAutoPurge")}
                        </label>

                      <label className="flex flex-col gap-1 text-xs font-semibold text-[var(--text-muted)]">
                        {tl("adminDbDateColumn")}
                        <select
                          className="min-w-0 rounded-md border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--text)] disabled:opacity-50"
                          value={draft.dateColumn || ""}
                          disabled={disabled}
                          onChange={(e) => patchDraft(selectedTable.table, { dateColumn: e.target.value })}
                        >
                          {disabled ? <option value="">{tl("adminDbNoDateColumn")}</option> : selectedTable.dateColumns.map((c) => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </label>

                      <div className="grid grid-cols-[minmax(0,1fr)_96px] gap-2">
                        <label className="flex flex-col gap-1 text-xs font-semibold text-[var(--text-muted)]">
                          {tl("adminDbRetentionField")}
                          <input
                            type="number"
                            min="1"
                            className="rounded-md border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-right text-sm text-[var(--text)] disabled:opacity-50"
                            value={draft.retentionValue || 1}
                            disabled={disabled}
                            onChange={(e) => {
                              const retentionValue = e.target.value;
                              patchDraft(selectedTable.table, {
                                retentionValue,
                                retentionDays: toRetentionDays(retentionValue, draft.retentionUnit),
                              });
                            }}
                          />
                        </label>
                        <label className="flex flex-col gap-1 text-xs font-semibold text-[var(--text-muted)]">
                          {tl("adminDbRetentionUnitField")}
                          <select
                            className="rounded-md border border-[var(--border)] bg-[var(--surface)] px-2 py-2 text-sm text-[var(--text)] disabled:opacity-50"
                            value={draft.retentionUnit || DEFAULT_RETENTION_UNIT}
                            disabled={disabled}
                            onChange={(e) => {
                              const retentionUnit = e.target.value;
                              patchDraft(selectedTable.table, {
                                retentionUnit,
                                retentionDays: toRetentionDays(draft.retentionValue, retentionUnit),
                              });
                            }}
                          >
                            {RETENTION_UNITS.map((u) => <option key={u.value} value={u.value}>{tl(u.labelKey)}</option>)}
                          </select>
                        </label>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          disabled={disabled || savingTable === selectedTable.table}
                          onClick={() => savePolicy(selectedTable)}
                          className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-[var(--brand-blue,#2563eb)] px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-50"
                        >
                          {savingTable === selectedTable.table ? <RefreshCw size={15} className="animate-spin" /> : <Save size={15} />}
                          {tl("adminDbSavePolicy")}
                        </button>
                        <button
                          type="button"
                          title={tl("adminDbRunCleanupNow")}
                          disabled={disabled || !selectedTable.retentionPolicy?.enabled || runningTable === selectedTable.table}
                          onClick={() => runCleanup(selectedTable)}
                          className="flex h-10 w-10 items-center justify-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] transition hover:bg-[var(--surface-alt)] disabled:opacity-50"
                        >
                          {runningTable === selectedTable.table ? <RefreshCw size={15} className="animate-spin" /> : <Play size={15} />}
                        </button>
                      </div>

                      {selectedTable.retentionPolicy && (
                        <div className="rounded-md bg-[var(--surface-alt)] px-3 py-2 text-xs leading-relaxed text-[var(--text-muted)]">
                          {tl("adminDbLastRun")
                            .replace("{time}", toDateTime(selectedTable.retentionPolicy.lastRunAt))
                            .replace("{count}", Number(selectedTable.retentionPolicy.lastDeletedCount || 0).toLocaleString())}
                          {selectedTable.retentionPolicy.lastError ? ` · ${selectedTable.retentionPolicy.lastError}` : ""}
                        </div>
                      )}
                      </div>
                    </Card>
                  </div>
                </div>
              );
            })()}
        </>
      )}

      {/* DB 백업 — 켤지 말지, 언제 돌지, 결과와 파일, 되돌리기까지 한자리에서. */}
      <Card className="mt-4 p-4">
        <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
          <div className="flex min-w-0 flex-col">
            <span className="flex items-center gap-2 text-sm font-extrabold text-[var(--text)]">
              <ShieldCheck size={15} className="text-[var(--brand-emerald,#059669)]" />
              {tl("adminDbBackupTitle")}
            </span>
            <span className="text-xs text-[var(--text-muted)]">{tl("adminDbBackupDesc")}</span>
          </div>
          <button
            type="button"
            onClick={runBackupNow}
            disabled={backupRunning || busy}
            className="inline-flex shrink-0 items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-xs font-bold text-[var(--text)] transition hover:bg-[var(--surface-alt)] disabled:opacity-50"
          >
            {backupRunning ? <RefreshCw size={14} className="animate-spin" /> : <Play size={14} />}
            {backupRunning ? tl("adminDbBackupRunning") : tl("adminDbBackupRunNow")}
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2 rounded-[var(--radius-lg,12px)] border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-3">
          <label className="inline-flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
            <input
              type="checkbox"
              checked={backupEnabled}
              onChange={(e) => setBackupEnabled(e.target.checked)}
              className="h-4 w-4 accent-[var(--brand-blue,#2563eb)]"
            />
            {tl("adminDbBackupEnabled")}
          </label>
          <label className="flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
            <span className="text-xs text-[var(--text-muted)]">{tl("adminDbBackupRunAt")}</span>
            <input
              type="time"
              value={backupRunAt}
              onChange={(e) => setBackupRunAt(e.target.value)}
              disabled={!backupEnabled}
              className="rounded-md border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--text)] disabled:opacity-50"
            />
          </label>
          <label className="flex items-center gap-2 text-sm font-semibold text-[var(--text)]">
            <span className="text-xs text-[var(--text-muted)]">{tl("adminDbBackupInterval")}</span>
            <select
              value={backupIntervalHours}
              onChange={(e) => setBackupIntervalHours(Number(e.target.value))}
              disabled={!backupEnabled}
              className="rounded-md border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--text)] disabled:opacity-50"
            >
              <option value={24}>{tl("adminDbBackupIntervalDaily")}</option>
              {[12, 8, 6, 4, 2, 1].map((h) => (
                <option key={h} value={h}>{tl("adminDbBackupIntervalHours").replace("{hours}", String(h))}</option>
              ))}
            </select>
          </label>
          <span className="rounded-md border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-xs font-semibold text-[var(--text-muted)]">
            {tl("adminDbScheduleBrowser")} {timezoneLabel(backupTimezoneOffset)}
          </span>
          <button
            type="button"
            onClick={saveBackupConfig}
            disabled={savingBackup}
            className="inline-flex items-center gap-2 rounded-lg bg-[var(--brand-blue,#2563eb)] px-4 py-2 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-50"
          >
            {savingBackup ? <RefreshCw size={15} className="animate-spin" /> : <Save size={15} />}
            {tl("adminDbSave")}
          </button>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-[var(--text-muted)]">
          {backupInfo?.nextRunAt && (
            <span>{tl("adminDbBackupNextRun")} · {toDateTime(backupInfo.nextRunAt)}</span>
          )}
          {backupInfo?.lastSuccessAt && (
            <span>{tl("adminDbBackupLastSuccess")} · {toDateTime(backupInfo.lastSuccessAt)}</span>
          )}
          {backupInfo?.state === "skipped" && backupInfo?.reason && (
            <span className="font-bold text-[var(--warning,#f59e0b)]">
              {tl("adminDbBackupStateSkipped").replace("{reason}", backupInfo.reason)}
            </span>
          )}
        </div>

        {backupSummary && (
          <div className="mt-3 rounded-md border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-2 text-sm font-semibold text-[var(--text)]">
            {backupSummary}
          </div>
        )}

        <div className="mt-4 mb-2 flex items-center justify-between gap-3">
          <span className="flex items-center gap-2 text-sm font-extrabold text-[var(--text)]">
            <History size={14} className="text-[var(--text-muted)]" />
            {tl("adminDbBackupHistoryTitle")}
          </span>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[var(--text-muted)]">
              {tl("adminDbHistoryCount")
                .replace("{days}", String(backupHistoryDays))
                .replace("{count}", backupHistory.length.toLocaleString())}
            </span>
            <PanelToggle collapsed={collapsed.backupHistory} onToggle={() => togglePanel("backupHistory")} label={tl("adminDbBackupHistoryTitle")} />
          </div>
        </div>

        {collapsed.backupHistory ? null : backupHistory.length === 0 ? (
          <div className="rounded-md border border-dashed border-[var(--border)] bg-[var(--surface-alt)] px-3 py-4 text-sm text-[var(--text-muted)]">
            {tl("adminDbBackupHistoryEmpty")}
          </div>
        ) : (
          <div className="grid max-h-[22rem] grid-cols-1 gap-2 overflow-y-auto lg:grid-cols-2">
            {backupHistory.map((h) => {
              const okResult = h.result === "OK";
              return (
                <div key={h.backupId} className="min-w-0 rounded-md border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-2">
                  <div className="flex min-w-0 items-center justify-between gap-3">
                    <span
                      className="shrink-0 rounded px-1.5 py-0.5 text-[11px] font-extrabold"
                      style={{
                        color: okResult ? "var(--brand-emerald,#059669)" : "var(--danger,#ef4444)",
                        background: okResult
                          ? "color-mix(in srgb, var(--brand-emerald,#059669) 12%, transparent)"
                          : "color-mix(in srgb, var(--danger,#ef4444) 12%, transparent)",
                      }}
                    >
                      {okResult ? tl("adminDbBackupResultOk") : tl("adminDbBackupResultFailed")}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-right text-xs font-bold tabular-nums text-[var(--text)]">
                      {okResult ? formatBytes(h.sizeBytes) : ""}
                    </span>
                  </div>
                  <div className="mt-1 flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-[var(--text-muted)]">
                    <span>{toDateTime(h.startedAt)}</span>
                    {h.method && <span>{h.method}</span>}
                    <span>{h.triggeredBy === "cron" ? tl("adminDbTriggerScheduled") : tl("adminDbTriggerManual")}</span>
                    {h.rowCount != null && <span className="tabular-nums">{tl("adminDbHistoryRows").replace("{count}", Number(h.rowCount).toLocaleString())}</span>}
                  </div>
                  {h.errorMessage && (
                    <div className="mt-1 min-w-0 break-words text-[11px] font-bold text-[var(--danger,#ef4444)]">{h.errorMessage}</div>
                  )}
                  {okResult && h.objectKey && (
                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => downloadBackup(h)}
                        className="inline-flex items-center gap-1.5 rounded-md border border-[var(--border)] bg-[var(--surface)] px-2.5 py-1.5 text-[11px] font-bold text-[var(--text)] transition hover:bg-[var(--surface-alt)]"
                      >
                        <Download size={12} />
                        {tl("adminDbBackupDownload")}
                      </button>
                      <button
                        type="button"
                        onClick={() => { setRestoreTarget(h); setRestoreConfirm(""); setRestoreNote(""); }}
                        className="inline-flex items-center gap-1.5 rounded-md border border-[var(--danger,#ef4444)] bg-[var(--surface)] px-2.5 py-1.5 text-[11px] font-bold text-[var(--danger,#ef4444)] transition hover:bg-[var(--surface-alt)]"
                      >
                        <RotateCcw size={12} />
                        {tl("adminDbBackupRestore")}
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* 복원은 되돌릴 수 없는 조작이다. 브라우저 기본 confirm 대신 파일 이름을
          직접 입력받아 잘못 눌러 데이터가 사라지는 일을 막는다. */}
      {restoreTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 px-4 py-6"
          onClick={() => { if (!restoreBusy) setRestoreTarget(null); }}
        >
          <div className="w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
            <Card className="max-h-[calc(100vh-48px)] w-full overflow-y-auto p-0 shadow-xl">
              <div className="flex items-start justify-between gap-3 border-b border-[var(--border)] px-5 py-4">
                <div className="flex min-w-0 flex-col gap-1">
                  <span className="text-sm font-extrabold text-[var(--text)]">{tl("adminDbBackupRestoreTitle")}</span>
                  <span className="truncate font-mono text-xs text-[var(--text-muted)]">{restoreTarget.objectKey}</span>
                  <span className="text-xs text-[var(--text-muted)]">{toDateTime(restoreTarget.startedAt)}</span>
                </div>
                <button
                  type="button"
                  title={tl("adminDbClose")}
                  onClick={() => setRestoreTarget(null)}
                  disabled={restoreBusy}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] transition hover:bg-[var(--surface-alt)] disabled:opacity-50"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="flex flex-col gap-3 px-5 py-4">
                <p className="text-sm font-semibold text-[var(--danger,#ef4444)]">{tl("adminDbBackupRestoreWarn")}</p>
                <label className="flex flex-col gap-1.5">
                  <span className="text-xs text-[var(--text-muted)]">{tl("adminDbBackupRestoreConfirmHint")}</span>
                  <input
                    type="text"
                    value={restoreConfirm}
                    onChange={(e) => setRestoreConfirm(e.target.value)}
                    placeholder={restoreTarget.objectKey}
                    className="w-full rounded-md border border-[var(--border)] bg-[var(--surface)] px-3 py-2 font-mono text-sm text-[var(--text)]"
                  />
                </label>
                {restoreNote && (
                  <div className="rounded-md border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-2 text-sm font-semibold text-[var(--text)]">
                    {restoreNote}
                  </div>
                )}
                <div className="flex flex-wrap items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setRestoreTarget(null)}
                    disabled={restoreBusy}
                    className="rounded-lg border border-[var(--border)] bg-[var(--surface)] px-4 py-2 text-sm font-bold text-[var(--text)] transition hover:bg-[var(--surface-alt)] disabled:opacity-50"
                  >
                    {tl("adminDbBackupCancel")}
                  </button>
                  <button
                    type="button"
                    onClick={() => callRestore(true)}
                    disabled={restoreBusy}
                    className="inline-flex items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--surface)] px-4 py-2 text-sm font-bold text-[var(--text)] transition hover:bg-[var(--surface-alt)] disabled:opacity-50"
                  >
                    {restoreBusy ? <RefreshCw size={14} className="animate-spin" /> : <ShieldCheck size={14} />}
                    {tl("adminDbBackupRestoreCheck")}
                  </button>
                  <button
                    type="button"
                    onClick={() => callRestore(false)}
                    disabled={restoreBusy || restoreConfirm !== restoreTarget.objectKey}
                    className="inline-flex items-center gap-2 rounded-lg bg-[var(--danger,#ef4444)] px-4 py-2 text-sm font-bold text-white transition hover:opacity-90 disabled:opacity-50"
                  >
                    <RotateCcw size={14} />
                    {tl("adminDbBackupRestore")}
                  </button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
