"use client";

import { useState, useEffect, useRef } from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import Loading from "@/components/core/client/loading";
import PageContainer from "@/components/core/client/ui/PageContainer";

const STATUS_CLS = {
  RECEIVED: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200",
  IN_PROGRESS: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  RESOLVED: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  APPROVED: "bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300",
};

const MAX_IMAGES = 3;

// 첨부 이미지는 base64 data URL로 저장 — 긴 변 1280px JPEG로 리사이즈해 용량 절약
const resizeImageToDataUrl = (file, maxW = 1280, maxH = 1280) =>
  new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      const scale = Math.min(maxW / img.width, maxH / img.height, 1);
      const w = Math.round(img.width * scale);
      const h = Math.round(img.height * scale);
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      canvas.getContext("2d").drawImage(img, 0, 0, w, h);
      resolve(canvas.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      resolve(null);
    };
    img.src = url;
  });

export default function ComplaintContent() {
  const [loading, setLoading] = useState(false);
  const [content, setContent] = useState("");
  const [images, setImages] = useState([]); // data URL 배열 (최대 3장)
  const [viewerImage, setViewerImage] = useState(null); // 클릭 확대 보기
  const fileInputRef = useRef(null);
  const [myRows, setMyRows] = useState([]);
  const [allRows, setAllRows] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [languageCode, setLanguageCode] = useState(null);
  const [highlightId, setHighlightId] = useState(null);
  const rowRefs = useRef({});
  const { BrunnerMessageBox, openOkCancelModal, openOkModal, openInputModal } =
    useModal();

  const tl = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.label,
      languageCode,
    );
  const tm = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.message,
      languageCode,
    );
  const statusLabel = (s) =>
    ({
      RECEIVED: tl("complaintStatusReceived"),
      IN_PROGRESS: tl("complaintStatusInProgress"),
      RESOLVED: tl("complaintStatusResolved"),
      APPROVED: tl("complaintStatusApproved"),
    })[s] || s;

  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode());
    setIsAdmin(userInfo.isAdminUser());
    const urlId = typeof window !== "undefined"
      ? parseInt(new URLSearchParams(window.location.search).get("id") || "0", 10) || null
      : null;
    if (urlId) setHighlightId(urlId);
    loadMyComplaints();
    if (userInfo.isAdminUser()) loadAllComplaints();
  }, []);

  // 데이터 로드 후 하이라이트 행으로 자동 스크롤
  useEffect(() => {
    if (!highlightId) return;
    const el = rowRefs.current[highlightId];
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      // 3초 후 하이라이트 해제
      const timer = setTimeout(() => setHighlightId(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [highlightId, myRows, allRows]);

  const loadMyComplaints = async () => {
    const res = await RequestServer({
      commandName: constants.commands.COMPLAINT_MY_LIST,
            userId: userInfo.getLoginUserId(),
    });
    if (res.error_code === constants.errorCode.Success) {
      setMyRows(res.data || []);
    }
  };

  const loadAllComplaints = async () => {
    const res = await RequestServer({
      commandName: constants.commands.COMPLAINT_ALL_LIST,
          });
    if (res.error_code === constants.errorCode.Success) {
      setAllRows(res.data || []);
    }
  };

  const refreshAll = () => {
    loadMyComplaints();
    if (userInfo.isAdminUser()) loadAllComplaints();
  };

  const handleAttachImages = async (e) => {
    const files = Array.from(e.target.files || []).filter((f) =>
      f.type.startsWith("image/"),
    );
    e.target.value = "";
    if (files.length === 0) return;

    const remain = MAX_IMAGES - images.length;
    const targets = files.slice(0, remain);
    const dataUrls = (
      await Promise.all(targets.map((f) => resizeImageToDataUrl(f)))
    ).filter(Boolean);
    if (dataUrls.length > 0) setImages((prev) => [...prev, ...dataUrls].slice(0, MAX_IMAGES));
  };

  const removeImage = (idx) =>
    setImages((prev) => prev.filter((_, i) => i !== idx));

  const parseImages = (row) => {
    try {
      const arr = JSON.parse(row.images || "[]");
      return Array.isArray(arr) ? arr : [];
    } catch {
      return [];
    }
  };

  const handleSubmit = async () => {
    if (!content.trim()) return;
    try {
      setLoading(true);
      const res = await RequestServer({
        commandName: constants.commands.COMPLAINT_REGISTER,
                languageCode,
        userId: userInfo.getLoginUserId(),
        userName: userInfo.getLoginUserName?.() || "",
        content: content.trim(),
        images,
      });
      setLoading(false);
      if (res.error_code === constants.errorCode.Success) {
        setContent("");
        setImages([]);
        await openOkModal(
          tm("COMPLAINT_REGISTERED"),
          constants.messageCategory.Info,
        );
        refreshAll();
      } else {
        await openOkModal(res.error_message, constants.messageCategory.Error);
      }
    } catch (e) {
      setLoading(false);
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  const handleApprove = async (row) => {
    const confirmed = await openOkCancelModal(
      tm("COMPLAINT_APPROVE_CONFIRM"),
      constants.messageCategory.Confirm,
    );
    if (!confirmed) return;
    const res = await RequestServer({
      commandName: constants.commands.COMPLAINT_APPROVE,
            languageCode,
      complaintId: row.complaint_id,
      userId: userInfo.getLoginUserId(),
    });
    if (res.error_code === constants.errorCode.Success) {
      refreshAll();
    } else {
      await openOkModal(res.error_message, constants.messageCategory.Error);
    }
  };

  const handleUpdateStatus = async (row, status) => {
    let resolution = null;
    if (status === "RESOLVED") {
      const confirmed = await openOkCancelModal(
        tm("COMPLAINT_RESOLVE_CONFIRM"),
        constants.messageCategory.Confirm,
      );
      if (!confirmed) return;
      resolution = await openInputModal(
        tl("complaintResolution"),
        row.resolution || "",
        tl("complaintResolution"),
      );
      if (resolution === null || resolution === false) return;
    }
    const res = await RequestServer({
      commandName: constants.commands.COMPLAINT_UPDATE_STATUS,
            languageCode,
      complaintId: row.complaint_id,
      status,
      resolution,
      resolvedBy: userInfo.getLoginUserId(),
    });
    if (res.error_code === constants.errorCode.Success) {
      refreshAll();
    } else {
      await openOkModal(res.error_message, constants.messageCategory.Error);
    }
  };

  const fmtTime = (t) => (t ? new Date(t).toLocaleString() : "-");

  const StatusChip = ({ status }) => (
    <span
      className={`px-2 py-0.5 rounded-full text-xs font-semibold whitespace-nowrap ${STATUS_CLS[status] || ""}`}
    >
      {statusLabel(status)}
    </span>
  );

  const AttachedImages = ({ row }) => {
    const imgs = parseImages(row);
    if (imgs.length === 0) return null;
    return (
      <div className="mt-2 flex flex-wrap gap-2">
        {imgs.map((img, idx) => (
          <img
            key={idx}
            src={img}
            alt={`attachment-${idx + 1}`}
            className="h-20 w-20 cursor-pointer rounded-lg border border-[var(--border-color)] object-cover"
            onClick={() => setViewerImage(img)}
          />
        ))}
      </div>
    );
  };

  return (
    <>
      {loading && <Loading />}
      <BrunnerMessageBox />

      <PageContainer variant="reading" className="py-4 text-sm">
        <h2 className="page-title">{tl("complaintTitle")}</h2>

        {/* 신고 등록 폼 */}
        <div className="mt-3 rounded-xl border border-[var(--border-color)] bg-[var(--surface)] p-4">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={tl("complaintContentPlaceholder")}
            rows={4}
            className="w-full rounded-lg border border-[var(--border-color)] bg-[var(--surface-alt)] px-3 py-2 text-sm text-[var(--general-text-color)] focus:outline-none focus:ring-2 focus:ring-[var(--brand-blue)]"
          />
          {/* 첨부 이미지 미리보기 */}
          {images.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {images.map((img, idx) => (
                <div key={idx} className="relative">
                  <img
                    src={img}
                    alt={`attachment-${idx + 1}`}
                    className="h-20 w-20 cursor-pointer rounded-lg border border-[var(--border-color)] object-cover"
                    onClick={() => setViewerImage(img)}
                  />
                  <button
                    onClick={() => removeImage(idx)}
                    className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-gray-700 text-xs text-white hover:bg-gray-900"
                    aria-label={tl("removeItem")}
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="mt-2 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleAttachImages}
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={images.length >= MAX_IMAGES}
                className="rounded-lg border border-[var(--border-color)] px-3 py-2 text-xs font-medium text-[var(--semi-text-color)] hover:bg-[var(--surface-alt)] disabled:opacity-40"
              >
                📷 {tl("complaintAttachImage")}
              </button>
              <span className="text-xs text-[var(--text-muted)]">
                {tl("complaintAttachLimit")} ({images.length}/{MAX_IMAGES})
              </span>
            </div>
            <button
              onClick={handleSubmit}
              disabled={!content.trim()}
              className="rounded-lg bg-[var(--brand-blue)] px-4 py-2 text-sm font-semibold text-white hover:opacity-90 disabled:opacity-40"
            >
              {tl("complaintSubmit")}
            </button>
          </div>
        </div>

        {/* 내 신고 내역 */}
        <div className="mt-6 flex items-center justify-between">
          <h3 className="font-bold text-[var(--general-text-color)]">
            {tl("complaintMyList")}
          </h3>
          <button
            onClick={refreshAll}
            className="text-xs px-3 py-1 rounded-lg border border-[var(--border-color)] text-[var(--semi-text-color)] hover:bg-[var(--surface-alt)]"
          >
            {tl("complaintRefresh")}
          </button>
        </div>
        <div className="mt-2 flex flex-col gap-2 max-h-72 overflow-y-auto pr-1">
          {myRows.length === 0 ? (
            <p className="py-6 text-center text-[var(--text-muted)]">
              {tl("complaintEmpty")}
            </p>
          ) : (
            myRows.map((row) => (
              <div
                key={row.complaint_id}
                ref={(el) => { rowRefs.current[row.complaint_id] = el; }}
                className={`rounded-xl border p-4 transition-colors duration-700 ${highlightId === row.complaint_id ? "border-blue-400 bg-blue-50 dark:bg-blue-950/40 ring-2 ring-blue-400" : "border-[var(--border-color)] bg-[var(--surface)]"}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-[var(--text-muted)]">
                    {tl("complaintReportTime")}: {fmtTime(row.created_at)}
                  </span>
                  <div className="flex items-center gap-2">
                    <StatusChip status={row.status} />
                    {row.status === "RESOLVED" && (
                      <button
                        onClick={() => handleApprove(row)}
                        className="rounded-lg bg-[var(--brand-blue)] px-3 py-1 text-xs font-semibold text-white hover:opacity-90"
                      >
                        {tl("complaintApprove")}
                      </button>
                    )}
                  </div>
                </div>
                <p className="mt-2 whitespace-pre-wrap text-[var(--general-text-color)]">
                  {row.content}
                </p>
                <AttachedImages row={row} />
                {row.resolution && (
                  <div className="mt-2 rounded-lg bg-[var(--surface-alt)] p-3 text-xs">
                    <span className="font-semibold text-[var(--semi-text-color)]">
                      {tl("complaintResolution")}:
                    </span>{" "}
                    <span className="whitespace-pre-wrap text-[var(--general-text-color)]">
                      {row.resolution}
                    </span>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* 관리자: 전체 신고 관리 */}
        {isAdmin && (
          <>
            <h3 className="mt-8 font-bold text-[var(--general-text-color)]">
              {tl("complaintAdminList")}
            </h3>
            <div className="mt-2 flex flex-col gap-2 max-h-72 overflow-y-auto pr-1">
              {allRows.length === 0 ? (
                <p className="py-6 text-center text-[var(--text-muted)]">
                  {tl("complaintEmpty")}
                </p>
              ) : (
                allRows.map((row) => (
                  <div
                    key={row.complaint_id}
                    ref={(el) => { rowRefs.current[row.complaint_id] = el; }}
                    className={`rounded-xl border p-4 transition-colors duration-700 ${highlightId === row.complaint_id ? "border-blue-400 bg-blue-50 dark:bg-blue-950/40 ring-2 ring-blue-400" : "border-[var(--border-color)] bg-[var(--surface)]"}`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-xs text-[var(--text-muted)]">
                        #{row.complaint_id} · {tl("complaintReporter")}:{" "}
                        {row.user_name || row.user_id} ·{" "}
                        {fmtTime(row.created_at)}
                      </span>
                      <div className="flex items-center gap-2">
                        <StatusChip status={row.status} />
                        {row.status === "RECEIVED" && (
                          <button
                            onClick={() =>
                              handleUpdateStatus(row, "IN_PROGRESS")
                            }
                            className="rounded-lg border border-[var(--border-color)] px-3 py-1 text-xs font-semibold text-[var(--semi-text-color)] hover:bg-[var(--surface-alt)]"
                          >
                            {tl("complaintStartProgress")}
                          </button>
                        )}
                        {["RECEIVED", "IN_PROGRESS"].includes(row.status) && (
                          <button
                            onClick={() => handleUpdateStatus(row, "RESOLVED")}
                            className="rounded-lg bg-[var(--brand-blue)] px-3 py-1 text-xs font-semibold text-white hover:opacity-90"
                          >
                            {tl("complaintResolve")}
                          </button>
                        )}
                      </div>
                    </div>
                    <p className="mt-2 whitespace-pre-wrap text-[var(--general-text-color)]">
                      {row.content}
                    </p>
                    <AttachedImages row={row} />
                    {row.resolution && (
                      <div className="mt-2 rounded-lg bg-[var(--surface-alt)] p-3 text-xs">
                        <span className="font-semibold text-[var(--semi-text-color)]">
                          {tl("complaintResolution")}:
                        </span>{" "}
                        <span className="whitespace-pre-wrap text-[var(--general-text-color)]">
                          {row.resolution}
                        </span>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </>
        )}
      </PageContainer>

      {/* 이미지 확대 보기 오버레이 */}
      {viewerImage && (
        <div
          className="fixed inset-0 z-[10010] flex items-center justify-center bg-black/80 p-4"
          onClick={() => setViewerImage(null)}
        >
          <img
            src={viewerImage}
            alt="attachment-viewer"
            className="max-h-full max-w-full rounded-lg object-contain"
          />
          <button
            onClick={() => setViewerImage(null)}
            className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-black/60 text-lg text-white"
            aria-label={tl("close")}
          >
            ✕
          </button>
        </div>
      )}
    </>
  );
}
