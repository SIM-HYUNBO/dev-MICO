"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import { useRouter } from "next/router";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import { RequestServer } from "@/components/core/client/requestServer";
import Button from "@/components/core/client/ui/Button";
import Input from "@/components/core/client/ui/Input";
import Chip from "@/components/core/client/ui/Chip";

import { registerInAppBack } from "@/components/core/client/frames/backNavigationButton";
const CATEGORIES = [
  { code: "ALL",   labelKey: "openChatCategoryAll" },
  { code: "STOCK", labelKey: "openChatCategoryStock" },
  { code: "STUDY", labelKey: "openChatCategoryStudy" },
  { code: "GAME",  labelKey: "openChatCategoryGame" },
  { code: "MUSIC", labelKey: "openChatCategoryMusic" },
  { code: "ETC",   labelKey: "openChatCategoryEtc" },
];

const CATEGORY_COLORS = {
  STOCK: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  STUDY: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
  GAME:  "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300",
  MUSIC: "bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300",
  ETC:   "bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300",
};

export default function OpenChatContent() {
  const router = useRouter();
  const { BrunnerMessageBox, openOkModal } = useModal();
  const lc = userInfo.getCurrentLanguageCode();
  const tl = (k) => commonFunctions.getResourceByLanguage(k, constants.resourceType.label, lc);

  // 처음에는 STOCK 으로 열었는데, 홈의 오픈채팅 안읽음 배지는 카테고리를
  // 가리지 않고 전부 센다. 안읽음이 STUDY·GAME 같은 다른 카테고리 방에 있으면
  // 배지를 보고 들어와도 목록에 그 방이 없어 "숫자는 있는데 아무것도 없는"
  // 화면이 된다. 서버 기본값도 ALL 이다.
  const [activeCategory, setActiveCategory] = useState("ALL");
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [joining, setJoining] = useState(null);
  const [myRoomUnreadMap, setMyRoomUnreadMap] = useState({}); // { [roomId]: unreadCount }
  const [myRoomIds, setMyRoomIds] = useState(new Set());

  // 방 개설 모달 상태
  const [showCreate, setShowCreate] = useState(false);
  // 화면 안에서 열린 상세/폼은 URL이 바뀌지 않으므로, 열려 있는 동안
  // 뒤로가기를 '닫기'로 처리한다(홈으로 빠져나가지 않게).
  useEffect(() => {
    if (!showCreate) return undefined;
    return registerInAppBack(
      () => { setShowCreate(false); return true; },
      () => { setShowCreate(true); }, // 앞으로가기 → 다시 열기
    );
  }, [showCreate]);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ roomName: "", category: "STOCK", description: "", maxMembers: 100 });

  const loadRooms = useCallback(async (category) => {
    setLoading(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.OPENCHAT_LIST,
                languageCode: lc,
        category,
      });
      if (res.error_code === constants.errorCode.Success) {
        setRooms(res.data || []);
      }
    } finally {
      setLoading(false);
    }
  }, [lc]);

  useEffect(() => {
    loadRooms(activeCategory);
  }, [activeCategory, loadRooms]);

  // 안읽음이 있는 참여방 → 참여방 → 나머지 순. 목록이 카테고리 전체가 되면서
  // 방이 많아졌고, 배지를 보고 들어온 사람이 그 방을 찾을 수 있어야 한다.
  // 같은 등급 안에서는 서버가 준 순서를 그대로 둔다.
  const sortedRooms = useMemo(() => {
    const rank = (room) => {
      const id = String(room.id);
      if (myRoomUnreadMap[id] > 0) return 0;
      if (myRoomIds.has(id)) return 1;
      return 2;
    };
    return rooms
      .map((room, index) => ({ room, index }))
      .sort((a, b) => rank(a.room) - rank(b.room) || a.index - b.index)
      .map((entry) => entry.room);
  }, [rooms, myRoomIds, myRoomUnreadMap]);

  useEffect(() => {
    if (!userInfo.isLogin()) return;
    RequestServer({
      commandName: constants.commands.CHATROOM_LIST,
            userId: userInfo.getLoginUserId(),
    }).then((res) => {
      if (res.error_code !== constants.errorCode.Success) return;
      const unreadMap = {};
      const ids = new Set();
      for (const r of (res.data || [])) {
        if (String(r.room_type || "").toUpperCase() !== "OPEN") continue;
        ids.add(String(r.id));
        const cnt = Number(r.unread_count ?? r.unreadCount ?? 0);
        if (cnt > 0) unreadMap[String(r.id)] = cnt;
      }
      setMyRoomIds(ids);
      setMyRoomUnreadMap(unreadMap);
    }).catch(() => {});
  }, []);

  const handleJoin = async (room) => {
    if (joining) return;
    setJoining(room.id);
    try {
      const res = await RequestServer({
        commandName: constants.commands.OPENCHAT_JOIN,
                languageCode: lc,
        userId: userInfo.getLoginUserId(),
        roomId: room.id,
      });
      if (res.error_code === constants.errorCode.Success) {
        router.push(`/mainPages/chatRoom?roomId=${room.id}&roomName=${encodeURIComponent(room.name)}`);
      } else {
        openOkModal(res.error_message || "입장 실패", "Error");
      }
    } finally {
      setJoining(null);
    }
  };

  const handleCreate = async () => {
    if (!form.roomName.trim()) return;
    setCreating(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.OPENCHAT_CREATE,
                languageCode: lc,
        userId: userInfo.getLoginUserId(),
        roomName: form.roomName.trim(),
        category: form.category,
        description: form.description,
        maxMembers: Number(form.maxMembers) || 100,
      });
      if (res.error_code === constants.errorCode.Success) {
        setShowCreate(false);
        setForm({ roomName: "", category: "STOCK", description: "", maxMembers: 100 });
        router.push(`/mainPages/chatRoom?roomId=${res.roomId}&roomName=${encodeURIComponent(form.roomName.trim())}`);
      } else {
        openOkModal(res.error_message || "방 개설 실패", "Error");
      }
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="flex h-full flex-col bg-[var(--bg)]">
      <BrunnerMessageBox />
      {/* 헤더 */}
      <div className="flex items-center justify-between border-b border-[var(--border)] bg-[var(--surface)] px-4 py-3">
        <h1 className="text-lg font-bold text-[var(--text)]">{tl("openChat")}</h1>
        <Button size="sm" onClick={() => setShowCreate(true)}>{tl("openChatCreate")}</Button>
      </div>

      {/* 카테고리 탭 */}
      <div className="flex gap-1 overflow-x-auto border-b border-[var(--border)] bg-[var(--surface)] px-3 py-2 scrollbar-hide">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.code}
            onClick={() => setActiveCategory(cat.code)}
            className={`shrink-0 rounded-full px-3 py-1.5 text-sm font-semibold transition ${
              activeCategory === cat.code
                ? "bg-[var(--brand-blue)] text-white"
                : "text-[var(--text-muted)] hover:bg-[var(--surface-alt)]"
            }`}
          >
            {tl(cat.labelKey)}
          </button>
        ))}
      </div>

      {/* 방 목록 */}
      <div className="flex-1 overflow-y-auto p-4">
        {loading ? (
          <div className="flex h-40 items-center justify-center text-[var(--text-muted)]">
            <svg className="h-5 w-5 animate-spin" viewBox="0 0 24 24" fill="none">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
            </svg>
          </div>
        ) : rooms.length === 0 ? (
          <div className="flex h-40 flex-col items-center justify-center gap-3 text-[var(--text-muted)]">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            </svg>
            <p className="text-sm">{tl("openChatEmpty")}</p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {sortedRooms.map((room) => (
              <div
                key={room.id}
                className="flex flex-col justify-between rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 shadow-sm transition hover:shadow-md"
              >
                <div>
                  <div className="mb-2 flex items-center gap-2">
                    <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${CATEGORY_COLORS[room.category] || CATEGORY_COLORS.ETC}`}>
                      {tl(`openChatCategory${room.category?.charAt(0) + room.category?.slice(1).toLowerCase()}`) || room.category}
                    </span>
                    {myRoomUnreadMap[String(room.id)] > 0 && (
                      <Chip tone="danger">
                        {myRoomUnreadMap[String(room.id)] > 99 ? "99+" : myRoomUnreadMap[String(room.id)]}
                      </Chip>
                    )}
                  </div>
                  <p className="mb-1 font-bold text-[var(--text)] line-clamp-1">{room.name}</p>
                  {room.description && (
                    <p className="mb-2 text-sm text-[var(--text-muted)] line-clamp-2">{room.description}</p>
                  )}
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-xs text-[var(--text-muted)]">
                    {room.member_count}/{room.max_members}{tl("openChatMembers")}
                  </span>
                  <Button
                    size="sm"
                    disabled={joining === room.id || (!myRoomIds.has(String(room.id)) && Number(room.member_count) >= Number(room.max_members))}
                    onClick={() => handleJoin(room)}
                  >
                    {joining === room.id ? "..." : myRoomIds.has(String(room.id)) ? tl("openChatEnter") : tl("openChatJoin")}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 방 개설 모달 */}
      {showCreate && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 sm:items-center"
          onClick={(e) => { if (e.target === e.currentTarget) setShowCreate(false); }}
        >
          <div className="w-full max-w-md rounded-t-2xl bg-[var(--surface)] p-6 shadow-xl sm:rounded-2xl">
            <h2 className="mb-4 text-base font-bold text-[var(--text)]">{tl("openChatCreate")}</h2>

            <div className="flex flex-col gap-3">
              <div>
                <label className="mb-1 block text-sm font-semibold text-[var(--text-muted)]">{tl("openChatRoomName")} *</label>
                <Input
                  value={form.roomName}
                  onChange={(e) => setForm((f) => ({ ...f, roomName: e.target.value }))}
                  placeholder={tl("openChatRoomName")}
                  maxLength={50}
                />
              </div>

              <div>
                <label className="mb-1 block text-sm font-semibold text-[var(--text-muted)]">{tl("openChatCategory")} *</label>
                <div className="flex flex-wrap gap-2">
                  {CATEGORIES.filter((c) => c.code !== "ALL").map((cat) => (
                    <button
                      key={cat.code}
                      onClick={() => setForm((f) => ({ ...f, category: cat.code }))}
                      className={`rounded-full px-3 py-1 text-sm font-semibold transition ${
                        form.category === cat.code
                          ? "bg-[var(--brand-blue)] text-white"
                          : "bg-[var(--surface-alt)] text-[var(--text-muted)] hover:bg-[var(--border)]"
                      }`}
                    >
                      {tl(cat.labelKey)}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="mb-1 block text-sm font-semibold text-[var(--text-muted)]">{tl("openChatDescription")}</label>
                <Input
                  value={form.description}
                  onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                  placeholder={tl("openChatDescription")}
                  maxLength={200}
                />
              </div>

              <div>
                <label className="mb-1 block text-sm font-semibold text-[var(--text-muted)]">{tl("openChatMaxMembers")}</label>
                <Input
                  type="number"
                  value={form.maxMembers}
                  onChange={(e) => setForm((f) => ({ ...f, maxMembers: e.target.value }))}
                  min={2}
                  max={1000}
                />
              </div>
            </div>

            <div className="mt-5 flex gap-2">
              <Button variant="soft" className="flex-1" onClick={() => setShowCreate(false)}>
                {tl("cancel")}
              </Button>
              <Button className="flex-1" disabled={!form.roomName.trim() || creating} onClick={handleCreate}>
                {creating ? "..." : tl("openChatCreate")}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
