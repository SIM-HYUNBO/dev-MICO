"use client";

import { useState, useRef, useEffect } from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

import { useDeviceType } from "@/lib/commonFunctions";
import GoverningMessage from "@/components/core/client/governingMessage";

export default function ContactContent() {
  const { isMobile, isTablet } = useDeviceType();
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  return (
    <>
      <div>
        <div className={`w-full items-start text-left text-sm`}>
          <h2 className="page-title">
            {commonFunctions.getResourceByLanguage(
              "contactTitle",
              constants.resourceType.label,
              currentLanguageCode,
            )}
          </h2>
          <GoverningMessage
            governingMessage={`${commonFunctions.getResourceByLanguage(
              `GOVERNING_MESSAGE_CONTACT_CONTENT`,
              constants.resourceType.message,
              currentLanguageCode,
            )}`}
          />
          <div className={`flex justify-center mt-5`}>
            <GetContact />
          </div>
        </div>
      </div>
    </>
  );
}

export function GetContact() {
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  return (
    <>
      <div className={`flex flex-row items-center h-[50vh]`}>
        <div className={`px-5 py-2 mr-2 bg-indigo-500`}>
          <a href={`tel:82-10-7544-8698`}>
            {commonFunctions.getResourceByLanguage(
              "mobile",
              constants.resourceType.label,
              currentLanguageCode,
            )}
          </a>
        </div>
        <br />
        <div className={`px-5 py-2 mr-2 bg-indigo-500`}>
          <a href="mailto:hbsim0605@gmail.com">
            {commonFunctions.getResourceByLanguage(
              "email",
              constants.resourceType.label,
              currentLanguageCode,
            )}
          </a>
        </div>
      </div>
    </>
  );
}
