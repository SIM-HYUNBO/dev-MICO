"use client";

import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import React, { useEffect, useState } from "react";
import { createPortal } from "react-dom";

export default function Loading({ message = null }) {
  const [overlayStyle, setOverlayStyle] = useState(null);
  const [ready, setReady] = useState(false);
  const [dots, setDots] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);

  /* ===========================
     점(...) 애니메이션
  =========================== */
  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());

    const interval = setInterval(() => {
      setDots((prev) => (prev.length >= 10 ? "" : prev + "."));
    }, 500);

    return () => clearInterval(interval);
  }, []);

  /* ===========================
     오버레이 위치 계산
  =========================== */
  useEffect(() => {
    if (typeof window === "undefined") return;

    let raf = 0;

    const calculate = () => {
      try {
        const header = document.querySelector("header");
        const footer = document.querySelector("footer");

        const headerRect = header
          ? header.getBoundingClientRect()
          : { bottom: 0 };
        const footerRect = footer
          ? footer.getBoundingClientRect()
          : { top: window.innerHeight };

        const topDoc = Math.max(0, headerRect.bottom + window.scrollY);
        const footerTopDoc = footerRect.top + window.scrollY;
        const heightDoc = Math.max(0, footerTopDoc - topDoc);

        if (heightDoc <= 0) {
          setOverlayStyle({
            position: "fixed",
            inset: 0,
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "rgba(0,0,0,0.35)",
            backdropFilter: "blur(4px)",
          });
          setReady(true);
          return;
        }

        setOverlayStyle({
          position: "absolute",
          top: `${topDoc}px`,
          left: "0px",
          width: "100%",
          height: `${heightDoc}px`,
          zIndex: 9999,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "rgba(0,0,0,0.35)",
          backdropFilter: "blur(4px)",
        });

        setReady(true);
      } catch (e) {
        setOverlayStyle({
          position: "fixed",
          inset: 0,
          zIndex: 9999,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "rgba(0,0,0,0.35)",
          backdropFilter: "blur(4px)",
        });
        setReady(true);
      }
    };

    const tick = () => {
      if (raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(calculate);
    };

    tick();

    window.addEventListener("resize", tick, { passive: true });
    window.addEventListener("scroll", tick, { passive: true });

    const mo = new MutationObserver(tick);
    mo.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
    });

    return () => {
      window.removeEventListener("resize", tick);
      window.removeEventListener("scroll", tick);
      mo.disconnect();
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  if (typeof document === "undefined" || !ready) return null;

  const overlayNode = (
    <div style={overlayStyle}>
      <div className="flex flex-col items-center gap-4">
        <div className="text-white text-lg font-semibold">
          {message ||
            commonFunctions.getResourceByLanguage(
              `WORK_IN_PROCESS_IN_SERVER`,
              constants.resourceType.message,
              currentLanguageCode,
            )}
          <span className="inline-block w-20">{dots}</span>
        </div>

        <div className="flex gap-2">
          <span className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.3s]" />
          <span className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.15s]" />
          <span className="w-2 h-2 bg-white rounded-full animate-bounce" />
        </div>
      </div>
    </div>
  );

  return createPortal(overlayNode, document.body);
}
