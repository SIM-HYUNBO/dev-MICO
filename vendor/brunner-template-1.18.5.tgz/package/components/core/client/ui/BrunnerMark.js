"use client";

// Brunner 브랜드 마크 — B 안에 위=연기(스팀), 아래=머그컵을 음각(뚫린 공간)으로 형상화.
// 카페 소셜 플랫폼 정체성을 담은 로고. 배경 위에서 머그·스팀이 배경색으로 비쳐 보인다.
export default function BrunnerMark({ size = 32, className = "" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" className={className}
      role="img" aria-label="BRUNNER" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="brunnerMugGrad" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#d59657" />
          <stop offset="1" stopColor="#6e3719" />
        </linearGradient>
        {/* 흰=보임, 검정=구멍(머그·스팀) */}
        <mask id="brunnerMugMask">
          <rect width="100" height="100" fill="#fff" />
          {/* 커피(스팀+머그)만 중심 기준 축소 — B 글자는 원본 유지 */}
          <g transform="translate(49,55) scale(0.87) translate(-49,-55)">
            {/* 위: 스팀 세 줄 (가늘게) */}
            <path d="M41 46 c4 -4 -4 -7 0 -12 M46 46 c4 -4 -4 -7 0 -12 M51 46 c4 -4 -4 -7 0 -12"
              fill="none" stroke="#000" strokeWidth="3" strokeLinecap="round" />
            {/* 아래: 머그컵 몸통 + 손잡이 */}
            <path d="M38 61 h16.5 v11 a5 5 0 0 1 -5 5 h-6.5 a5 5 0 0 1 -5 -5 Z" fill="#000" />
            <path d="M54.5 63.5 a6 6 0 0 1 0 11" fill="none" stroke="#000" strokeWidth="3.5" />
          </g>
        </mask>
      </defs>
      <path mask="url(#brunnerMugMask)" fill="url(#brunnerMugGrad)"
        d="M26 18 h26 c14 0 22 7.5 22 18 c0 7.4-4 12.6-10.6 14.6 C71.5 52.6 78 59 78 68 C78 79 69 87 54 87 H26 Z" />
    </svg>
  );
}
