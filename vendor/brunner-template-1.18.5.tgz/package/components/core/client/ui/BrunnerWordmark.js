"use client";

// Brunner 워드마크 — "BRUNNER"의 첫 글자 B를 커피 머그와 한 몸인 B로 대체.
// 머그의 왼쪽 곧은 벽 + 오른쪽 두 볼록이 그대로 B 글자가 되고, 위엔 김, 왼쪽엔 손잡이,
// 아래 볼록엔 카운터(구멍)를 넣어 B로 또렷하게 읽힌다. 나머지 "RUNNER"는 브랜드 블루 유지.
// className으로 폰트 크기를 넘기면 B도 글자 높이에 맞춰 스케일된다(em 기준).
export default function BrunnerWordmark({ className = "" }) {
  return (
    <span className={`inline-flex items-baseline leading-none ${className}`} role="img" aria-label="BRUNNER">
      {/* viewBox 하단 = 잔 밑면(=베이스라인), 몸통 높이 ≈ RUNNER 캡 높이, 김은 캡 위로 넘친다.
          height=1.02em은 잔 몸통(rim~base)이 RUNNER 대문자 높이와 맞도록 실측 보정한 값. */}
      <svg viewBox="8 12 204 271" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
        style={{ height: "1.02em", width: "auto", marginRight: "0.03em", verticalAlign: "baseline" }}>
        <defs>
          {/* 커피색(로스티드: 붉은기 도는 갈색) 그라데이션 — RUNNER 블루와 구분 */}
          <linearGradient id="bwmGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#d59657" />
            <stop offset="1" stopColor="#6e3719" />
          </linearGradient>
        </defs>
        {/* 손잡이 */}
        <path d="M52 150 C14 150 14 210 52 210" fill="none" stroke="url(#bwmGrad)" strokeWidth="17" strokeLinecap="round" />
        {/* 잔=B 단일 실루엣 (왼쪽 곧은 벽 + 오른쪽 두 볼록) */}
        <path d="M55 106 L58 248 C60 264 74 274 94 274 C154 274 200 250 200 208 C200 182 182 166 154 162 C184 156 194 138 192 120 C188 100 152 96 122 96 L55 96 Z"
          fill="none" stroke="url(#bwmGrad)" strokeWidth="17" strokeLinejoin="round" />
        {/* B 허리(오른쪽 잘록) */}
        <path d="M154 162 C132 165 108 164 92 163" fill="none" stroke="url(#bwmGrad)" strokeWidth="17" strokeLinecap="round" />
        {/* B 아래 볼록의 카운터 — 커피색으로 채워 또렷하게 */}
        <path d="M104 188 C146 188 170 196 170 213 C170 230 146 240 104 240 Z" fill="url(#bwmGrad)" stroke="url(#bwmGrad)" strokeWidth="4" strokeLinejoin="round" />
        {/* 컵 입구(윗면 타원) + 커피 */}
        <ellipse cx="100" cy="96" rx="46" ry="13" fill="none" stroke="url(#bwmGrad)" strokeWidth="17" />
        <ellipse cx="100" cy="97" rx="29" ry="6.5" fill="#5a2e15" />
        {/* 김 */}
        <g fill="none" stroke="url(#bwmGrad)" strokeWidth="10" strokeLinecap="round">
          <path d="M80 78 C88 66 72 58 80 46 C86 37 76 32 82 24" />
          <path d="M108 78 C116 64 100 56 108 42 C114 33 106 28 112 20" />
        </g>
      </svg>
      <span className="gradient-text" aria-hidden="true">RUNNER</span>
    </span>
  );
}
