const variantClasses = {
  primary: "border-transparent shadow-[var(--shadow-primary)]",
  ghost: "theme-button",
  soft: "theme-button",
  success: "border-transparent shadow-[var(--shadow-success)]",
  danger: "border-transparent shadow-[var(--shadow-danger)]",
};

const sizeClasses = {
  sm: "px-3 py-1.5 text-[13px]",
  md: "px-4 py-2.5 text-sm",
};

const variantStyles = {
  primary: {
    backgroundImage: "var(--brand-gradient)",
    color: "#fff",
  },
  success: {
    backgroundColor: "var(--brand-emerald)",
    color: "#fff",
  },
  danger: {
    backgroundColor: "var(--danger)",
    color: "#fff",
  },
};

export default function Button({ variant = "primary", size = "md", icon, children, className = "", disabled, style, ...rest }) {
  return (
    <button
      type="button"
      disabled={disabled}
      style={{ ...(variantStyles[variant] || {}), ...style }}
      className={`inline-flex items-center justify-center gap-2 rounded-[var(--radius-md)] border font-semibold transition duration-150 ease-out hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50 ${variantClasses[variant] || variantClasses.primary} ${sizeClasses[size] || sizeClasses.md} ${className}`}
      {...rest}
    >
      {icon}
      {children}
    </button>
  );
}
