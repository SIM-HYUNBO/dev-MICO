export default function Card({ strong = false, className = "", children }) {
  return (
    <div
      className={`rounded-[var(--radius-lg)] border border-[var(--border)] bg-[var(--surface)] ${strong ? "p-6 shadow-[var(--shadow-card-strong)]" : "p-4 shadow-[var(--shadow-card)]"} ${className}`}
    >
      {children}
    </div>
  );
}
