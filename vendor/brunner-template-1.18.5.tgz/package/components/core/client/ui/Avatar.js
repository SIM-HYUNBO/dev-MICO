const ALLOWED_SIZES = new Set([24, 28, 32, 36, 40, 44, 56, 72]);

export default function Avatar({ src, initial = "?", size = 36, color, online = false, className = "" }) {
  const avatarSize = ALLOWED_SIZES.has(Number(size)) ? Number(size) : 36;
  const background = typeof color === "number" ? `hsl(${color}, 70%, 55%)` : "var(--brand-gradient)";
  const dotSize = avatarSize >= 56 ? 10 : 8;

  return (
    <span className={`relative inline-flex shrink-0 items-center justify-center overflow-visible rounded-full text-white ${className}`} style={{ width: avatarSize, height: avatarSize, background, fontSize: Math.max(11, Math.round(avatarSize * 0.4)), fontWeight: 700 }}>
      {src ? (
        <img src={src} alt="" className="h-full w-full rounded-full object-cover" />
      ) : (
        <span className="leading-none">{String(initial || "?").trim().charAt(0).toUpperCase()}</span>
      )}
      {online && (
        <span
          className="absolute bottom-0 right-0 rounded-full bg-[#22c55e]"
          style={{ width: dotSize, height: dotSize, boxShadow: "0 0 0 2px var(--surface)" }}
        />
      )}
    </span>
  );
}
