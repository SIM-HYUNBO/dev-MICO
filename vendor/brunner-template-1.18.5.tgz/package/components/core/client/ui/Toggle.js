export default function Toggle({ checked, onChange, disabled = false, ...rest }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      {...rest}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!disabled) onChange?.(!checked);
      }}
      className={`relative inline-flex h-5 w-9 items-center rounded-[var(--radius-pill)] transition duration-150 ease-out disabled:cursor-not-allowed disabled:opacity-50 ${
        checked ? "bg-[var(--brand-emerald)]" : "bg-[var(--border-strong)]"
      }`}
    >
      <span className={`inline-block h-4 w-4 rounded-full bg-white transition duration-150 ease-out ${checked ? "translate-x-[18px]" : "translate-x-0.5"}`} />
    </button>
  );
}
