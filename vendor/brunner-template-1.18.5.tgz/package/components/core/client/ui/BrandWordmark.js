"use client";

import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import BrunnerWordmark from "@/components/core/client/ui/BrunnerWordmark";

/**
 * 화면 상단·로그인·404 에 쓰는 브랜드 표시.
 *
 * 왜 이 파일이 따로 있나
 *   프레임들이 BrunnerWordmark 를 직접 import 하고 있었다. 그래서 파생 서비스는
 *   로고 두 줄을 바꾸겠다고 헤더·로그인·회원가입·404 를 통째로 포크해야 했고
 *   (zicp 가 실제로 6개를 포크했다), 그 뒤로 템플릿이 그 화면을 고쳐도 받지
 *   못한다. 갈아끼우는 지점을 이 파일 하나로 모은다.
 *
 * 파생 서비스는 이 파일만 자기 리포에 두면 된다. next.config 의 별칭이 로컬을
 * 먼저 보므로 프레임은 템플릿 것을 그대로 쓰면서 로고만 바뀐다.
 *
 * 로고가 아직 없는 새 시스템
 *   설치 마법사가 입력받은 프로젝트 이름을 brandName 라벨로 심는다. 그 값이
 *   있으면 로고 대신 그 이름을 글자로 보여준다 — 남의 서비스에 브런너 로고가
 *   뜨는 것보다 자기 이름이 뜨는 편이 맞다.
 */
export default function BrandWordmark({ className = "" }) {
  const brandName = commonFunctions.getResourceByLanguage(
    "brandName",
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

  // 라벨이 없으면 "[리소스 없음:...]" 이 돌아오고, 리소스를 아직 못 받았으면 빈
  // 문자열이다. 둘 다 심긴 이름이 없다는 뜻이므로 기본 로고로 떨어진다.
  const named = Boolean(brandName) && !brandName.startsWith("[리소스 없음:");
  if (!named) return <BrunnerWordmark className={className} />;

  return (
    <span className={`inline-flex items-baseline leading-none ${className}`} role="img" aria-label={brandName}>
      <span className="gradient-text">{brandName}</span>
    </span>
  );
}
