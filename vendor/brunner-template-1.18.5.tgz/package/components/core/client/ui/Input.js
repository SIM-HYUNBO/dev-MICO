import { forwardRef } from "react";

const Input = forwardRef(function Input({ icon, error = false, className = "", inputClassName = "", ...inputProps }, ref) {
  const errorClass = error ? "border-[var(--danger)]" : "border-[var(--border)]";
  const paddingClass = icon ? "pl-10 pr-3" : "px-3";

  return (
    <div className={`relative inline-flex w-full items-center ${className}`}>
      {icon && (
        <span className="pointer-events-none absolute left-3 inline-flex h-4 w-4 items-center justify-center text-[var(--text-subtle)]">
          {icon}
        </span>
      )}
      <input
        ref={ref}
        className={`h-11 w-full rounded-[var(--radius-md)] border bg-[var(--surface)] ${paddingClass} text-sm text-[var(--text)] outline-none transition placeholder:text-[var(--text-subtle)] focus:outline focus:outline-2 focus:outline-offset-2 focus:outline-[var(--brand-blue)] ${errorClass} ${inputClassName}`}
        {...inputProps}
      />
    </div>
  );
});

export default Input;
