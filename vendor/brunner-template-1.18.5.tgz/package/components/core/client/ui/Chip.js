const toneClasses = {
  neutral: "bg-[var(--surface-alt)] text-[var(--text-muted)]",
  brand: "bg-[rgba(2,132,199,0.10)] text-[var(--brand-blue-dark)]",
  success: "bg-[rgba(5,150,105,0.10)] text-[var(--brand-emerald-dark)]",
  danger: "bg-[rgba(239,68,68,0.10)] text-[#b91c1c]",
  warn: "bg-[rgba(245,158,11,0.10)] text-[#b45309]",
};

export default function Chip({ tone = "neutral", className = "", children }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-[var(--radius-pill)] px-2.5 py-[3px] text-[11px] font-semibold ${toneClasses[tone] || toneClasses.neutral} ${className}`}>
      {children}
    </span>
  );
}
