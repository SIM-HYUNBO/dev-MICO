"use client";

/**
 * 페이지 본문 컨테이너 — 화면마다 제각각이던 본문 폭을 한곳에서 정한다.
 *
 * 좌우 여백을 비율로 잡지 않는 이유: 퍼센트로 두면 울트라와이드에서 한 줄이
 * 지나치게 길어져 눈이 줄을 따라가지 못하고, 좁은 노트북에서는 답답해진다.
 * 본문 폭을 고정하고 남는 공간을 여백으로 흘리는 것이 표준적인 방식이다.
 *
 * 폭은 한 줄에 들어가는 글자 수(가독성 최적 45~75자)를 기준으로 잡았다.
 *   app     1152px — 채팅·목록·대시보드처럼 정보를 나열하는 화면(기본값)
 *   reading  896px — 글을 읽거나 폼을 채우는 화면
 *   narrow   672px — 로그인·가입처럼 단일 폼만 있는 화면
 *
 * 세로 여백·배경처럼 화면마다 다른 것은 className 으로 넘긴다.
 * 이 컴포넌트가 소유하는 것은 가운데 정렬·최대 폭·좌우 패딩뿐이다.
 */
const WIDTHS = {
  app: "max-w-6xl",
  reading: "max-w-4xl",
  narrow: "max-w-2xl",
};

export default function PageContainer({
  variant = "app",
  className = "",
  children,
  ...rest
}) {
  const width = WIDTHS[variant] || WIDTHS.app;
  return (
    <div
      className={`mx-auto w-full ${width} px-4 sm:px-6 lg:px-8 ${className}`.trim()}
      {...rest}
    >
      {children}
    </div>
  );
}
