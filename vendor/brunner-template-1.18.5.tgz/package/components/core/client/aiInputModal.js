import React, { useState, useRef, useEffect } from "react";
import { Button } from "antd";

import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";

import { useModal } from "@/components/core/client/brunnerMessageBox";
import AIModelSelector from "@/components/core/client/aiModelSelector";

export default function AIInputModal({
  isOpen,
  onClose,
  commandName,
  onAIResponse,
}) {
  const [loading, setLoading] = useState(false);
  const { BrunnerMessageBox, openOkModal } = useModal();
  const [instructions, setInstructions] = useState(constants.emptyString);
  const [aiModel, setAIModel] = useState("free-auto");
  const [errorMessage, setErrorMessage] = useState(constants.emptyString);
  const modalRef = useRef(null);
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);
  const [isMobile, setIsMobile] = useState(false);

  // 드래그 상태 (데스크톱 전용)
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });

  // 리사이즈 상태 (데스크톱 전용)
  const MIN_WIDTH = 480;
  const MIN_HEIGHT = 360;
  const [size, setSize] = useState({ width: 700, height: 520 });
  const resizingRef = useRef(null);

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  useEffect(() => {
    const checkLogin = async () => {
      if (!userInfo.isLogin()) {
        await openOkModal(
          commonFunctions.getResourceByLanguage("LOGIN_REQUIRED", constants.resourceType.message),
          constants.messageCategory.Error,
        );
      }
    };
    checkLogin();
  }, [onClose]);

  // 드래그
  const handleMouseDown = (e) => {
    if (isMobile) return;
    const tag = e.target.tagName;
    if (["INPUT", "TEXTAREA", "SELECT", "BUTTON"].includes(tag)) return;
    if (e.target.dataset?.resizeHandle === "true") return;
    setDragging(true);
    dragStart.current = { x: e.clientX - position.x, y: e.clientY - position.y };
  };

  const handleMouseMove = (e) => {
    if (dragging) setPosition({ x: e.clientX - dragStart.current.x, y: e.clientY - dragStart.current.y });
  };

  const handleMouseUp = () => setDragging(false);

  useEffect(() => {
    if (dragging) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    } else {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [dragging]);

  // 리사이즈
  const handleResizeMouseDown = (e) => {
    if (isMobile) return;
    e.stopPropagation();
    setDragging(false);
    resizingRef.current = { startX: e.clientX, startY: e.clientY, startWidth: size.width, startHeight: size.height };
    document.addEventListener("mousemove", handleResizeMouseMove);
    document.addEventListener("mouseup", handleResizeMouseUp);
  };

  const handleResizeMouseMove = (e) => {
    if (!resizingRef.current) return;
    setSize({
      width: Math.max(MIN_WIDTH, resizingRef.current.startWidth + e.clientX - resizingRef.current.startX),
      height: Math.max(MIN_HEIGHT, resizingRef.current.startHeight + e.clientY - resizingRef.current.startY),
    });
  };

  const handleResizeMouseUp = () => {
    resizingRef.current = null;
    document.removeEventListener("mousemove", handleResizeMouseMove);
    document.removeEventListener("mouseup", handleResizeMouseUp);
  };

  useEffect(() => {
    return () => {
      document.removeEventListener("mousemove", handleResizeMouseMove);
      document.removeEventListener("mouseup", handleResizeMouseUp);
    };
  }, []);

  const handleRequest = async () => {
    if (!userInfo.isLogin()) {
      await openOkModal(
        commonFunctions.getResourceByLanguage("LOGIN_REQUIRED", constants.resourceType.message),
        constants.messageCategory.Error,
      );
      return;
    }
    if (!instructions || !aiModel) {
      await openOkModal(
        `${commonFunctions.getResourceByLanguage("REQUIRED_FIELD", constants.resourceType.message, currentLanguageCode)} [instructions, aiModel]`,
        "Error",
        constants.messageCategory.Error,
      );
      return;
    }

    setErrorMessage(constants.emptyString);
    try {
      setLoading(true);
      const jResponse = await RequestServer({
        commandName,
                userId: userInfo.getLoginUserId(),
        languageCode: currentLanguageCode,
        instructionInfo: { instructions, aiModel },
      });
      if (jResponse.error_code == constants.errorCode.Success) {
        await onAIResponse(jResponse);
      } else {
        setErrorMessage(jResponse.error_message || commonFunctions.getResourceByLanguage("AI_DOC_GENERATE_FAILED", constants.resourceType.message, currentLanguageCode));
      }
    } catch (e) {
      setErrorMessage(`${commonFunctions.getResourceByLanguage("AI_DOC_GENERATE_FAILED", constants.resourceType.message, currentLanguageCode)} ${e}`);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[10001] flex items-end md:items-center justify-center bg-black/60">
      <BrunnerMessageBox />
      <div
        ref={modalRef}
        className="relative flex flex-col w-full rounded-t-2xl md:rounded-2xl bg-[var(--surface)] text-[var(--text)] shadow-xl cursor-default md:cursor-move"
        style={isMobile ? {
          maxHeight: "90dvh",
          paddingBottom: "max(1.5rem, env(safe-area-inset-bottom))",
        } : {
          transform: `translate(${position.x}px, ${position.y}px)`,
          width: `${size.width}px`,
          height: `${size.height}px`,
          minWidth: `${MIN_WIDTH}px`,
          minHeight: `${MIN_HEIGHT}px`,
        }}
        onMouseDown={handleMouseDown}
        role="dialog"
        aria-modal="true"
      >
        {loading && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-black/60 rounded-t-2xl md:rounded-2xl gap-4">
            <div className="text-white text-base font-semibold">{commonFunctions.getResourceByLanguage("AI_GENERATING", constants.resourceType.message, currentLanguageCode)}</div>
            <div className="flex gap-2">
              <span className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.3s]" />
              <span className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:-0.15s]" />
              <span className="w-2 h-2 bg-white rounded-full animate-bounce" />
            </div>
          </div>
        )}

        {/* 헤더 */}
        <div className="flex items-center justify-between px-5 pt-5 pb-3 shrink-0">
          <h2 className="text-base font-extrabold select-none">{commonFunctions.getResourceByLanguage("aiGenerateDocTitle", constants.resourceType.label, currentLanguageCode)}</h2>
          <button onClick={onClose} className="text-[var(--text-muted)] hover:text-[var(--text)] text-xl leading-none">✕</button>
        </div>

        {/* 본문 — 모바일에서 스크롤 */}
        <div className="flex flex-col flex-1 min-h-0 overflow-y-auto px-5 pb-2">
          {errorMessage && (
            <div className="mb-3 text-danger text-xs font-medium">{errorMessage}</div>
          )}

          <label className="block mb-1 text-xs font-semibold text-[var(--text-muted)]">{commonFunctions.getResourceByLanguage("aiModelSelect", constants.resourceType.label, currentLanguageCode)}</label>
          <div onMouseDown={(e) => e.stopPropagation()} className="mb-4">
            <AIModelSelector model={aiModel} setAIModel={setAIModel} />
          </div>

          <label className="block mb-1 text-xs font-semibold text-[var(--text-muted)]">{commonFunctions.getResourceByLanguage("aiInstructions", constants.resourceType.label, currentLanguageCode)}</label>
          <textarea
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            className="w-full flex-1 min-h-[120px] md:min-h-0 md:flex-grow border border-[var(--border)] rounded-[var(--radius-md)] p-2 text-sm resize-none bg-[var(--bg)] text-[var(--text)] focus:outline-none focus:ring-2 focus:ring-[var(--brand-blue)]"
            placeholder={commonFunctions.getResourceByLanguage("aiInstructionsPlaceholder", constants.resourceType.label, currentLanguageCode)}
          />
        </div>

        {/* 푸터 버튼 */}
        <div className="flex gap-2 px-5 pt-3 pb-4 shrink-0">
          <button
            onClick={onClose}
            className="flex-1 rounded-[var(--radius-md)] border border-[var(--border)] py-2 text-sm font-semibold text-[var(--text)] hover:bg-[var(--surface-alt)]"
          >
            {commonFunctions.getResourceByLanguage("close", constants.resourceType.label, currentLanguageCode)}
          </button>
          <button
            onClick={handleRequest}
            disabled={loading}
            className="flex-1 rounded-[var(--radius-md)] bg-brand-blue py-2 text-sm font-semibold text-white hover:bg-brand-blue/90 disabled:opacity-50"
          >
            {commonFunctions.getResourceByLanguage("generate", constants.resourceType.label, currentLanguageCode)}
          </button>
        </div>

        {/* 리사이즈 핸들 (데스크톱 전용) */}
        {!isMobile && (
          <div
            data-resize-handle="true"
            onMouseDown={handleResizeMouseDown}
            className="absolute bottom-2 right-2 w-4 h-4 cursor-se-resize bg-gray-400/60 dark:bg-gray-600/80 rounded-sm"
          />
        )}
      </div>
    </div>
  );
}
