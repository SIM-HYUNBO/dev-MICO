import React, { useState, useEffect, useRef, useCallback } from "react";
import { createPortal } from "react-dom";
import Loading from "@/components/core/client/loading";
import { Input, Button } from "antd";
import * as constants from "@/lib/constants";

export const useModal = () => {
  const [modalContent, setModalContent] = useState({
    isOpen: false,
    title: constants.emptyString,
    message: constants.emptyString,
    inputVisible: false,
    cancelVisible: true,
    confirmResolve: null,
    cancelReject: null,
    initialValue: constants.emptyString,
    inputPlaceholder: constants.emptyString,
    checkboxLabel: null,
    initialChecked: false,
    multiline: false,
  });

  const [loading, setLoading] = useState(false);

  const [localChecked, setLocalChecked] = useState(false);
  const isComposingRef = useRef(false);
  const inputRef = useRef(null);
  // 사용자가 입력한 값을 ref에 보존 — BrunnerMessageBox remount 시에도 유지됨
  const typedValueRef = useRef("");

  useEffect(() => {
    if (modalContent.isOpen) {
      typedValueRef.current = modalContent.initialValue ?? "";
      setLocalChecked(modalContent.initialChecked ?? false);
      isComposingRef.current = false;
    }
  }, [modalContent.isOpen]);

  // 버튼 배경·글자색은 클래스가 아니라 인라인 style 로 준다.
  //
  // 여기 Button 은 antd 컴포넌트라 자기 CSS 로 흰 배경·어두운 글자를 넣는다.
  // Tailwind 유틸리티(bg-danger, text-white)는 특이도가 antd 와 같아서 어느
  // 쪽이 이길지는 CSS 로딩 순서로 갈리고, 그 순서는 빌드에 따라 달라진다.
  // 배경만 antd(흰색)가 이기고 글자는 Tailwind(흰색)가 이기면 흰 바탕에 흰
  // 글씨가 되어 버튼 글자가 안 보인다. 인라인 style 은 클래스보다 항상
  // 우선하므로 순서와 무관하게 고정된다.
  const getColorClassByTitle = (title) => {
    switch (title) {
      case "Confirm":
        return { title: "text-brand-blue border-brand-blue", okStyle: { backgroundColor: "var(--brand-blue)", color: "#fff" } };
      case "Info":
        return { title: "text-info border-info", okStyle: { backgroundColor: "var(--info)", color: "#fff" } };
      case "Warning":
        return { title: "text-warn border-warn", okStyle: { backgroundColor: "var(--warn)", color: "#fff" } };
      case "Error":
        return { title: "text-danger border-danger", okStyle: { backgroundColor: "var(--danger)", color: "#fff" } };
      case "Exception":
        return { title: "text-brand-violet border-brand-violet", okStyle: { backgroundColor: "var(--brand-violet)", color: "#fff" } };
      default:
        return { title: "text-[var(--text)] dark:text-[var(--text)] border-[var(--border-color)] dark:border-[var(--border-strong)]", okStyle: { backgroundColor: "var(--brand-blue)", color: "#fff" } };
    }
  };

  const openOkCancelModal = (message, title = constants.emptyString) => {
    return new Promise((resolve, reject) => {
      setModalContent({
        isOpen: true, title, message,
        inputVisible: false, cancelVisible: true,
        confirmResolve: () => resolve(true),
        cancelReject: () => reject(false),
        initialValue: constants.emptyString,
        inputPlaceholder: constants.emptyString,
      });
    });
  };

  const openOkModal = (message, title = constants.emptyString) => {
    return new Promise((resolve) => {
      setModalContent({
        isOpen: true, title, message,
        inputVisible: false, cancelVisible: false,
        confirmResolve: () => resolve(true),
        cancelReject: null,
        initialValue: constants.emptyString,
        inputPlaceholder: constants.emptyString,
      });
    });
  };

  const openInputModal = (
    message,
    initialValue = constants.emptyString,
    title = constants.emptyString,
    multiline = false,
    inputPlaceholder = constants.emptyString,
  ) => {
    return new Promise((resolve, reject) => {
      setModalContent({
        isOpen: true, title, message,
        inputVisible: true, cancelVisible: true, multiline,
        confirmResolve: (val) => resolve(val),
        cancelReject: () => reject(null),
        initialValue,
        inputPlaceholder,
      });
    });
  };

  const openInputWithCheckboxModal = (message, initialValue = "", checkboxLabel = "", initialChecked = false, title = "") => {
    return new Promise((resolve, reject) => {
      setModalContent({
        isOpen: true, title, message,
        inputVisible: true, cancelVisible: true,
        checkboxLabel, initialChecked,
        confirmResolve: (val) => resolve(val),
        cancelReject: () => reject(null),
        initialValue,
        inputPlaceholder: constants.emptyString,
      });
    });
  };

  const closeModal = () => {
    setModalContent({
      isOpen: false,
      title: constants.emptyString,
      message: constants.emptyString,
      inputVisible: false,
      confirmResolve: null,
      cancelReject: null,
      initialValue: constants.emptyString,
      inputPlaceholder: constants.emptyString,
    });
  };

  const handleConfirm = () => {
    try {
      if (typeof modalContent.confirmResolve === "function") {
        const val = inputRef.current?.value ?? typedValueRef.current;
        const result = modalContent.checkboxLabel != null
          ? { value: val, checked: localChecked }
          : val;
        modalContent.confirmResolve(result);
      }
    } finally {
      closeModal();
    }
  };

  const handleCancel = () => {
    try {
      if (typeof modalContent.cancelReject === "function") {
        modalContent.cancelReject();
      }
    } finally {
      closeModal();
    }
  };

  /** 📌 실제 모달 렌더링 */
  const BrunnerMessageBox = useCallback(() => {
    if (!modalContent.isOpen) return null;

    const isObject = (value) => value && typeof value === "object" && !Array.isArray(value);

    const handleKeyDown = (e) => {
      if (isComposingRef.current || e.nativeEvent?.isComposing) return;
      if (e.key === "Enter") {
        if (modalContent.multiline && e.target?.tagName === "TEXTAREA") return;
        e.preventDefault();
        handleConfirm();
      } else if (e.key === "Escape") {
        if (modalContent.cancelVisible) handleCancel();
      }
    };

    const color = getColorClassByTitle(modalContent.title);

    const modalNode = (
      <>
        {loading && <Loading />}
        <div
          data-brunner-modal
          className="flex items-center justify-center fixed inset-0 text-sm"
          style={{ zIndex: 1000002, backgroundColor: "rgba(0,0,0,0.5)" }}
          onKeyDown={handleKeyDown}
        >
          <div className="rounded-lg p-8 h-auto w-auto min-w-[350px] max-w-[90vw] general-text-bg-color general-text-color">
            {modalContent.title && (
              <h2 className={`text-xl font-bold mb-4 border-b semi-text-bg-color pb-2 ${color.title}`}>
                {modalContent.title}
              </h2>
            )}

            <p className="text-smtext-left mb-4 whitespace-pre-line">
              {isObject(modalContent.message) ? JSON.stringify(modalContent.message) : modalContent.message}
            </p>

            {modalContent.inputVisible && (
              modalContent.multiline ? (
                <textarea
                  ref={inputRef}
                  rows={4}
                  className="mb-4 w-full rounded-md border border-[var(--border-color)] dark:border-[var(--border-strong)] px-3 py-2 text-sm outline-none focus:border-brand-blue focus:ring-1 focus:ring-brand-blue general-text-color general-text-bg-color resize-none"
                  autoFocus
                  defaultValue={modalContent.initialValue ?? constants.emptyString}
                  placeholder={modalContent.inputPlaceholder || constants.emptyString}
                  onChange={(e) => { typedValueRef.current = e.target.value; }}
                  onCompositionStart={() => { isComposingRef.current = true; }}
                  onCompositionEnd={(e) => {
                    isComposingRef.current = false;
                    typedValueRef.current = e.target.value;
                  }}
                />
              ) : (
                <input
                  ref={inputRef}
                  className="mb-4 h-11 w-full rounded-md border border-[var(--border-color)] dark:border-[var(--border-strong)] px-3 text-sm outline-none focus:border-brand-blue focus:ring-1 focus:ring-brand-blue general-text-color general-text-bg-color"
                  autoFocus
                  defaultValue={modalContent.initialValue ?? constants.emptyString}
                  placeholder={modalContent.inputPlaceholder || constants.emptyString}
                  onChange={(e) => { typedValueRef.current = e.target.value; }}
                  onCompositionStart={() => { isComposingRef.current = true; }}
                  onCompositionEnd={(e) => {
                    isComposingRef.current = false;
                    typedValueRef.current = e.target.value;
                  }}
                />
              )
            )}

            {modalContent.checkboxLabel && (
              <label className="flex items-center gap-2 mb-4 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={localChecked}
                  onChange={(e) => setLocalChecked(e.target.checked)}
                  className="w-4 h-4 accent-purple-500"
                />
                <span>{modalContent.checkboxLabel}</span>
              </label>
            )}

            <div className="flex justify-center gap-2">
              <Button
                autoFocus={!modalContent.inputVisible}
                className="font-bold px-4 py-2 border-transparent"
                style={color.okStyle}
                onClick={handleConfirm}
              >
                OK
              </Button>
              {modalContent.cancelVisible && (
                <Button
                  className="font-bold py-2 px-4 rounded"
                  style={{
                    backgroundColor: "var(--button-surface)",
                    color: "var(--button-text)",
                    borderColor: "var(--button-border)",
                  }}
                  onClick={handleCancel}
                >
                  Cancel
                </Button>
              )}
            </div>
          </div>
        </div>
      </>
    );

    if (typeof document === "undefined") return null;
    return createPortal(modalNode, document.body);
  }, [loading, modalContent, localChecked]);

  return {
    BrunnerMessageBox,
    openOkCancelModal,
    openOkModal,
    openInputModal,
    openInputWithCheckboxModal,
    setLoading,
    loading,
  };
};
