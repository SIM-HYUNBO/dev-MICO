"use client";

import { useState, useEffect } from "react";

import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";

export default function PdfViewer({ fileUrl }) {
  const [currentLanguageCode, setCurrentLanguageCode] = useState(null);

  useEffect(() => {
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());
  }, []);

  if (!fileUrl) {
    return (
      <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
        {commonFunctions.getResourceByLanguage(
          `noPdfFile`,
          constants.resourceType.label,
          currentLanguageCode,
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col w-full h-full bg-gray-100 dark:bg-neutral-900">
      {/* 상단 바 */}
      <div className="flex items-center justify-between px-4 py-2 bg-white dark:bg-neutral-800 shadow">
        <span className="text-sm font-medium text-gray-700 dark:text-gray-200">
          {commonFunctions.getResourceByLanguage(
            `userManual`,
            constants.resourceType.label,
            currentLanguageCode,
          )}
        </span>

        <a
          href={encodeURI(fileUrl)}
          download
          className="text-sm text-brand-blue dark:text-brand-blue hover:underline"
        >
          {commonFunctions.getResourceByLanguage(
            `download`,
            constants.resourceType.label,
            currentLanguageCode,
          )}
        </a>
      </div>

      {/* PDF 뷰어 */}
      <div className="flex-1">
        <iframe
          src={encodeURI(fileUrl)}
          title="PDF Viewer"
          className="w-full h-full border-0 bg-white"
        />
      </div>
    </div>
  );
}
