"use client";

import React, {
  useEffect,
  useLayoutEffect,
  useState,
  useRef,
  use,
  useMemo,
} from "react";
import { flushSync } from "react-dom";
import { getSocket } from "@/lib/socket";
import { setAppBadgeCount } from "@/lib/nativeBadge";

import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import { registerInAppBack } from "@/components/core/client/frames/backNavigationButton";
import Loading from "@/components/core/client/loading";
import Button from "@/components/core/client/ui/Button";
import Chip from "@/components/core/client/ui/Chip";
import Avatar from "@/components/core/client/ui/Avatar";
import Input from "@/components/core/client/ui/Input";

// 🔥 추가
import SmokingArea from "@/components/core/client/chatArea/smokingArea";
import CoffeeArea from "@/components/core/client/chatArea/coffeeArea";
import LinkPreviewCard, { extractFirstUrl } from "@/components/core/client/chatArea/LinkPreviewCard";
import { playCafeStartAndSip } from "@/lib/cafeSounds";
import { useSearchParams } from "next/navigation";

const DECRYPT_FAILURE_TEXTS = new Set(["[복호화 실패]", "[복호화실패]"]);
const DECRYPT_FAILURE_NOTICE = "암호화된 메시지를 열 수 없습니다.";
const isDecryptFailureText = (value) =>
  DECRYPT_FAILURE_TEXTS.has(String(value ?? "").trim());
const normalizeRoomId = (roomId) => String(roomId ?? "");
const createClientTempId = () =>
  `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
const EMOJI_CATEGORIES = [
  {
    id: "face",
    icon: "🙂",
    items: [
      "😂",
      "🥹",
      "🥲",
      "😭",
      "🤣",
      "😍",
      "🥰",
      "😎",
      "🤯",
      "🫠",
      "🫣",
      "😮‍💨",
      "💀",
      "😤",
      "🥸",
      "🤪",
    ],
  },
  {
    id: "gesture",
    icon: "👋",
    items: [
      "👋",
      "🤌",
      "🫶",
      "🫡",
      "🤙",
      "🫰",
      "👀",
      "💪",
      "🙏",
      "🤝",
      "🫂",
      "🙌",
      "👏",
      "🤦",
      "🤷",
      "🫠",
    ],
  },
  {
    id: "heart",
    icon: "❤️",
    items: [
      "❤️",
      "🩷",
      "💔",
      "🔥",
      "✨",
      "💯",
      "🎉",
      "🥳",
      "🎊",
      "😱",
      "😏",
      "🤩",
      "🫨",
      "💥",
      "🌈",
      "🎯",
    ],
  },
  {
    id: "animal",
    icon: "🐱",
    items: [
      "🐱",
      "🐶",
      "🐰",
      "🐻",
      "🦊",
      "🐸",
      "🐧",
      "🦋",
      "🌸",
      "🍀",
      "☀️",
      "🌙",
      "⚡",
      "🍕",
      "🧋",
      "🍫",
    ],
  },
];
const EMOJI_LABELS = {
  "😂": {
    "ko-KR": "웃겨서 눈물",
    "en-US": "Laughing tears",
    "ja-JP": "笑い泣き",
  },
  "🥹": { "ko-KR": "감동/울컥", "en-US": "Touched", "ja-JP": "感動" },
  "🥲": {
    "ko-KR": "웃으며 눈물",
    "en-US": "Smiling tear",
    "ja-JP": "笑顔の涙",
  },
  "😭": { "ko-KR": "엉엉 울음", "en-US": "Crying hard", "ja-JP": "大泣き" },
  "🤣": { "ko-KR": "박장대소", "en-US": "Rolling laugh", "ja-JP": "爆笑" },
  "😍": { "ko-KR": "반함", "en-US": "Heart eyes", "ja-JP": "大好き" },
  "🥰": { "ko-KR": "다정함", "en-US": "Affection", "ja-JP": "愛情" },
  "😎": { "ko-KR": "멋짐", "en-US": "Cool", "ja-JP": "クール" },
  "🤯": { "ko-KR": "충격/멘붕", "en-US": "Mind blown", "ja-JP": "衝撃" },
  "🫠": { "ko-KR": "녹아내림/민망함", "en-US": "Melting", "ja-JP": "溶ける" },
  "🫣": { "ko-KR": "몰래 봄", "en-US": "Peeking", "ja-JP": "こっそり見る" },
  "😮‍💨": { "ko-KR": "한숨", "en-US": "Sigh", "ja-JP": "ため息" },
  "💀": {
    "ko-KR": "너무 웃김/끝남",
    "en-US": "I'm dead",
    "ja-JP": "笑いすぎ/終わった",
  },
  "😤": { "ko-KR": "씩씩댐", "en-US": "Frustrated", "ja-JP": "ぷんぷん" },
  "🥸": { "ko-KR": "장난/변장", "en-US": "Disguised", "ja-JP": "変装" },
  "🤪": { "ko-KR": "장난스러움", "en-US": "Silly", "ja-JP": "ふざける" },
  "👋": { "ko-KR": "인사", "en-US": "Wave", "ja-JP": "挨拶" },
  "🤌": {
    "ko-KR": "딱 좋아/강조",
    "en-US": "Chef's kiss",
    "ja-JP": "最高/強調",
  },
  "🫶": { "ko-KR": "손하트", "en-US": "Heart hands", "ja-JP": "手ハート" },
  "🫡": { "ko-KR": "알겠어/경례", "en-US": "Salute", "ja-JP": "敬礼" },
  "🤙": { "ko-KR": "연락해/편하게", "en-US": "Call me", "ja-JP": "連絡して" },
  "🫰": {
    "ko-KR": "손가락 하트",
    "en-US": "Finger heart",
    "ja-JP": "指ハート",
  },
  "👀": { "ko-KR": "보고 있음", "en-US": "Watching", "ja-JP": "見てる" },
  "💪": { "ko-KR": "힘내", "en-US": "Strength", "ja-JP": "頑張ろう" },
  "🙏": {
    "ko-KR": "부탁/감사",
    "en-US": "Please/thanks",
    "ja-JP": "お願い/感謝",
  },
  "🤝": { "ko-KR": "합의/악수", "en-US": "Handshake", "ja-JP": "握手" },
  "🫂": { "ko-KR": "안아줌", "en-US": "Hug", "ja-JP": "ハグ" },
  "🙌": { "ko-KR": "만세", "en-US": "Hooray", "ja-JP": "ばんざい" },
  "👏": { "ko-KR": "박수", "en-US": "Applause", "ja-JP": "拍手" },
  "🤦": { "ko-KR": "아이고", "en-US": "Facepalm", "ja-JP": "やれやれ" },
  "🤷": { "ko-KR": "모르겠음", "en-US": "Shrug", "ja-JP": "わからない" },
  "❤️": { "ko-KR": "사랑", "en-US": "Love", "ja-JP": "愛" },
  "🩷": { "ko-KR": "따뜻한 마음", "en-US": "Warm heart", "ja-JP": "優しい心" },
  "💔": { "ko-KR": "상처", "en-US": "Heartbreak", "ja-JP": "失恋" },
  "🔥": { "ko-KR": "불타오름", "en-US": "On fire", "ja-JP": "燃える" },
  "✨": { "ko-KR": "반짝임", "en-US": "Sparkle", "ja-JP": "きらめき" },
  "💯": { "ko-KR": "완벽", "en-US": "Perfect", "ja-JP": "満点" },
  "🎉": { "ko-KR": "축하", "en-US": "Celebrate", "ja-JP": "お祝い" },
  "🥳": { "ko-KR": "파티", "en-US": "Party", "ja-JP": "パーティー" },
  "🎊": { "ko-KR": "축하 폭죽", "en-US": "Confetti", "ja-JP": "くす玉" },
  "😱": { "ko-KR": "깜짝 놀람", "en-US": "Shocked", "ja-JP": "びっくり" },
  "😏": { "ko-KR": "씨익", "en-US": "Smirk", "ja-JP": "にやり" },
  "🤩": { "ko-KR": "감탄", "en-US": "Starstruck", "ja-JP": "感激" },
  "🫨": { "ko-KR": "흔들림/멘붕", "en-US": "Shaken", "ja-JP": "動揺" },
  "💥": { "ko-KR": "펑/강조", "en-US": "Impact", "ja-JP": "衝撃" },
  "🌈": { "ko-KR": "무지개", "en-US": "Rainbow", "ja-JP": "虹" },
  "🎯": { "ko-KR": "정확히 맞음", "en-US": "Bullseye", "ja-JP": "的中" },
  "🐱": { "ko-KR": "고양이", "en-US": "Cat", "ja-JP": "猫" },
  "🐶": { "ko-KR": "강아지", "en-US": "Dog", "ja-JP": "犬" },
  "🐰": { "ko-KR": "토끼", "en-US": "Rabbit", "ja-JP": "うさぎ" },
  "🐻": { "ko-KR": "곰", "en-US": "Bear", "ja-JP": "くま" },
  "🦊": { "ko-KR": "여우", "en-US": "Fox", "ja-JP": "きつね" },
  "🐸": { "ko-KR": "개구리", "en-US": "Frog", "ja-JP": "カエル" },
  "🐧": { "ko-KR": "펭귄", "en-US": "Penguin", "ja-JP": "ペンギン" },
  "🦋": { "ko-KR": "나비", "en-US": "Butterfly", "ja-JP": "蝶" },
  "🌸": { "ko-KR": "꽃", "en-US": "Flower", "ja-JP": "花" },
  "🍀": { "ko-KR": "행운", "en-US": "Good luck", "ja-JP": "幸運" },
  "☀️": { "ko-KR": "맑음", "en-US": "Sunny", "ja-JP": "晴れ" },
  "🌙": { "ko-KR": "밤/달", "en-US": "Moon", "ja-JP": "月" },
  "⚡": { "ko-KR": "번개/빠름", "en-US": "Lightning", "ja-JP": "雷" },
  "🍕": { "ko-KR": "피자", "en-US": "Pizza", "ja-JP": "ピザ" },
  "🧋": { "ko-KR": "버블티", "en-US": "Bubble tea", "ja-JP": "タピオカ" },
  "🍫": { "ko-KR": "초콜릿", "en-US": "Chocolate", "ja-JP": "チョコ" },
};
const DRAW_EMOJI_CATEGORY = "draw";
const STICKER_CATEGORY = "sticker";
const CUSTOM_EMOJI_CATEGORY = "custom";
const RECENT_EMOJI_CATEGORY = "recent";
const FAV_EMOJI_CATEGORY = "fav";
const RECENT_EMOJI_KEY = "recentEmojis";
const FAV_EMOJI_KEY = "favoriteEmojis";
const MAX_RECENT_EMOJIS = 24;
const CONFETTI_STICKER_STYLES = { fireworks: "fireworks", sparkler: "burst" };
const STICKER_PACK = [
  {
    id: "heart",
    emoji: "❤️",
    cls: "animate-pulse",
    labelKey: "chatStickerHeart",
  },
  {
    id: "party",
    emoji: "🎉",
    cls: "animate-bounce",
    labelKey: "chatStickerParty",
  },
  {
    id: "fireworks",
    emoji: "🎆",
    cls: "sticker-flicker",
    labelKey: "chatStickerFireworks",
  },
  {
    id: "sparkler",
    emoji: "🎇",
    cls: "sticker-wobble",
    labelKey: "chatStickerSparkler",
  },
  {
    id: "fire",
    emoji: "🔥",
    cls: "sticker-flicker",
    labelKey: "chatStickerFire",
  },
  {
    id: "cool",
    emoji: "😎",
    cls: "animate-bounce",
    labelKey: "chatStickerCool",
  },
  { id: "cry", emoji: "😭", cls: "sticker-shake", labelKey: "chatStickerCry" },
  {
    id: "clap",
    emoji: "👏",
    cls: "sticker-swing",
    labelKey: "chatStickerClap",
  },
  {
    id: "muscle",
    emoji: "💪",
    cls: "animate-pulse",
    labelKey: "chatStickerMuscle",
  },
  { id: "star", emoji: "⭐", cls: "animate-spin", labelKey: "chatStickerStar" },
  {
    id: "rainbow",
    emoji: "🌈",
    cls: "sticker-wobble",
    labelKey: "chatStickerRainbow",
  },
  {
    id: "devil",
    emoji: "😈",
    cls: "sticker-shake",
    labelKey: "chatStickerDevil",
  },
  {
    id: "skull",
    emoji: "💀",
    cls: "sticker-shake",
    labelKey: "chatStickerSkull",
  },
  { id: "ok", emoji: "🤌", cls: "animate-bounce", labelKey: "chatStickerOk" },
];
const CONFETTI_TRIGGER_EMOJIS = ["🎉", "🎊", "🥳", "🎆", "🎇"];
const DRAW_COLORS = [
  "#111827",
  "#ef4444",
  "#f97316",
  "#facc15",
  "#22c55e",
  "#38bdf8",
  "#6366f1",
  "#ec4899",
];
const EMOJI_DISPLAY_STORAGE = "brunner_emoji_display_mode";
const EMOJI_DISPLAY_LARGE = "large";
const EMOJI_DISPLAY_BUBBLE = "bubble";
const TEXT_FORMATS = {
  bold: { prefix: "**", suffix: "**" },
  highlight: { prefix: "==", suffix: "==" },
  red: { prefix: "{{red:", suffix: "}}" },
};
const EMOJI_ONLY_PATTERN =
  /^(?:[\p{Emoji_Presentation}\p{Extended_Pictographic}\u2600-\u27BF\uFE0F]|\p{Regional_Indicator}|\p{Emoji_Modifier}|\u200D|\s)+$/u;

const getRoomMemberCount = (room) => {
  const value = room?.member_count ?? room?.memberCount;
  const count = Number(value);
  return Number.isFinite(count) ? count : null;
};

const getRawRoomUnread = (room) =>
  Number(room?.unread_count ?? room?.unreadCount ?? 0);

const getRoomType = (room) => String(room?.room_type || "").toUpperCase();

const isDirectRoom = (room) => {
  const roomType = getRoomType(room);
  if (roomType === "OPEN") return false;
  if (roomType === "DIRECT") return true;
  const memberCount = getRoomMemberCount(room);
  if (memberCount !== null) return memberCount <= 2;
  return false;
};

const getDirectPeerId = (room) =>
  String(
    room?.direct_peer_user_id ??
      room?.directPeerUserId ??
      room?.peer_user_id ??
      room?.peerUserId ??
      "",
  ).trim();

const getDirectPeerName = (room) =>
  String(
    room?.direct_peer_name ??
      room?.directPeerName ??
      room?.peer_user_name ??
      room?.peerUserName ??
      "",
  ).trim();

const getCleanRoomName = (room) =>
  String(room?.name || "")
    .replaceAll("🔒", "")
    .replaceAll("?뵏", "")
    .trim();

const isVisibleRoomForFilter = (room, roomTypeFilter) => {
  const roomType = getRoomType(room);
  if (roomType === "OPEN") return false;

  const filter = String(roomTypeFilter || "").toUpperCase();
  if (filter === "DIRECT") return isDirectRoom(room);
  if (filter === "GROUP") return !isDirectRoom(room);
  return true;
};

const buildVisibleRoomEntries = (rooms, roomTypeFilter) => {
  const entries = [];
  const directBundles = new Map();

  for (const room of rooms) {
    if (!isVisibleRoomForFilter(room, roomTypeFilter)) continue;

    const peerId = isDirectRoom(room) ? getDirectPeerId(room) : "";
    if (!peerId) {
      entries.push(room);
      continue;
    }

    const key = `direct:${peerId}`;
    let bundle = directBundles.get(key);
    if (!bundle) {
      bundle = {
        id: key,
        room_type: "DIRECT",
        member_count: 2,
        __isDirectBundle: true,
        __directPeerId: peerId,
        __rooms: [],
        __firstIndex: entries.length,
      };
      directBundles.set(key, bundle);
      entries.push(bundle);
    }

    bundle.__rooms.push(room);
    if (room.is_secret) bundle.__secretRoom = room;
    else bundle.__normalRoom = room;
  }

  return entries.map((entry) => {
    if (!entry.__isDirectBundle) return entry;
    const normalRoom = entry.__normalRoom || null;
    const secretRoom = entry.__secretRoom || null;
    const entryRoom = normalRoom || secretRoom || entry.__rooms[0];
    const displaySource = entry.__rooms.find((room) => getDirectPeerName(room)) || entryRoom;
    const displayName = getDirectPeerName(displaySource) || getCleanRoomName(entryRoom) || entry.__directPeerId;
    const unread = entry.__rooms.reduce((sum, room) => sum + getRawRoomUnread(room), 0);

    return {
      ...entry,
      name: displayName,
      is_secret: !!secretRoom && !normalRoom,
      unread_count: unread,
      unreadCount: unread,
      __entryRoom: entryRoom,
      __normalRoom: normalRoom,
      __secretRoom: secretRoom,
      __displayName: displayName,
    };
  });
};

export default function ChatClient({
  externalRoomId,
  externalRoomName,
  onLeaveRoom,
  roomTypeFilter,
}) {
  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");

  const {
    BrunnerMessageBox,
    openOkCancelModal,
    openOkModal,
    openInputModal,
    openInputWithCheckboxModal,
  } = useModal();

  const [loading, setLoading] = useState(false);
  const socketRef = useRef(null);

  if (!socketRef.current) {
    socketRef.current = getSocket();
  }

  const socket = socketRef.current;
  const [rooms, setRooms] = useState([]);
  const visibleRooms = useMemo(
    () => buildVisibleRoomEntries(rooms, roomTypeFilter),
    [rooms, roomTypeFilter],
  );
  const roomsLoadedRef = useRef(false);
  const [currentRoom, setCurrentRoom] = useState(null);
  const [roomUsers, setRoomUsers] = useState([]);
  const userProfileMap = useMemo(
    () =>
      new Map(
        roomUsers.map((u) => [u.user_id, u.profile_image_src || null]),
      ),
    [roomUsers],
  );
  const [messages, setMessages] = useState([]);
  const [readCounts, setReadCounts] = useState({}); // { [messageId]: number }
  const [unreadCounts, setUnreadCounts] = useState({}); // { [roomId]: number }
  const [mutedRooms, setMutedRooms] = useState(() => {
    try {
      return new Set(
        JSON.parse(localStorage.getItem("brunner_muted_rooms") || "[]").map(
          normalizeRoomId,
        ),
      );
    } catch {
      return new Set();
    }
  });
  const mutedRoomsRef = useRef(mutedRooms);
  const [recentEmojis, setRecentEmojis] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(RECENT_EMOJI_KEY) || "[]");
    } catch {
      return [];
    }
  });
  const [favEmojis, setFavEmojis] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(FAV_EMOJI_KEY) || "[]");
    } catch {
      return [];
    }
  });
  useEffect(() => {
    mutedRoomsRef.current = mutedRooms;
  }, [mutedRooms]);
  const isRoomMuted = (roomId) =>
    mutedRoomsRef.current.has(normalizeRoomId(roomId));
  // 방 목록 배지는 rooms state의 unread 값을 기준으로 표시한다.
  const getRoomUnread = (r) => getRawRoomUnread(r);
  const clearRoomUnreadLocally = (roomId) => {
    const targetRoomId = normalizeRoomId(roomId);
    if (!targetRoomId) return;
    setRooms((prev) =>
      prev.map((r) =>
        normalizeRoomId(r.id) === targetRoomId
          ? { ...r, unread_count: 0, unreadCount: 0 }
          : r,
      ),
    );
    setUnreadCounts((prev) => {
      const next = { ...prev, [targetRoomId]: 0 };
      setAppBadgeCount(Object.values(next).reduce((s, v) => s + v, 0));
      return next;
    });
  };
  const getListDirectPeerId = (r) =>
    r.__directPeerId || (isDirectRoom(r) ? getDirectPeerId(r) : "");
  const getListDirectPeerName = (r) =>
    r.__displayName || (isDirectRoom(r) ? getDirectPeerName(r) : "");
  const getListNormalRoom = (r) =>
    r.__normalRoom || (!r.__isDirectBundle && !r.is_secret ? r : null);
  const getListEntryRoom = (r) => getListNormalRoom(r) || r.__entryRoom || r;
  const getListSecretRoom = (r) =>
    r.__secretRoom || (!r.__isDirectBundle && r.is_secret ? r : null);
  const getListNormalUnread = (r) => getRawRoomUnread(getListNormalRoom(r));
  const getListSecretUnread = (r) => getRawRoomUnread(getListSecretRoom(r));
  const getListPrimaryUnread = (r) =>
    getListDirectPeerId(r) ? getListNormalUnread(r) : getRoomUnread(r);
  const formatListUnread = (count) => (count > 99 ? "99+" : count);
  const renderListPrimaryUnread = (r) => {
    const unread = getListPrimaryUnread(r);
    if (unread <= 0) return null;
    return <Chip tone="danger">{formatListUnread(unread)}</Chip>;
  };
  const renderListSecretUnread = (r) => {
    const unread = getListSecretUnread(r);
    if (unread <= 0) return null;
    return <Chip tone="danger">{formatListUnread(unread)}</Chip>;
  };
  const renderListModeActions = (r, { onAfter } = {}) => {
    if (!getListDirectPeerId(r)) {
      return (
        <>
          {isListRoomMuted(r) && (
            <span className="text-xs text-[var(--text-muted)]">🔇</span>
          )}
          {renderListPrimaryUnread(r)}
        </>
      );
    }

    return (
      <>
        <button
          type="button"
          className="inline-flex min-h-7 items-center gap-1 rounded-full border border-[var(--border)] bg-[var(--surface)] px-2 text-xs font-semibold text-[var(--text)] hover:border-[var(--brand-blue)] hover:text-[var(--brand-blue)]"
          aria-label={tl("chatNormalShort")}
          title={tl("chatNormalShort")}
          onClick={(e) => {
            e.stopPropagation();
            enterListRoom(r);
            onAfter?.();
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              e.stopPropagation();
              enterListRoom(r);
              onAfter?.();
            }
          }}
        >
          {tl("chatNormalShort")}
          {renderListPrimaryUnread(r)}
        </button>
        <button
          type="button"
          className="inline-flex min-h-7 items-center gap-1 rounded-full border border-[var(--border)] bg-[var(--surface-alt)] px-2 text-xs font-semibold text-[var(--text)] hover:border-[var(--brand-blue)] hover:text-[var(--brand-blue)]"
          aria-label={tl("secretChat")}
          title={tl("secretChat")}
          onClick={(e) => {
            enterListSecretRoom(e, r);
            onAfter?.();
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              enterListSecretRoom(e, r);
              onAfter?.();
            }
          }}
        >
          🔒 {tl("chatSecretShort")}
          {renderListSecretUnread(r)}
        </button>
        {isListRoomMuted(r) && (
          <span className="text-xs text-[var(--text-muted)]">🔇</span>
        )}
      </>
    );
  };
  const isListRoomActive = (r) => {
    if (!currentRoom?.id) return false;
    if (String(currentRoom.id) === String(r.id)) return true;
    return (r.__rooms || []).some((room) => String(room.id) === String(currentRoom.id));
  };
  const isListRoomMuted = (r) => isRoomMuted(getListEntryRoom(r).id);
  const enterListRoom = (r) => {
    const normalRoom = getListNormalRoom(r);
    if (normalRoom) {
      enterRoom(normalRoom);
      return;
    }

    const peerId = getListDirectPeerId(r);
    if (peerId) {
      startDirectChat(peerId, getListDirectPeerName(r) || r.name, {
        requireFriend: false,
      });
      return;
    }

    enterRoom(getListEntryRoom(r));
  };
  const enterListRoomByKey = (e, r) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      enterListRoom(r);
    }
  };
  const enterListSecretRoom = (e, r) => {
    e.stopPropagation();
    const secretRoom = getListSecretRoom(r);
    if (secretRoom) {
      enterRoom(secretRoom);
      return;
    }

    const peerId = getListDirectPeerId(r);
    if (peerId) {
      startSecretChat(peerId, getListDirectPeerName(r) || r.name, {
        requireFriend: false,
      });
    }
  };
  const [input, setInput] = useState("");
  const [pendingImages, setPendingImages] = useState([]); // base64 이미지 배열 (복수 전송)
  const [lightboxIndex, setLightboxIndex] = useState(null); // 이미지 메시지 배열 내 인덱스
  const [videoUploading, setVideoUploading] = useState(false);
  const imageInputRef = useRef(null);
  const videoInputRef = useRef(null);
  const messageInputRef = useRef(null);
  const formatSelectionRef = useRef(null);
  const emojiPanelRef = useRef(null);
  const emojiCanvasRef = useRef(null);
  const isDrawingEmojiRef = useRef(false);
  const [showEmojiPanel, setShowEmojiPanel] = useState(false);
  const [showFormatPanel, setShowFormatPanel] = useState(false);
  const [formatSelectionText, setFormatSelectionText] = useState("");
  const [showToolPanel, setShowToolPanel] = useState(false);
  const [emojiCategory, setEmojiCategory] = useState(EMOJI_CATEGORIES[0].id);
  const [customEmojis, setCustomEmojis] = useState([]);
  const [customEmojiUploading, setCustomEmojiUploading] = useState(false);
  const [customEmojiAiGenerating, setCustomEmojiAiGenerating] = useState(false);
  const customEmojiInputRef = useRef(null);
  const [emojiDrawColor, setEmojiDrawColor] = useState(DRAW_COLORS[0]);
  const [emojiDisplayMode, setEmojiDisplayMode] = useState(() => {
    try {
      return localStorage.getItem(EMOJI_DISPLAY_STORAGE) || EMOJI_DISPLAY_LARGE;
    } catch {
      return EMOJI_DISPLAY_LARGE;
    }
  });
  const [activityType, setActivityType] = useState(null);
  const chatContainerRef = useRef(null);
  const audioRef = useRef({});
  const currentRoomRef = useRef(null);
  const lastMessageIdRef = useRef(0);
  const [hasMoreHistory, setHasMoreHistory] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const loadingMoreRef = useRef(false);
  const [isSmokingActive, setIsSmokingActive] = useState(false);
  const [isDrinkingActive, setIsDrinkingActive] = useState(false);
  const [canChat, setCanChat] = useState(false);
  const coffeeRef = useRef(null);
  const smokingRef = useRef(null);
  const lastActivityTypeRef = useRef(
    typeof window !== "undefined"
      ? localStorage.getItem("lastActivityType") || "coffee"
      : "coffee",
  );
  const [pendingSend, setPendingSend] = useState(null);
  const [hadSession, setHadSession] = useState(false);
  const [roomCafePrefs, setRoomCafePrefs] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("roomCafePrefs") || "{}");
    } catch {
      return {};
    }
  });
  const [activityAreaCollapsed, setActivityAreaCollapsed] = useState(() => {
    try {
      return localStorage.getItem("activityAreaCollapsed") === "true";
    } catch {
      return false;
    }
  });

  // activityType 변경 시 hadSession·음료/흡연 상태 리셋
  useEffect(() => {
    setHadSession(false);
    setIsDrinkingActive(false);
    setIsSmokingActive(false);
  }, [activityType]);
  const searchParams = useSearchParams();
  const chatScrollRef = useRef(null);
  const leavingRoomIdRef = useRef(null);
  const [chatIntro, setChatIntro] = useState("");
  const [showRoomDrawer, setShowRoomDrawer] = useState(false);
  const [showRoomActions, setShowRoomActions] = useState(false);
  const [friends, setFriends] = useState([]);
  const [showInvitePanel, setShowInvitePanel] = useState(false);
  const [inviteKeyword, setInviteKeyword] = useState("");
  const [inviteSearchResults, setInviteSearchResults] = useState([]);
  const [invitingUserId, setInvitingUserId] = useState(null);
  const [chatToast, setChatToast] = useState(null);
  const chatToastTimerRef = useRef(null);
  const swipeTouchStartX = useRef(null);
  const inviteCheckPromiseRef = useRef(null); // 초대 확인 중 방 입장 차단용
  const fetchPendingInvitesRef = useRef(null); // handleUserChanged 등 외부에서 호출용
  const [editingRoomName, setEditingRoomName] = useState(false);
  const [roomNameInput, setRoomNameInput] = useState("");
  const [showMembersPanel, setShowMembersPanel] = useState(false);
  const [contextMenu, setContextMenu] = useState(null); // { messageIndex, x, y }
  const [nameMenu, setNameMenu] = useState(null); // { x, y, userId, userName }
  const [editingMessage, setEditingMessage] = useState(null); // { index, id }
  const [replyingTo, setReplyingTo] = useState(null); // { id, userName, message }
  const [reactions, setReactions] = useState({}); // { [messageId]: { [emoji]: string[] } }
  const [reactionPicker, setReactionPicker] = useState(null); // { messageId, x, y }
  const [pendingRemove, setPendingRemove] = useState(null); // { messageId, emoji } — 리액션 삭제 2단계 확인
  const [typingUsers, setTypingUsers] = useState([]); // [{ userId, userName }]
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const typingTimerRef = useRef(null);
  const REACTION_EMOJIS = ["❤️", "😂", "👍", "👎", "😮", "😢", "🔥", "👏"];
  const longPressTimer = useRef(null);
  const longPressTriggered = useRef(false);
  const messageRefs = useRef({});
  const highlightTimer = useRef(null);
  const [highlightedMessageId, setHighlightedMessageId] = useState(null);
  const [pendingScrollMessageId, setPendingScrollMessageId] = useState(null);

  // 음성 메시지
  const [voiceState, setVoiceState] = useState("idle"); // 'idle' | 'recording' | 'preview'
  const [recordingSec, setRecordingSec] = useState(0);
  const [voiceDataUrl, setVoiceDataUrl] = useState(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const micStreamRef = useRef(null);
  const recordingTimerRef = useRef(null);
  const [dictating, setDictating] = useState(false);
  const [dictationInterim, setDictationInterim] = useState("");
  const [pendingInvites, setPendingInvites] = useState([]); // [{ invite_id, room_id, room_name, inviter_id, inviter_name }]
  const secretRoomKeysRef = useRef({});
  const secretRoomKeyCandidatesRef = useRef({});
  const verifiedRoomKeyPersistedRef = useRef({});
  const myE2EEPrivKeyRef = useRef(null);
  const myE2EEDeviceIdRef = useRef(null);
  const secretRoomRetryTimersRef = useRef({});
  const sentTempIdsRef = useRef(new Set());

  const fetchReactionsForIds = async (msgIds) => {
    if (!msgIds?.length || !currentLoginUserId || !currentRoomRef.current?.id)
      return;
    try {
      const token = userInfo.getLoginSessionToken?.() || "";
      const roomId = currentRoomRef.current.id;
      const res = await fetch(
        `/api/chat/reaction?userId=${currentLoginUserId}&roomId=${roomId}&messageIds=${msgIds.join(",")}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        },
      );
      if (!res.ok) return;
      const { reactions: data } = await res.json();
      if (data && Object.keys(data).length) {
        setReactions((prev) => ({ ...prev, ...data }));
      }
    } catch {}
  };

  const toggleReaction = (messageId, emoji, { fromPicker = false } = {}) => {
    if (!messageId || !emoji || !currentRoom) return;
    const mid = String(messageId);
    const users = reactions[mid]?.[emoji] || [];
    const hasReacted = users.includes(currentLoginUserId);
    if (fromPicker) {
      // picker에서는 즉시 토글
      socket.emit(
        hasReacted
          ? constants.websocketMessageType.removeReaction
          : constants.websocketMessageType.addReaction,
        {
          roomId: currentRoom.id,
          messageId,
          userId: currentLoginUserId,
          emoji,
        },
      );
      setReactionPicker(null);
      return;
    }
    if (hasReacted) {
      // pill 클릭: 이미 반응했으면 2단계 확인
      const isPending =
        pendingRemove?.messageId === mid && pendingRemove?.emoji === emoji;
      if (isPending) {
        // 2번째 클릭 → 실제 삭제
        socket.emit(constants.websocketMessageType.removeReaction, {
          roomId: currentRoom.id,
          messageId,
          userId: currentLoginUserId,
          emoji,
        });
        setPendingRemove(null);
      } else {
        // 1번째 클릭 → ✕ 표시만
        setPendingRemove({ messageId: mid, emoji });
      }
    } else {
      // 반응 안 했으면 즉시 추가
      socket.emit(constants.websocketMessageType.addReaction, {
        roomId: currentRoom.id,
        messageId,
        userId: currentLoginUserId,
        emoji,
      });
      setPendingRemove(null);
    }
    setReactionPicker(null);
  };

  const doSearch = async () => {
    if (!searchQuery.trim() || !currentRoom || !currentLoginUserId) return;
    setSearchLoading(true);
    setSearchResults([]);
    try {
      const token = userInfo.getLoginSessionToken?.() || "";
      const res = await fetch(
        `/api/chat/search?userId=${currentLoginUserId}&roomId=${currentRoom.id}&query=${encodeURIComponent(searchQuery)}`,
        { headers: { Authorization: `Bearer ${token}` } },
      );
      if (!res.ok) return;
      const { results } = await res.json();
      setSearchResults(results || []);
    } catch {
    } finally {
      setSearchLoading(false);
    }
  };

  const fireConfetti = async (style = "burst") => {
    const confetti = (await import("canvas-confetti")).default;
    if (style === "fireworks") {
      const end = Date.now() + 1500;
      const frame = () => {
        confetti({
          particleCount: 6,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ["#ff4444", "#ffaa00", "#44ff44", "#4444ff", "#ff44ff"],
        });
        confetti({
          particleCount: 6,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ["#ff4444", "#ffaa00", "#44ff44", "#4444ff", "#ff44ff"],
        });
        if (Date.now() < end) requestAnimationFrame(frame);
      };
      frame();
    } else {
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
        colors: [
          "#ff4444",
          "#ffaa00",
          "#44ff44",
          "#4488ff",
          "#ff44ff",
          "#44ffff",
        ],
      });
    }
  };

  const loadCustomEmojis = async () => {
    try {
      const uid = userInfo.getLoginUserId?.() || currentLoginUserId;
      const tok = userInfo.getLoginSessionToken?.();
      if (!uid || !tok) {
        setCustomEmojis([]);
        return;
      }
      const res = await fetch(
        `/api/chat/custom-emoji?userId=${encodeURIComponent(uid)}`,
        {
          headers: { Authorization: `Bearer ${tok}` },
        },
      );
      if (!res.ok) return;
      const { emojis } = await res.json();
      setCustomEmojis(emojis || []);
    } catch {}
  };

  const registerCustomEmoji = async (dataUrl, name) => {
    const uid = userInfo.getLoginUserId?.() || currentLoginUserId;
    const tok = userInfo.getLoginSessionToken?.();
    if (!uid || !tok) {
      await openOkModal(
        tl("chatCustomEmojiLoginRequired"),
        constants.messageCategory.Warning,
      );
      return;
    }
    setCustomEmojiUploading(true);
    try {
      const res = await fetch("/api/chat/custom-emoji", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${tok}`,
        },
        body: JSON.stringify({ userId: uid, dataUrl, name }),
      });
      if (!res.ok) {
        const { error } = await res.json().catch(() => ({}));
        await openOkModal(
          error || tl("chatCustomEmojiError"),
          constants.messageCategory.Error,
        );
        return;
      }
      await loadCustomEmojis();
    } catch {
      await openOkModal(
        tl("chatCustomEmojiError"),
        constants.messageCategory.Error,
      );
    } finally {
      setCustomEmojiUploading(false);
    }
  };

  const generateAiEmoji = async () => {
    const uid = userInfo.getLoginUserId?.() || currentLoginUserId;
    const tok = userInfo.getLoginSessionToken?.();
    if (!uid || !tok) {
      await openOkModal(
        tl("chatCustomEmojiLoginRequired"),
        constants.messageCategory.Warning,
      );
      return;
    }

    const prompt = await openInputModal(
      tl("chatAiEmojiPrompt"),
      "",
      constants.messageCategory.Info,
      true,
      tl("chatAiEmojiPromptExample"),
    );
    if (!prompt?.trim()) return;
    setCustomEmojiAiGenerating(true);
    try {
      const proxyRes = await fetch("/api/chat/ai-emoji", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${tok}`,
        },
        body: JSON.stringify({ userId: uid, prompt: prompt.trim() }),
        signal: AbortSignal.timeout(50000),
      });
      const proxyData = await proxyRes.json().catch(() => ({}));
      if (proxyRes.status === 401) {
        await openOkModal(
          tl("chatCustomEmojiLoginRequired"),
          constants.messageCategory.Warning,
        );
        return;
      }
      if (!proxyRes.ok)
        throw new Error(proxyData.error || `서버 오류 (${proxyRes.status})`);
      const { dataUrl, suggestedName } = proxyData;

      const defaultName = (suggestedName || prompt.trim()).slice(0, 10);
      const name = await openInputModal(
        tl("chatCustomEmojiNamePrompt"),
        defaultName,
        constants.messageCategory.Info,
      );
      if (!name) return;
      await registerCustomEmoji(dataUrl, name.slice(0, 20));
    } catch (e) {
      console.error("AI emoji error:", e);
      await openOkModal(
        e?.message || tl("chatCustomEmojiError"),
        constants.messageCategory.Error,
      );
    } finally {
      setCustomEmojiAiGenerating(false);
    }
  };

  const deleteCustomEmoji = async (id) => {
    const uid = userInfo.getLoginUserId?.() || currentLoginUserId;
    const tok = userInfo.getLoginSessionToken?.();
    if (!uid || !tok) {
      await openOkModal(
        tl("chatCustomEmojiLoginRequired"),
        constants.messageCategory.Warning,
      );
      return;
    }
    const ok = await openOkCancelModal(
      tl("chatCustomEmojiDeleteConfirm"),
      constants.messageCategory.Warning,
    );
    if (!ok) return;
    const res = await fetch(
      `/api/chat/custom-emoji?id=${id}&userId=${encodeURIComponent(uid)}`,
      {
        method: "DELETE",
        headers: { Authorization: `Bearer ${tok}` },
      },
    );
    if (!res.ok) {
      await openOkModal(
        tl("chatCustomEmojiError"),
        constants.messageCategory.Error,
      );
      return;
    }
    setCustomEmojis((prev) => prev.filter((e) => e.id !== id));
  };

  const fileToDataUrl = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

  const isAnimatedEmojiMime = (mimeType = "") =>
    ["image/gif", "image/webp"].includes(String(mimeType).toLowerCase());

  const prepareCustomEmojiDataUrl = async (file) => {
    if (isAnimatedEmojiMime(file.type)) {
      return fileToDataUrl(file);
    }
    return resizeImageToDataUrl(file, 160, 160);
  };

  const prepareCustomEmojiDataUrlFromBlob = async (blob) => {
    const dataUrl = await new Promise((resolve) => {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result);
      fr.readAsDataURL(blob);
    });
    if (isAnimatedEmojiMime(blob.type)) return dataUrl;
    return resizeDataUrlToDataUrl(dataUrl, 160, 160);
  };

  const handleCustomEmojiFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    e.target.value = "";
    if (!file.type.startsWith("image/")) {
      await openOkModal(
        tl("chatCustomEmojiOnlyImage"),
        constants.messageCategory.Error,
      );
      return;
    }
    const name = await openInputModal(
      tl("chatCustomEmojiNamePrompt"),
      "",
      constants.messageCategory.Info,
    );
    if (!name) return;
    const emojiDataUrl = await prepareCustomEmojiDataUrl(file);
    await registerCustomEmoji(emojiDataUrl, name.slice(0, 20));
  };

  const resizeDataUrlToDataUrl = (src, maxW, maxH) =>
    new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(maxW / img.width, maxH / img.height, 1);
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        canvas.getContext("2d").drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/png", 0.85));
      };
      img.src = src;
    });

  const resizeImageToDataUrl = (file, maxW, maxH) =>
    new Promise((resolve) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        const scale = Math.min(maxW / img.width, maxH / img.height, 1);
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement("canvas");
        canvas.width = w;
        canvas.height = h;
        canvas.getContext("2d").drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL("image/png", 0.85));
      };
      img.src = url;
    });

  const tl = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.label,
      currentLanguageCode,
    );
  const tm = (k) =>
    commonFunctions.getResourceByLanguage(
      k,
      constants.resourceType.message,
      currentLanguageCode,
    );
  const getEmojiTooltip = (emoji) => {
    const label =
      EMOJI_LABELS[emoji]?.[currentLanguageCode] ||
      EMOJI_LABELS[emoji]?.["ko-KR"];
    return label ? `${emoji} ${label}` : emoji;
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (socket.connected) {
        socket.emit("ping", Date.now());
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [socket]);

  useEffect(() => {
    currentRoomRef.current = currentRoom;
  }, [currentRoom]);

  const loadMoreHistoryRef = useRef(null);
  // true일 때: onOlderMessages가 flushSync+직접복원으로 처리 → useLayoutEffect는 스크롤 건드리지 않음
  const skipScrollToBottomRef = useRef(false);
  const scrollRafRef = useRef(null);
  const shouldStickToBottomRef = useRef(true);
  const lastAutoScrollMessageCountRef = useRef(0);

  // 새 메시지 → 맨 아래로 스크롤 (이전 메시지 로드 시엔 skipScrollToBottomRef로 건너뜀)
  useLayoutEffect(() => {
    const el = chatScrollRef.current;
    if (!el) return;

    if (skipScrollToBottomRef.current) {
      skipScrollToBottomRef.current = false;
      lastAutoScrollMessageCountRef.current = messages.length;
      return;
    }

    const countIncreased =
      messages.length > lastAutoScrollMessageCountRef.current;
    lastAutoScrollMessageCountRef.current = messages.length;
    if (!countIncreased) return;

    const lastMessage = messages[messages.length - 1];
    const isOwnLastMessage = lastMessage?.userId === currentLoginUserId;
    if (!shouldStickToBottomRef.current && !isOwnLastMessage) return;

    if (scrollRafRef.current) {
      cancelAnimationFrame(scrollRafRef.current);
      scrollRafRef.current = null;
    }
    scrollRafRef.current = requestAnimationFrame(() => {
      el.scrollTop = el.scrollHeight;
      scrollRafRef.current = null;
    });
  }, [messages, currentLoginUserId]);

  const focusMessageElement = (messageId) => {
    const targetId = String(messageId);
    const target = messageRefs.current[targetId];
    if (!target) return false;

    target.scrollIntoView({ behavior: "smooth", block: "center" });
    setHighlightedMessageId(targetId);

    if (highlightTimer.current) clearTimeout(highlightTimer.current);
    highlightTimer.current = setTimeout(() => {
      setHighlightedMessageId(null);
      highlightTimer.current = null;
    }, 1600);

    return true;
  };

  const scrollToReplyTarget = (replyTo) => {
    if (!replyTo?.id) return;
    if (focusMessageElement(replyTo.id)) return;

    setPendingScrollMessageId(String(replyTo.id));
    if (hasMoreHistory && !loadingMore) {
      loadMoreHistoryRef.current?.();
    }
  };

  useEffect(() => {
    if (!pendingScrollMessageId) return;
    if (focusMessageElement(pendingScrollMessageId)) {
      setPendingScrollMessageId(null);
      return;
    }
    if (hasMoreHistory && !loadingMore) {
      loadMoreHistoryRef.current?.();
      return;
    }
    if (!hasMoreHistory && !loadingMore) {
      setPendingScrollMessageId(null);
    }
  }, [messages, pendingScrollMessageId, hasMoreHistory, loadingMore]);

  useEffect(
    () => () => {
      if (highlightTimer.current) clearTimeout(highlightTimer.current);
    },
    [],
  );

  useEffect(() => {
    const handleVisibility = () => {
      const visible = document.visibilityState === "visible";
      if (visible && socket.disconnected) {
        socket.connect();
      }
      // 백그라운드로 내려가면 서버가 이 소켓을 온라인에서 제외해 푸시를 보내도록 알린다
      socket.emit("visibility", { visible });
    };

    document.addEventListener("visibilitychange", handleVisibility);
    return () =>
      document.removeEventListener("visibilitychange", handleVisibility);
  }, [socket]);

  useEffect(() => {
    const onReconnect = () => {
      // 연결/재연결 시 userId 등록 (방 입장 전에도 notifyInvited 수신 가능하도록)
      if (currentLoginUserId) {
        socket.emit("identify", { userId: currentLoginUserId });
      }

      const room = currentRoomRef.current;
      if (room) {
        socket.emit(constants.websocketMessageType.join, {
          roomId: room.id,
          userId: currentLoginUserId,
          userName: userInfo.getLoginUserName(),
          lastMessageId: lastMessageIdRef.current,
          suppressMessage: true,
        });

        getRoomUsers(room.id);
      }
    };

    socket.on("connect", onReconnect);
    // 이미 연결된 상태면 즉시 identify
    if (socket.connected && currentLoginUserId) {
      socket.emit("identify", { userId: currentLoginUserId });
    }
    return () => socket.off("connect", onReconnect);
  }, [socket, currentLoginUserId]);

  // 로그인/로그아웃 시 방 목록 갱신
  useEffect(() => {
    const systemCode = userInfo.getCurrentSystemCode();
    const userId = userInfo.getLoginUserId();
    const lang = userInfo.getCurrentLanguageCode();

    setCurrentSystemCode(systemCode);
    setCurrentLoginUserId(userId);
    setCurrentLanguageCode(lang);
  }, []);

  useEffect(() => {
    if (!currentSystemCode || !currentLoginUserId) return;

    loadRooms(currentSystemCode, currentLoginUserId);

    // 로그인 시 미처리 초대 조회
    const cacheKey = `pendingInvites_${currentLoginUserId}`;
    const fetchPendingInvites = () => {
      inviteCheckPromiseRef.current = RequestServer({
        commandName: constants.commands.CHATROOM_GET_PENDING_INVITES,
                loginUserId: currentLoginUserId,
      })
        .then((res) => {
          const invites = res.error_code === constants.errorCode.Success ? (res.invites || []) : [];
          try {
            localStorage.setItem(cacheKey, JSON.stringify(invites));
          } catch {}
          setPendingInvites(invites);
        })
        .finally(() => {
          inviteCheckPromiseRef.current = null;
        });
    };
    fetchPendingInvitesRef.current = fetchPendingInvites;

    fetchPendingInvites();

    // 앱이 닫혀있다 열릴 때 SW가 URL 파라미터로 초대 데이터를 전달한 경우 즉시 모달 표시
    const urlParams = new URLSearchParams(window.location.search);
    const inviteIdParam = urlParams.get("inviteId");
    if (inviteIdParam) {
      setPendingInvites((prev) => {
        if (prev.some((i) => String(i.invite_id) === String(inviteIdParam)))
          return prev;
        return [
          ...prev,
          {
            invite_id: inviteIdParam,
            room_id: urlParams.get("roomId"),
            room_name: urlParams.get("roomName"),
            inviter_id: urlParams.get("inviterId"),
            inviter_name: urlParams.get("inviterName"),
          },
        ];
      });
      window.history.replaceState({}, "", window.location.pathname);
    }

    // 푸시 알림 클릭 시 앱이 이미 열려있으면 서비스 워커가 메시지를 보냄 → pending 초대 재조회
    const onSwMessage = (e) => {
      if (e.data?.type === "NOTIFICATION_CLICK") {
        // 푸시 데이터에 초대 정보가 있으면 API 응답 기다리지 않고 즉시 모달 표시
        const inv = e.data.inviteData;
        if (inv?.inviteId) {
          setPendingInvites((prev) => {
            if (prev.some((i) => String(i.invite_id) === String(inv.inviteId)))
              return prev;
            return [
              ...prev,
              {
                invite_id: inv.inviteId,
                room_id: inv.roomId,
                room_name: inv.roomName,
                inviter_id: inv.inviterId,
                inviter_name: inv.inviterName,
              },
            ];
          });
        }
        fetchPendingInvites();
      }
    };
    navigator.serviceWorker?.addEventListener("message", onSwMessage);
    return () =>
      navigator.serviceWorker?.removeEventListener("message", onSwMessage);
  }, [currentSystemCode, currentLoginUserId]);

  // pendingInvites 변경 시 localStorage 동기화 (캐시 자동 갱신)
  useEffect(() => {
    if (!currentLoginUserId) return;
    try {
      localStorage.setItem(
        `pendingInvites_${currentLoginUserId}`,
        JSON.stringify(pendingInvites),
      );
    } catch {}
  }, [pendingInvites, currentLoginUserId]);

  // E2EE 초기화: 키 쌍 생성 또는 로드 → 공개키 서버 업로드
  useEffect(() => {
    if (!currentSystemCode || !currentLoginUserId) return;
    (async () => {
      try {
        const {
          loadOrGenerateKeyPair,
          getStoredPublicKeyJwk,
          getOrCreateDeviceId,
        } = await import("@/lib/e2ee");
        const { privateKey } = await loadOrGenerateKeyPair();
        myE2EEPrivKeyRef.current = privateKey;
        const deviceId = getOrCreateDeviceId();
        myE2EEDeviceIdRef.current = deviceId;
        const pubJwk = getStoredPublicKeyJwk();
        if (pubJwk) {
          const publicKey = JSON.stringify(pubJwk);
          await RequestServer({
            commandName: constants.commands.CHATROOM_SAVE_PUBLIC_KEY,
                        userId: currentLoginUserId,
            publicKey,
          });
          await RequestServer({
            commandName: constants.commands.CHATROOM_SAVE_DEVICE_PUBLIC_KEY,
                        userId: currentLoginUserId,
            deviceId,
            publicKey,
          });
        }

        // 키 로드 완료 시점에 이미 비밀방에 있으면 키 재설정 + 표시된 메시지 재복호화
        const room = currentRoomRef.current;
        if (room?.is_secret && !secretRoomKeysRef.current[room.id]) {
          try {
            const usersRes = await RequestServer({
              commandName: constants.commands.CHATROOM_USERS,
                            userId: currentLoginUserId,
              roomId: room.id,
            });
            const others = (usersRes.data || []).filter(
              (u) => u.user_id !== currentLoginUserId,
            );
            await setupSecretRoomKey(
              room.id,
              others.map((u) => u.user_id),
            );
          } catch {}

          if (secretRoomKeysRef.current[room.id]) {
            setMessages((prev) => {
              // 재복호화는 비동기라 별도 흐름으로 처리
              (async () => {
                const decrypted = await decryptSecretMessages(room.id, prev);
                setMessages(decrypted);
              })();
              return prev;
            });
          }
        }
      } catch {}
    })();
  }, [currentSystemCode, currentLoginUserId]);

  useEffect(() => {
    const handleUserChanged = ({ detail }) => {
      if (detail?.userId) {
        loadRooms();
        loadCustomEmojis();
        fetchPendingInvitesRef.current?.();
      } else {
        Object.keys(secretRoomRetryTimersRef.current).forEach(
          clearSecretRoomRetryTimer,
        );
        setRooms([]);
        setCurrentRoom(null);
        setMessages([]);
        setRoomUsers([]);
        setActivityType(null);
        setCanChat(false);
        setCustomEmojis([]);
      }
    };

    window.addEventListener("userChanged", handleUserChanged);

    return () => {
      window.removeEventListener("userChanged", handleUserChanged);
    };
  }, []);

  useEffect(() => {
    if (!showEmojiPanel) return;
    const close = (e) => {
      if (emojiPanelRef.current?.contains(e.target)) return;
      if (e.target?.closest?.("[data-chat-tool-panel]")) return;
      if (e.target?.closest?.("[data-brunner-modal]")) return;
      setShowEmojiPanel(false);
    };
    const t = setTimeout(() => {
      document.addEventListener("click", close);
      document.addEventListener("touchstart", close, { passive: true });
    }, 0);
    return () => {
      clearTimeout(t);
      document.removeEventListener("click", close);
      document.removeEventListener("touchstart", close);
    };
  }, [showEmojiPanel]);

  useEffect(() => {
    if (!showFormatPanel) return;
    const close = (e) => {
      if (e.target?.closest?.("[data-chat-format-panel]")) return;
      if (e.target?.closest?.("[data-brunner-modal]")) return;
      setShowFormatPanel(false);
    };
    const t = setTimeout(() => {
      document.addEventListener("click", close);
      document.addEventListener("touchstart", close, { passive: true });
    }, 0);
    return () => {
      clearTimeout(t);
      document.removeEventListener("click", close);
      document.removeEventListener("touchstart", close);
    };
  }, [showFormatPanel]);

  useEffect(() => {
    if (!showToolPanel) return;
    const close = (e) => {
      if (e.target?.closest?.("[data-chat-tool-panel]")) return;
      if (e.target?.closest?.("[data-brunner-modal]")) return;
      setShowToolPanel(false);
    };
    const t = setTimeout(() => {
      document.addEventListener("click", close);
      document.addEventListener("touchstart", close, { passive: true });
    }, 0);
    return () => {
      clearTimeout(t);
      document.removeEventListener("click", close);
      document.removeEventListener("touchstart", close);
    };
  }, [showToolPanel]);

  useEffect(() => {
    setChatIntro(
      commonFunctions.getResourceByLanguage(
        "SELECT_OR_CREATE_A_CHATROOM",
        constants.resourceType.message,
        userInfo.getCurrentLanguageCode(),
      ),
    );

    loadRooms();
    loadCustomEmojis();

    audioRef.current = {
      chat: new Audio("/sounds/chat.mp3"),
      join: new Audio("/sounds/enterLeave.mp3"),
      leave: new Audio("/sounds/enterLeave.mp3"),
    };

    Object.values(audioRef.current).forEach((a) => {
      a.preload = "auto";
      a.volume = 0.5;
    });

    if ("serviceWorker" in navigator && "PushManager" in window) {
      navigator.serviceWorker.register("/sw.js")
        .then((reg) => reg.update?.().catch(() => {}))
        .catch(() => {});
    }

    // SW → 앱 배지 업데이트 (Android Capacitor: setAppBadge 미지원 시 postMessage 경유)
    const handleSWMessage = (event) => {
      if (event.data?.type === "SET_BADGE") {
        setAppBadgeCount(event.data.count);
      }
    };
    navigator.serviceWorker?.addEventListener("message", handleSWMessage);
    return () =>
      navigator.serviceWorker?.removeEventListener("message", handleSWMessage);
  }, []);

  /* -------------------- 소켓 이벤트 -------------------- */

  useEffect(() => {
    const playWav = (type) => {
      const src = audioRef.current[type];
      if (!src) return;

      const audio = src.cloneNode(true);
      audio.volume = src.volume;
      audio.play().catch(() => {});
    };

    const normalizeTime = (m) => {
      if (m.time) return m;
      const raw = m.send_time || m.created_at || m.sent_at;
      if (raw) return { ...m, time: raw };
      if (m.ts) return { ...m, time: new Date(m.ts).toISOString() };
      return m;
    };

    const sendReadReceipt = (msgs) => {
      const room = currentRoomRef.current;
      if (!room) return;
      const ids = msgs.map((m) => m.id).filter(Boolean);
      if (ids.length === 0) return;
      socket.emit(constants.websocketMessageType.readReceipt, {
        roomId: room.id,
        userId: currentLoginUserId,
        messageIds: ids,
      });
    };

    const onHistory = async (msgs) => {
      const room = currentRoomRef.current;
      if (!msgs?.length) {
        clearRoomUnreadLocally(room?.id);
        return;
      }

      const lastMsg = msgs[msgs.length - 1];
      if (lastMsg.id) {
        lastMessageIdRef.current = lastMsg.id;
      }

      // DB에서 message가 null이면 삭제된 메시지로 처리
      let normalized = msgs
        .slice(-1000)
        .map((m) =>
          normalizeTime(m.message === null ? { ...m, deleted: true } : m),
        );

      // 비밀채팅방이면 클라이언트 복호화
      if (room?.is_secret) {
        normalized = await decryptSecretMessages(room.id, normalized);
        if (hasDecryptFailure(normalized)) {
          retrySecretRoomKeySync(
            room.id,
            roomUsers
              .map((u) => u.user_id)
              .filter((userId) => userId !== currentLoginUserId),
          );
        }
      }

      setMessages(normalized);
      sendReadReceipt(normalized);
      // 실제 history 로드 시점에 해당 방 미읽은 수 0으로 설정
      if (room) {
        clearRoomUnreadLocally(room.id);
      }
      // 리액션 로드
      const msgIds = normalized.map((m) => m.id).filter(Boolean);
      if (msgIds.length) fetchReactionsForIds(msgIds);
    };

    const onChat = async (msg) => {
      const activeRoom = currentRoomRef.current;
      // 모든 방의 메시지에 대해 방 목록 순서 갱신 (최근 메시지 순)
      if (msg.roomId) bringRoomToTop(msg.roomId, msg.time);
      if (!activeRoom || String(msg.roomId) !== String(activeRoom.id)) {
        // 비활성 방의 타인 메시지 → 미읽은 수 증가
        if (msg.userId && msg.userId !== currentLoginUserId) {
          setRooms((prev) =>
            prev.map((r) => {
              if (String(r.id) !== String(msg.roomId)) return r;
              const unread = Number(r.unread_count ?? r.unreadCount ?? 0) + 1;
              return { ...r, unread_count: unread, unreadCount: unread };
            }),
          );
          setUnreadCounts((prev) => {
            const next = { ...prev, [msg.roomId]: (prev[msg.roomId] ?? 0) + 1 };
            setAppBadgeCount(Object.values(next).reduce((s, v) => s + v, 0));
            return next;
          });
        }
        return;
      }

      msg.time = msg.time || new Date().toISOString();

      if (msg.id && msg.id <= lastMessageIdRef.current) return;
      if (msg.id) lastMessageIdRef.current = msg.id;

      if (msg.userId === currentLoginUserId) {
        if (!msg.id) return;
        // sentTempIdsRef에 있으면 이 기기에서 보낸 메시지 → 낙관적 id 업데이트 후 종료
        // 없으면 같은 계정 다른 기기(동시 접속)가 보낸 메시지 → 아래로 내려가 일반 표시
        if (msg.clientTempId && sentTempIdsRef.current.has(msg.clientTempId)) {
          sentTempIdsRef.current.delete(msg.clientTempId);
          setMessages((prev) => {
            const updated = [...prev];
            const tempIndex = updated.findIndex(
              (m) => m.clientTempId === msg.clientTempId,
            );
            if (tempIndex !== -1) {
              updated[tempIndex] = { ...updated[tempIndex], id: msg.id };
            }
            return updated;
          });
          return;
        }
      }

      // 비밀채팅방이면 복호화 후 표시
      let displayMsg = msg;
      if (activeRoom.is_secret) {
        displayMsg = (await decryptSecretMessages(activeRoom.id, [msg]))[0];
        if (hasDecryptFailure([displayMsg])) {
          retrySecretRoomKeySync(
            activeRoom.id,
            roomUsers
              .map((u) => u.user_id)
              .filter((userId) => userId !== currentLoginUserId),
          );
        }
      }

      setMessages((prev) => {
        if (msg.userId === currentLoginUserId && !msg.clientTempId) {
          const updated = [...prev];
          for (let i = updated.length - 1; i >= 0; i -= 1) {
            if (updated[i].userId === currentLoginUserId && !updated[i].id) {
              updated[i] = { ...updated[i], id: msg.id };
              return updated;
            }
          }
        }
        return [...prev, displayMsg].slice(-1000);
      });
      const plainText = String(displayMsg?.message || "");
      if (CONFETTI_TRIGGER_EMOJIS.some((e) => plainText.includes(e))) {
        fireConfetti("burst");
      }
      const rcvStickerMatch = plainText.match(/^\[sticker:([a-z0-9_]+)\]$/);
      if (rcvStickerMatch && rcvStickerMatch[1] in CONFETTI_STICKER_STYLES) {
        fireConfetti(CONFETTI_STICKER_STYLES[rcvStickerMatch[1]]);
      }
      if (!isRoomMuted(activeRoom.id)) {
        playWav(constants.websocketMessageType.chat);
      }
      sendReadReceipt([msg]);
    };

    const onReadReceiptUpdate = (updates) => {
      setReadCounts((prev) => {
        const next = { ...prev };
        for (const { messageId, readCount } of updates) {
          next[messageId] = readCount;
        }
        return next;
      });
    };

    const onJoin = ({ roomId, userId, userName }) => {
      if (
        normalizeRoomId(currentRoomRef.current?.id) !== normalizeRoomId(roomId)
      )
        return;

      const msg = {
        message: tm("ROOM_USER_ENTERED").replace("{0}", userName),
        isSystem: true,
        roomId,
        time: new Date().toISOString(),
      };

      if (userId !== currentLoginUserId && !isRoomMuted(roomId)) {
        playWav(constants.websocketMessageType.join);
      }

      setMessages((prev) => [...prev, msg].slice(-1000));
      getRoomUsers(roomId);

      // 단체 비밀방: 새 멤버에게 룸 키 자동 전달
      const room = currentRoomRef.current;
      if (room?.is_secret && !room?.partner_user_id) {
        const roomKey = secretRoomKeysRef.current[roomId];
        if (roomKey && myE2EEPrivKeyRef.current) {
          (async () => {
            try {
              const e2ee = await import("@/lib/e2ee");
              await persistRoomKeyForMembers(roomId, roomKey, [userId], e2ee);
            } catch (_) {}
          })();
        }
      }
    };

    const onLeave = ({ roomId, userId, userName }) => {
      if (
        normalizeRoomId(currentRoomRef.current?.id) !== normalizeRoomId(roomId)
      )
        return;

      const msg = {
        message: tm("ROOM_USER_LEFT").replace("{0}", userName),
        isSystem: true,
        roomId,
        time: new Date().toISOString(),
      };

      if (userId !== currentLoginUserId && !isRoomMuted(roomId)) {
        playWav(constants.websocketMessageType.leave);
      }

      setMessages((prev) => [...prev, msg].slice(-1000));
      getRoomUsers(roomId);
    };

    const onKicked = ({ roomId }) => {
      if (
        normalizeRoomId(currentRoomRef.current?.id) !== normalizeRoomId(roomId)
      )
        return;
      clearSecretRoomRetryTimer(roomId);
      setCurrentRoom(null);
      setMessages([]);
      setRoomUsers([]);
      resetActivityState();
      loadRooms(currentSystemCode, currentLoginUserId, { showLoading: false });
      openOkModal(tm("YOU_WERE_KICKED"), constants.messageCategory.Info);
    };

    const onMemberUpdate = ({ roomId }) => {
      if (
        normalizeRoomId(currentRoomRef.current?.id) === normalizeRoomId(roomId)
      )
        getRoomUsers(roomId);
    };

    const onSystemMessage = ({ roomId, message }) => {
      if (
        normalizeRoomId(currentRoomRef.current?.id) !== normalizeRoomId(roomId)
      )
        return;
      setMessages((prev) =>
        [
          ...prev,
          { message, time: new Date().toISOString(), isSystem: true },
        ].slice(-1000),
      );
    };

    const onMessageEdited = async ({ roomId, messageId, newMessage }) => {
      if (roomId && String(roomId) !== String(currentRoomRef.current?.id))
        return;

      let plaintext = newMessage;
      if (currentRoomRef.current?.is_secret) {
        plaintext = await decryptSecretMessage(
          currentRoomRef.current.id,
          newMessage,
        );
      }
      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId
            ? {
                ...m,
                message: plaintext,
                encryptedMessage: newMessage,
                edited: true,
              }
            : m,
        ),
      );
    };

    const onMessageDeleted = ({ roomId, messageId }) => {
      if (roomId && String(roomId) !== String(currentRoomRef.current?.id))
        return;

      setMessages((prev) =>
        prev.map((m) =>
          m.id === messageId ? { ...m, message: null, deleted: true } : m,
        ),
      );
    };

    const onHistoryMeta = ({ hasMore }) => {
      setHasMoreHistory(!!hasMore);
    };

    const onOlderMessages = async ({ messages: older, hasMore }) => {
      const el = chatScrollRef.current;
      const savedScrollHeight = el?.scrollHeight ?? 0;
      const savedScrollTop = el?.scrollTop ?? 0;

      let normalizedOlder = older.map(normalizeTime);

      // 비밀채팅방이면 복호화
      if (currentRoomRef.current?.is_secret) {
        normalizedOlder = await decryptSecretMessages(
          currentRoomRef.current.id,
          normalizedOlder,
        );
      }

      skipScrollToBottomRef.current = true;

      flushSync(() => {
        setMessages((prev) => {
          const existingIds = new Set(
            prev.filter((m) => m.id).map((m) => m.id),
          );
          const deduped = normalizedOlder.filter(
            (m) => !m.id || !existingIds.has(m.id),
          );
          return [...deduped, ...prev];
        });
        setHasMoreHistory(!!hasMore);
        loadingMoreRef.current = false;
        setLoadingMore(false);
      });

      if (el) {
        el.scrollTop = savedScrollTop + (el.scrollHeight - savedScrollHeight);
      }
    };

    const onSyncMessages = async (msgs) => {
      if (!msgs?.length) return;

      const lastMsg = msgs[msgs.length - 1];
      if (lastMsg.id && lastMsg.id > lastMessageIdRef.current) {
        lastMessageIdRef.current = lastMsg.id;
      }

      let normalized = msgs.map((m) =>
        normalizeTime(m.message === null ? { ...m, deleted: true } : m),
      );

      if (currentRoomRef.current?.is_secret) {
        normalized = await decryptSecretMessages(
          currentRoomRef.current.id,
          normalized,
        );
        if (hasDecryptFailure(normalized)) {
          retrySecretRoomKeySync(
            currentRoomRef.current.id,
            roomUsers
              .map((u) => u.user_id)
              .filter((userId) => userId !== currentLoginUserId),
          );
        }
      }

      setMessages((prev) => {
        const existingIds = new Set(prev.map((m) => m.id).filter(Boolean));
        const newMsgs = normalized.filter(
          (m) => !m.id || !existingIds.has(m.id),
        );
        return newMsgs.length > 0 ? [...prev, ...newMsgs].slice(-1000) : prev;
      });
      sendReadReceipt(normalized);
    };

    socket.on(constants.websocketMessageType.history, onHistory);
    socket.on(constants.websocketMessageType.syncMessages, onSyncMessages);
    socket.on(constants.websocketMessageType.chat, onChat);
    socket.on(constants.websocketMessageType.join, onJoin);
    socket.on(constants.websocketMessageType.leave, onLeave);
    socket.on(constants.websocketMessageType.kicked, onKicked);
    socket.on(constants.websocketMessageType.memberUpdate, onMemberUpdate);
    socket.on(constants.websocketMessageType.systemMessage, onSystemMessage);
    socket.on(
      constants.websocketMessageType.readReceiptUpdate,
      onReadReceiptUpdate,
    );
    socket.on(constants.websocketMessageType.messageEdited, onMessageEdited);
    socket.on(constants.websocketMessageType.messageDeleted, onMessageDeleted);
    socket.on("historyMeta", onHistoryMeta);
    socket.on("olderMessages", onOlderMessages);
    socket.on(
      constants.websocketMessageType.newRoomInvite,
      ({ inviteId, roomId, roomName, inviterName }) => {
        if (!inviteId) {
          // inviteId 없음 = startDirectChat/startSecretChat 알림 — DB 초대 없이 방 목록만 갱신
          loadRooms(currentSystemCode, currentLoginUserId);
          return;
        }
        setPendingInvites((prev) => {
          if (prev.some((i) => i.invite_id === inviteId)) return prev;
          return [
            ...prev,
            {
              invite_id: inviteId,
              room_id: roomId,
              room_name: roomName,
              inviter_name: inviterName,
            },
          ];
        });
      },
    );

    // 다른 기기가 룸키를 요청할 때: 보유 중인 키를 해당 기기에 배포
    const onRoomKeyRequest = async ({
      roomId,
      requesterId,
      deviceId,
      publicKey,
    }) => {
      if (!roomId || !requesterId || !deviceId || !publicKey) return;
      // 자기 기기가 보낸 요청은 무시 (동일 사용자 다른 기기는 처리)
      if (deviceId === myE2EEDeviceIdRef.current) return;
      // primary key 없으면 후보(ECDH 파생키 포함)를 대신 배포 — 같은 계정 다기기 복호화 지원
      const roomKey =
        secretRoomKeysRef.current[roomId] ||
        (secretRoomKeyCandidatesRef.current[roomId] || [])[0];
      if (!roomKey || !myE2EEPrivKeyRef.current) return;
      try {
        const e2ee = await import("@/lib/e2ee");
        const wrapped = await e2ee.wrapRoomKeyForMember(
          roomKey,
          myE2EEPrivKeyRef.current,
          publicKey,
        );
        const providerDeviceId = myE2EEDeviceIdRef.current || "default";
        await RequestServer({
          commandName: constants.commands.CHATROOM_SET_MEMBER_DEVICE_KEY,
                    userId: currentLoginUserId,
          roomId,
          targetUserId: requesterId,
          deviceId,
          encryptedKey: wrapped,
          keyProviderId: currentLoginUserId,
          keyProviderDeviceId: providerDeviceId,
        });
      } catch (_) {}
    };
    socket.on("roomKeyRequest", onRoomKeyRequest);

    const onStickerEffect = ({ style }) => fireConfetti(style || "burst");
    socket.on("stickerEffect", onStickerEffect);

    const onTypingUpdate = ({ roomId, typing }) => {
      if (roomId !== currentRoomRef.current?.id) return;
      setTypingUsers(
        (typing || []).filter((t) => t.userId !== currentLoginUserId),
      );
    };
    socket.on(constants.websocketMessageType.typingUpdate, onTypingUpdate);

    const onReactionUpdate = ({ messageId, userId, emoji, action }) => {
      const mid = String(messageId);
      setReactions((prev) => {
        const room = { ...(prev[mid] || {}) };
        const users = [...(room[emoji] || [])];
        if (action === "add" && !users.includes(userId)) {
          room[emoji] = [...users, userId];
        } else if (action === "remove") {
          room[emoji] = users.filter((u) => u !== userId);
          if (room[emoji].length === 0) delete room[emoji];
        }
        if (Object.keys(room).length === 0) {
          const next = { ...prev };
          delete next[mid];
          return next;
        }
        return { ...prev, [mid]: room };
      });
    };
    socket.on(constants.websocketMessageType.reactionUpdate, onReactionUpdate);

    return () => {
      socket.off(constants.websocketMessageType.history, onHistory);
      socket.off(constants.websocketMessageType.syncMessages, onSyncMessages);
      socket.off(constants.websocketMessageType.chat, onChat);
      socket.off(constants.websocketMessageType.join, onJoin);
      socket.off(constants.websocketMessageType.leave, onLeave);
      socket.off(constants.websocketMessageType.kicked, onKicked);
      socket.off(constants.websocketMessageType.memberUpdate, onMemberUpdate);
      socket.off("historyMeta", onHistoryMeta);
      socket.off("olderMessages", onOlderMessages);
      socket.off(constants.websocketMessageType.systemMessage, onSystemMessage);
      socket.off(
        constants.websocketMessageType.readReceiptUpdate,
        onReadReceiptUpdate,
      );
      socket.off(constants.websocketMessageType.messageEdited, onMessageEdited);
      socket.off(
        constants.websocketMessageType.messageDeleted,
        onMessageDeleted,
      );
      socket.off(constants.websocketMessageType.newRoomInvite);
      socket.off("roomKeyRequest", onRoomKeyRequest);
      socket.off("stickerEffect", onStickerEffect);
      socket.off(constants.websocketMessageType.typingUpdate, onTypingUpdate);
      socket.off(
        constants.websocketMessageType.reactionUpdate,
        onReactionUpdate,
      );
    };
  }, [socket, currentRoom]);

  // ─── 전화 통화 메뉴 ─────────────────────────────────────────────

  const nameMenuRef = useRef(null);

  // nameMenu 바깥 클릭/터치 시 닫기 (메뉴 내부는 무시)
  useEffect(() => {
    if (!nameMenu) return;
    const close = (e) => {
      if (nameMenuRef.current?.contains(e.target)) return;
      setNameMenu(null);
    };
    const t = setTimeout(() => {
      document.addEventListener("click", close);
      document.addEventListener("touchstart", close, { passive: true });
    }, 0);
    return () => {
      clearTimeout(t);
      document.removeEventListener("click", close);
      document.removeEventListener("touchstart", close);
    };
  }, [nameMenu]);

  // externalRoomId 자동 입장 — 최초 1회만 (수동으로 다른 방에 들어간 후에는 실행 안 함)
  const externalRoomEnteredRef = useRef(false);
  const lastHandledUrlRoomIdRef = useRef(null);
  useEffect(() => {
    if (!externalRoomId || !roomsLoadedRef.current) return;
    if (externalRoomEnteredRef.current) return; // 이미 입장했으면 skip

    const targetRoom = rooms.find(
      (r) => String(r.id) === String(externalRoomId),
    );
    if (targetRoom) {
      externalRoomEnteredRef.current = true;
      enterRoom(targetRoom);
    } else {
      externalRoomEnteredRef.current = true;
      setChatIntro(tm("CHATROOM_ACCESS_DENIED"));
      if (onLeaveRoom) onLeaveRoom();
    }
  }, [rooms, externalRoomId, onLeaveRoom]);

  // 방에 들어가 있는 동안에는 헤더 뒤로가기가 "방 목록"으로 가게 한다.
  // 방 선택은 URL을 바꾸지 않아 방문 이력에 남지 않으므로, 이 등록이 없으면
  // 뒤로가기가 채팅 화면 진입 이전(홈)으로 바로 빠져나갔다.
  useEffect(() => {
    if (!currentRoom) return undefined;
    const room = currentRoom;
    return registerInAppBack(
      () => {
        setCurrentRoom(null);
        return true; // 화면 안에서 처리했으므로 라우트 이동은 하지 않는다
      },
      () => enterRoom(room), // 앞으로가기 → 방으로 다시 들어간다
    );
  }, [currentRoom]);

  // 푸시 알림 클릭으로 진입 시 URL roomId 파라미터로 자동 입장
  const urlRoomId = searchParams.get("roomId");
  useEffect(() => {
    if (!urlRoomId || !currentSystemCode || !currentLoginUserId) return;
    if (lastHandledUrlRoomIdRef.current === String(urlRoomId)) return;
    if (leavingRoomIdRef.current === urlRoomId) return;
    if (!roomsLoadedRef.current) return;
    const targetRoom = rooms.find((r) => String(r.id) === String(urlRoomId));
    if (targetRoom) {
      lastHandledUrlRoomIdRef.current = String(urlRoomId);
      enterRoom(targetRoom);
    } else {
      lastHandledUrlRoomIdRef.current = String(urlRoomId);
      setChatIntro(tm("CHATROOM_ACCESS_DENIED"));
    }
  }, [rooms, urlRoomId, currentSystemCode, currentLoginUserId]);

  useEffect(() => {
    if (!urlRoomId || !currentSystemCode || !currentLoginUserId) return;
    loadRooms(currentSystemCode, currentLoginUserId, { showLoading: false });
  }, [urlRoomId, currentSystemCode, currentLoginUserId]);

  /* -------------------- API -------------------- */

  const scrollToBottom = () => {
    const el = chatScrollRef.current;
    if (!el) return;

    el.scrollTop = el.scrollHeight;
  };

  const bringRoomToTop = (roomId, time) => {
    setRooms((prev) => {
      const idx = prev.findIndex((r) => String(r.id) === String(roomId));
      if (idx <= 0) return prev;
      const updated = {
        ...prev[idx],
        last_message_at: time || new Date().toISOString(),
      };
      const rest = prev.filter((_, i) => i !== idx);
      return [updated, ...rest];
    });
  };

  const loadRooms = async (systemCodeParam, userIdParam, options = {}) => {
    const systemCodeVal = systemCodeParam || currentSystemCode;
    const userIdVal = userIdParam || currentLoginUserId;
    // 첫 로드에만 오버레이 표시 — 이후 갱신은 silent 처리
    const { showLoading = !roomsLoadedRef.current } = options;

    if (!systemCodeVal || !userIdVal) return;

    try {
      if (showLoading) setLoading(true);

      const res = await RequestServer({
        commandName: constants.commands.CHATROOM_LIST,
                userId: userIdVal,
      });

      if (res.error_code === constants.errorCode.Success) {
        const activeRoomId = normalizeRoomId(currentRoomRef.current?.id);
        const roomData = (res.data || []).map((r) =>
          activeRoomId && normalizeRoomId(r.id) === activeRoomId
            ? { ...r, unread_count: 0, unreadCount: 0 }
            : r,
        );
        setRooms(roomData);
        roomsLoadedRef.current = true;
        setUnreadCounts((prev) => {
          const next = {};
          for (const r of roomData) {
            const unread =
              r.unread_count ??
              r.unreadCount ??
              r.unread_message_count ??
              r.unreadMessageCount ??
              0;
            next[r.id] =
              activeRoomId && normalizeRoomId(r.id) === activeRoomId
                ? 0
                : Number(unread || 0);
          }
          const total = Object.values(next).reduce((s, v) => s + v, 0);
          setAppBadgeCount(total);
          return next;
        });
      }
    } finally {
      if (showLoading) setLoading(false);
    }
  };

  const toggleMuteRoom = (roomId) => {
    const targetRoomId = normalizeRoomId(roomId);
    if (!targetRoomId) return;
    setMutedRooms((prev) => {
      const next = new Set(prev);
      if (next.has(targetRoomId)) next.delete(targetRoomId);
      else next.add(targetRoomId);
      mutedRoomsRef.current = next;
      const list = [...next];
      try {
        localStorage.setItem("brunner_muted_rooms", JSON.stringify(list));
      } catch {}
      // SW가 IndexedDB를 통해 음소거 상태 확인하도록 동기화
      try {
        const req = indexedDB.open("brunner_prefs", 1);
        req.onupgradeneeded = (e) =>
          e.target.result.createObjectStore("muted_rooms", { keyPath: "key" });
        req.onsuccess = (e) => {
          const tx = e.target.result.transaction("muted_rooms", "readwrite");
          tx.objectStore("muted_rooms").put({ key: "list", value: list });
        };
      } catch {}
      return next;
    });
  };

  const getRoomUsers = async (roomId) => {
    try {
      const res = await RequestServer({
        commandName: constants.commands.CHATROOM_USERS,
                userId: currentLoginUserId,
        roomId,
      });

      if (res.error_code === constants.errorCode.Success) {
        setRoomUsers(res.data || []);
      }
    } catch {}
  };

  const activateRoomView = (room) => {
    flushSync(() => {
      resetActivityState();
      setCurrentRoom(room);
      setMessages([]);
      setReadCounts({});
      setReactions({});
      setTypingUsers([]);
      setShowSearch(false);
      setShowRoomActions(false);
      setSearchQuery("");
      setSearchResults([]);
      setHasMoreHistory(false);
      loadingMoreRef.current = false;
      setLoadingMore(false);
      setRoomUsers([]);
      setChatIntro("");
      setShowRoomDrawer(false);
    });
    currentRoomRef.current = room;
    lastMessageIdRef.current = 0;
  };

  const createRoom = async () => {
    if (!currentLoginUserId) {
      await openOkModal(
        tm("LOGIN_REQUIRED") || "로그인이 필요합니다.",
        constants.messageCategory.Info,
      );
      return;
    }
    const result = await openInputWithCheckboxModal(
      tl("roomName"),
      tl("myRoom"),
      `🔒 ${tl("makeSecretRoom")}`,
    ).catch(() => null);
    if (!result || !result.value?.trim()) return;

    const roomName = result.value.trim();
    const makeSecret = result.checked;

    const finalName = makeSecret ? `🔒 ${roomName}` : roomName;

    const res = await RequestServer({
      commandName: constants.commands.CHATROOM_CREATE,
            userId: currentLoginUserId,
      roomName: finalName,
      isSecret: makeSecret,
    });

    if (res.error_code === constants.errorCode.Success && res.roomId) {
      const newRoom = {
        id: res.roomId,
        name: finalName,
        is_secret: makeSecret,
      };
      if (makeSecret) {
        const e2ee = await import("@/lib/e2ee");
        const { generateRoomKey, saveRoomKeyLocally } = e2ee;
        const roomKey = await generateRoomKey();
        await saveRoomKeyLocally(res.roomId, roomKey);
        addSecretRoomKeyCandidate(res.roomId, roomKey, true);
        await persistRoomKeyForMembers(res.roomId, roomKey, [], e2ee);
      }
      flushSync(() => {
        setRooms((prev) => [
          newRoom,
          ...prev.filter((room) => String(room.id) !== String(newRoom.id)),
        ]);
      });
      const entered = await enterRoom(newRoom);
      if (entered) {
        setTimeout(() => messageInputRef.current?.focus(), 0);
        loadRooms(currentSystemCode, currentLoginUserId, {
          showLoading: false,
        });
      }
    } else if (res.error_code !== constants.errorCode.Success) {
      await openOkModal(
        res.error_message || tm("FAILED_TO_CREATE_ROOM"),
        constants.messageCategory.Info,
      );
    }
  };

  const resetActivityState = () => {
    setActivityType(null);
    setIsSmokingActive(false);
    setIsDrinkingActive(false);
    setCanChat(false);
  };

  const addSecretRoomKeyCandidate = (
    roomId,
    key,
    preferred = false,
    setPrimaryWhenMissing = true,
  ) => {
    if (!roomId || !key) return;
    const current = secretRoomKeyCandidatesRef.current[roomId] || [];
    const next = current.includes(key)
      ? current.filter((item) => item !== key)
      : current;
    secretRoomKeyCandidatesRef.current[roomId] = preferred
      ? [key, ...next]
      : [...next, key];
    if (
      preferred ||
      (setPrimaryWhenMissing && !secretRoomKeysRef.current[roomId])
    ) {
      secretRoomKeysRef.current[roomId] = key;
    }
  };

  const decryptSecretMessage = async (roomId, ciphertext) => {
    if (!ciphertext?.startsWith?.("sec:")) return ciphertext;
    const primaryKey = secretRoomKeysRef.current[roomId];
    const candidates = secretRoomKeyCandidatesRef.current[roomId] || [];
    const keys = primaryKey
      ? [primaryKey, ...candidates.filter((key) => key !== primaryKey)]
      : candidates;
    const { tryDecryptMessage } = await import("@/lib/e2ee");
    for (const key of keys) {
      const result = await tryDecryptMessage(key, ciphertext);
      if (result.ok) {
        if (secretRoomKeysRef.current[roomId] !== key) {
          secretRoomKeysRef.current[roomId] = key;
        }
        persistVerifiedRoomKey(roomId, key);
        return result.plaintext;
      }
    }
    return "[복호화 실패]";
  };

  const decryptSecretMessages = async (roomId, sourceMessages) =>
    Promise.all(
      (sourceMessages || []).map(async (m) => {
        if (m.deleted) return m;
        const encryptedMessage =
          m.encryptedMessage ||
          (m.message?.startsWith?.("sec:") ? m.message : null);
        if (
          !encryptedMessage &&
          !m.replyTo?.encryptedMessage &&
          !m.replyTo?.message?.startsWith?.("sec:")
        )
          return m;

        const result = { ...m };
        if (encryptedMessage) {
          const plaintext = await decryptSecretMessage(
            roomId,
            encryptedMessage,
          );
          result.message = plaintext;
          result.encryptedMessage = encryptedMessage;
        }
        const encryptedReplyMessage =
          m.replyTo?.encryptedMessage ||
          (m.replyTo?.message?.startsWith?.("sec:") ? m.replyTo.message : null);
        if (encryptedReplyMessage) {
          result.replyTo = {
            ...m.replyTo,
            message: await decryptSecretMessage(roomId, encryptedReplyMessage),
            encryptedMessage: encryptedReplyMessage,
          };
        }
        return result;
      }),
    );

  const hasDecryptFailure = (sourceMessages) =>
    (sourceMessages || []).some(
      (m) =>
        isDecryptFailureText(m?.message) ||
        isDecryptFailureText(m?.replyTo?.message),
    );

  const clearSecretRoomRetryTimer = (roomId) => {
    if (!roomId || !secretRoomRetryTimersRef.current[roomId]) return;
    clearTimeout(secretRoomRetryTimersRef.current[roomId]);
    delete secretRoomRetryTimersRef.current[roomId];
  };

  const retrySecretRoomKeySync = (roomId, memberUserIds = [], attempt = 1) => {
    if (!roomId || attempt > 5) return;
    clearTimeout(secretRoomRetryTimersRef.current[roomId]);
    secretRoomRetryTimersRef.current[roomId] = setTimeout(async () => {
      if (
        normalizeRoomId(currentRoomRef.current?.id) !== normalizeRoomId(roomId)
      ) {
        clearSecretRoomRetryTimer(roomId);
        return;
      }
      await setupSecretRoomKey(roomId, memberUserIds);
      setMessages((prev) => {
        (async () => {
          const next = await decryptSecretMessages(roomId, prev);
          if (
            normalizeRoomId(currentRoomRef.current?.id) !==
            normalizeRoomId(roomId)
          )
            return;
          setMessages(next);
          if (hasDecryptFailure(next)) {
            retrySecretRoomKeySync(roomId, memberUserIds, attempt + 1);
          } else {
            clearSecretRoomRetryTimer(roomId);
          }
        })();
        return prev;
      });
    }, attempt * 1200);
  };

  const getE2EEDevicePublicKeys = async (
    targetUserId,
    targetDeviceId = null,
  ) => {
    const res = await RequestServer({
      commandName: constants.commands.CHATROOM_GET_DEVICE_PUBLIC_KEYS,
            targetUserId,
      targetDeviceId,
    });
    return (res.publicKeys || []).filter((item) => item?.publicKey);
  };

  const getProviderPublicKey = async (targetUserId, targetDeviceId = null) => {
    const deviceKeys = await getE2EEDevicePublicKeys(
      targetUserId,
      targetDeviceId,
    );
    if (deviceKeys[0]?.publicKey) return deviceKeys[0].publicKey;

    return getLegacyPublicKey(targetUserId);
  };

  const getLegacyPublicKey = async (targetUserId) => {
    const legacyRes = await RequestServer({
      commandName: constants.commands.CHATROOM_GET_PUBLIC_KEY,
            targetUserId,
    });
    return legacyRes.publicKey || null;
  };

  const persistRoomKeyForMembers = async (
    roomId,
    roomKey,
    memberUserIds,
    e2ee,
  ) => {
    if (!roomId || !roomKey || !myE2EEPrivKeyRef.current) return;
    const providerDeviceId = myE2EEDeviceIdRef.current || "default";

    // 룸키를 DB에 직접 저장 — PC 오프라인 무관 기기간 공유
    // exportKey는 non-extractable 키에서 실패하므로 localStorage b64를 직접 사용
    try {
      const roomKeyB64 = e2ee.getRoomKeyB64Locally(roomId);
      if (roomKeyB64) {
        await RequestServer({
          commandName: constants.commands.CHATROOM_SAVE_ROOM_KEY,
                    userId: currentLoginUserId,
          roomId,
          roomKeyB64,
        });
      }
    } catch {}

    const targetIds = [
      ...new Set(
        [currentLoginUserId, ...(memberUserIds || [])]
          .filter(Boolean)
          .map(String),
      ),
    ];

    await Promise.all(
      targetIds.map(async (targetUserId) => {
        try {
          const publicKeys = await getE2EEDevicePublicKeys(targetUserId);
          await Promise.all(
            publicKeys.map(async ({ deviceId, publicKey }) => {
              const wrapped = await e2ee.wrapRoomKeyForMember(
                roomKey,
                myE2EEPrivKeyRef.current,
                publicKey,
              );
              await RequestServer({
                commandName: constants.commands.CHATROOM_SET_MEMBER_DEVICE_KEY,
                                userId: currentLoginUserId,
                roomId,
                targetUserId,
                deviceId,
                encryptedKey: wrapped,
                keyProviderId: currentLoginUserId,
                keyProviderDeviceId: providerDeviceId,
              });
            }),
          );

          const legacyPublicKey = publicKeys[0]?.publicKey;
          if (legacyPublicKey) {
            const wrapped = await e2ee.wrapRoomKeyForMember(
              roomKey,
              myE2EEPrivKeyRef.current,
              legacyPublicKey,
            );
            await RequestServer({
              commandName: constants.commands.CHATROOM_SET_MEMBER_KEY,
                            userId: currentLoginUserId,
              roomId,
              targetUserId,
              encryptedKey: wrapped,
              keyProviderId: currentLoginUserId,
            });
          }
        } catch {}
      }),
    );
  };

  const persistVerifiedRoomKey = async (roomId, roomKey) => {
    if (!roomId || !roomKey) return;
    try {
      const raw = await window.crypto.subtle.exportKey("raw", roomKey);
      const b64 = btoa(String.fromCharCode(...new Uint8Array(raw)));
      if (verifiedRoomKeyPersistedRef.current[roomId] === b64) return;
      verifiedRoomKeyPersistedRef.current[roomId] = b64;
      const e2ee = await import("@/lib/e2ee");
      e2ee.saveRoomKeyB64Locally(roomId, b64);
      await RequestServer({
        commandName: constants.commands.CHATROOM_SAVE_ROOM_KEY,
                userId: currentLoginUserId,
        roomId,
        roomKeyB64: b64,
      });
    } catch {}
  };

  const setupSecretRoomKey = async (
    roomId,
    memberUserIds = [],
    options = {},
  ) => {
    try {
      const e2ee = await import("@/lib/e2ee");
      if (!myE2EEPrivKeyRef.current) {
        const { privateKey } = await e2ee.loadOrGenerateKeyPair();
        myE2EEPrivKeyRef.current = privateKey;
      }
      if (!myE2EEDeviceIdRef.current) {
        myE2EEDeviceIdRef.current = e2ee.getOrCreateDeviceId();
      }
      const pubJwk = e2ee.getStoredPublicKeyJwk();
      if (pubJwk && currentSystemCode && currentLoginUserId) {
        const publicKey = JSON.stringify(pubJwk);
        await RequestServer({
          commandName: constants.commands.CHATROOM_SAVE_DEVICE_PUBLIC_KEY,
                    userId: currentLoginUserId,
          deviceId: myE2EEDeviceIdRef.current,
          publicKey,
        });
      }
      const otherUserIds = [
        ...new Set((memberUserIds || []).filter(Boolean).map(String)),
      ];
      let roomKey = null;
      let canPersistRoomKey = false;

      // localStorage 키는 과거 split-brain 키일 수 있으므로 후보로만 유지한다.
      const localKey = await e2ee.loadRoomKeyLocally(roomId);
      if (localKey) {
        addSecretRoomKeyCandidate(roomId, localKey, false, false);
      }

      // 1순위: DB 방별 룸키 후보 전체 조회 (과거 split-brain 키 복구)
      try {
        const roomKeyRes = await RequestServer({
          commandName: constants.commands.CHATROOM_GET_ROOM_KEY,
                    userId: currentLoginUserId,
          roomId,
        });
        const b64List = [
          ...(roomKeyRes.roomKeyB64List || []),
          roomKeyRes.roomKeyB64,
        ].filter(Boolean);
        for (const b64 of [...new Set(b64List)]) {
          const raw = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
          const candidateKey = await window.crypto.subtle.importKey(
            "raw",
            raw,
            { name: "AES-GCM", length: 256 },
            true,
            ["encrypt", "decrypt"],
          );
          if (!roomKey) {
            roomKey = candidateKey;
            addSecretRoomKeyCandidate(roomId, candidateKey, true);
            e2ee.saveRoomKeyB64Locally(roomId, b64);
          } else {
            addSecretRoomKeyCandidate(roomId, candidateKey, false, false);
          }
        }
      } catch {}

      // 2순위: 기기별 암호화된 룸키 (기존 호환)
      const deviceId = myE2EEDeviceIdRef.current;
      if (!roomKey && deviceId) {
        const wrappedDeviceKeyRes = await RequestServer({
          commandName: constants.commands.CHATROOM_GET_MEMBER_DEVICE_KEY,
                    userId: currentLoginUserId,
          roomId,
          deviceId,
        });
        if (
          wrappedDeviceKeyRes.encryptedKey &&
          wrappedDeviceKeyRes.keyProviderId
        ) {
          try {
            const providerPublicKey = await getProviderPublicKey(
              wrappedDeviceKeyRes.keyProviderId,
              wrappedDeviceKeyRes.keyProviderDeviceId || null,
            );
            if (providerPublicKey) {
              roomKey = await e2ee.unwrapRoomKey(
                wrappedDeviceKeyRes.encryptedKey,
                myE2EEPrivKeyRef.current,
                providerPublicKey,
              );
              addSecretRoomKeyCandidate(roomId, roomKey, true);
              await e2ee.saveRoomKeyLocally(roomId, roomKey);
              canPersistRoomKey = true;
            }
          } catch (e) {
            console.warn("[chat e2ee] failed to unwrap device room key", e);
          }
        }
      }

      // 3순위: 레거시 유저별 암호화된 룸키 (기존 호환)
      if (!roomKey) {
        const wrappedKeyRes = await RequestServer({
          commandName: constants.commands.CHATROOM_GET_MEMBER_KEY,
                    userId: currentLoginUserId,
          roomId,
        });
        if (wrappedKeyRes.encryptedKey && wrappedKeyRes.keyProviderId) {
          try {
            const providerPublicKey = await getLegacyPublicKey(
              wrappedKeyRes.keyProviderId,
            );
            if (providerPublicKey) {
              roomKey = await e2ee.unwrapRoomKey(
                wrappedKeyRes.encryptedKey,
                myE2EEPrivKeyRef.current,
                providerPublicKey,
              );
              addSecretRoomKeyCandidate(roomId, roomKey, true);
              await e2ee.saveRoomKeyLocally(roomId, roomKey);
              canPersistRoomKey = true;
            }
          } catch (e) {
            console.warn("[chat e2ee] failed to unwrap room key", e);
          }
        }
      }

      if (!roomKey && localKey) {
        roomKey = localKey;
        addSecretRoomKeyCandidate(roomId, localKey, true);
      }

      if (!roomKey && options.allowGenerate) {
        roomKey = await e2ee.generateRoomKey();
        addSecretRoomKeyCandidate(roomId, roomKey, true);
        await e2ee.saveRoomKeyLocally(roomId, roomKey);
        canPersistRoomKey = true;
      }

      if (roomKey && canPersistRoomKey) {
        await persistRoomKeyForMembers(roomId, roomKey, otherUserIds, e2ee);
      } else {
        // 키를 못 받은 경우 온라인 멤버에게 소켓으로 배포 요청
        const pubJwk = e2ee.getStoredPublicKeyJwk();
        if (pubJwk && deviceId && currentLoginUserId) {
          socket.emit("roomKeyRequest", {
            roomId,
            requesterId: currentLoginUserId,
            deviceId,
            publicKey: JSON.stringify(pubJwk),
          });
        }
      }

      // 1:1 ECDH 파생키: 룸키가 없으면 primary로 승격해 DB에 저장 (구형 방 복구)
      if (otherUserIds.length === 1) {
        const keyRes = await RequestServer({
          commandName: constants.commands.CHATROOM_GET_PUBLIC_KEY,
                    targetUserId: otherUserIds[0],
        });
        if (!keyRes.publicKey) return;
        const theirKey = await e2ee.importPublicKey(keyRes.publicKey);
        const derivedKey = await e2ee.deriveSharedKey(
          myE2EEPrivKeyRef.current,
          theirKey,
        );
        if (!roomKey) {
          // 룸키가 없는 구형 1:1 방: ECDH 파생키를 primary로 세팅하고 DB에 올려 다기기 공유
          roomKey = derivedKey;
          addSecretRoomKeyCandidate(roomId, roomKey, true);
          await e2ee.saveRoomKeyLocally(roomId, roomKey);
          await persistRoomKeyForMembers(roomId, roomKey, otherUserIds, e2ee);
        } else {
          addSecretRoomKeyCandidate(roomId, derivedKey, false);
        }
      }
    } catch {}
  };

  const enterRoom = async (room, { skipInviteCheck = false } = {}) => {
    // 초대 확인이 진행 중이면 완료까지 대기 → 초대 모달이 방 입장보다 먼저 표시됨
    if (!skipInviteCheck && inviteCheckPromiseRef.current) {
      await inviteCheckPromiseRef.current;
    }
    if (currentRoomRef.current?.id === room.id) return true;
    const prevRoom = currentRoomRef.current;

    if (prevRoom) {
      clearSecretRoomRetryTimer(prevRoom.id);
      socket.emit(constants.websocketMessageType.leave, {
        roomId: prevRoom.id,
        userId: currentLoginUserId,
        userName: userInfo.getLoginUserName(),
      });
      clearTimeout(secretRoomRetryTimersRef.current[prevRoom.id]);
      delete secretRoomRetryTimersRef.current[prevRoom.id];
    }

    activateRoomView(room);
    clearRoomUnreadLocally(room.id);

    if (room.is_secret) {
      // 비밀방: CHATROOM_USERS(키 준비)와 CHATROOM_ENTER(권한 확인)를 병렬 실행
      const [usersRes, enterResult] = await Promise.all([
        RequestServer({
          commandName: constants.commands.CHATROOM_USERS,
                    userId: currentLoginUserId,
          roomId: room.id,
        }),
        RequestServer({
          commandName: constants.commands.CHATROOM_ENTER,
                    userId: currentLoginUserId,
          roomId: room.id,
        }),
      ]);

      if (currentRoomRef.current?.id !== room.id) return false;

      if (enterResult.error_code !== constants.errorCode.Success) {
        setCurrentRoom(null);
        currentRoomRef.current = null;
        setMessages([]);
        setRoomUsers([]);
        setChatIntro(enterResult.error_message || tm("CHATROOM_ACCESS_DENIED"));
        return false;
      }

      // 권한 확인 후 키 준비 (과거 버전 호환: ECDH/룸키 후보 모두 확보)
      try {
        const others = (usersRes.data || []).filter(
          (u) => u.user_id !== currentLoginUserId,
        );
        await setupSecretRoomKey(
          room.id,
          others.map((u) => u.user_id),
        );
      } catch {}

      if (currentRoomRef.current?.id !== room.id) return false;

      socket.emit(constants.websocketMessageType.join, {
        roomId: room.id,
        userId: currentLoginUserId,
        userName: userInfo.getLoginUserName(),
        lastMessageId: 0,
      });
    } else {
      // 일반방: socket join과 CHATROOM_ENTER를 병렬로 시작 — 메시지 수신 지연 최소화
      const enterPromise = RequestServer({
        commandName: constants.commands.CHATROOM_ENTER,
                userId: currentLoginUserId,
        roomId: room.id,
      });

      socket.emit(constants.websocketMessageType.join, {
        roomId: room.id,
        userId: currentLoginUserId,
        userName: userInfo.getLoginUserName(),
        lastMessageId: 0,
      });

      const enterResult = await enterPromise;

      if (enterResult.error_code !== constants.errorCode.Success) {
        socket.emit(constants.websocketMessageType.leave, {
          roomId: room.id,
          userId: currentLoginUserId,
          userName: userInfo.getLoginUserName(),
        });
        setCurrentRoom(null);
        currentRoomRef.current = null;
        setMessages([]);
        setRoomUsers([]);
        setChatIntro(enterResult.error_message || tm("CHATROOM_ACCESS_DENIED"));
        return false;
      }
    }

    // 백그라운드에서 병렬 처리 — UI를 블로킹하지 않음
    Promise.all([
      RequestServer({
        commandName: constants.commands.CHATROOM_MARK_ALL_READ,
                userId: currentLoginUserId,
        roomId: room.id,
      }),
      getRoomUsers(room.id),
      loadFriends(),
    ]).finally(() => {
      loadRooms(currentSystemCode, currentLoginUserId, { showLoading: false });
    });

    return true;
  };

  const startDirectChat = async (
    targetUserId,
    targetUserName,
    { requireFriend = true } = {},
  ) => {
    if (!targetUserId || targetUserId === currentLoginUserId) return;

    // 친구 목록에 있는 경우에만
    const isFriend = friends.some((f) => f.friend_id === targetUserId);
    if (requireFriend && !isFriend) return;

    const res = await RequestServer({
      commandName: constants.commands.FRIEND_CHECK_CHATROOM_WITH_FRIEND,
            userId: currentLoginUserId,
      userName: userInfo.getLoginUserName(),
      friendId: targetUserId,
    });

    if (res.error_code === constants.errorCode.Success && res.roomId) {
      const newRoom = {
        id: res.roomId,
        name: res.roomName || targetUserName,
        is_secret: false,
        room_type: "DIRECT",
        member_count: 2,
        direct_peer_user_id: targetUserId,
        direct_peer_name: targetUserName,
      };
      setRooms((prev) =>
        prev.some((r) => r.id === newRoom.id) ? prev : [...prev, newRoom],
      );
      // 상대방 앱이 열려 있으면 즉시 방 목록 갱신
      socket.emit(constants.websocketMessageType.notifyInvited, {
        targetUserId,
        roomId: res.roomId,
        roomName: res.roomName || targetUserName,
        inviterName: userInfo.getLoginUserName?.() || "",
      });
      await enterRoom(newRoom);
    }
  };

  // 단톡방에서 이름 클릭: 비밀방 우선 → 일반방 → 없으면 비밀방 생성
  const startPreferredChat = async (targetUserId, targetUserName) => {
    if (!targetUserId || targetUserId === currentLoginUserId) return;
    const isFriend = friends.some((f) => f.friend_id === targetUserId);
    if (!isFriend) return;

    const res = await RequestServer({
      commandName: constants.commands.FRIEND_FIND_PREFERRED_CHATROOM,
            userId: currentLoginUserId,
      userName: userInfo.getLoginUserName(),
      friendId: targetUserId,
    });

    if (res.error_code !== constants.errorCode.Success) return;

    if (res.hasSecret && res.roomId) {
      await setupSecretRoomKey(res.roomId, [targetUserId], {
        allowGenerate: !!res.created,
      });
      const room = {
        id: res.roomId,
        name: res.roomName || `🔒 ${targetUserName}`,
        is_secret: true,
      };
      setRooms((prev) =>
        prev.some((r) => r.id === room.id) ? prev : [...prev, room],
      );
      await enterRoom(room);
    } else if (res.hasNormal && res.roomId) {
      const room = { id: res.roomId, name: res.roomName || targetUserName };
      setRooms((prev) =>
        prev.some((r) => r.id === room.id) ? prev : [...prev, room],
      );
      await enterRoom(room);
    } else {
      // 방이 없으면 비밀방 생성
      await startSecretChat(targetUserId, targetUserName);
    }
  };

  const getPersonPhoneNumber = (targetUserId) => {
    const friend = friends.find(
      (f) => String(f.friend_id) === String(targetUserId),
    );
    const roomUser = roomUsers.find(
      (u) => String(u.user_id) === String(targetUserId),
    );
    return (
      friend?.phone_number ||
      friend?.phoneNumber ||
      friend?.friend_phone_number ||
      friend?.friendPhoneNumber ||
      roomUser?.phone_number ||
      roomUser?.phoneNumber ||
      ""
    );
  };

  const connectPhoneCall = async (targetUserId) => {
    const phoneNumber = getPersonPhoneNumber(targetUserId);
    const normalized = String(phoneNumber || "").replace(/[^0-9+]/g, "");
    setNameMenu(null);
    if (!normalized) {
      await openOkModal(
        "전화번호가 등록되어 있지 않습니다.",
        constants.messageCategory.Info,
      );
      return;
    }
    window.location.href = `tel:${normalized}`;
  };

  const startSecretChat = async (
    targetUserId,
    targetUserName,
    { requireFriend = true } = {},
  ) => {
    if (!targetUserId || targetUserId === currentLoginUserId) return;
    const isFriend = friends.some((f) => f.friend_id === targetUserId);
    if (requireFriend && !isFriend) return;

    const res = await RequestServer({
      commandName: constants.commands.FRIEND_CHECK_SECRET_CHATROOM,
            userId: currentLoginUserId,
      userName: userInfo.getLoginUserName(),
      friendId: targetUserId,
    });

    if (res.error_code === constants.errorCode.Success && res.roomId) {
      // 키 사전 파생 후 입장
      await setupSecretRoomKey(res.roomId, [targetUserId]);
      const newRoom = {
        id: res.roomId,
        name: res.roomName || `🔒 ${targetUserName}`,
        is_secret: true,
        room_type: "DIRECT",
        member_count: 2,
        direct_peer_user_id: targetUserId,
        direct_peer_name: targetUserName,
      };
      setRooms((prev) =>
        prev.some((r) => r.id === newRoom.id) ? prev : [...prev, newRoom],
      );
      socket.emit(constants.websocketMessageType.notifyInvited, {
        targetUserId,
        roomId: res.roomId,
        roomName: res.roomName,
        inviterName: userInfo.getLoginUserName?.() || "",
      });
      enterRoom(newRoom);
    } else if (res.error_code !== constants.errorCode.Success) {
      await openOkModal(
        res.error_message || tl("secretChatPartnerNoKey"),
        constants.messageCategory.Info,
      );
    }
  };

  const loadMoreHistory = () => {
    if (!currentRoom || loadingMoreRef.current || !hasMoreHistory) return;
    const firstId = messages.find((m) => m.id)?.id;
    loadingMoreRef.current = true;
    setLoadingMore(true);
    socket.emit("loadMore", { roomId: currentRoom.id, beforeId: firstId });
  };

  // ref로 최신 함수 참조 유지 (스크롤 핸들러에서 클로저 stale 방지)
  useEffect(() => {
    loadMoreHistoryRef.current = loadMoreHistory;
  });

  // 스크롤이 상단 100px 이내에 오면 자동으로 이전 메시지 로드
  useEffect(() => {
    const el = chatScrollRef.current;
    if (!el) return;
    const handleScroll = () => {
      shouldStickToBottomRef.current =
        el.scrollHeight - el.scrollTop - el.clientHeight < 120;
      if (el.scrollTop < 100) loadMoreHistoryRef.current?.();
    };
    el.addEventListener("scroll", handleScroll, { passive: true });
    return () => el.removeEventListener("scroll", handleScroll);
  }, [currentRoom]);

  const leaveRoom = async () => {
    if (!currentRoom) return;

    leavingRoomIdRef.current = currentRoom.id;
    clearSecretRoomRetryTimer(currentRoom.id);

    await RequestServer({
      commandName: constants.commands.CHATROOM_LEAVE,
            userId: currentLoginUserId,
      roomId: currentRoom.id,
    });

    socket.emit(constants.websocketMessageType.leave, {
      roomId: currentRoom.id,
      userId: currentLoginUserId,
      userName: userInfo.getLoginUserName(),
    });

    setCurrentRoom(null);
    setMessages([]);
    // 나간 방을 즉시 목록에서 제거 후 서버 상태 동기화
    setRooms((prev) => prev.filter((r) => r.id !== currentRoom.id));
    onLeaveRoom?.();
    loadRooms(currentSystemCode, currentLoginUserId, { showLoading: false });
  };

  const loadFriends = async () => {
    try {
      const res = await RequestServer({
        commandName: constants.commands.FRIEND_LIST_BY_USER,
                userId: currentLoginUserId,
      });
      if (res.error_code === constants.errorCode.Success) {
        setFriends(res.data || []);
      }
    } catch {}
  };

  const handleInviteToggle = async () => {
    if (!showInvitePanel) {
      await loadFriends();
      setInviteKeyword("");
      setInviteSearchResults([]);
    }
    setShowInvitePanel((v) => !v);
  };

  const searchInviteUser = async (keyword) => {
    setInviteKeyword(keyword);
    if (!keyword.trim()) {
      setInviteSearchResults([]);
      return;
    }
    const res = await RequestServer({
      commandName: constants.commands.FRIEND_SEARCH_USER_BY_KEYWORD,
            userId: currentLoginUserId,
      keyword,
    });
    if (res.error_code === constants.errorCode.Success) {
      setInviteSearchResults(res.data || []);
    }
  };

  const inviteUser = async (friend) => {
    if (!currentRoom) return;

    const targetUserId = friend.friend_id || friend.user_id;
    const targetUserName = friend.user_name;

    if (invitingUserId) return; // 진행 중이면 중복 차단
    setInvitingUserId(targetUserId);

    try {
      const alreadyIn = roomUsers.some((u) => u.user_id === targetUserId);
      if (alreadyIn) {
        await openOkModal(
          tm("ROOM_ALREADY_IN").replace("{0}", targetUserName),
          constants.messageCategory.Info,
        );
        return;
      }

      // 비밀방 초대: 룸키가 있으면 상대방 공개키로 암호화해 DB에 저장, 없으면 초대만 진행
      if (currentRoom.is_secret) {
        let roomKey = secretRoomKeysRef.current[currentRoom.id];
        if (!roomKey && myE2EEPrivKeyRef.current) {
          // 메모리에 없으면 로컬/DB에서 재로드 시도
          const otherMemberIds = roomUsers
            .map((u) => u.user_id)
            .filter((userId) => userId !== currentLoginUserId);
          await setupSecretRoomKey(currentRoom.id, otherMemberIds);
          roomKey = secretRoomKeysRef.current[currentRoom.id];
        }
        if (roomKey && myE2EEPrivKeyRef.current) {
          const e2ee = await import("@/lib/e2ee");
          await persistRoomKeyForMembers(
            currentRoom.id,
            roomKey,
            [targetUserId],
            e2ee,
          );
          // 공개키가 아직 등록되지 않은 기기는 입장 후 자동 키 전달
        }
        // roomKey/privKey 없어도 초대는 계속 진행
      }

      const res = await RequestServer({
        commandName: constants.commands.CHATROOM_INVITE,
                roomId: currentRoom.id,
        targetUserId,
        inviterId: currentLoginUserId,
        inviterName: userInfo.getLoginUserName?.() || "",
        roomName: currentRoom.name || "",
      });

      if (res.error_code === constants.errorCode.Success) {
        setShowInvitePanel(false);
        setInviteKeyword("");
        setInviteSearchResults([]);
        clearTimeout(chatToastTimerRef.current);
        setChatToast(tl("inviteSent").replace("{0}", targetUserName));
        chatToastTimerRef.current = setTimeout(() => setChatToast(null), 2500);
        socket.emit(constants.websocketMessageType.systemMessage, {
          roomId: currentRoom.id,
          message: tm("INVITED_USER").replace("{0}", targetUserName),
        });
        // 초대받은 유저에게 소켓으로 초대 알림 (inviteId 포함)
        socket.emit(constants.websocketMessageType.notifyInvited, {
          targetUserId,
          roomId: currentRoom.id,
          roomName: currentRoom.name,
          inviterName: userInfo.getLoginUserName?.() || "",
          inviteId: res.inviteId,
        });
      } else {
        await openOkModal(
          res.error_message || tm("FAILED_TO_INVITE_USER"),
          constants.messageCategory.Error,
        );
      }
    } finally {
      setInvitingUserId(null);
    }
  };

  const handleAcceptInvite = async (invite) => {
    const res = await RequestServer({
      commandName: constants.commands.CHATROOM_ACCEPT_INVITE,
            loginUserId: currentLoginUserId,
      inviteId: invite.invite_id,
    });
    setPendingInvites((prev) =>
      prev.filter((i) => i.invite_id !== invite.invite_id),
    );
    if (res.error_code === constants.errorCode.Success) {
      // 참여 시스템 메시지 + 멤버 목록 갱신 브로드캐스트
      socket.emit(constants.websocketMessageType.systemMessage, {
        roomId: res.roomId,
        message: tm("ACCEPTED_ROOM_INVITE").replace(
          "{0}",
          userInfo.getLoginUserName?.() || currentLoginUserId,
        ),
      });
      socket.emit(constants.websocketMessageType.memberUpdate, {
        roomId: res.roomId,
      });
      // enterRoom 내부에서 loadRooms를 백그라운드 호출하므로 여기서 중복 호출 불필요
      // rooms state는 stale이므로 invite 데이터로 직접 방 구성
      enterRoom(
        { id: res.roomId, name: invite.room_name },
        { skipInviteCheck: true },
      );
    } else {
      await openOkModal(res.error_message, constants.messageCategory.Error);
    }
  };

  const handleRejectInvite = async (invite) => {
    await RequestServer({
      commandName: constants.commands.CHATROOM_REJECT_INVITE,
            loginUserId: currentLoginUserId,
      inviteId: invite.invite_id,
    });
    setPendingInvites((prev) =>
      prev.filter((i) => i.invite_id !== invite.invite_id),
    );
  };

  const handleCopyInviteLink = async () => {
    const res = await RequestServer({
      commandName: constants.commands.CHATROOM_CREATE_INVITE_TOKEN,
            userId: currentLoginUserId,
      roomId: currentRoom.id,
    });
    if (res.error_code !== constants.errorCode.Success) {
      await openOkModal(res.error_message, constants.messageCategory.Error);
      return;
    }
    const link = `${window.location.origin}/invite/${res.token}`;
    await navigator.clipboard.writeText(link);
    await openOkModal(
      `초대 링크가 복사되었습니다.\n카카오톡이나 문자로 붙여넣기 해서 전달하세요.`,
      constants.messageCategory.Info,
    );
  };

  const kickUser = async (targetUser) => {
    if (!currentRoom) return;

    const confirmed = await openOkCancelModal(
      tm("CONFIRM_KICK_USER").replace("{0}", targetUser.user_name),
      constants.messageCategory.Info,
    );
    if (!confirmed) return;

    const res = await RequestServer({
      commandName: constants.commands.CHATROOM_KICK,
            roomId: currentRoom.id,
      targetUserId: targetUser.user_id,
    });

    if (res.error_code === constants.errorCode.Success) {
      socket.emit(constants.websocketMessageType.kick, {
        roomId: currentRoom.id,
        targetUserId: targetUser.user_id,
        targetUserName: targetUser.user_name,
      });
      getRoomUsers(currentRoom.id);
    } else {
      await openOkModal(
        res.error_message || tm("FAILED_TO_KICK_USER"),
        constants.messageCategory.Error,
      );
    }
  };

  const renameRoom = async () => {
    const newName = roomNameInput.trim();
    if (!newName || newName === currentRoom.name) {
      setEditingRoomName(false);
      return;
    }

    const res = await RequestServer({
      commandName: constants.commands.CHATROOM_RENAME,
            userId: currentLoginUserId,
      roomId: currentRoom.id,
      roomName: newName,
    });

    if (res.error_code === constants.errorCode.Success) {
      setCurrentRoom((prev) => ({ ...prev, name: newName }));
      setRooms((prev) =>
        prev.map((r) =>
          r.id === currentRoom.id ? { ...r, name: newName } : r,
        ),
      );
      socket.emit(constants.websocketMessageType.systemMessage, {
        roomId: currentRoom.id,
        message:
          tm("ROOM_NAME_CHANGED")?.replace("{0}", newName) ||
          `방 이름이 "${newName}"(으)로 변경되었습니다.`,
      });
    } else {
      await openOkModal(
        res.error_message || tm("FAILED_TO_RENAME_ROOM"),
        constants.messageCategory.Error,
      );
    }
    setEditingRoomName(false);
  };

  const doSendMsg = async (data, isImage) => {
    const room = currentRoomRef.current;
    const currentReplyingTo = replyingTo;
    let secretKey = room?.is_secret ? secretRoomKeysRef.current[room.id] : null;

    if (room?.is_secret && !secretKey) {
      const otherMemberIds = roomUsers
        .map((u) => u.user_id)
        .filter((userId) => userId !== currentLoginUserId);
      await setupSecretRoomKey(room.id, otherMemberIds);
      secretKey = secretRoomKeysRef.current[room.id];
      if (!secretKey) {
        await openOkModal(
          "이 기기에서 아직 비밀방 키를 받을 수 없어. 키가 있는 다른 기기에서 같은 방에 들어온 뒤 다시 시도해줘.",
          constants.messageCategory.Info,
        );
        return;
      }
    }

    let wireMessage = data;
    let wireReplyTo = currentReplyingTo;

    if (secretKey) {
      const { encryptMessage } = await import("@/lib/e2ee");
      wireMessage = await encryptMessage(secretKey, data);
      if (currentReplyingTo?.message) {
        wireReplyTo = {
          ...currentReplyingTo,
          message: await encryptMessage(secretKey, currentReplyingTo.message),
        };
      }
    }

    // 낙관적 UI: 평문으로 즉시 표시
    const tempId = createClientTempId();
    sentTempIdsRef.current.add(tempId);
    const displayMsg = {
      clientTempId: tempId,
      roomId: room?.id,
      userId: currentLoginUserId,
      userName: userInfo.getLoginUserName(),
      message: data,
      time: new Date().toISOString(),
      ...(currentReplyingTo ? { replyTo: currentReplyingTo } : {}),
    };
    setMessages((prev) => [...prev, displayMsg]);
    if (!isImage && CONFETTI_TRIGGER_EMOJIS.some((e) => data.includes(e))) {
      fireConfetti("burst");
    }
    const stickerIdMatch = data.match(/^\[sticker:([a-z0-9_]+)\]$/);
    if (stickerIdMatch && stickerIdMatch[1] in CONFETTI_STICKER_STYLES) {
      fireConfetti(CONFETTI_STICKER_STYLES[stickerIdMatch[1]]);
    }

    // 소켓 전송: 비밀방이면 암호화된 내용
    const wireMsg = {
      ...displayMsg,
      message: wireMessage,
      ...(wireReplyTo ? { replyTo: wireReplyTo } : {}),
    };
    socket.emit(constants.websocketMessageType.chat, wireMsg);
    setReplyingTo(null);
    if (!isImage) setInput("");
  };

  const doSendImages = (images) => {
    if (!images.length) return;
    images.forEach((dataUrl) => doSendMsg(dataUrl, true));
    setPendingImages([]);
  };

  // ── 음성 메시지 ──────────────────────────────────────────
  const stopMicStream = () => {
    micStreamRef.current?.getTracks().forEach((t) => t.stop());
    micStreamRef.current = null;
    clearInterval(recordingTimerRef.current);
  };

  const dictatingActiveRef = useRef(false);
  const dictationMediaRef = useRef(null);
  const dictationChunksRef = useRef([]);

  const startDictation = async () => {
    if (dictatingActiveRef.current) {
      stopDictation();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported("audio/webm")
        ? "audio/webm"
        : MediaRecorder.isTypeSupported("audio/mp4")
          ? "audio/mp4"
          : "audio/ogg";
      const recorder = new MediaRecorder(stream, { mimeType });
      dictationChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) dictationChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        if (!dictationChunksRef.current.length) return;
        const blob = new Blob(dictationChunksRef.current, { type: mimeType });
        const base64 = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result.split(",")[1]);
          reader.readAsDataURL(blob);
        });
        setDictationInterim("변환 중...");
        try {
          const token = userInfo.getLoginSessionToken?.() || "";
          const res = await fetch("/api/chat/speech-to-text", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ audioBase64: base64, mimeType }),
          });
          const data = await res.json();
          if (data.text)
            setInput((prev) => (prev ? prev + " " + data.text : data.text));
          else if (data.error) openOkModal(tl("chatSttFailed") + ": " + data.error, "Error");
        } catch {
          openOkModal(tl("chatSttRequestFailed"), "Error");
        }
        setDictating(false);
        setDictationInterim("");
      };
      dictationMediaRef.current = recorder;
      dictatingActiveRef.current = true;
      recorder.start();
      setDictating(true);
      setDictationInterim("");
    } catch (e) {
      openOkModal(tl("chatMicPermission"), "Warning");
    }
  };

  const stopDictation = () => {
    dictatingActiveRef.current = false;
    if (dictationMediaRef.current?.state === "recording") {
      dictationMediaRef.current.stop();
    }
    dictationMediaRef.current = null;
  };

  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;
      const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : MediaRecorder.isTypeSupported("audio/mp4")
          ? "audio/mp4"
          : "audio/webm";
      const mr = new MediaRecorder(stream, { mimeType });
      audioChunksRef.current = [];
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      mr.start();
      mediaRecorderRef.current = mr;
      setVoiceState("recording");
      setRecordingSec(0);
      recordingTimerRef.current = setInterval(
        () => setRecordingSec((s) => s + 1),
        1000,
      );
    } catch {
      setVoiceState("idle");
    }
  };

  const stopVoiceRecording = () => {
    const mr = mediaRecorderRef.current;
    if (!mr) return;
    stopMicStream();
    mr.onstop = () => {
      if (!audioChunksRef.current.length) {
        setVoiceState("idle");
        return;
      }
      const blobMime = mr.mimeType.split(";")[0];
      const blob = new Blob(audioChunksRef.current, { type: blobMime });
      const reader = new FileReader();
      reader.onload = (e) => {
        setVoiceDataUrl(e.target.result);
        setVoiceState("preview");
      };
      reader.readAsDataURL(blob);
    };
    try {
      mr.stop();
    } catch {
      setVoiceState("idle");
    }
  };

  const sendVoiceMessage = () => {
    if (voiceDataUrl) doSendMsg(voiceDataUrl, false);
    setVoiceDataUrl(null);
    setVoiceState("idle");
    setRecordingSec(0);
  };

  const cancelVoiceRecording = () => {
    stopMicStream();
    try {
      mediaRecorderRef.current?.stop();
    } catch {}
    mediaRecorderRef.current = null;
    setVoiceDataUrl(null);
    setRecordingSec(0);
    setVoiceState("idle");
  };
  // ─────────────────────────────────────────────────────────

  const submitEditMessage = async () => {
    if (!editingMessage || !input.trim()) {
      setEditingMessage(null);
      setInput("");
      return;
    }
    const plaintext = input.trim();
    let secretKey = currentRoom?.is_secret
      ? secretRoomKeysRef.current[currentRoom.id]
      : null;
    if (currentRoom?.is_secret && !secretKey) {
      await setupSecretRoomKey(
        currentRoom.id,
        roomUsers
          .map((u) => u.user_id)
          .filter((userId) => userId !== currentLoginUserId),
      );
      secretKey = secretRoomKeysRef.current[currentRoom.id];
      if (!secretKey) {
        await openOkModal(
          "이 기기에서 아직 비밀방 키를 받을 수 없어. 키가 있는 다른 기기에서 같은 방에 들어온 뒤 다시 시도해줘.",
          constants.messageCategory.Info,
        );
        return;
      }
    }
    let newMessage = plaintext;
    if (secretKey) {
      const { encryptMessage } = await import("@/lib/e2ee");
      newMessage = await encryptMessage(secretKey, plaintext);
    }
    socket.emit(constants.websocketMessageType.messageEdit, {
      roomId: currentRoom.id,
      messageId: editingMessage.id,
      newMessage,
      userId: currentLoginUserId,
          });
    // 로컬 낙관적 업데이트 — 평문으로
    setMessages((prev) =>
      prev.map((m) =>
        m.id === editingMessage.id
          ? { ...m, message: plaintext, edited: true }
          : m,
      ),
    );
    setEditingMessage(null);
    setInput("");
  };

  const deleteMessage = (msg) => {
    if (!msg?.id) {
      setContextMenu(null);
      return;
    }
    socket.emit(constants.websocketMessageType.messageDelete, {
      roomId: currentRoom.id,
      messageId: msg.id,
      userId: currentLoginUserId,
          });
    setContextMenu(null);
  };

  const trackRecentEmoji = (emoji) => {
    setRecentEmojis((prev) => {
      const next = [emoji, ...prev.filter((e) => e !== emoji)].slice(
        0,
        MAX_RECENT_EMOJIS,
      );
      localStorage.setItem(RECENT_EMOJI_KEY, JSON.stringify(next));
      return next;
    });
  };

  const toggleFavEmoji = (emoji) => {
    setFavEmojis((prev) => {
      const next = prev.includes(emoji)
        ? prev.filter((e) => e !== emoji)
        : [...prev, emoji];
      localStorage.setItem(FAV_EMOJI_KEY, JSON.stringify(next));
      return next;
    });
  };

  const emojiLongPressRef = useRef({
    timer: null,
    triggered: false,
    moved: false,
    handledByTouch: false,
    startX: 0,
    startY: 0,
  });
  const onEmojiTouchStart = (emoji) => (e) => {
    emojiLongPressRef.current.triggered = false;
    emojiLongPressRef.current.moved = false;
    emojiLongPressRef.current.handledByTouch = false;
    const t = e?.touches?.[0];
    emojiLongPressRef.current.startX = t ? t.clientX : 0;
    emojiLongPressRef.current.startY = t ? t.clientY : 0;
    emojiLongPressRef.current.timer = setTimeout(() => {
      emojiLongPressRef.current.triggered = true;
      toggleFavEmoji(emoji);
      if (navigator.vibrate) navigator.vibrate(30);
    }, 500);
  };
  // 10px 이상 이동해야 스크롤로 간주 — 손가락 미세 흔들림은 여전히 탭으로 처리해
  // touchend 삽입이 누락되지 않도록 한다.
  const onEmojiTouchMove = (e) => {
    const t = e?.touches?.[0];
    if (!t) return;
    const dx = t.clientX - emojiLongPressRef.current.startX;
    const dy = t.clientY - emojiLongPressRef.current.startY;
    if (dx * dx + dy * dy > 100) {
      emojiLongPressRef.current.moved = true;
      clearTimeout(emojiLongPressRef.current.timer);
    }
  };
  // 짧은 탭은 touchend에서 바로 삽입 — iOS는 첫 탭의 synthesized click을 자주 누락해
  // 이모지가 첫 클릭에 안 들어가던 문제를 회피한다. 뒤이어 오는 click은 아래 플래그로 무시.
  const onEmojiTouchEnd = (emoji) => () => {
    clearTimeout(emojiLongPressRef.current.timer);
    if (
      !emojiLongPressRef.current.triggered &&
      !emojiLongPressRef.current.moved
    ) {
      emojiLongPressRef.current.handledByTouch = true;
      insertEmoji(emoji);
    }
    emojiLongPressRef.current.triggered = false;
  };
  const onEmojiClick = (emoji) => {
    if (emojiLongPressRef.current.handledByTouch) {
      emojiLongPressRef.current.handledByTouch = false;
      return;
    }
    if (!emojiLongPressRef.current.triggered) insertEmoji(emoji);
    emojiLongPressRef.current.triggered = false;
  };

  const insertEmoji = (emoji) => {
    const inputEl = messageInputRef.current;
    const start = inputEl?.selectionStart ?? input.length;
    const end = inputEl?.selectionEnd ?? input.length;
    const next = `${input.slice(0, start)}${emoji}${input.slice(end)}`;
    setInput(next);
    trackRecentEmoji(emoji);
    requestAnimationFrame(() => {
      messageInputRef.current?.focus();
      const caret = start + emoji.length;
      messageInputRef.current?.setSelectionRange(caret, caret);
    });
  };

  const wrapSelectedInput = (format) => {
    const markers = TEXT_FORMATS[format];
    if (!markers) return;
    const inputEl = messageInputRef.current;
    const savedSelection = formatSelectionRef.current;
    const start =
      savedSelection?.start ?? inputEl?.selectionStart ?? input.length;
    const end = savedSelection?.end ?? inputEl?.selectionEnd ?? input.length;
    const selected = input.slice(start, end) || tl("chatFormatSample");
    const wrapped = `${markers.prefix}${selected}${markers.suffix}`;
    const next = `${input.slice(0, start)}${wrapped}${input.slice(end)}`;
    const innerStart = start + markers.prefix.length;
    const nextSelection = {
      start: innerStart,
      end: innerStart + selected.length,
    };
    formatSelectionRef.current = nextSelection;
    setFormatSelectionText(selected);
    setInput(next);
    requestAnimationFrame(() => {
      const target = messageInputRef.current;
      target?.setSelectionRange(nextSelection.start, nextSelection.end);
    });
  };

  const focusFormattedInput = () => {
    const target = messageInputRef.current;
    const selection = formatSelectionRef.current;
    setShowFormatPanel(false);
    target?.focus?.({ preventScroll: true });
    requestAnimationFrame(() => {
      const nextTarget = messageInputRef.current;
      nextTarget?.focus?.({ preventScroll: true });
      if (selection)
        nextTarget?.setSelectionRange(selection.start, selection.end);
    });
  };

  const updateEmojiDisplayMode = (mode) => {
    setEmojiDisplayMode(mode);
    try {
      localStorage.setItem(EMOJI_DISPLAY_STORAGE, mode);
    } catch {}
  };

  const getEmojiCanvasPoint = (event) => {
    const canvas = emojiCanvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const source = event.touches?.[0] || event.changedTouches?.[0] || event;
    return {
      x: ((source.clientX - rect.left) / rect.width) * canvas.width,
      y: ((source.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const startEmojiDrawing = (event) => {
    const canvas = emojiCanvasRef.current;
    const point = getEmojiCanvasPoint(event);
    if (!canvas || !point) return;
    event.preventDefault?.();
    isDrawingEmojiRef.current = true;
    const ctx = canvas.getContext("2d");
    ctx.beginPath();
    ctx.moveTo(point.x, point.y);
  };

  const drawEmojiStroke = (event) => {
    if (!isDrawingEmojiRef.current) return;
    const canvas = emojiCanvasRef.current;
    const point = getEmojiCanvasPoint(event);
    if (!canvas || !point) return;
    event.preventDefault?.();
    const ctx = canvas.getContext("2d");
    ctx.lineWidth = 10;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.strokeStyle = emojiDrawColor;
    ctx.lineTo(point.x, point.y);
    ctx.stroke();
  };

  const stopEmojiDrawing = () => {
    isDrawingEmojiRef.current = false;
  };

  const clearEmojiCanvas = () => {
    const canvas = emojiCanvasRef.current;
    if (!canvas) return;
    canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);
  };

  // Draw 탭이 열릴 때 캔버스 버퍼를 CSS 너비에 맞게 조정 (색 변경 등 re-render 시엔 실행 안 됨)
  React.useEffect(() => {
    if (emojiCategory !== DRAW_EMOJI_CATEGORY) return;
    const canvas = emojiCanvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const w = rect.width > 0 ? Math.round(rect.width) : 280;
    if (canvas.width !== w) canvas.width = w;
    if (canvas.height !== 180) canvas.height = 180;
  }, [emojiCategory]);

  const addDrawnEmoji = () => {
    const canvas = emojiCanvasRef.current;
    if (!canvas) return;
    // 흰 배경 위에 합성해서 캡처 — 투명 PNG가 다크 배경에서 안 보이는 문제 방지
    const flat = document.createElement("canvas");
    flat.width = canvas.width;
    flat.height = canvas.height;
    const ctx = flat.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, flat.width, flat.height);
    ctx.drawImage(canvas, 0, 0);
    setPendingImages((prev) => [...prev, flat.toDataURL("image/png")]);
    clearEmojiCanvas();
    setShowEmojiPanel(false);
  };

  const sendMessage = () => {
    if (editingMessage) {
      submitEditMessage();
      return;
    }
    if (!currentRoom) return;

    const isImage = pendingImages.length > 0;
    const data = isImage ? pendingImages[0] : input;
    if (!data) return;
    setShowEmojiPanel(false);

    const activeType = activityType;
    const activeRef =
      activeType === "coffee"
        ? coffeeRef
        : activeType === "smoking"
          ? smokingRef
          : null;
    const isActive = activeRef?.current?.isActive?.() ?? false;

    if (!isActive) {
      // 다 마셨거나 끄고 난 후 → 리필 전까지 전송 차단
      if (hadSession) return;

      // 첫 메시지 — 자동 시작 후 전송
      const targetType = activeType || lastActivityTypeRef.current;

      if (activeType !== targetType) {
        if (targetType === "coffee") {
          const cafePref = roomCafePrefs[currentRoom?.id];
          playCafeStartAndSip({
            isDessert: ["dujjeonku", "shanghaibutter"].includes(
              cafePref?.drinkType,
            ),
            muted: isRoomMuted(currentRoom?.id),
          });
        }
        // 패널이 열려있지 않음 → 열고 대기 (useEffect에서 전송)
        setPendingSend(
          isImage
            ? { isImage: true, images: pendingImages }
            : { data, isImage: false },
        );
        setActivityType(targetType);
        return;
      }
      // 패널은 열려있지만 시작 안 됨 → 바로 시작
      activeRef?.current?.triggerStart();
      setHadSession(true);
    }

    if (isImage) {
      doSendImages(pendingImages);
    } else {
      doSendMsg(data, false);
    }

    // 메시지 전송 시 자동 한 모금
    if (activeType === "coffee") activeRef?.current?.triggerSip?.();
    else if (activeType === "smoking") activeRef?.current?.triggerPuff?.();
  };

  // 패널이 새로 열린 후 pendingSend 처리
  useEffect(() => {
    if (!pendingSend || !activityType) return;
    const ref = activityType === "coffee" ? coffeeRef : smokingRef;
    if (!ref.current) return;

    ref.current.triggerStart();
    setHadSession(true);
    if (pendingSend.isImage) {
      doSendImages(pendingSend.images);
    } else {
      doSendMsg(pendingSend.data, false);
    }
    if (activityType === "coffee") ref.current.triggerSip?.();
    else if (activityType === "smoking") ref.current.triggerPuff?.();

    setPendingSend(null);
  }, [pendingSend, activityType]); // eslint-disable-line

  const loadImageFile = (file, onLoad) => {
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) {
      openOkModal(tm("IMAGE_TOO_LARGE"), constants.messageCategory.Error);
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => onLoad(ev.target.result);
    reader.readAsDataURL(file);
  };

  const loadImageFiles = (files) => {
    const arr = Array.from(files).slice(0, 10); // 최대 10장
    let loaded = [];
    arr.forEach((file) => {
      loadImageFile(file, (dataUrl) => {
        loaded = [...loaded, dataUrl];
        setPendingImages((prev) => [...prev, dataUrl]);
      });
    });
  };

  const handlePaste = (e) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
      if (item.type.startsWith("image/")) {
        e.preventDefault();
        loadImageFile(item.getAsFile(), (dataUrl) =>
          setPendingImages((prev) => [...prev, dataUrl]),
        );
        return;
      }
    }
  };

  const handleImageFileChange = (e) => {
    loadImageFiles(e.target.files);
    e.target.value = "";
  };

  // 브라우저에서 R2 로 바로 올린다. 서버는 서명 URL 만 내주고 바이트는 앱서버를
  // 거치지 않으므로, 큰 영상이 컨테이너 메모리를 먹지 않는다.
  // 성공하면 파일 id, 직업로드가 불가능한 환경이면 null 을 돌려준다(호출부가 폴백).
  const uploadChatFileDirect = async (file, roomId) => {
    const token = userInfo.getLoginSessionToken?.() || "";
    const authHeaders = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    };

    let issued;
    try {
      issued = await fetch("/api/chat/uploadUrl", {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({
          roomId,
          userId: currentLoginUserId,
          fileName: file.name,
          mimeType: file.type,
          size: file.size,
        }),
      });
    } catch {
      return null;
    }
    if (!issued.ok) return null;
    const { fileId, key, url } = await issued.json();

    // R2 버킷에 CORS 가 설정되기 전에는 이 PUT 이 막힌다. 그때는 조용히 기존
    // 서버 경유 업로드로 되돌아가야 하므로 실패를 예외로 올리지 않는다.
    try {
      const put = await fetch(url, {
        method: "PUT",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!put.ok) return null;
    } catch {
      return null;
    }

    // 여기서부터는 파일이 이미 R2 에 올라가 있다. 확정 실패는 서버 쪽 문제이고
    // 기존 경로로 바꿔도 같은 곳에서 막히므로, 폴백하지 않고 그대로 알린다.
    const done = await fetch("/api/chat/uploadComplete", {
      method: "POST",
      headers: authHeaders,
      body: JSON.stringify({
        roomId,
        userId: currentLoginUserId,
        fileId,
        key,
        fileName: file.name,
        mimeType: file.type,
      }),
    });
    if (!done.ok) throw new Error((await done.json()).error || "업로드 확정 실패");
    return (await done.json()).id;
  };

  const handleVideoFileChange = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !currentRoomRef.current) return;
    if (file.size > 500 * 1024 * 1024) {
      openOkModal(tl("chatVideoSizeLimit"), "Warning");
      return;
    }
    setVideoUploading(true);
    try {
      const roomId = currentRoomRef.current.id;
      let id = await uploadChatFileDirect(file, roomId);
      if (!id) {
        // 직업로드가 불가능한 환경 — 기존 서버 경유 업로드로 처리
        const res = await fetch(
          `/api/chat/upload?roomId=${roomId}&userId=${encodeURIComponent(currentLoginUserId)}&mimeType=${encodeURIComponent(file.type)}&fileName=${encodeURIComponent(file.name)}`,
          { method: "POST", headers: { "Content-Type": file.type }, body: file },
        );
        if (!res.ok) throw new Error((await res.json()).error || "업로드 실패");
        id = (await res.json()).id;
      }
      doSendMsg(`[video:${id}]`, false);
    } catch (err) {
      openOkModal(tl("chatVideoUploadFailed") + ": " + err.message, "Error");
    } finally {
      setVideoUploading(false);
    }
  };

  /* -------------------- UI -------------------- */

  // 라이트박스 탐색용 이미지 메시지 목록 (삭제된 것 제외)
  const imageMessages = messages.filter(
    (m) =>
      (m.message?.startsWith("data:image/") ||
        /^\[img:\d+\]$/.test(m.message ?? "")) &&
      !m.deleted,
  );
  const lightboxMsg =
    lightboxIndex !== null ? imageMessages[lightboxIndex] : null;
  const lightboxSrc = lightboxMsg
    ? lightboxMsg.message?.startsWith("data:image/")
      ? lightboxMsg.message
      : `/api/chat/image?msgId=${lightboxMsg.id}`
    : null;
  const lightboxPrev = () => setLightboxIndex((idx) => Math.max(0, idx - 1));
  const lightboxNext = () =>
    setLightboxIndex((idx) => Math.min(imageMessages.length - 1, idx + 1));
  const isEmojiOnlyMessage = (text) => {
    const value = String(text ?? "").trim();
    return (
      value.length > 0 && value.length <= 24 && EMOJI_ONLY_PATTERN.test(value)
    );
  };
  const renderPlainTextPart = (part, keyPrefix) =>
    String(part)
      .split(/(@[^\s@]+)/g)
      .map((piece, index) =>
        piece.startsWith("@") ? (
          <span
            key={`${keyPrefix}-mention-${index}`}
            className="rounded bg-[rgba(245,158,11,0.15)] px-1 text-[var(--warn)]"
          >
            {piece}
          </span>
        ) : (
          piece
        ),
      );

  const renderMessageText = (text) => {
    const source = String(text ?? "");

    const findNextFormat = (value, fromIndex = 0) => {
      const candidates = [
        {
          type: "bold",
          start: value.indexOf("**", fromIndex),
          prefix: "**",
          suffix: "**",
        },
        {
          type: "highlight",
          start: value.indexOf("==", fromIndex),
          prefix: "==",
          suffix: "==",
        },
        {
          type: "color",
          start: value.indexOf("{{red:", fromIndex),
          prefix: "{{red:",
          suffix: "}}",
          color: "red",
        },
        {
          type: "color",
          start: value.indexOf("{{blue:", fromIndex),
          prefix: "{{blue:",
          suffix: "}}",
          color: "blue",
        },
        {
          type: "color",
          start: value.indexOf("{{green:", fromIndex),
          prefix: "{{green:",
          suffix: "}}",
          color: "green",
        },
      ].filter((item) => item.start >= 0);
      candidates.sort((a, b) => a.start - b.start);

      for (const candidate of candidates) {
        const contentStart = candidate.start + candidate.prefix.length;
        const end = value.indexOf(candidate.suffix, contentStart);
        if (end >= 0) return { ...candidate, contentStart, end };
      }
      return null;
    };

    const renderInline = (value, keyPrefix = "text") => {
      const nodes = [];
      let cursor = 0;
      let format;

      while ((format = findNextFormat(value, cursor))) {
        if (format.start > cursor) {
          nodes.push(
            ...renderPlainTextPart(
              value.slice(cursor, format.start),
              `${keyPrefix}-plain-${cursor}`,
            ),
          );
        }

        const inner = renderInline(
          value.slice(format.contentStart, format.end),
          `${keyPrefix}-${format.type}-${format.start}`,
        );
        if (format.type === "bold") {
          nodes.push(
            <strong
              key={`${keyPrefix}-bold-${format.start}`}
              className="font-extrabold"
            >
              {inner}
            </strong>,
          );
        } else if (format.type === "highlight") {
          nodes.push(
            <mark
              key={`${keyPrefix}-highlight-${format.start}`}
              className="rounded bg-warn/30 px-1 py-0.5 text-gray-950"
            >
              {inner}
            </mark>,
          );
        } else {
          const colorClass =
            format.color === "blue"
              ? "text-info"
              : format.color === "green"
                ? "text-brand-emerald"
                : "text-danger";
          nodes.push(
            <span
              key={`${keyPrefix}-color-${format.start}`}
              className={colorClass}
            >
              {inner}
            </span>,
          );
        }
        cursor = format.end + format.suffix.length;
      }

      if (cursor < value.length) {
        nodes.push(
          ...renderPlainTextPart(
            value.slice(cursor),
            `${keyPrefix}-plain-${cursor}`,
          ),
        );
      }
      return nodes.length ? nodes : value;
    };

    return renderInline(source);
  };

  return (
    <div className="flex h-full min-h-0 w-full flex-col bg-[var(--bg)] text-[var(--text)] md:flex-row">
      {loading && <Loading />}
      <BrunnerMessageBox />

      {/* 모바일 드로어 오버레이 */}
      {!externalRoomId && showRoomDrawer && (
        <div
          className="fixed inset-0 z-50 flex md:hidden"
          onClick={() => setShowRoomDrawer(false)}
        >
          <div
            className="flex h-full w-72 flex-col gap-2 overflow-y-auto bg-[var(--surface)] p-4 shadow-[var(--shadow-card-strong)]"
            onClick={(e) => e.stopPropagation()}
            onTouchStart={(e) => {
              swipeTouchStartX.current = e.touches[0].clientX;
            }}
            onTouchEnd={(e) => {
              if (swipeTouchStartX.current === null) return;
              const dx = e.changedTouches[0].clientX - swipeTouchStartX.current;
              if (dx < -60) setShowRoomDrawer(false);
              swipeTouchStartX.current = null;
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-bold text-[var(--text)]">
                {tl("chatroomList")}
              </span>
              <button
                onClick={() => setShowRoomDrawer(false)}
                className="text-lg font-bold text-[var(--text-subtle)] hover:text-[var(--text)]"
                aria-label={tl("close")}
              >
                ✕
              </button>
            </div>
            <Button className="w-full" onClick={createRoom}>
              {tl("createRoom")}
            </Button>
            {visibleRooms.map((r) => (
              <div
                key={r.id}
                role="button"
                tabIndex={0}
                className={`w-full rounded-[var(--radius-md)] border px-3 py-2 text-left transition ${
                  isListRoomActive(r)
                    ? "border-[var(--brand-blue)] bg-[image:var(--brand-gradient-soft)] text-[var(--brand-blue)]"
                    : "border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text)]"
                }`}
                onClick={() => {
                  enterListRoom(r);
                  setShowRoomDrawer(false);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    enterListRoom(r);
                    setShowRoomDrawer(false);
                  }
                }}
              >
                <span className="flex items-center justify-between gap-2">
                  <span className="truncate">
                    {r.is_secret && !getListDirectPeerId(r) && <span className="mr-1">🔒</span>}
                    {r.name.replace(/🔒\s*/g, "")}
                  </span>
                  <span className="flex shrink-0 items-center gap-1">
                    {renderListModeActions(r, {
                      onAfter: () => setShowRoomDrawer(false),
                    })}
                  </span>
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 방 목록 — 데스크탑: 좌측 세로 */}
      {!externalRoomId && (
        <div className="hidden shrink-0 border-r border-[var(--border)] bg-[var(--surface)] p-4 md:flex md:w-72 md:flex-col md:gap-3 md:overflow-y-auto">
          <Button className="w-full" onClick={createRoom}>
            {tl("createRoom")}
          </Button>

          {visibleRooms.map((r) => (
            <div
              key={r.id}
              role="button"
              tabIndex={0}
              className={`w-full rounded-[var(--radius-md)] border px-3 py-3 text-left transition hover:border-[var(--brand-blue)] ${
                isListRoomActive(r)
                  ? "border-[var(--brand-blue)] bg-[image:var(--brand-gradient-soft)] text-[var(--brand-blue)]"
                  : "border-[var(--border)] bg-[var(--surface)] text-[var(--text)]"
              }`}
              onClick={() => enterListRoom(r)}
              onKeyDown={(e) => enterListRoomByKey(e, r)}
            >
              <span className="flex items-center gap-3">
                <Avatar
                  initial={(r.name || "B").replace("🔒", "").trim().charAt(0)}
                  size={32}
                />
                <span className="min-w-0 flex-1 truncate text-sm font-semibold">
                  {r.is_secret && !getListDirectPeerId(r) && <span className="mr-1">🔒</span>}
                  {r.name.replace(/🔒\s*/g, "")}
                </span>
                <span className="flex shrink-0 items-center gap-1">
                  {renderListModeActions(r)}
                </span>
              </span>
            </div>
          ))}
        </div>
      )}

      {/* 채팅 */}
      <div className="flex h-full min-h-0 min-w-0 flex-1 bg-[var(--bg)]">
        {currentRoom ? (
          <div
            className={`relative flex h-full min-h-0 flex-1 flex-col overflow-hidden ${showMembersPanel ? "md:pr-60" : ""}`}
          >
            <div className="sticky top-0 z-20 flex h-16 shrink-0 items-center gap-3 border-b border-[var(--border)] bg-[var(--surface)] px-3 md:px-5">
              {/* 모바일: 방 목록 토글 버튼 */}
              {!externalRoomId && (
                <button
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--surface-alt)] text-sm text-[var(--text)] md:hidden"
                  onClick={() => setShowRoomDrawer(true)}
                  aria-label={tl("chatroomList")}
                >
                  ☰
                </button>
              )}
              {externalRoomId && (
                <button
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-[var(--surface-alt)] text-sm text-[var(--text)]"
                  onClick={() =>
                    onLeaveRoom ? onLeaveRoom() : window.history.back()
                  }
                  aria-label={tl("back")}
                >
                  ←
                </button>
              )}
              {editingRoomName ? (
                <div className="flex flex-1 items-center gap-1">
                  <input
                    autoFocus
                    className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-2 py-1 text-sm font-bold text-[var(--text)]"
                    value={roomNameInput}
                    maxLength={50}
                    onChange={(e) => setRoomNameInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") renameRoom();
                      if (e.key === "Escape") setEditingRoomName(false);
                    }}
                  />
                  <button
                    onClick={renameRoom}
                    className="text-xs font-bold text-[var(--brand-blue)]"
                    aria-label={tl("save")}
                  >
                    ✓
                  </button>
                  <button
                    onClick={() => setEditingRoomName(false)}
                    className="text-xs text-[var(--text-subtle)]"
                    aria-label={tl("cancel")}
                  >
                    ✕
                  </button>
                </div>
              ) : (
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <Avatar
                    initial={(currentRoom.name || "B")
                      .replace("🔒", "")
                      .trim()
                      .charAt(0)}
                    size={36}
                    online
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="truncate text-base font-extrabold text-[var(--text)]">
                        {currentRoom.name}
                      </h3>
                      <button
                        onClick={() => {
                          setRoomNameInput(currentRoom.name);
                          setEditingRoomName(true);
                        }}
                        className="inline-flex text-xs text-[var(--text-subtle)] hover:text-[var(--brand-blue)]"
                        title={tl("renameRoom")}
                        aria-label={tl("renameRoom")}
                      >
                        ✏️
                      </button>
                      {/* 모바일 전용 알림 상태 아이콘 — 항상 표시 */}
                      {(() => {
                        const muted = isRoomMuted(currentRoom.id);
                        const noPermission =
                          typeof Notification !== "undefined" &&
                          Notification.permission !== "granted";
                        const pushOff =
                          !noPermission &&
                          localStorage.getItem("pushNotificationsEnabled") ===
                            "false";
                        const hasIssue = noPermission || pushOff;
                        const dotColor = hasIssue
                          ? "bg-[var(--danger)]"
                          : muted
                            ? "bg-[var(--text-muted)]"
                            : "bg-[var(--success)]";
                        return (
                          <span
                            className="relative inline-flex shrink-0 items-center md:hidden"
                            title={
                              muted
                                ? tl("notifMutedRoom")
                                : hasIssue
                                  ? noPermission
                                    ? tl("notifNoPermission")
                                    : tl("notifPushOff")
                                  : tl("pushNotifications")
                            }
                          >
                            <span className="text-sm">
                              {muted ? "🔕" : "🔔"}
                            </span>
                            <span
                              className={`absolute -right-1 -top-0.5 h-2 w-2 rounded-full ${dotColor}`}
                            />
                          </span>
                        );
                      })()}
                    </div>
                    <div className="mt-0.5 hidden items-center gap-2 md:flex">
                      <Chip tone="neutral">
                        {tl("chatMembersCount").replace(
                          "{count}",
                          roomUsers.length || currentRoom?.member_count || 1,
                        )}
                      </Chip>
                      {currentRoom?.is_secret && (
                        <Chip tone="brand">🔐 {tl("chatEncrypted")}</Chip>
                      )}
                      {isRoomMuted(currentRoom.id) && (
                        <Chip tone="neutral">🔕 {tl("notifMutedRoom")}</Chip>
                      )}
                      {!isRoomMuted(currentRoom.id) &&
                        typeof Notification !== "undefined" &&
                        Notification.permission !== "granted" && (
                          <Chip tone="danger">{tl("notifNoPermission")}</Chip>
                        )}
                      {!isRoomMuted(currentRoom.id) &&
                        typeof Notification !== "undefined" &&
                        Notification.permission === "granted" &&
                        localStorage.getItem("pushNotificationsEnabled") ===
                          "false" && (
                          <Chip tone="danger">{tl("notifPushOff")}</Chip>
                        )}
                    </div>
                  </div>
                </div>
              )}
              {!currentRoom?.is_secret && (
                <button
                  type="button"
                  onClick={() => {
                    setShowRoomActions(false);
                    setShowSearch((v) => !v);
                    setSearchQuery("");
                    setSearchResults([]);
                  }}
                  className={`flex h-9 w-9 items-center justify-center rounded-full bg-[var(--surface-alt)] hover:text-[var(--brand-blue)] ${showSearch ? "text-[var(--brand-blue)]" : "text-[var(--text-muted)]"}`}
                  title={tl("search")}
                  aria-label={tl("search")}
                >
                  🔎
                </button>
              )}
              <div className="relative shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setShowSearch(false);
                    setShowRoomActions((v) => !v);
                  }}
                  className={`flex h-9 w-9 items-center justify-center rounded-full bg-[var(--surface-alt)] text-lg leading-none hover:text-[var(--brand-blue)] ${showRoomActions ? "text-[var(--brand-blue)]" : "text-[var(--text-muted)]"}`}
                  title={tl("settings")}
                  aria-label={tl("settings")}
                  aria-expanded={showRoomActions}
                >
                  ⋯
                </button>
                {/* w-max·whitespace-nowrap 이 없으면 모바일에서 항목이 여러 줄로 접힌다.
                    absolute 요소의 가용 폭은 위치 기준이 되는 부모(⋯ 버튼, 약 36px)에서
                    오므로, 폭을 내용에 맞추지 않으면 그 좁은 폭으로 줄바꿈된다. */}
                {showRoomActions && (
                  <div className="absolute right-0 top-11 z-40 w-max min-w-44 whitespace-nowrap overflow-hidden rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] py-1 shadow-[var(--shadow-card-strong)]">
                    <button
                      type="button"
                      onClick={() => {
                        toggleMuteRoom(currentRoom.id);
                        setShowRoomActions(false);
                      }}
                      className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-[var(--text)] hover:bg-[var(--surface-alt)]"
                    >
                      <span className="w-5 text-center">
                        {isRoomMuted(currentRoom.id) ? "🔇" : "🔊"}
                      </span>
                      <span>
                        {isRoomMuted(currentRoom.id)
                          ? tl("unmuteRoom")
                          : tl("muteRoom")}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowMembersPanel((v) => !v);
                        setShowRoomActions(false);
                      }}
                      className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-[var(--text)] hover:bg-[var(--surface-alt)]"
                    >
                      <span className="w-5 text-center">👥</span>
                      <span>
                        {tl("memberList")} ({roomUsers.length})
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowMembersPanel(true);
                        setInviteKeyword("");
                        setInviteSearchResults([]);
                        setShowInvitePanel(true);
                        setShowRoomActions(false);
                      }}
                      className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-[var(--text)] hover:bg-[var(--surface-alt)]"
                    >
                      <span className="w-5 text-center">＋</span>
                      <span>{tl("invite")}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleCopyInviteLink();
                        setShowRoomActions(false);
                      }}
                      className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-[var(--text)] hover:bg-[var(--surface-alt)]"
                    >
                      <span className="w-5 text-center">🔗</span>
                      <span>{tl("inviteLink")}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowRoomActions(false);
                        leaveRoom();
                      }}
                      className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-[var(--danger)] hover:bg-[var(--surface-alt)]"
                    >
                      <span className="w-5 text-center">↩</span>
                      <span>{tl("leave")}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* 비밀채팅 안내 배너 */}
            {currentRoom?.is_secret && (
              <div className="flex justify-center border-b border-[var(--border)] bg-[var(--surface)] px-2 py-2 text-xs">
                <Chip tone="brand">🔐 {tl("secretChatNotice")}</Chip>
              </div>
            )}

            {/* 참여자 패널 — 토글 */}
            {showMembersPanel && (
              <div className="fixed inset-x-0 bottom-0 top-16 z-20 overflow-y-auto bg-[var(--surface)] p-3 md:absolute md:bottom-0 md:right-0 md:top-16 md:z-10 md:w-60 md:shrink-0 md:border-b-0 md:border-l">
                <div className="mb-1 flex justify-end">
                  <Button
                    size="sm"
                    variant="success"
                    onClick={() => setShowMembersPanel(false)}
                    className="whitespace-nowrap"
                  >
                    {tl("close")}
                  </Button>
                  {/*                   
                <button
                  type="button"
                  onClick={() => setShowMembersPanel(false)}
                  className="flex h-7 w-7 items-center justify-center rounded-full text-[var(--text-muted)] hover:bg-[var(--surface-alt)] hover:text-[var(--text)]"
                  aria-label={tl("close")}
                >✕</button> */}
                </div>
                <div className="mb-3 flex flex-wrap items-center justify-end gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={handleInviteToggle}
                    className="whitespace-nowrap"
                  >
                    {tl("invite")}
                  </Button>
                  <Button
                    size="sm"
                    variant="success"
                    onClick={handleCopyInviteLink}
                    className="whitespace-nowrap"
                  >
                    {tl("inviteLink")}
                  </Button>
                  <Button
                    size="sm"
                    variant="danger"
                    onClick={leaveRoom}
                    className="whitespace-nowrap"
                  >
                    {tl("leave")}
                  </Button>
                </div>

                {/* 친구 초대 패널 */}
                {showInvitePanel && (
                  <div className="mb-3 rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface-alt)] p-2">
                    {/* 사용자 검색 */}
                    <Input
                      type="text"
                      value={inviteKeyword}
                      onChange={(e) => searchInviteUser(e.target.value)}
                      placeholder={tl("searchUser")}
                      className="mb-2"
                      inputClassName="h-9 text-xs"
                    />
                    {/* 검색 결과 */}
                    {inviteKeyword.trim() ? (
                      <div className="flex flex-wrap gap-1">
                        {inviteSearchResults.length === 0 ? (
                          <span className="text-xs text-gray-400">
                            {tm("NO_SEARCH_RESULTS")}
                          </span>
                        ) : (
                          inviteSearchResults.map((u, i) => {
                            const uid = u.friend_id || u.user_id;
                            const isInviting = invitingUserId === uid;
                            return (
                              <button
                                key={i}
                                onClick={() => inviteUser(u)}
                                disabled={!!invitingUserId}
                                className={`rounded-full px-2 py-1 text-xs font-semibold transition-opacity
                              ${isInviting ? "bg-[var(--surface-alt)] text-[var(--semi-text-color)] cursor-wait" : "bg-[image:var(--brand-gradient-soft)] text-[var(--brand-blue)] hover:opacity-80"}
                              ${invitingUserId && !isInviting ? "opacity-40" : ""}`}
                              >
                                {isInviting ? "…" : u.user_name}
                              </button>
                            );
                          })
                        )}
                      </div>
                    ) : (
                      /* 친구 목록 */
                      <div className="flex flex-wrap gap-1">
                        {friends.filter((f) => f.status !== "BLOCKED")
                          .length === 0 ? (
                          <span className="text-xs text-gray-400">
                            {tm("NO_FRIENDS")}
                          </span>
                        ) : (
                          friends
                            .filter((f) => f.status !== "BLOCKED")
                            .map((f, i) => {
                              const uid = f.friend_id || f.user_id;
                              const isInviting = invitingUserId === uid;
                              return (
                                <button
                                  key={i}
                                  onClick={() => inviteUser(f)}
                                  disabled={!!invitingUserId}
                                  className={`rounded-full px-2 py-1 text-xs font-semibold transition-opacity
                                  ${isInviting ? "bg-[var(--surface-alt)] text-[var(--semi-text-color)] cursor-wait" : "bg-[image:var(--brand-gradient-soft)] text-[var(--brand-blue)] hover:opacity-80"}
                                  ${invitingUserId && !isInviting ? "opacity-40" : ""}`}
                                >
                                  {isInviting ? "…" : f.user_name}
                                </button>
                              );
                            })
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* 참여자 리스트 */}
                <div className="mt-2 flex flex-col gap-2">
                  <div className="text-xs font-bold text-[var(--text-muted)]">
                    {tl("chatOnlineMembers")}
                  </div>
                  {roomUsers.map((u, i) => {
                    const isOwner =
                      rooms.find((r) => r.id === currentRoom?.id)
                        ?.created_by === currentLoginUserId;
                    const isSelf = u.user_id === currentLoginUserId;
                    const isFriend = friends.some(
                      (f) => f.friend_id === u.user_id,
                    );
                    return (
                      <div
                        key={i}
                        className="flex items-center gap-2 rounded-[var(--radius-md)] bg-[var(--surface-alt)] px-2 py-2 text-xs text-[var(--text)]"
                      >
                        <Avatar
                          src={u.profile_image_src || undefined}
                          initial={(u.user_name || u.user_id || "B").charAt(0)}
                          size={32}
                          online
                        />
                        <span className="min-w-0 flex-1 truncate font-semibold">
                          {u.user_name || u.user_id}
                        </span>
                        {!isSelf && isFriend && !currentRoom?.is_secret && (
                          <button
                            onClick={() =>
                              startSecretChat(u.user_id, u.user_name)
                            }
                            className="text-xs hover:opacity-70"
                            title={tl("secretChat")}
                            aria-label={tl("secretChat")}
                          >
                            🔒
                          </button>
                        )}
                        {isOwner && !isSelf && (
                          <button
                            onClick={() => kickUser(u)}
                            className="font-bold leading-none text-[var(--danger)] hover:opacity-70"
                            title={tl("kick")}
                            aria-label={tl("kick")}
                          >
                            ×
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="flex shrink-0 flex-row items-center justify-center gap-2 border-b border-[var(--border)] bg-[var(--surface)] px-2 py-2">
              <button
                className={`rounded-full border px-3 py-1.5 text-xs font-bold transition ${activityType === "coffee" ? "border-transparent bg-[image:var(--brand-gradient)] text-white shadow-[var(--shadow-primary)]" : "border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-muted)]"}`}
                onClick={() => {
                  if (activityType === "coffee") {
                    setActivityType(null);
                  } else {
                    setActivityType("coffee");
                    lastActivityTypeRef.current = "coffee";
                    localStorage.setItem("lastActivityType", "coffee");
                    setActivityAreaCollapsed(false);
                    localStorage.setItem("activityAreaCollapsed", "false");
                  }
                }}
              >
                {tl("cafe")}
              </button>

              <button
                className={`rounded-full border px-3 py-1.5 text-xs font-bold transition ${activityType === "smoking" ? "border-transparent bg-[var(--brand-emerald)] text-white shadow-[var(--shadow-success)]" : "border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text-muted)]"}`}
                onClick={async () => {
                  if (activityType === "smoking") {
                    setActivityType(null);
                    return;
                  }
                  if (!userInfo.hasBirthDate()) {
                    const go = await openOkCancelModal(
                      tm("BIRTH_DATE_REQUIRED"),
                      constants.messageCategory.Info,
                    );
                    if (go) window.location.href = "/mainPages/userAccount";
                    return;
                  }
                  if (!userInfo.isAdult()) {
                    await openOkModal(
                      tm("ADULT_VERIFY_FAILED"),
                      constants.messageCategory.Error,
                    );
                    return;
                  }
                  setActivityType("smoking");
                  lastActivityTypeRef.current = "smoking";
                  localStorage.setItem("lastActivityType", "smoking");
                  setActivityAreaCollapsed(false);
                  localStorage.setItem("activityAreaCollapsed", "false");
                }}
              >
                {tl("smoking")}
              </button>

              {activityType && (
                <button
                  className="ml-auto rounded-full border border-[var(--border)] bg-[var(--surface-alt)] px-2 py-1 text-xs text-[var(--text-muted)] hover:text-[var(--brand-blue)]"
                  title={
                    activityAreaCollapsed
                      ? tl("expandActivityArea")
                      : tl("collapseActivityArea")
                  }
                  aria-label={
                    activityAreaCollapsed
                      ? tl("expandActivityArea")
                      : tl("collapseActivityArea")
                  }
                  onClick={() => {
                    const next = !activityAreaCollapsed;
                    setActivityAreaCollapsed(next);
                    localStorage.setItem("activityAreaCollapsed", String(next));
                  }}
                >
                  {activityAreaCollapsed ? "▼" : "▲"}
                </button>
              )}
            </div>

            {activityType === "coffee" && isDrinkingActive && (
              <div className="mx-3 mt-3 shrink-0 rounded-[var(--radius-lg)] border border-[var(--border)] bg-[var(--surface)] p-3 shadow-[var(--shadow-card)]">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-sm font-bold text-[var(--text)]">
                    {isDrinkingActive.isDessert ? "🍪" : "☕"}{" "}
                    {isDrinkingActive.drinkLabel || tl("chatExtractingCoffee")}{" "}
                    {isDrinkingActive.isDessert ? "먹는중" : "추출중"}
                  </span>
                  <Chip tone="brand">{tl("cafe")}</Chip>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-[var(--surface-alt)]">
                  <div className="h-full w-2/3 rounded-full bg-[image:var(--brand-gradient)]" />
                </div>
              </div>
            )}

            {activityType === "smoking" && isSmokingActive && (
              <div className="mx-3 mt-3 shrink-0 rounded-[var(--radius-lg)] border border-[var(--border)] bg-[var(--surface)] p-3 shadow-[var(--shadow-card)]">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-sm font-bold text-[var(--text)]">
                    🚬 흡연중
                  </span>
                  <Chip tone="success">{tl("smoking")}</Chip>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-[var(--surface-alt)]">
                  <div className="h-full w-2/3 rounded-full bg-[var(--brand-emerald)]" />
                </div>
              </div>
            )}

            {activityType === "smoking" && (
              <div
                className={`shrink-0 overflow-y-auto h-[35vh] px-1 ${activityAreaCollapsed ? "hidden" : ""}`}
              >
                <SmokingArea
                  ref={smokingRef}
                  onSmokingChange={(v) => setIsSmokingActive(v)}
                  setCanChat={setCanChat}
                  onStarted={() => setHadSession(true)}
                  isMuted={isRoomMuted(currentRoom?.id)}
                />
              </div>
            )}

            {activityType === "coffee" && (
              <div
                className={`shrink-0 overflow-x-hidden overflow-y-auto h-[35vh] w-full px-1 ${activityAreaCollapsed ? "hidden" : ""}`}
              >
                <CoffeeArea
                  ref={coffeeRef}
                  initialDrinkType={roomCafePrefs[currentRoom?.id]?.drinkType}
                  initialTemp={roomCafePrefs[currentRoom?.id]?.temp}
                  onDrinkingChange={(v) => {
                    setIsDrinkingActive(v);
                    if (v.drinkType && currentRoom?.id) {
                      const next = {
                        ...roomCafePrefs,
                        [currentRoom.id]: {
                          drinkType: v.drinkType,
                          temp: v.temp,
                        },
                      };
                      setRoomCafePrefs(next);
                      localStorage.setItem(
                        "roomCafePrefs",
                        JSON.stringify(next),
                      );
                    }
                  }}
                  setCanChat={setCanChat}
                  onStarted={() => setHadSession(true)}
                  isMuted={isRoomMuted(currentRoom?.id)}
                />
              </div>
            )}

            {/* 메시지 검색 패널 */}
            {showSearch && !currentRoom?.is_secret && (
              <div className="shrink-0 border-b border-[var(--border)] bg-[var(--surface)] px-3 py-2">
                <div>
                  <div className="flex items-center gap-2">
                    <input
                      autoFocus
                      type="text"
                      className="min-w-0 flex-1 rounded-full border border-[var(--border)] bg-[var(--surface-alt)] px-4 py-1.5 text-sm text-[var(--text)] outline-none placeholder:text-[var(--text-muted)]"
                      placeholder={tl("chatMsgSearchPlaceholder")}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") doSearch();
                      }}
                    />
                    <button
                      onClick={doSearch}
                      className="shrink-0 rounded-full bg-[var(--brand-blue)] px-4 py-1.5 text-sm font-semibold text-white hover:opacity-80"
                    >
                      {tl("search")}
                    </button>
                  </div>
                  <p className="mt-1 text-[10px] text-[var(--text-subtle)]">
                    최근 1,000건 메시지 내에서 검색
                  </p>
                  {searchLoading && (
                    <p className="mt-1 text-xs text-[var(--text-muted)]">
                      검색 중…
                    </p>
                  )}
                  {!searchLoading &&
                    searchResults.length === 0 &&
                    searchQuery && (
                      <p className="mt-1 text-xs text-[var(--text-muted)]">
                        {tl("chatMsgSearchNoResult")}
                      </p>
                    )}
                  {searchResults.length > 0 && (
                    <div className="mt-2 max-h-48 overflow-y-auto space-y-1">
                      {searchResults.map((r) => (
                        <button
                          key={r.id}
                          className="w-full rounded-lg bg-[var(--surface-alt)] px-3 py-2 text-left hover:bg-[var(--surface-hover)]"
                          onClick={() => {
                            setShowSearch(false);
                            setPendingScrollMessageId(r.id);
                          }}
                        >
                          <div className="text-xs font-semibold text-[var(--brand-blue)]">
                            {r.userName}
                          </div>
                          <div className="truncate text-xs text-[var(--text)]">
                            {r.message}
                          </div>
                          <div className="text-[10px] text-[var(--text-muted)]">
                            {r.time
                              ? new Date(r.time).toLocaleString([], {
                                  month: "numeric",
                                  day: "numeric",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })
                              : ""}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 메시지 영역 */}
            <div
              ref={chatScrollRef}
              className="mt-3 min-h-0 flex-1 basis-0 touch-pan-y overflow-x-hidden overflow-y-auto overscroll-contain px-3 pb-4 pt-2 md:px-5"
              style={{ WebkitOverflowScrolling: "touch" }}
              onClick={() => {
                setContextMenu(null);
                setNameMenu(null);
                setReactionPicker(null);
                setShowRoomActions(false);
                setPendingRemove(null);
              }}
            >
              {loadingMore && (
                <div className="flex justify-center py-2 text-xs text-[var(--text-subtle)]">
                  {tl("chatLoadingMore")}
                </div>
              )}
              {messages.map((m, i) => {
                const isSystemMsg = m.isSystem || !m.userId;
                const isMine = !isSystemMsg && m.userId === currentLoginUserId;
                const msgDate = m.time
                  ? new Date(m.time).toLocaleDateString()
                  : null;
                const prevDate =
                  i > 0 && messages[i - 1].time
                    ? new Date(messages[i - 1].time).toLocaleDateString()
                    : null;
                const showDateSep = msgDate && msgDate !== prevDate;
                const isImage = m.message?.startsWith("data:image/");
                const isImagePlaceholder =
                  !isImage && /^\[img:\d+\]$/.test(m.message ?? "");
                const isAudio = m.message?.startsWith("data:audio/");
                const isVideoFile = /^\[video:[0-9a-f-]+\]$/i.test(
                  m.message ?? "",
                );
                const videoFileId = isVideoFile ? m.message.slice(7, -1) : null;
                const isSticker = /^\[sticker:[a-z0-9_]+\]$/.test(
                  m.message ?? "",
                );
                const stickerId = isSticker ? m.message.slice(9, -1) : null;
                const isCustomEmoji = /^\[custom-emoji:[0-9a-f-]+\]$/i.test(
                  m.message ?? "",
                );
                const customEmojiId = isCustomEmoji
                  ? m.message.slice(14, -1)
                  : null;
                const isDecryptFailed = isDecryptFailureText(m.message);
                const isEmojiOnly =
                  !isImage &&
                  !isImagePlaceholder &&
                  !isAudio &&
                  !isVideoFile &&
                  !isSticker &&
                  !isCustomEmoji &&
                  isEmojiOnlyMessage(m.message);
                const showLargeEmoji =
                  isEmojiOnly && emojiDisplayMode === EMOJI_DISPLAY_LARGE;
                const canEdit =
                  isMine &&
                  m.id &&
                  !m.deleted &&
                  !isDecryptFailed &&
                  !isImage &&
                  !isImagePlaceholder &&
                  !isAudio &&
                  !isVideoFile &&
                  !isSticker &&
                  !isCustomEmoji &&
                  !showLargeEmoji;
                const canInteract = m.id && !m.deleted && !isDecryptFailed;

                const handleBubblePress = (e) => {
                  if (!canInteract) return;
                  e.stopPropagation();
                  const rect = e.currentTarget.getBoundingClientRect();
                  setContextMenu({
                    messageIndex: i,
                    msg: m,
                    rect,
                    isMine,
                    canEdit,
                  });
                };

                const handleTouchStart = (e) => {
                  if (!canInteract) return;
                  e.stopPropagation();
                  longPressTriggered.current = false;
                  const rect = e.currentTarget.getBoundingClientRect();
                  longPressTimer.current = setTimeout(() => {
                    longPressTriggered.current = true;
                    setContextMenu({
                      messageIndex: i,
                      msg: m,
                      rect,
                      isMine,
                      canEdit,
                    });
                  }, 500);
                };

                const handleTouchEnd = () =>
                  clearTimeout(longPressTimer.current);

                return (
                  <React.Fragment key={i}>
                    {showDateSep && (
                      <div className="my-4 flex justify-center">
                        <Chip tone="neutral">
                          {new Date(m.time).toLocaleDateString([], {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </Chip>
                      </div>
                    )}
                    {isSystemMsg ? (
                      <div className="mb-3 flex justify-start">
                        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[var(--surface-alt)] text-base">
                          🤖
                        </div>
                        <div className="ml-2 flex flex-col items-start">
                          <span className="chat-msg-sender mb-1 ml-1 font-semibold text-[var(--text-muted)]">
                            {tl("system")}
                          </span>
                          <span className="rounded-[18px] rounded-tl-[5px] bg-[var(--surface-alt)] px-3.5 py-2.5 text-sm text-[var(--text)] shadow-[var(--shadow-card)]">
                            {m.message}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div
                        ref={(el) => {
                          if (!m.id) return;
                          const key = String(m.id);
                          if (el) messageRefs.current[key] = el;
                          else delete messageRefs.current[key];
                        }}
                        className={`mb-3 flex rounded-lg transition-shadow duration-300 ${isMine ? "justify-end" : "justify-start"} ${m.id && highlightedMessageId === String(m.id) ? "ring-2 ring-[var(--brand-blue)] ring-offset-2 ring-offset-transparent" : ""}`}
                      >
                        {!isMine && (
                          <Avatar
                            src={userProfileMap.get(m.userId) || undefined}
                            initial={(m.userName || tl("system")).charAt(0)}
                            size={28}
                          />
                        )}
                        <div
                          className={`flex max-w-[78%] flex-col ${isMine ? "items-end" : "ml-2 items-start"}`}
                        >
                          {!isMine && (
                            <span
                              className={`chat-msg-sender mb-1 ml-1 font-semibold text-[var(--text-muted)] ${friends.some((f) => f.friend_id === m.userId) ? "cursor-pointer underline decoration-dotted hover:text-[var(--brand-blue)]" : ""}`}
                              onClick={(e) => {
                                if (
                                  !friends.some((f) => f.friend_id === m.userId)
                                )
                                  return;
                                e.stopPropagation();
                                const rect =
                                  e.currentTarget.getBoundingClientRect();
                                setNameMenu({
                                  x: rect.left,
                                  y: rect.bottom + 4,
                                  userId: m.userId,
                                  userName: m.userName,
                                });
                              }}
                            >
                              {m.userName || tl("system")}
                            </span>
                          )}
                          {m.replyTo && !m.deleted && (
                            <button
                              type="button"
                              className="mb-1 max-w-[220px] cursor-pointer overflow-hidden rounded-[var(--radius-md)] border-l-4 border-[var(--brand-blue)] bg-[image:var(--brand-gradient-soft)] text-left hover:opacity-85 focus:outline-none focus:ring-2 focus:ring-[var(--brand-blue)]"
                              onClick={(e) => {
                                e.stopPropagation();
                                scrollToReplyTarget(m.replyTo);
                              }}
                              title={tl("chatGoToOriginal")}
                            >
                              <div className="flex items-center gap-1 px-2 pt-1">
                                <span className="text-sm font-black leading-none text-[var(--brand-blue)]">
                                  ↳
                                </span>
                                <span className="truncate text-[11px] font-bold text-[var(--brand-blue)]">
                                  {m.replyTo.userName}
                                </span>
                              </div>
                              <div className="truncate px-2 pb-1 text-[11px] text-[var(--text-muted)]">
                                {m.replyTo.message?.startsWith("data:image/") ||
                                /^\[img:\d+\]$/.test(m.replyTo.message ?? "")
                                  ? "🖼️ 이미지"
                                  : isDecryptFailureText(m.replyTo.message)
                                    ? DECRYPT_FAILURE_NOTICE
                                    : m.replyTo.message}
                              </div>
                            </button>
                          )}
                          {m.deleted ? (
                            <span className="rounded-2xl border border-[var(--border)] px-3 py-1.5 text-[12px] italic text-[var(--text-subtle)]">
                              삭제된 메시지입니다.
                            </span>
                          ) : isDecryptFailed ? (
                            <span className="rounded-2xl border border-[var(--border)] bg-[var(--surface-alt)] px-3 py-1.5 text-[12px] italic text-[var(--text-subtle)]">
                              {DECRYPT_FAILURE_NOTICE}
                            </span>
                          ) : isAudio ? (
                            <div
                              className={`flex max-w-[220px] items-center gap-2 rounded-2xl px-3 py-2 ${isMine ? "bg-[image:var(--brand-gradient)] text-white" : "bg-[var(--surface-alt)] text-[var(--text)]"}`}
                              onContextMenu={(e) => {
                                e.preventDefault();
                                handleBubblePress(e);
                              }}
                              onTouchStart={handleTouchStart}
                              onTouchEnd={handleTouchEnd}
                              onTouchMove={handleTouchEnd}
                            >
                              <span className="text-lg">🎤</span>
                              <audio
                                controls
                                src={m.message}
                                className="h-8 w-36"
                                style={{
                                  accentColor: isMine ? "#fff" : undefined,
                                }}
                              />
                            </div>
                          ) : isVideoFile ? (
                            <video
                              src={`/api/chat/media?id=${videoFileId}`}
                              controls
                              playsInline
                              preload="metadata"
                              className="max-h-[280px] max-w-[260px] rounded-[var(--radius-lg)] border border-[var(--border)]"
                              onTouchStart={handleTouchStart}
                              onTouchEnd={handleTouchEnd}
                            />
                          ) : isSticker ? (
                            (() => {
                              const stickerDef = STICKER_PACK.find(
                                (s) => s.id === stickerId,
                              );
                              return (
                                <span
                                  className={`block select-none px-1 py-0.5 text-6xl leading-none drop-shadow-md ${stickerDef?.cls ?? "animate-bounce"} ${canInteract ? "cursor-pointer" : ""}`}
                                  title={
                                    stickerDef?.labelKey
                                      ? tl(stickerDef.labelKey)
                                      : undefined
                                  }
                                  onContextMenu={(e) => {
                                    e.preventDefault();
                                    handleBubblePress(e);
                                  }}
                                  onTouchStart={handleTouchStart}
                                  onTouchEnd={handleTouchEnd}
                                  onTouchMove={handleTouchEnd}
                                  onClick={
                                    canInteract
                                      ? stickerId in CONFETTI_STICKER_STYLES
                                        ? () => {
                                            const style =
                                              CONFETTI_STICKER_STYLES[
                                                stickerId
                                              ];
                                            fireConfetti(style);
                                            socket.emit("stickerEffect", {
                                              roomId:
                                                currentRoomRef.current?.id,
                                              style,
                                            });
                                          }
                                        : handleBubblePress
                                      : undefined
                                  }
                                >
                                  {stickerDef?.emoji ?? "🎭"}
                                </span>
                              );
                            })()
                          ) : isCustomEmoji ? (
                            <img
                              src={`/api/chat/custom-emoji-image?id=${customEmojiId}`}
                              alt={tl("chatCustomEmojiAlt")}
                              className={`h-24 w-24 rounded object-contain drop-shadow-sm ${canInteract ? "cursor-pointer" : ""}`}
                              onContextMenu={(e) => {
                                e.preventDefault();
                                handleBubblePress(e);
                              }}
                              onTouchStart={handleTouchStart}
                              onTouchEnd={handleTouchEnd}
                              onTouchMove={handleTouchEnd}
                              onClick={
                                canInteract ? handleBubblePress : undefined
                              }
                            />
                          ) : isImage || isImagePlaceholder ? (
                            <img
                              src={
                                isImage
                                  ? m.message
                                  : `/api/chat/image?msgId=${m.id}`
                              }
                              alt="shared"
                              loading="lazy"
                              className="max-h-[220px] max-w-[220px] cursor-pointer rounded-[var(--radius-lg)] border border-[var(--border)] shadow-[var(--shadow-card)]"
                              draggable={false}
                              style={{
                                WebkitTouchCallout: "none",
                                userSelect: "none",
                              }}
                              onContextMenu={(e) => {
                                e.preventDefault();
                                handleBubblePress(e);
                              }}
                              onTouchStart={handleTouchStart}
                              onTouchEnd={handleTouchEnd}
                              onTouchMove={handleTouchEnd}
                              onClick={() => {
                                if (longPressTriggered.current) {
                                  longPressTriggered.current = false;
                                  return;
                                }
                                setLightboxIndex(
                                  imageMessages.findIndex((img) => img === m),
                                );
                              }}
                            />
                          ) : showLargeEmoji ? (
                            <span
                              className={`max-w-[240px] whitespace-pre-wrap break-words px-2 py-1 text-5xl leading-tight drop-shadow-sm md:text-6xl ${canInteract ? "cursor-pointer select-none" : ""}`}
                              onContextMenu={(e) => {
                                e.preventDefault();
                                handleBubblePress(e);
                              }}
                              onTouchStart={handleTouchStart}
                              onTouchEnd={handleTouchEnd}
                              onTouchMove={handleTouchEnd}
                              onClick={
                                canInteract ? handleBubblePress : undefined
                              }
                            >
                              {m.message}
                              {m.edited && (
                                <span className="ml-1 align-middle text-[9px] opacity-60">
                                  수정됨
                                </span>
                              )}
                            </span>
                          ) : (
                            <>
                              <span
                                className={`chat-msg-text whitespace-pre-wrap break-words px-3.5 py-2.5 leading-6 shadow-[var(--shadow-card)] ${isMine ? "rounded-[18px] rounded-tr-[5px] bg-[image:var(--brand-gradient)] text-white" : "rounded-[18px] rounded-tl-[5px] bg-[var(--surface-alt)] text-[var(--text)]"} ${canInteract ? "cursor-pointer select-none" : ""}`}
                                onContextMenu={(e) => {
                                  e.preventDefault();
                                  handleBubblePress(e);
                                }}
                                onTouchStart={handleTouchStart}
                                onTouchEnd={handleTouchEnd}
                                onTouchMove={handleTouchEnd}
                                onClick={
                                  canInteract ? handleBubblePress : undefined
                                }
                              >
                                {renderMessageText(m.message)}
                                {m.edited && (
                                  <span className="ml-1 text-[9px] opacity-60">
                                    수정됨
                                  </span>
                                )}
                              </span>
                              {(() => {
                                const previewUrl = extractFirstUrl(m.message);
                                return previewUrl ? (
                                  <LinkPreviewCard url={previewUrl} isMine={isMine} />
                                ) : null;
                              })()}
                            </>
                          )}
                          <div
                            className={`mx-1 mt-1 flex items-center gap-1 ${isMine ? "flex-row-reverse" : "flex-row"}`}
                          >
                            {m.time && (
                              <span className="text-[10px] text-[var(--text-subtle)]">
                                {new Date(m.time).toLocaleTimeString([], {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </span>
                            )}
                            {m.id &&
                              readCounts[m.id] !== undefined &&
                              (() => {
                                const unread = Math.max(
                                  0,
                                  roomUsers.length - readCounts[m.id],
                                );
                                return unread > 0 ? (
                                  <span className="text-[10px] font-semibold text-[var(--warn)]">
                                    {unread}
                                  </span>
                                ) : null;
                              })()}
                          </div>
                          {/* 리액션 pills */}
                          {m.id &&
                            reactions[String(m.id)] &&
                            Object.keys(reactions[String(m.id)]).length > 0 && (
                              <div
                                className={`mt-0.5 flex flex-wrap gap-1 ${isMine ? "justify-end" : "justify-start"}`}
                              >
                                {Object.entries(reactions[String(m.id)]).map(
                                  ([emoji, users]) => {
                                    const isCustom =
                                      emoji.startsWith("[custom-emoji:");
                                    const customId = isCustom
                                      ? emoji.slice(14, -1)
                                      : null;
                                    const isMineReaction =
                                      users.includes(currentLoginUserId);
                                    const isPending =
                                      isMineReaction &&
                                      pendingRemove?.messageId ===
                                        String(m.id) &&
                                      pendingRemove?.emoji === emoji;
                                    return (
                                      <button
                                        key={emoji}
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          toggleReaction(m.id, emoji);
                                        }}
                                        className={`relative flex items-center gap-0.5 rounded-full border px-1.5 py-0.5 text-xs transition-colors ${isMineReaction ? "border-[var(--brand-blue)] bg-brand-blue/10 text-[var(--brand-blue)]" : "border-[var(--border)] bg-[var(--surface-alt)] text-[var(--text)]"}`}
                                      >
                                        {isPending && (
                                          <span className="absolute -right-1 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[var(--danger)] text-[9px] font-bold text-white leading-none">
                                            ✕
                                          </span>
                                        )}
                                        {isCustom ? (
                                          <img
                                            src={`/api/chat/custom-emoji-image?id=${customId}`}
                                            alt="emoji"
                                            className="h-4 w-4 object-contain"
                                          />
                                        ) : (
                                          <span>{emoji}</span>
                                        )}
                                        <span className="font-semibold">
                                          {users.length}
                                        </span>
                                      </button>
                                    );
                                  },
                                )}
                              </div>
                            )}
                        </div>
                        {isMine && (
                          <Avatar
                            src={userInfo.getLoginProfileImage() || undefined}
                            initial={(currentLoginUserId || "B").charAt(0)}
                            size={28}
                            className="ml-2 self-end"
                          />
                        )}
                      </div>
                    )}
                  </React.Fragment>
                );
              })}
            </div>

            {/* 메시지 컨텍스트 메뉴 */}
            {contextMenu &&
              (() => {
                const menuWidth = 120;
                const canDelete = contextMenu.isMine && contextMenu.msg?.id;
                const ctxMsg = contextMenu.msg?.message ?? "";
                const canSaveEmoji =
                  ctxMsg.startsWith("data:image/") ||
                  /^\[img:\d+\]$/.test(ctxMsg) ||
                  /^\[custom-emoji:[0-9a-f-]+\]$/i.test(ctxMsg);
                const menuHeight =
                  50 +
                  48 +
                  (canSaveEmoji ? 48 : 0) +
                  (contextMenu.canEdit ? 48 : 0) +
                  (canDelete ? 48 : 0);
                const { rect, isMine } = contextMenu;
                const top = Math.min(
                  rect.top,
                  window.innerHeight - menuHeight - 8,
                );
                const left = isMine
                  ? Math.max(8, rect.left - menuWidth - 6)
                  : Math.min(rect.right + 6, window.innerWidth - menuWidth - 8);
                return (
                  <div
                    className="fixed z-[9998] flex flex-col overflow-hidden rounded-xl shadow-xl general-text-bg-color"
                    style={{
                      top,
                      left,
                      border: "1px solid var(--theme-semi-bg)",
                      minWidth: menuWidth,
                    }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    {contextMenu.msg?.id && (
                      <>
                        <button
                          className="px-4 py-3 text-sm text-left font-medium general-text-color hover:opacity-70"
                          onClick={(e) => {
                            const rect =
                              e.currentTarget.getBoundingClientRect();
                            setReactionPicker({
                              messageId: contextMenu.msg.id,
                              x: rect.left,
                              y: rect.top,
                            });
                            setContextMenu(null);
                          }}
                        >
                          😊 {tl("chatAddReaction")}
                        </button>
                        <div
                          style={{
                            height: 1,
                            background: "var(--theme-semi-bg)",
                          }}
                        />
                      </>
                    )}
                    <button
                      className="px-4 py-3 text-sm text-left font-medium general-text-color hover:opacity-70"
                      onClick={() => {
                        setReplyingTo({
                          id: contextMenu.msg.id,
                          userName: contextMenu.msg.userName || tl("system"),
                          message: contextMenu.msg.message,
                        });
                        setContextMenu(null);
                      }}
                    >
                      ↩️ 답장
                    </button>
                    <div
                      style={{ height: 1, background: "var(--theme-semi-bg)" }}
                    />
                    <button
                      className="px-4 py-3 text-sm text-left font-medium general-text-color hover:opacity-70"
                      onClick={() => {
                        const text = contextMenu.msg.message || "";
                        navigator.clipboard?.writeText(text).catch(() => {});
                        setContextMenu(null);
                      }}
                    >
                      📋 복사
                    </button>
                    {canSaveEmoji && (
                      <>
                        <div
                          style={{
                            height: 1,
                            background: "var(--theme-semi-bg)",
                          }}
                        />
                        <button
                          className="px-4 py-3 text-sm text-left font-medium general-text-color hover:opacity-70"
                          onClick={async () => {
                            setContextMenu(null);
                            let dataUrl = ctxMsg;
                            if (/^\[img:\d+\]$/.test(ctxMsg)) {
                              const id = ctxMsg.match(/\d+/)[0];
                              const r = await fetch(
                                `/api/chat/image?msgId=${id}`,
                              );
                              const blob = await r.blob();
                              dataUrl =
                                await prepareCustomEmojiDataUrlFromBlob(blob);
                            } else if (
                              /^\[custom-emoji:[0-9a-f-]+\]$/i.test(ctxMsg)
                            ) {
                              const id = ctxMsg.slice(14, -1);
                              const r = await fetch(
                                `/api/chat/custom-emoji-image?id=${id}`,
                              );
                              const blob = await r.blob();
                              dataUrl =
                                await prepareCustomEmojiDataUrlFromBlob(blob);
                            } else if (
                              !isAnimatedEmojiMime(
                                dataUrl.match(/^data:([^;]+)/)?.[1],
                              )
                            ) {
                              dataUrl = await resizeDataUrlToDataUrl(
                                dataUrl,
                                160,
                                160,
                              );
                            }
                            const name = await openInputModal(
                              tl("chatCustomEmojiNamePrompt"),
                              "",
                              constants.messageCategory.Info,
                            );
                            if (!name) return;
                            await registerCustomEmoji(
                              dataUrl,
                              name.slice(0, 20),
                            );
                            setEmojiCategory(CUSTOM_EMOJI_CATEGORY);
                          }}
                        >
                          🖼️ {tl("chatCustomEmojiSave")}
                        </button>
                      </>
                    )}
                    {(contextMenu.canEdit || contextMenu.isMine) && (
                      <>
                        {contextMenu.canEdit && (
                          <>
                            <div
                              style={{
                                height: 1,
                                background: "var(--theme-semi-bg)",
                              }}
                            />
                            <button
                              className="px-4 py-3 text-sm text-left font-medium general-text-color hover:opacity-70"
                              onClick={() => {
                                setInput(contextMenu.msg.message);
                                setEditingMessage({
                                  index: contextMenu.messageIndex,
                                  id: contextMenu.msg.id,
                                });
                                setContextMenu(null);
                              }}
                            >
                              ✏️ 수정
                            </button>
                          </>
                        )}
                        {canDelete && (
                          <>
                            <div
                              style={{
                                height: 1,
                                background: "var(--theme-semi-bg)",
                              }}
                            />
                            <button
                              className="px-4 py-3 text-sm text-left text-danger font-medium hover:opacity-70"
                              onClick={() => deleteMessage(contextMenu.msg)}
                            >
                              🗑️ 삭제
                            </button>
                          </>
                        )}
                      </>
                    )}
                  </div>
                );
              })()}

            {/* 리액션 이모지 피커 */}
            {reactionPicker && (
              <div
                className="fixed z-[9999] rounded-2xl bg-[var(--surface)] px-3 py-2 shadow-xl"
                style={{
                  top: Math.min(
                    reactionPicker.y - 56,
                    window.innerHeight - (customEmojis.length > 0 ? 108 : 72),
                  ),
                  left: Math.max(
                    8,
                    Math.min(reactionPicker.x, window.innerWidth - 360),
                  ),
                  border: "1px solid var(--border)",
                }}
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex gap-2">
                  {REACTION_EMOJIS.map((emoji) => {
                    const reacted =
                      reactions[String(reactionPicker.messageId)]?.[
                        emoji
                      ]?.includes(currentLoginUserId);
                    return (
                      <button
                        key={emoji}
                        onClick={() =>
                          toggleReaction(reactionPicker.messageId, emoji, {
                            fromPicker: true,
                          })
                        }
                        className={`flex h-9 w-9 items-center justify-center rounded-full text-xl transition-colors ${reacted ? "bg-brand-blue/20 ring-2 ring-[var(--brand-blue)]" : "hover:bg-[var(--surface-alt)]"}`}
                        title={reacted ? "클릭하면 리액션 취소" : undefined}
                      >
                        {emoji}
                      </button>
                    );
                  })}
                </div>
                {customEmojis.length > 0 && (
                  <div className="mt-1 flex gap-1 border-t border-[var(--border)] pt-1 overflow-x-auto">
                    {customEmojis.slice(0, 10).map((e) => {
                      const emojiKey = `[custom-emoji:${e.id}]`;
                      const reacted =
                        reactions[String(reactionPicker.messageId)]?.[
                          emojiKey
                        ]?.includes(currentLoginUserId);
                      return (
                        <button
                          key={e.id}
                          onClick={() =>
                            toggleReaction(reactionPicker.messageId, emojiKey, {
                              fromPicker: true,
                            })
                          }
                          className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full transition-colors ${reacted ? "bg-brand-blue/20 ring-2 ring-[var(--brand-blue)]" : "hover:bg-[var(--surface-alt)]"}`}
                          title={reacted ? "클릭하면 리액션 취소" : e.name}
                        >
                          <img
                            src={`/api/chat/custom-emoji-image?id=${e.id}`}
                            alt={e.name}
                            className="h-6 w-6 object-contain"
                          />
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* 이미지 프리뷰 (복수) */}
            {pendingImages.length > 0 && (
              <div className="mt-1 shrink-0 px-3">
                <div className="flex items-center gap-2 overflow-x-auto rounded-[var(--radius-lg)] border border-[var(--border)] bg-[var(--surface)] p-2 shadow-[var(--shadow-card)]">
                  {pendingImages.map((src, idx) => (
                    <div key={idx} className="relative shrink-0">
                      <img
                        src={src}
                        alt="preview"
                        className="max-h-20 max-w-[100px] rounded-[var(--radius-md)] border border-[var(--border)]"
                      />
                      <button
                        onClick={() =>
                          setPendingImages((prev) =>
                            prev.filter((_, i) => i !== idx),
                          )
                        }
                        className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-[var(--danger)] text-xs leading-none text-white"
                        title={tl("cancel")}
                        aria-label={tl("cancel")}
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                  <span className="ml-1 shrink-0 text-xs text-[var(--text-muted)]">
                    {pendingImages.length}장 전송 준비됨
                  </span>
                  <button
                    onClick={() => setPendingImages([])}
                    className="ml-auto shrink-0 text-lg leading-none text-[var(--text-subtle)] hover:text-[var(--danger)]"
                    title={tl("chatCancelAll")}
                    aria-label={tl("cancel")}
                  >
                    ✕
                  </button>
                </div>
              </div>
            )}

            {/* 타이핑 인디케이터 */}
            {typingUsers.length > 0 && (
              <div className="shrink-0 px-4 pb-0.5 pt-1 text-xs text-[var(--text-muted)]">
                {typingUsers.length === 1
                  ? tl("chatTypingIndicator").replace(
                      "{name}",
                      typingUsers[0].userName,
                    )
                  : tl("chatTypingIndicatorMulti")}
              </div>
            )}

            {/* 입력창: flex shrink-0으로 하단 고정 */}
            <div
              className="flex shrink-0 flex-col border-t border-[var(--border)] bg-[var(--surface)]"
              style={{ paddingBottom: "max(0px, env(safe-area-inset-bottom))" }}
            >
              {replyingTo && !editingMessage && (
                <div className="flex items-center gap-2 border-b border-[var(--border)] border-l-4 border-l-[var(--brand-blue)] bg-[image:var(--brand-gradient-soft)] px-3 py-1.5">
                  <span className="shrink-0 text-base font-black leading-none text-[var(--brand-blue)]">
                    ↩
                  </span>
                  <div className="flex-1 min-w-0">
                    <span className="mr-1 text-xs font-bold text-[var(--brand-blue)]">
                      {replyingTo.userName}
                    </span>
                    <span className="truncate text-xs text-[var(--text-muted)]">
                      {replyingTo.message?.startsWith("data:image/") ||
                      /^\[img:\d+\]$/.test(replyingTo.message ?? "")
                        ? "🖼️ 이미지"
                        : replyingTo.message}
                    </span>
                  </div>
                  <button
                    className="shrink-0 text-lg font-bold leading-none text-[var(--text-subtle)] hover:text-[var(--danger)]"
                    onClick={() => setReplyingTo(null)}
                    aria-label={tl("cancel")}
                  >
                    ✕
                  </button>
                </div>
              )}
              {editingMessage && (
                <div className="flex items-center gap-2 border-b border-[var(--border)] bg-[image:var(--brand-gradient-soft)] px-4 py-1.5">
                  <span className="flex-1 text-xs text-[var(--brand-blue)]">
                    ✏️ {tl("chatEditingMessage")}
                  </span>
                  <button
                    className="text-xs text-[var(--text-subtle)] hover:text-[var(--text)]"
                    onClick={() => {
                      setEditingMessage(null);
                      setInput("");
                    }}
                  >
                    {tl("cancel")}
                  </button>
                </div>
              )}
              {/* 받아쓰기 중 UI */}
              {dictating && (
                <div
                  className="flex cursor-pointer items-center gap-3 bg-[rgba(59,130,246,0.10)] px-4 py-2"
                  onClick={stopDictation}
                >
                  <span className="h-2.5 w-2.5 shrink-0 animate-pulse rounded-full bg-[var(--brand-blue)]" />
                  <span className="flex-1 truncate text-sm text-[var(--text-muted)] italic">
                    {dictationInterim || tl("dictationActive")}
                  </span>
                  <span className="shrink-0 text-xs text-[var(--danger)]">
                    ■ 중지
                  </span>
                </div>
              )}
              {/* 녹음 중 / 잠금 UI */}
              {voiceState === "recording" && (
                <div className="flex items-center gap-3 bg-[rgba(239,68,68,0.10)] px-4 py-3">
                  <span className="h-3 w-3 shrink-0 animate-pulse rounded-full bg-[var(--danger)]" />
                  <span className="font-mono-data text-sm text-[var(--danger)]">
                    {`${Math.floor(recordingSec / 60)}:${String(recordingSec % 60).padStart(2, "0")}`}
                  </span>
                  <span className="flex-1 text-center text-xs text-[var(--text-muted)]">
                    {tl("chatRecording")}
                  </span>
                  <Button
                    size="sm"
                    variant="danger"
                    onClick={stopVoiceRecording}
                  >
                    {tl("chatStopRecording")}
                  </Button>
                </div>
              )}
              {voiceState === "preview" && (
                <div className="flex items-center gap-2 border-t border-[var(--border)] bg-[var(--surface)] px-4 py-3">
                  <audio controls src={voiceDataUrl} className="flex-1 h-9" />
                  <button
                    onClick={cancelVoiceRecording}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--surface-alt)] text-[var(--text-muted)]"
                    aria-label={tl("delete")}
                  >
                    🗑
                  </button>
                  <button
                    onClick={sendVoiceMessage}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[image:var(--brand-gradient)] font-bold text-white"
                    aria-label={tl("send")}
                  >
                    ➤
                  </button>
                </div>
              )}

              <div className="flex items-center gap-1 px-2 py-2 md:gap-2 md:px-4">
                {/* 숨김 파일 inputs */}
                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={handleImageFileChange}
                />
                <input
                  ref={videoInputRef}
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={handleVideoFileChange}
                />
                {/* 도구 메뉴 */}
                <div className="relative flex shrink-0" data-chat-tool-panel>
                  <button
                    type="button"
                    onClick={() => {
                      setShowFormatPanel(false);
                      setShowToolPanel((v) => !v);
                    }}
                    className={`flex h-8 w-8 items-center justify-center rounded-full text-lg font-bold transition ${showToolPanel ? "bg-[image:var(--brand-gradient)] text-white" : "bg-[var(--surface-alt)] text-[var(--text)] hover:bg-[var(--surface-hover)]"}`}
                    title={tl("chatTools")}
                    aria-label={tl("chatTools")}
                    aria-expanded={showToolPanel}
                  >
                    +
                  </button>
                  {showToolPanel && (
                    <div
                      className="absolute bottom-10 left-0 z-[70] flex flex-col overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-[var(--shadow-card-strong)]"
                      style={{ minWidth: 140 }}
                      onClick={(e) => e.stopPropagation()}
                      onTouchStart={(e) => e.stopPropagation()}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setShowToolPanel(false);
                          imageInputRef.current?.click();
                        }}
                        className="flex items-center gap-3 px-4 py-3 text-sm text-[var(--text)] hover:bg-[var(--surface-alt)] transition-colors"
                      >
                        <span className="text-base">🖼️</span>
                        <span>{tl("attachImage")}</span>
                      </button>
                      <div className="mx-3 h-px bg-[var(--border)]" />
                      <button
                        type="button"
                        onClick={() => {
                          setShowToolPanel(false);
                          videoInputRef.current?.click();
                        }}
                        disabled={videoUploading}
                        className="flex items-center gap-3 px-4 py-3 text-sm text-[var(--text)] hover:bg-[var(--surface-alt)] transition-colors disabled:opacity-40"
                      >
                        <span className="text-base">
                          {videoUploading ? "⏳" : "🎬"}
                        </span>
                        <span>{tl("attachVideo")}</span>
                      </button>
                      <div className="mx-3 h-px bg-[var(--border)]" />
                      <button
                        type="button"
                        onClick={() => {
                          if (voiceState !== "idle") return;
                          setShowToolPanel(false);
                          startVoiceRecording();
                        }}
                        disabled={voiceState !== "idle"}
                        className="flex items-center gap-3 px-4 py-3 text-sm text-[var(--text)] hover:bg-[var(--surface-alt)] transition-colors disabled:opacity-40"
                      >
                        <span className="text-base">🎤</span>
                        <span>{tl("attachVoice")}</span>
                      </button>
                      <div className="mx-3 h-px bg-[var(--border)]" />
                      <button
                        type="button"
                        onClick={() => {
                          setShowToolPanel(false);
                          if (dictating) stopDictation();
                          else startDictation();
                        }}
                        className={`flex items-center gap-3 px-4 py-3 text-sm transition-colors hover:bg-[var(--surface-alt)] ${dictating ? "text-[var(--danger)]" : "text-[var(--text)]"}`}
                      >
                        <span className="text-base">⌨️</span>
                        <span>
                          {dictating ? "받아쓰기 중지" : tl("attachDictation")}
                        </span>
                      </button>
                      <div className="mx-3 h-px bg-[var(--border)]" />
                      <button
                        type="button"
                        onClick={() => {
                          setShowToolPanel(false);
                          setShowEmojiPanel((v) => !v);
                        }}
                        className={`flex items-center gap-3 px-4 py-3 text-sm transition-colors hover:bg-[var(--surface-alt)] ${showEmojiPanel ? "text-[var(--brand-blue)]" : "text-[var(--text)]"}`}
                      >
                        <span className="text-base">🙂</span>
                        <span>{tl("chatEmoji")}</span>
                      </button>
                    </div>
                  )}
                  {/* 이모지 패널 앵커 */}
                  <div ref={emojiPanelRef} className="relative shrink-0">
                    <button
                      onClick={() => setShowEmojiPanel((v) => !v)}
                      className="hidden"
                      title={tl("chatEmoji")}
                      aria-label={tl("chatEmoji")}
                      aria-expanded={showEmojiPanel}
                    >
                      🙂
                    </button>
                    {showEmojiPanel && (
                      <div
                        className="fixed bottom-16 left-1/2 z-[60] w-[min(92vw,340px)] -translate-x-1/2 overflow-hidden rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] shadow-[var(--shadow-card-strong)]"
                        onClick={(e) => e.stopPropagation()}
                        onTouchStart={(e) => e.stopPropagation()}
                      >
                        <div className="flex border-b border-[var(--border)] bg-[var(--surface-alt)] p-1">
                          {[
                            { id: RECENT_EMOJI_CATEGORY, icon: "🕐" },
                            { id: FAV_EMOJI_CATEGORY, icon: "⭐" },
                            ...EMOJI_CATEGORIES,
                            { id: STICKER_CATEGORY, icon: "🎭" },
                            { id: CUSTOM_EMOJI_CATEGORY, icon: "🖼️" },
                            { id: DRAW_EMOJI_CATEGORY, icon: "✏️" },
                          ].map((category) => (
                            <button
                              key={category.id}
                              onClick={() => setEmojiCategory(category.id)}
                              className={`flex h-8 flex-1 items-center justify-center rounded text-lg transition ${emojiCategory === category.id ? "bg-[var(--surface)] shadow-sm" : "hover:bg-[var(--surface)]"}`}
                              aria-label={`${tl("chatEmoji")} ${category.icon}`}
                            >
                              {category.icon}
                            </button>
                          ))}
                        </div>
                        {emojiCategory !== STICKER_CATEGORY &&
                          emojiCategory !== CUSTOM_EMOJI_CATEGORY &&
                          emojiCategory !== DRAW_EMOJI_CATEGORY &&
                          emojiCategory !== RECENT_EMOJI_CATEGORY &&
                          emojiCategory !== FAV_EMOJI_CATEGORY && (
                            <div className="flex gap-1 border-b border-[var(--border)] p-2">
                              <button
                                onClick={() =>
                                  updateEmojiDisplayMode(EMOJI_DISPLAY_LARGE)
                                }
                                className={`h-8 flex-1 rounded text-xs font-bold ${emojiDisplayMode === EMOJI_DISPLAY_LARGE ? "bg-[image:var(--brand-gradient)] text-white" : "bg-[var(--surface-alt)] text-[var(--text-muted)]"}`}
                              >
                                {tl("chatEmojiLarge")}
                              </button>
                              <button
                                onClick={() =>
                                  updateEmojiDisplayMode(EMOJI_DISPLAY_BUBBLE)
                                }
                                className={`h-8 flex-1 rounded text-xs font-bold ${emojiDisplayMode === EMOJI_DISPLAY_BUBBLE ? "bg-[image:var(--brand-gradient)] text-white" : "bg-[var(--surface-alt)] text-[var(--text-muted)]"}`}
                              >
                                {tl("chatEmojiBubble")}
                              </button>
                            </div>
                          )}
                        {emojiCategory === RECENT_EMOJI_CATEGORY ? (
                          <div className="grid grid-cols-8 gap-1 p-2">
                            {recentEmojis.length === 0 ? (
                              <p className="col-span-8 py-4 text-center text-xs text-[var(--text-muted)]">
                                {tl("chatEmojiRecentEmpty")}
                              </p>
                            ) : (
                              recentEmojis.map((emoji) => {
                                const emojiTooltip = getEmojiTooltip(emoji);
                                return (
                                  <div key={emoji} className="group relative">
                                    <button
                                      onClick={() => onEmojiClick(emoji)}
                                      onTouchStart={onEmojiTouchStart(emoji)}
                                      onTouchEnd={onEmojiTouchEnd(emoji)}
                                      onTouchMove={onEmojiTouchMove}
                                      className="flex aspect-square w-full items-center justify-center rounded text-xl transition hover:bg-[var(--surface-alt)]"
                                      title={emojiTooltip}
                                    >
                                      {emoji}
                                    </button>
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        toggleFavEmoji(emoji);
                                      }}
                                      className={`absolute -right-0.5 -top-0.5 hidden h-4 w-4 items-center justify-center rounded-full text-[8px] group-hover:flex ${favEmojis.includes(emoji) ? "bg-warn/30 text-white" : "bg-[var(--surface-alt)] text-[var(--text-muted)]"}`}
                                    >
                                      ⭐
                                    </button>
                                  </div>
                                );
                              })
                            )}
                          </div>
                        ) : emojiCategory === FAV_EMOJI_CATEGORY ? (
                          <div className="grid grid-cols-8 gap-1 p-2">
                            {favEmojis.length === 0 ? (
                              <p className="col-span-8 py-4 text-center text-xs text-[var(--text-muted)]">
                                {tl("chatEmojiFavEmpty")}
                              </p>
                            ) : (
                              favEmojis.map((emoji) => {
                                const emojiTooltip = getEmojiTooltip(emoji);
                                return (
                                  <div key={emoji} className="group relative">
                                    <button
                                      onClick={() => onEmojiClick(emoji)}
                                      onTouchStart={onEmojiTouchStart(emoji)}
                                      onTouchEnd={onEmojiTouchEnd(emoji)}
                                      onTouchMove={onEmojiTouchMove}
                                      className="flex aspect-square w-full items-center justify-center rounded text-xl transition hover:bg-[var(--surface-alt)]"
                                      title={emojiTooltip}
                                    >
                                      {emoji}
                                    </button>
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        toggleFavEmoji(emoji);
                                      }}
                                      className="absolute -right-0.5 -top-0.5 hidden h-4 w-4 items-center justify-center rounded-full bg-warn/30 text-[8px] text-white group-hover:flex"
                                    >
                                      ⭐
                                    </button>
                                  </div>
                                );
                              })
                            )}
                          </div>
                        ) : emojiCategory === STICKER_CATEGORY ? (
                          <div className="p-2">
                            <div className="grid grid-cols-4 gap-2">
                              {STICKER_PACK.map((sticker) => (
                                <button
                                  key={sticker.id}
                                  onClick={() => {
                                    doSendMsg(`[sticker:${sticker.id}]`, false);
                                    setShowEmojiPanel(false);
                                  }}
                                  className="flex flex-col items-center justify-center gap-0.5 rounded-lg bg-[var(--surface-alt)] p-2 hover:bg-[var(--surface-hover)] active:scale-95 transition-transform"
                                  title={tl(sticker.labelKey)}
                                >
                                  <span
                                    className={`text-4xl leading-none ${sticker.cls}`}
                                  >
                                    {sticker.emoji}
                                  </span>
                                  <span className="text-[10px] text-[var(--text-muted)]">
                                    {tl(sticker.labelKey)}
                                  </span>
                                </button>
                              ))}
                            </div>
                          </div>
                        ) : emojiCategory === CUSTOM_EMOJI_CATEGORY ? (
                          <div className="p-2">
                            <input
                              ref={customEmojiInputRef}
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={handleCustomEmojiFileChange}
                            />
                            {customEmojis.length === 0 ? (
                              <p className="py-4 text-center text-xs text-[var(--text-muted)]">
                                {tl("chatCustomEmojiEmpty")}
                              </p>
                            ) : (
                              <div className="mb-2 grid grid-cols-5 gap-1.5 max-h-[160px] overflow-y-auto">
                                {customEmojis.map((e) => (
                                  <div
                                    key={e.id}
                                    className="group relative flex flex-col items-center"
                                  >
                                    <button
                                      onClick={() => {
                                        doSendMsg(
                                          `[custom-emoji:${e.id}]`,
                                          false,
                                        );
                                        setShowEmojiPanel(false);
                                      }}
                                      className="flex h-12 w-12 items-center justify-center rounded-lg bg-[var(--surface-alt)] hover:bg-[var(--surface-hover)] active:scale-95 transition-transform overflow-hidden"
                                      title={e.name}
                                    >
                                      <img
                                        src={`/api/chat/custom-emoji-image?id=${e.id}`}
                                        alt={e.name}
                                        className="h-10 w-10 object-contain"
                                      />
                                    </button>
                                    <span className="truncate text-[9px] text-[var(--text-muted)] w-12 text-center">
                                      {e.name}
                                    </span>
                                    <button
                                      onClick={() => deleteCustomEmoji(e.id)}
                                      className="absolute -right-1 -top-1 hidden h-4 w-4 items-center justify-center rounded-full bg-danger text-[9px] text-white group-hover:flex"
                                      title={tl("chatCustomEmojiDelete")}
                                    >
                                      ×
                                    </button>
                                  </div>
                                ))}
                              </div>
                            )}
                            <div className="mt-1 flex gap-1">
                              <button
                                onClick={() =>
                                  customEmojiInputRef.current?.click()
                                }
                                disabled={
                                  customEmojiUploading ||
                                  customEmojiAiGenerating
                                }
                                className="flex-1 rounded-lg bg-[var(--surface-alt)] py-2 text-xs font-bold text-[var(--text-muted)] hover:bg-[var(--surface-hover)] disabled:opacity-50"
                              >
                                {customEmojiUploading
                                  ? tl("chatCustomEmojiAdding")
                                  : tl("chatCustomEmojiAdd")}
                              </button>
                              <button
                                onClick={generateAiEmoji}
                                disabled={
                                  customEmojiUploading ||
                                  customEmojiAiGenerating
                                }
                                className="flex-1 rounded-lg bg-[image:var(--brand-gradient)] py-2 text-xs font-bold text-white hover:opacity-90 disabled:opacity-50"
                              >
                                {customEmojiAiGenerating
                                  ? tl("chatAiEmojiGenerating")
                                  : tl("chatAiEmojiGenerate")}
                              </button>
                            </div>
                          </div>
                        ) : emojiCategory === DRAW_EMOJI_CATEGORY ? (
                          <div className="p-2">
                            <canvas
                              ref={emojiCanvasRef}
                              className="h-[180px] w-full touch-none rounded border border-[var(--border)] bg-white"
                              onMouseDown={startEmojiDrawing}
                              onMouseMove={drawEmojiStroke}
                              onMouseUp={stopEmojiDrawing}
                              onMouseLeave={stopEmojiDrawing}
                              onTouchStart={startEmojiDrawing}
                              onTouchMove={drawEmojiStroke}
                              onTouchEnd={stopEmojiDrawing}
                            />
                            <div className="mt-2 flex items-center gap-1">
                              {DRAW_COLORS.map((color) => (
                                <button
                                  key={color}
                                  onClick={() => setEmojiDrawColor(color)}
                                  className={`h-7 w-7 rounded-full border ${emojiDrawColor === color ? "border-[var(--text)]" : "border-[var(--border)]"}`}
                                  style={{ backgroundColor: color }}
                                  aria-label={color}
                                />
                              ))}
                              <button
                                onClick={clearEmojiCanvas}
                                className="ml-auto flex h-8 w-8 items-center justify-center rounded bg-[var(--surface-alt)] text-[var(--text-muted)]"
                                title={tl("chatClearCanvas")}
                                aria-label={tl("chatClearCanvas")}
                              >
                                ↺
                              </button>
                              <button
                                onClick={addDrawnEmoji}
                                className="flex h-8 w-8 items-center justify-center rounded bg-[image:var(--brand-gradient)] font-bold text-white"
                                title={tl("chatAddSticker")}
                                aria-label={tl("chatAddSticker")}
                              >
                                +
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="grid grid-cols-8 gap-1 p-2">
                            {(
                              EMOJI_CATEGORIES.find(
                                (category) => category.id === emojiCategory,
                              ) || EMOJI_CATEGORIES[0]
                            ).items.map((emoji) => {
                              const emojiTooltip = getEmojiTooltip(emoji);
                              return (
                                <div key={emoji} className="group relative">
                                  <button
                                    onClick={() => onEmojiClick(emoji)}
                                    onTouchStart={onEmojiTouchStart(emoji)}
                                    onTouchEnd={onEmojiTouchEnd(emoji)}
                                    onTouchMove={onEmojiTouchMove}
                                    className="flex aspect-square w-full items-center justify-center rounded text-xl transition hover:bg-[var(--surface-alt)]"
                                    title={emojiTooltip}
                                    aria-label={emojiTooltip}
                                  >
                                    {emoji}
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      toggleFavEmoji(emoji);
                                    }}
                                    className={`absolute -right-0.5 -top-0.5 hidden h-4 w-4 items-center justify-center rounded-full text-[8px] group-hover:flex ${favEmojis.includes(emoji) ? "bg-warn/30 text-white" : "bg-[var(--surface-alt)] text-[var(--text-muted)]"}`}
                                  >
                                    ⭐
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
                {/* end 도구 메뉴 */}
                <div className="relative shrink-0" data-chat-format-panel>
                  <button
                    type="button"
                    onClick={() => {
                      setShowToolPanel(false);
                      setShowFormatPanel((v) => !v);
                    }}
                    className={`flex h-8 min-w-8 items-center justify-center rounded-full px-2 text-xs font-extrabold transition ${showFormatPanel ? "bg-[image:var(--brand-gradient)] text-white" : "bg-[var(--surface-alt)] text-[var(--text)] hover:bg-[var(--surface-hover)]"}`}
                    title={tl("chatFormatText")}
                    aria-label={tl("chatFormatText")}
                    aria-expanded={showFormatPanel}
                  >
                    Aa
                  </button>
                  {showFormatPanel && (
                    <div
                      className="absolute bottom-10 left-1/2 z-[70] flex -translate-x-1/2 flex-col items-center gap-1 rounded-[var(--radius-lg)] border border-[var(--border)] bg-[var(--surface)] p-1 shadow-[var(--shadow-card-strong)]"
                      onClick={(e) => e.stopPropagation()}
                      onTouchStart={(e) => e.stopPropagation()}
                    >
                      <div className="max-w-[220px] truncate rounded-full bg-[rgba(2,132,199,0.10)] px-2 py-1 text-[11px] font-semibold text-[var(--brand-blue)]">
                        선택: {formatSelectionText || tl("chatFormatSample")}
                      </div>
                      <div className="flex gap-1">
                        <button
                          type="button"
                          onClick={() => wrapSelectedInput("bold")}
                          className="flex h-8 min-w-8 items-center justify-center rounded-full bg-[var(--surface-alt)] px-2 text-xs font-extrabold text-[var(--text)] hover:bg-[var(--surface-hover)]"
                          title={tl("chatFormatBold")}
                          aria-label={tl("chatFormatBold")}
                        >
                          B
                        </button>
                        <button
                          type="button"
                          onClick={() => wrapSelectedInput("highlight")}
                          className="flex h-8 min-w-8 items-center justify-center rounded-full bg-warn/30 px-2 text-xs font-bold text-gray-950 hover:bg-warn/30"
                          title={tl("chatFormatHighlight")}
                          aria-label={tl("chatFormatHighlight")}
                        >
                          H
                        </button>
                        <button
                          type="button"
                          onClick={() => wrapSelectedInput("red")}
                          className="flex h-8 min-w-8 items-center justify-center rounded-full bg-[var(--surface-alt)] px-2 text-xs font-bold text-danger hover:bg-[var(--surface-hover)]"
                          title={tl("chatFormatRed")}
                          aria-label={tl("chatFormatRed")}
                        >
                          A
                        </button>
                        <button
                          type="button"
                          onClick={focusFormattedInput}
                          className="flex h-8 min-w-8 items-center justify-center rounded-full bg-[image:var(--brand-gradient)] px-2 text-xs font-bold text-white hover:opacity-90"
                          title={tl("chatFormatStartTyping")}
                          aria-label={tl("chatFormatStartTyping")}
                        >
                          ⌨
                        </button>
                      </div>
                    </div>
                  )}
                </div>
                <Input
                  ref={messageInputRef}
                  className="min-w-0 flex-1"
                  inputClassName="rounded-full"
                  value={input}
                  onChange={(e) => {
                    formatSelectionRef.current = null;
                    setFormatSelectionText("");
                    setInput(e.target.value);
                    if (
                      currentRoom &&
                      currentLoginUserId &&
                      e.target.value &&
                      !typingTimerRef.current
                    ) {
                      socket.emit(constants.websocketMessageType.typing, {
                        roomId: currentRoom.id,
                      });
                      typingTimerRef.current = setTimeout(() => {
                        typingTimerRef.current = null;
                      }, 2000);
                    }
                  }}
                  onPaste={handlePaste}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                />
                {/* 모바일: 아이콘 버튼 / 데스크탑: 텍스트 버튼 */}
                {activityType && hadSession && !canChat && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      const ref =
                        activityType === "coffee" ? coffeeRef : smokingRef;
                      ref?.current?.triggerStart();
                      setHadSession(false);
                    }}
                    className="shrink-0 rounded-full"
                  >
                    {tl("chatRefill")}
                  </Button>
                )}
                <button
                  onClick={sendMessage}
                  className="flex h-10 shrink-0 items-center justify-center rounded-full bg-[image:var(--brand-gradient)] px-4 text-sm font-bold text-white shadow-[var(--shadow-primary)] transition hover:opacity-90"
                  aria-label={editingMessage ? tl("save") : tl("send")}
                >
                  {editingMessage
                    ? tl("save")
                    : activityType === "coffee" &&
                        ["dujjeonku", "shanghaibutter"].includes(
                          isDrinkingActive?.drinkType,
                        )
                      ? tl("cafeDessertBite")
                      : activityType === "coffee"
                        ? tl("cafeSip")
                        : tl("send")}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-1 flex-col gap-3 px-3 py-4">
            {!externalRoomId && (
              <>
                {/* 모바일: 방 만들기 + 방 목록 직접 표시 */}
                <Button className="w-full md:hidden" onClick={createRoom}>
                  {tl("createRoom")}
                </Button>
                <div className="flex flex-col gap-2 md:hidden">
                  {visibleRooms.map((r) => (
                    <div
                      key={r.id}
                      role="button"
                      tabIndex={0}
                      className="w-full rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-3 text-left text-sm text-[var(--text)]"
                      onClick={() => enterListRoom(r)}
                      onKeyDown={(e) => enterListRoomByKey(e, r)}
                    >
                      <span className="flex items-center gap-3">
                        <Avatar
                          initial={(r.name || "B")
                            .replace("🔒", "")
                            .trim()
                            .charAt(0)}
                          size={32}
                        />
                        <span className="min-w-0 flex-1 truncate">
                          {r.is_secret && !getListDirectPeerId(r) && <span className="mr-1">🔒</span>}
                          {r.name.replace(/🔒\s*/g, "")}
                        </span>
                        <span className="flex shrink-0 items-center gap-1">
                          {renderListModeActions(r)}
                        </span>
                      </span>
                    </div>
                  ))}
                  {rooms.length === 0 && (
                    <p className="mt-4 text-center text-sm text-[var(--text-muted)]">
                      {chatIntro}
                    </p>
                  )}
                </div>
                {/* 데스크탑: 안내 문구만 (사이드바에 방 목록 있음) */}
                <p className="mt-8 hidden text-center text-sm text-[var(--text-muted)] md:block">
                  {chatIntro}
                </p>
              </>
            )}
            {externalRoomId && (
              <p className="mt-4 text-center text-sm text-[var(--text-muted)]">
                {chatIntro}
              </p>
            )}
          </div>
        )}
      </div>
      {/* 초대 완료 토스트 */}
      {chatToast && (
        <div className="fixed bottom-24 left-1/2 z-[9980] -translate-x-1/2 rounded-full bg-[var(--brand-blue)] px-4 py-2 text-sm font-medium text-white shadow-lg">
          {chatToast}
        </div>
      )}
      {/* 채팅방 초대 수락/거절 모달 */}
      {pendingInvites.length > 0 && (
        <div className="fixed inset-0 z-[10000] flex items-end justify-center pb-8 sm:items-center">
          <div className="mx-4 w-full max-w-sm rounded-2xl border border-[var(--border-color)] bg-[var(--surface)] shadow-2xl">
            <div className="px-5 py-4 border-b border-[var(--border-color)]">
              <p className="font-semibold text-[var(--general-text-color)]">
                {tl("roomInviteReceived")}
              </p>
            </div>
            <div className="max-h-72 overflow-y-auto divide-y divide-[var(--border-color)]">
              {pendingInvites.map((inv) => (
                <div
                  key={inv.invite_id}
                  className="flex items-center gap-3 px-5 py-4"
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-[var(--general-text-color)] truncate">
                      <span className="font-medium">
                        {inv.inviter_name || inv.inviter_id}
                      </span>{" "}
                      {tl("roomInviteBody")}
                    </p>
                    <p className="text-sm font-semibold text-[var(--general-text-color)] truncate mt-0.5">
                      {inv.room_name || inv.room_id}
                    </p>
                  </div>
                  <button
                    onClick={() => handleRejectInvite(inv)}
                    className="shrink-0 rounded-lg px-3 py-1.5 text-xs font-medium text-[var(--semi-text-color)] border border-[var(--border-color)] hover:bg-[var(--surface-alt)]"
                  >
                    {tl("roomInviteReject")}
                  </button>
                  <button
                    onClick={() => handleAcceptInvite(inv)}
                    className="shrink-0 rounded-lg px-3 py-1.5 text-xs font-medium text-white bg-[var(--brand-blue)] hover:opacity-90"
                  >
                    {tl("roomInviteAccept")}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {lightboxIndex !== null && lightboxSrc && (
        <div
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80"
          onClick={() => setLightboxIndex(null)}
          onKeyDown={(e) => {
            if (e.key === "ArrowLeft") {
              e.stopPropagation();
              lightboxPrev();
            }
            if (e.key === "ArrowRight") {
              e.stopPropagation();
              lightboxNext();
            }
            if (e.key === "Escape") setLightboxIndex(null);
          }}
          tabIndex={0}
          ref={(el) => el?.focus()}
          onTouchStart={(e) => {
            swipeTouchStartX.current = e.touches[0].clientX;
          }}
          onTouchEnd={(e) => {
            if (swipeTouchStartX.current === null) return;
            const dx = e.changedTouches[0].clientX - swipeTouchStartX.current;
            if (dx > 50) lightboxPrev();
            else if (dx < -50) lightboxNext();
            swipeTouchStartX.current = null;
          }}
        >
          <img
            src={lightboxSrc}
            alt={tl("enlargedImage")}
            className="max-w-[95vw] max-h-[95vh] md:max-w-[85vw] md:max-h-[85vh] rounded-xl shadow-2xl object-contain"
          />
          {/* 다운로드 + 닫기 */}
          <div
            className="absolute right-4 flex items-center gap-2"
            style={{ top: "max(1rem, env(safe-area-inset-top, 1rem))" }}
          >
            <a
              href={lightboxSrc}
              download={`image_${lightboxMsg?.id ?? "brunner"}`}
              onClick={(e) => e.stopPropagation()}
              className="flex items-center gap-1 rounded-full bg-white/20 px-3 py-1.5 text-sm text-white hover:bg-white/30"
              title={tl("downloadImage")}
            >
              ⬇ {tl("downloadImage")}
            </a>
            <button
              className="text-white text-3xl leading-none hover:text-gray-300"
              onClick={() => setLightboxIndex(null)}
            >
              ✕
            </button>
          </div>
          {/* 이전 */}
          {lightboxIndex > 0 && (
            <button
              className="absolute left-3 top-1/2 -translate-y-1/2 text-white text-4xl leading-none hover:text-gray-300 px-2 select-none"
              onClick={(e) => {
                e.stopPropagation();
                lightboxPrev();
              }}
            >
              ‹
            </button>
          )}
          {/* 다음 */}
          {lightboxIndex < imageMessages.length - 1 && (
            <button
              className="absolute right-3 top-1/2 -translate-y-1/2 text-white text-4xl leading-none hover:text-gray-300 px-2 select-none"
              onClick={(e) => {
                e.stopPropagation();
                lightboxNext();
              }}
            >
              ›
            </button>
          )}
          {/* 인덱스 표시 */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white text-sm opacity-70">
            {lightboxIndex + 1} / {imageMessages.length}
          </div>
        </div>
      )}

      {/* 이름 클릭 컨텍스트 메뉴 */}
      {nameMenu && (
        <div
          ref={nameMenuRef}
          className="fixed z-50 overflow-hidden rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] shadow-[var(--shadow-card)]"
          style={{ top: nameMenu.y, left: nameMenu.x }}
        >
          <button
            className="flex w-full items-center gap-2 px-4 py-2.5 text-sm hover:bg-[var(--surface-alt)]"
            onClick={() => {
              startDirectChat(nameMenu.userId, nameMenu.userName, {
                requireFriend: false,
              });
              setNameMenu(null);
            }}
          >
            💬 {tl("directMessage")}
          </button>
          <button
            className="flex w-full items-center gap-2 px-4 py-2.5 text-sm hover:bg-[var(--surface-alt)]"
            onClick={() => connectPhoneCall(nameMenu.userId)}
          >
            📞 {tl("voiceCall")}
          </button>
        </div>
      )}
    </div>
  );
}
