import React, {
  useState,
  useRef,
  useEffect,
  useCallback,
  forwardRef,
} from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import Loading from "@/components/core/client/loading";
import { Input, Button, Table } from "antd";

const AutoResizeTextarea = forwardRef(
  ({ name, value, onChange, readOnly }, ref) => {
    const textareaRef = useRef(null);

    // 높이 조정 로직
    useEffect(() => {
      const textarea = textareaRef.current;
      if (textarea) {
        textarea.style.height = "auto"; // 높이 초기화
        textarea.style.height = `${textarea.scrollHeight + 5}px`; // 내용에 맞게 높이 설정
      }
    }, [value]);

    const handleResizeHeight = useCallback(() => {
      textareaRef.current.style.height =
        textareaRef.current.scrollHeight + "px";
    }, []);

    const handleChange = (e) => {
      if (!readOnly) {
        onChange(e); // 값 변경 처리
      }
      handleResizeHeight();
    };

    return (
      <textarea
        ref={textareaRef}
        name={name}
        value={value}
        onChange={handleChange}
        readOnly={readOnly}
        className={`
          w-full 
          border 
          border-gray-300 
          resize-none 
          rounded-md 
          p-2 
          mt-1
          ${
            readOnly
              ? `bg-gray-100 
             text-slate-400 
             dark-bg-color 
             dark:text-slate-800`
              : `general-text-bg-color`
          }
          `}
        rows="10"
      />
    );
  },
);

const DynamicSQL = () => {
  // 로딩 & 메시지 박스
  // {

  const [currentSystemCode, setCurrentSystemCode] = useState("");
  const [currentLoginUserId, setCurrentLoginUserId] = useState("");
  const [currentLanguageCode, setCurrentLanguageCode] = useState("");
  const [mounted, setMounted] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const [loading, setLoading] = useState(false);
  const { BrunnerMessageBox, openOkCancelModal, openOkModal, openInputModal } =
    useModal();

  const editPanelRef = useRef(null); // EditPanel Div 참조
  const [isEditing, setIsEditing] = useState(false);
  const [isCreating, setIsCreating] = useState(false);

  const [queries, setQueries] = useState([]);
  const [sqlInput, setSqlInput] = useState({
    system_code: constants.emptyString,
    sql_name: constants.emptyString,
    sql_seq: constants.emptyString,
    sql_content: constants.emptyString,
  });
  var [currentDynamicSQL, setCurrentDynamicSQL] = useState(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    setMounted(true);
    setIsAdmin(userInfo.isAdminUser());
    setCurrentSystemCode(userInfo.getCurrentSystemCode());
    setCurrentLoginUserId(userInfo.getLoginUserId());
    setCurrentLanguageCode(userInfo.getCurrentLanguageCode());

    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // Fetch queries from API — systemCode/userId 세팅 후 호출
  useEffect(() => {
    if (!currentSystemCode || !currentLoginUserId) return;
    fetchSQLList();
  }, [currentSystemCode, currentLoginUserId]);

  var editingDynamicSQL;

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    editingDynamicSQL = {
      system_code: name === "system_code" ? value : sqlInput.system_code,
      sql_name: name === "sql_name" ? value : sqlInput.sql_name,
      sql_seq: name === "sql_seq" ? value : sqlInput.sql_seq,
      sql_content: name === "sql_content" ? value : sqlInput.sql_content,
    };

    setSqlInput((prevForm) => editingDynamicSQL);
  };

  const fetchSQLList = async () => {
    // 관리자 계정인 경우만 조회
    try {
      const jRequest = {
        commandName: constants.commands.DYNAMIC_SEQ_SELECT_ALL,
                userId: currentLoginUserId,
        languageCode: currentLanguageCode,
      };

      setLoading(true); // 데이터 로딩 시작
      const jResponse = await RequestServer(jRequest);
      setLoading(false); // 데이터 로딩 끝

      if (jResponse.error_code === constants.errorCode.Success) {
        setQueries(jResponse.data);
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }

      setSqlInput({
        system_code: constants.emptyString,
        sql_name: constants.emptyString,
        sql_seq: constants.emptyString,
        sql_content: constants.emptyString,
      });
      setCurrentDynamicSQL(null);
      setIsEditing(false);
      setIsCreating(false);
    } catch (e) {
      setLoading(false); // 데이터 로딩 끝
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  // Handle create or update action
  const handleCreateOrUpdate = async (e) => {
    e.preventDefault();
    try {
      var jRequest = {};
      var jResponse = null;

      console.info(
        `${sqlInput.system_code} ${sqlInput.sql_name} ${sqlInput.sql_seq} ${sqlInput.sql_content}`,
      );

      jRequest.commandName = constants.commands.DYNAMIC_SEQ_UPDATE_ONE;
      jRequest.sqlName = sqlInput.sql_name;
      jRequest.sqlSeq = sqlInput.sql_seq;
      jRequest.sqlContent = sqlInput.sql_content;
      jRequest.action = isEditing ? "Update" : isCreating ? "Create" : null;
      jRequest.userId = currentLoginUserId;
      jRequest.languageCode = currentLanguageCode;

      setLoading(true); // 데이터 로딩 시작
      jResponse = await RequestServer(jRequest);
      setLoading(false); // 데이터 로딩 끝

      if (jResponse.error_code === constants.errorCode.Success) {
        await openOkModal(
          commonFunctions.getResourceByLanguage(
            `SUCCESS_SAVED`,
            constants.resourceType.message,
            jRequest.languageCode,
          ),
          constants.messageCategory.Info,
        );
        fetchSQLList();
      } else {
        await openOkModal(
          jResponse.error_message,
          constants.messageCategory.Error,
        );
      }
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    }
  };

  const handleNew = () => {
    setSqlInput({
      system_code: constants.emptyString,
      sql_name: constants.emptyString,
      sql_seq: constants.emptyString,
      sql_content: constants.emptyString,
    });
    setCurrentDynamicSQL({
      system_code: constants.emptyString,
      sql_name: constants.emptyString,
      sql_seq: constants.emptyString,
      sql_content: constants.emptyString,
    });
    setIsCreating(true); // 신규 데이터 생성 모드 활성화
  };

  // Handle edit action
  const handleEdit = (userQueryItem) => {
    setSqlInput({
      system_code: userQueryItem.system_code,
      sql_name: userQueryItem.sql_name,
      sql_seq: userQueryItem.sql_seq,
      sql_content: userQueryItem.sql_content,
    });

    setCurrentDynamicSQL(userQueryItem);

    setIsEditing(true);

    // 스크롤을 TextArea로 이동
    editPanelRef.current.scrollIntoView({ behavior: "smooth" });
  };

  const ClearInputButton = () => {
    return (
      <Button
        onClick={handleNew}
        className="px-4 py-2 rounded-md focus:outline-none focus:ring focus:ring-success focus:ring-opacity-50 ml-1"
        style={{ backgroundColor: "var(--success)", color: "#fff", borderColor: "transparent" }}
      >
        {commonFunctions.getResourceByLanguage(
          "clear",
          constants.resourceType.label,
          currentLanguageCode,
        )}
      </Button>
    );
  };

  const CreateUpdateButton = () => {
    return (
      <Button
        onClick={handleCreateOrUpdate}
        className="px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue focus:ring-opacity-50"
        style={{ backgroundColor: "var(--brand-blue)", color: "#fff", borderColor: "transparent" }}
      >
        {currentDynamicSQL
          ? commonFunctions.getResourceByLanguage(
              `update`,
              constants.resourceType.label,
              currentLanguageCode,
            )
          : commonFunctions.getResourceByLanguage(
              `create`,
              constants.resourceType.label,
              currentLanguageCode,
            )}
      </Button>
    );
  };

  // Handle delete action
  const handleDelete = async (userQueryItem) => {
    try {
      const result = await openOkModal(
        commonFunctions.getResourceByLanguage(
          `CONFIRM_DELETE_ITEM`,
          constants.resourceType.message,
          currentLanguageCode,
        ),
        constants.messageCategory.Confirm,
      );
      if (!result) return;

      var jRequest = {};
      var jResponse = null;

      jRequest.commandName = constants.commands.DYNAMIC_SEQ_DELETE_ONE;
      jRequest.sqlName = userQueryItem.sql_name;
      jRequest.sqlSeq = userQueryItem.sql_seq;
      jRequest.userId = currentLoginUserId;
      jRequest.languageCode = currentLanguageCode;

      setLoading(true); // 데이터 로딩 시작
      jResponse = await RequestServer(jRequest);
      setLoading(false); // 데이터 로딩 끝

      if (jResponse.error_code === constants.errorCode.Success) {
        await openOkModal(
          commonFunctions.getResourceByLanguage(
            `SUCCESS_DELETED`,
            constants.resourceType.message,
            currentLanguageCode,
          ),
          constants.messageCategory.Info,
        );
        fetchSQLList();
      } else
        openOkModal(jResponse.error_message, constants.messageCategory.Error);
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
      console.error(`message:${e.message}\n stack:${e.stack}\n`);
    }
  };

  return (
    <>
      <BrunnerMessageBox />
      <div className="flex-1 overflow-auto relative">
        {loading && <Loading />}
      </div>
      {mounted && isAdmin && (
        <div className={`w-full p-4`}>
          <div ref={editPanelRef} className={`w-full mb-4`}>
            <label className={`block mb-2`}>
              <span className={`text-gray-400`}>System Code:</span>
              <input
                type="text"
                name="system_code"
                value={sqlInput.system_code}
                onChange={handleInputChange}
                readOnly={!isEditing && !isCreating}
                className={`mt-1 
                            block 
                            w-full 
                            border 
                            border-gray-300 
                            text-gray-800 
                            dark:text-gray-400 
                            dark-bg-color 
                            rounded-md 
                            shadow-sm 
                            focus:border-brand-blue 
                            focus:ring 
                            focus:ring-brand-blue 
                            focus:ring-opacity-50`}
                required
              />
            </label>
            <label className={`block mb-2`}>
              <span className={`text-gray-400`}>SQL Name:</span>
              <input
                type="text"
                name="sql_name"
                value={sqlInput.sql_name}
                onChange={handleInputChange}
                readOnly={!isEditing && !isCreating}
                className={`mt-1 
                            block 
                            w-full 
                            border 
                            border-gray-300 
                            text-gray-800 
                            dark:text-gray-400 
                            dark-bg-color 
                            rounded-md 
                            shadow-sm 
                            focus:border-brand-blue 
                            focus:ring 
                            focus:ring-brand-blue 
                            focus:ring-opacity-50`}
                required
              />
            </label>
            <label className={`block mb-2`}>
              <span className={`text-gray-400`}>SQL Sequence:</span>
              <input
                type="text"
                name="sql_seq"
                value={sqlInput.sql_seq}
                onChange={handleInputChange}
                readOnly={!isEditing && !isCreating}
                className={`mt-1 
                            block 
                            w-full 
                            border 
                            border-gray-300 
                            text-gray-800 
                            dark:text-gray-400 
                            dark-bg-color 
                            rounded-md 
                            shadow-sm 
                            focus:border-brand-blue 
                            focus:ring 
                            focus:ring-brand-blue 
                            focus:ring-opacity-50`}
                required
              />
            </label>
            <label className={`block mb-4`}>
              <span className={`text-gray-400`}>SQL Content:</span>
              <AutoResizeTextarea
                name="sql_content"
                value={sqlInput.sql_content}
                onChange={handleInputChange}
                readOnly={!isEditing && !isCreating}
              />
            </label>
            <div className={constants.emptyString}>
              <CreateUpdateButton />
              <ClearInputButton />
            </div>
          </div>
          <h2
            className={`text-sm 
                          font-semibold 
                          mb-4`}
          >
            {commonFunctions.getResourceByLanguage(
              "sqlList",
              constants.resourceType,
              currentLanguageCode,
            )}
          </h2>
          <Button
            onClick={fetchSQLList}
            className="px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue focus:ring-opacity-50 mt-2"
            style={{ backgroundColor: "var(--brand-blue)", color: "#fff", borderColor: "transparent" }}
          >
            {commonFunctions.getResourceByLanguage(
              "refresh",
              constants.resourceType.label,
              currentLanguageCode,
            )}
          </Button>
          <div className="w-full mt-2">
            {isMobile ? (
              /* =========================
                📱 모바일 카드 모드
                ========================= */
              <div className="space-y-3">
                {queries.map((query) => (
                  <div
                    key={`${query.system_code}-${query.sql_name}-${query.sql_seq}`}
                    className="border border-gray-300 rounded-md p-3 general-text-be-color shadow-sm"
                  >
                    <div className="text-sm mb-1">
                      <span className="text-gray-400">System Code</span>
                      <div className="font-medium">{query.system_code}</div>
                    </div>

                    <div className="text-sm mb-1">
                      <span className="text-gray-400">SQL Name</span>
                      <div className="font-medium break-words">
                        {query.sql_name}
                      </div>
                    </div>

                    <div className="text-sm mb-1">
                      <span className="text-gray-400">SQL Sequence</span>
                      <div className="font-medium">{query.sql_seq}</div>
                    </div>

                    <div className="text-sm mb-2">
                      <span className="text-gray-400">SQL Content</span>
                      <pre className="mt-1 p-2 general-text-bg-color rounded text-xs overflow-x-auto break-words">
                        {query.sql_content}
                      </pre>
                    </div>

                    <div className="flex gap-2 mt-2">
                      <Button
                        onClick={() => handleEdit(query)}
                        className="px-3 py-1 rounded-md"
                        style={{ backgroundColor: "var(--warn)", color: "#fff", borderColor: "transparent" }}
                      >
                        {commonFunctions.getResourceByLanguage(
                          "edit",
                          constants.resourceType.label,
                          currentLanguageCode,
                        )}
                      </Button>
                      <Button
                        onClick={() => handleDelete(query)}
                        className="px-3 py-1 rounded-md"
                        style={{ backgroundColor: "var(--danger)", color: "#fff", borderColor: "transparent" }}
                      >
                        {commonFunctions.getResourceByLanguage(
                          "del",
                          constants.resourceType.label,
                          currentLanguageCode,
                        )}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              /* =========================
              🖥 PC 테이블 모드 (원본 그대로)
              ========================= */
              <div className="w-full overflow-x-auto">
                <table
                  className={`w-full general-text-be-color border border-gray-300 mt-2`}
                >
                  <thead>
                    <tr>
                      <th className="border border-gray-300 dark:text-gray-400 dark-bg-color px-4 py-2">
                        System Code
                      </th>
                      <th className="border border-gray-300 dark:text-gray-400 dark-bg-color px-4 py-2">
                        SQL Name
                      </th>
                      <th className="border border-gray-300 dark:text-gray-400 dark-bg-color px-4 py-2">
                        SQL Sequence
                      </th>
                      <th className="border border-gray-300 dark:text-gray-400 dark-bg-color px-4 py-2">
                        SQL Content
                      </th>
                      <th className="border border-gray-300 dark:text-gray-400 dark-bg-color px-4 py-2">
                        Actions
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    {queries.map((query) => (
                      <tr key={query.id}>
                        <td className="border border-gray-300 general-text-bg-color px-4 py-2">
                          {query.system_code}
                        </td>
                        <td className="border border-gray-300 general-text-bg-color px-4 py-2">
                          {query.sql_name}
                        </td>
                        <td className="border border-gray-300 general-text-bg-color px-4 py-2">
                          {query.sql_seq}
                        </td>
                        <td className="border border-gray-300 general-text-bg-color px-4 py-2">
                          <pre className="general-text-bg-color">
                            {query.sql_content}
                          </pre>
                        </td>
                        <td className="border border-gray-300 general-text-bg-color px-4 py-2">
                          <Button
                            onClick={() => handleEdit(query)}
                            className="px-2 py-1 rounded-md mr-1"
                            style={{ backgroundColor: "var(--warn)", color: "#fff", borderColor: "transparent" }}
                          >
                            {commonFunctions.getResourceByLanguage(
                              "edit",
                              constants.resourceType.label,
                              currentLanguageCode,
                            )}
                          </Button>
                          <Button
                            onClick={() => handleDelete(query)}
                            className="px-2 py-1 rounded-md"
                            style={{ backgroundColor: "var(--danger)", color: "#fff", borderColor: "transparent" }}
                          >
                            {commonFunctions.getResourceByLanguage(
                              "del",
                              constants.resourceType.label,
                              currentLanguageCode,
                            )}
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          <Button
            onClick={fetchSQLList}
            className="px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-brand-blue focus:ring-opacity-50 mt-2"
            style={{ backgroundColor: "var(--brand-blue)", color: "#fff", borderColor: "transparent" }}
          >
            {commonFunctions.getResourceByLanguage(
              "refresh",
              constants.resourceType.label,
              currentLanguageCode,
            )}
          </Button>
        </div>
      )}
    </>
  );
};

export default DynamicSQL;
