# 파생 저장소 표준 구조

`brunner-template` 을 패키지로 쓰는 서비스 저장소(zicp, brunner-next, 설치 마법사가
만드는 새 시스템)가 따르는 구조다. 설치 마법사가 생성하는 형태가 기준이다.

## 왜 표준이 필요한가

파생 저장소는 템플릿 파일을 복사해 두고 일부만 고쳐 쓰기 시작했다. 시간이 지나자
"일부러 고친 것"과 "그냥 낡은 것"이 섞여 구분되지 않았다. zicp 를 실측하니
`scripts` 96 개 중 86 개, `components/core` 30 개 중 19 개가 템플릿과 달랐는데,
그중 무엇이 의도된 커스터마이징인지 말할 수 있는 사람이 없었다.

그 상태에서는 템플릿을 올려도 반영되지 않고, 되돌릴 수도 없다. 공용 자산을
패키지로 묶은 의미가 사라진다.

## 저장소에 두는 것

| 자리 | 무엇을 | 왜 저장소에 있어야 하나 |
|------|--------|------------------------|
| `pages/` | 라우팅 | Next 는 앱 루트의 `pages` 만 URL 로 만든다. 패키지 안의 페이지는 라우팅되지 않는다 |
| `public/` | 정적 자산 | Next 는 앱의 `public` 만 서빙한다 |
| `styles/` | 전역 스타일 | `_app` 이 상대경로로 읽는다 |
| 루트 설정 | `next.config.js`, `jsconfig.json`, `tailwind.config.js` 등 | 빌드 도구가 앱 루트에서 찾는다 |
| `vendor/` | 템플릿 tarball | `package.json` 이 `file:` 로 참조한다 |
| `service/` | **이 시스템 고유 코드** | 아래 참조 |
| `scripts/` | **이 시스템 전용 SQL** | 공용 SQL 은 패키지 것을 쓴다 |

`lib/`, `server.js`, 공용 `scripts/` 는 저장소에 두지 않는다. 패키지 안의 것을
그대로 실행한다. 시작 명령이 이렇게 패키지를 가리킨다.

| 스크립트 | 값 |
|----------|-----|
| `dev` | `node node_modules/brunner-template/server.js` |
| `start` | `node node_modules/brunner-template/scripts/railway_start.cjs` |
| `db:init` | `node node_modules/brunner-template/scripts/run_sql.cjs` |

`railway_start` 는 스크립트를 패키지에서 찾고 서버는 앱 루트에서 띄운다. 그래서
`pages` 와 `.env` 는 저장소의 것이 쓰인다.

## 시스템 고유 파일은 `service/` 아래에 둔다

이 시스템에만 있는 화면·모듈은 `service/` 아래에 모은다.

```
service/
  components/     이 시스템 전용 화면
  lib/            이 시스템 전용 모듈
```

**공용 이름공간(`components/core/`, `lib/`)에 고유 파일을 넣지 않는다.** 지금
zicp 는 `components/core/client/contents/zicpBuyingContent.js` 처럼 공용 폴더
안에 자기 화면을 두고 있는데, 두 가지가 나빠진다. 읽는 사람이 무엇이 공용이고
무엇이 우리 것인지 파일 이름으로 짐작해야 하고, 나중에 템플릿이 같은 경로에
파일을 만들면 조용히 충돌한다.

`pages/` 는 예외다. 라우팅은 앱 루트에서만 되므로 고유 화면의 라우트도 `pages/`
안에 둔다. 대신 라우트 파일은 얇게 두고 본체는 `service/` 에서 가져온다.

```js
// pages/mainPages/buying.js
import Layout from "@/components/core/client/frames/layout";
import BuyingContent from "@/service/components/buyingContent";

export default function Buying() {
  return <BuyingContent />;
}
Buying.getLayout = (page) => <Layout>{page}</Layout>;
```

## 공용 파일을 바꾸려면 — 같은 경로에 두고 이유를 적는다

패키지 안의 파일을 직접 고치지 않는다. 저장소에 **같은 경로**로 파일을 만들면
그 파일이 대신 쓰인다(`withBrunnerTemplate` 의 `sharedFileAliases` 가 내용이 다른
파일만 alias 에서 제외한다).

교체한 파일은 `template-overrides.json` 에 이유와 함께 적는다.

```json
{
  "overrides": [
    { "path": "components/core/client/contents/homeContent.js", "reason": "서비스 랜딩 화면" },
    { "path": "lib/menuManifest.js", "reason": "메뉴 구성이 서비스마다 다름" }
  ]
}
```

이 목록이 있어야 "다른 파일"이 의도된 교체인지, 그냥 낡아서 갈라진 것인지 구분된다.

## 이 시스템 전용 SQL

공용 DDL 은 패키지가 갖는다. 서비스 전용 SQL(그 서비스만 쓰는 테이블, 리소스 시드
등)은 저장소의 `scripts/` 에 두고 목록을 적는다.

```json
// scripts/service_sql_files.json
["seed_resource_text_zicp.sql", "create_zicp_tables.sql"]
```

패키지의 `run_sql` 이 이 목록을 읽는다.

| 상황 | 도는 것 |
|------|---------|
| `DB_SCHEMA_OWNED=true` (자기 스키마의 주인) | 공용 DDL + 이 목록 |
| 그 외 (남의 스키마에 테넌트로 합류) | 이 목록만 |

소유자가 아닐 때 공용 DDL 을 건너뛰는 이유는, 공용 SQL 에 `TB_COR_SQL_INFO` 를
지우는 것이 있어 남의 스키마에 돌리면 그 서비스의 동적 SQL 이 통째로 날아가기
때문이다. 전용 SQL 은 그런 위험이 없으므로 그대로 돌린다.

## 갈라짐 점검

```bash
node node_modules/brunner-template/scripts/template_drift.cjs
```

네 가지로 나눠 보여준다.

| 분류 | 뜻 | 해야 할 일 |
|------|-----|-----------|
| `same` | 패키지와 내용이 같다 | 지운다. 패키지 것이 쓰인다 |
| `same (유지필요)` | 같지만 `pages`·`public` 이다 | **지우지 않는다.** 앱 루트에 없으면 라우팅·서빙이 안 된다 |
| `override` | 다르고 목록에 있다 | 그대로 둔다 |
| `drift` | 다른데 목록에 없다 | 교체가 맞으면 목록에 적고, 아니면 패키지 것으로 되돌린다 |
| `own` | 패키지에 없다 | `service/` 아래인지 확인한다 |

`--prune-same` 은 `same` 파일을 지운다. `--strict` 는 `drift` 가 있으면 실패하므로
빌드 전 검사에 걸 수 있다.

## 템플릿 갱신 절차

1. 템플릿에서 `npm pack`
2. 새 tarball 을 파생 저장소 `vendor/` 에 넣고 옛것을 지운다
3. `package.json` 의 `brunner-template` 경로를 새 파일명으로 바꾼다
4. `npm install`
5. `node node_modules/brunner-template/scripts/template_drift.cjs` 로 갈라짐을 본다
6. `npm run build` 로 확인한 뒤 push
