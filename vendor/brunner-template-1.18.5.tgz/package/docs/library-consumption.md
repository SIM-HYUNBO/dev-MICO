# Brunner Template Library Consumption

`brunner-template` can run as its own source service, while tenant apps such as
`brunner-next` and `zicp` consume shared code from the packaged artifact.

## Install

From npm registry:

```bash
npm install brunner-template@1.14.7
```

From the GitHub repository:

```bash
npm install github:SIM-HYUNBO/brunner-template#v1.14.7
```

From a packaged tarball:

```bash
npm install ./brunner-template-1.14.7.tgz
```

The consuming repository receives the shared implementation as an npm
dependency under `node_modules/brunner-template`. It does not need copied
shared source files. In normal cases the target app changes only:

- `package.json` dependency entry
- `package-lock.json`
- `next.config.js` wrapper
- tenant-specific overrides that intentionally stay local

## Next.js Configuration

In the consuming app, wrap the existing Next config:

```js
import { withBrunnerTemplate } from "brunner-template";

const nextConfig = {
  reactStrictMode: false,
};

export default withBrunnerTemplate(nextConfig);
```

This maps common imports to the installed npm package:

- `@/components/core` -> `brunner-template/components/core`
- `@/lib` -> `brunner-template/lib`
- `@/styles` -> `brunner-template/styles`

If the consuming app keeps part of the common paths locally, enable only the
aliases that should come from the package:

```js
import { withBrunnerTemplate } from "brunner-template";

const nextConfig = {
  reactStrictMode: false,
};

export default withBrunnerTemplate(nextConfig, {
  aliases: ["@/components/core", "@/styles"],
});
```

For tenant apps that still keep local service-specific files under
`components/core` or `lib`, prefer exact shared-file aliasing:

```js
export default withBrunnerTemplate(nextConfig, {
  aliases: [],
  sharedFileAliases: true,
});
```

This aliases only files whose local content exactly matches the installed
`brunner-template` package, leaving customized tenant files local.

Keep tenant-specific `pages`, domain modules, env values, and overrides in the
consuming repository.

## Deployment Model

1. Package `brunner-template` with `npm pack`, publish it to a registry, or install it from GitHub.
2. Update `brunner-next` or `zicp` dependency with `npm install brunner-template@1.14.7`.
3. Rebuild and redeploy the consuming Railway service.
4. Use `REDIS_URL` when Railway replicas are enabled so realtime events sync across instances.
