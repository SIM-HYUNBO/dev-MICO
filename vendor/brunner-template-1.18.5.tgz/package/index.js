export const brunnerTemplatePackage = {
  name: "brunner-template",
  install: "npm install brunner-template@1.14.7",
  githubInstall: "npm install github:SIM-HYUNBO/brunner-template#v1.14.7",
  includesRailwayProvisioningWizard: true,
  adminRailwayDeployPath: "/admin/railway-deploy",
  dbConfigPath: "/mainPages/adminDbUsage",
};

export { withBrunnerTemplate } from "./lib/packageNextConfig.js";
