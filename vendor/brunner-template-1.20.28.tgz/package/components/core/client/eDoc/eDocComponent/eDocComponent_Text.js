import React from "react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { Select } from "antd";
import EDocTextStyleEditor from "@/components/core/client/eDoc/eDocTextStyleEditor";
import { renderInlineMarkdown } from "@/components/core/client/eDoc/inlineMarkdown";

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

const keepTextInputKeysLocal = (event) => {
  event.stopPropagation();
};

export const initDefaultRuntimeData = (defaultRuntimeData) => {
  defaultRuntimeData.content = L("eDocDefaultText");
  defaultRuntimeData.textAlign = "left";
  defaultRuntimeData.positionAlign = "left";

  // font 관련 기본 설정
  defaultRuntimeData.fontFamily = "Arial";
  defaultRuntimeData.fontSize = 12;
  defaultRuntimeData.underline = false;
  defaultRuntimeData.fontColor = "#000000";
  defaultRuntimeData.backgroundColor = "#ffffff";
  defaultRuntimeData.fontWeight = "normal";

  return defaultRuntimeData;
};

export const getBindingValue = (component) => {
  if (!component.runtime_data?.bindingKey) {
    return null;
  }
  return component.runtime_data?.content || null;
};

export const setBindingValue = (component, value, updateRuntimeData) => {
  if (!component.runtime_data?.bindingKey) return;
  if (value === undefined || value === null) return;

  updateRuntimeData("content", String(value));
};

export const getNewRuntimeData = (component, { key, value }) => {
  return {
    ...(component.runtime_data || {}),
    [key]: value,
  };
};

export function renderProperty(
  component,
  updateRuntimeData,
  renderWidthProperty,
  renderForceNewLineProperty,
  renderPositionAlignProperty,
) {
  const renderComponentProperty = (component) => {
    return (
      <div>
        <label>Binding Key:</label>
        <input
          type="text"
          value={component.runtime_data?.bindingKey || constants.emptyString}
          onKeyDown={keepTextInputKeysLocal}
          onChange={(e) => updateRuntimeData("bindingKey", e.target.value)}
          className="w-full border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
        />

        <label>{L("eDocTextLabel")}</label>
        <textarea
          value={component.runtime_data?.content || constants.emptyString}
          onKeyDown={keepTextInputKeysLocal}
          onChange={(e) => updateRuntimeData("content", e.target.value)}
          rows={4}
          className="w-full border border-gray-300 dark:border-gray-600 rounded p-2"
        />

        <label>{L("eDocContentAlign")}</label>
        <Select
          value={component.runtime_data?.textAlign || "left"}
          onChange={(value) => updateRuntimeData("textAlign", value)}
          className="w-full h-12 border border-gray-300 dark:border-gray-600 rounded p-2 mb-2"
        >
          <option value="left">{L("eDocAlignLeft")}</option>
          <option value="center">{L("eDocAlignCenter")}</option>
          <option value="right">{L("eDocAlignRight")}</option>
        </Select>

        {renderWidthProperty()}
        {renderForceNewLineProperty()}
        {renderPositionAlignProperty()}

        <EDocTextStyleEditor
          fontFamily={component.runtime_data?.fontFamily || "Arial"}
          fontSize={component.runtime_data?.fontSize || 12}
          fontWeight={component.runtime_data?.fontWeight || "normal"}
          underline={component.runtime_data?.underline || false}
          fontColor={component.runtime_data?.fontColor || "#000000"}
          backgroundColor={component.runtime_data?.backgroundColor || "#ffffff"}
          onChange={(updatedProps) => {
            Object.entries(updatedProps).forEach(([key, value]) => {
              updateRuntimeData(key, value);
            });
          }}
        />
      </div>
    );
  };

  return renderComponentProperty(component);
}

export default function RenderComponent(props) {
  const {
    documentData,
    pageData,
    component,
    handleComponentClick,
    onRuntimeDataChange,
    selectedClass,
    alignmentClass,
    textAlign,
    isDesignMode,
  } = props;

  const {
    // font 관련 속성들
    fontFamily,
    fontSize,
    fontWeight,
    underline,
    fontColor,
    backgroundColor,
  } = component.runtime_data || {};

  const style = {
    width: "100%",
    height: component.runtime_data?.height || "auto",
    textAlign, // 텍스트 정렬 적용
    fontFamily: fontFamily || "Arial",
    fontSize: fontSize ? `${fontSize}px` : "12px",
    fontWeight: fontWeight || "normal",
    textDecoration: underline ? "underline" : "none",
    color: fontColor || "#000000",
    backgroundColor: backgroundColor || "transparent",
  };

  return (
    <p
      className={`${selectedClass} ${alignmentClass} whitespace-pre-wrap overflow-visible cursor-pointer`}
      style={style}
      onClick={handleComponentClick}
    >
      {(component.runtime_data?.content || constants.emptyString)
        .split("\n")
        .map((line, idx) => (
          <React.Fragment key={idx}>
            {renderInlineMarkdown(line, `${component.id || "text"}-${idx}`)}
            <br />
          </React.Fragment>
        ))}
    </p>
  );
}
