"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Plus, RefreshCw, Save, Search, Trash2, X } from "lucide-react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";
import { useModal } from "@/components/core/client/brunnerMessageBox";
import Card from "@/components/core/client/ui/Card";
import Loading from "@/components/core/client/loading";

// 언어 목록은 코드에 두지 않는다.
//
// 왜
//   언어는 TB_COR_RESOURCE_TEXT 의 LANGUAGE_CODE 데이터다. 화면이 ko/en/ja 세 칸을
//   박아두면 네 번째 언어가 들어와도 이 화면에서는 영영 안 보이고, 관리자가 새 언어를
//   넣을 방법도 없다. 무엇을 보여줄지는 데이터가 정한다.
const LANGUAGE_FORMAT = /^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8}){0,2}$/;

const TYPE_FILTERS = [
  { value: "", labelKey: "resourceTextTypeAll" },
  { value: constants.resourceType.label, labelKey: "resourceTextTypeLabel" },
  { value: constants.resourceType.message, labelKey: "resourceTextTypeMessage" },
];

const toDateTime = (value) => {
  if (!value) return "-";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? "-" : d.toLocaleString();
};

export default function AdminResourceTextContent() {
  const [languageCode, setLanguageCode] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [ready, setReady] = useState(false);

  const [loading, setLoading] = useState(false);
  // 입력칸과 실제 조회 조건을 나눈다. 글자를 칠 때마다 조회하면 7천 행짜리
  // 테이블을 매 타자마다 훑는다.
  const [filterInput, setFilterInput] = useState({ resourceKey: "", text: "", language: "" });
  const [filters, setFilters] = useState({ resourceKey: "", text: "", language: "" });
  const [typeFilter, setTypeFilter] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize] = useState(50);
  const [keys, setKeys] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  // 이 시스템이 이미 쓰고 있는 언어. 새 리소스를 만들 때 편집칸을 이걸로 깐다.
  const [systemLanguages, setSystemLanguages] = useState([]);

  const [selected, setSelected] = useState(null); // { resourceType, resourceKey }
  const [draftType, setDraftType] = useState(constants.resourceType.label);
  const [draftKey, setDraftKey] = useState("");
  // [{ languageCode, text, updateUserId, updateTime, isNew }] — 순서는 언어코드순.
  const [draftRows, setDraftRows] = useState([]);
  const [newLanguage, setNewLanguage] = useState("");
  const [isNew, setIsNew] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const { BrunnerMessageBox, openOkModal, openOkCancelModal } = useModal();

  const tl = (key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.label, languageCode);
  const tm = (key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.message, languageCode);

  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode?.() || constants.languageCode.ko_KR);
    setIsAdmin(userInfo.isAdminUser?.() === true);
    setReady(true);
  }, []);

  const totalPages = useMemo(
    () => Math.max(1, Math.ceil((Number(totalCount) || 0) / pageSize)),
    [totalCount, pageSize],
  );

  const sortRows = (rows) =>
    [...rows].sort((a, b) => a.languageCode.localeCompare(b.languageCode));

  const loadKeys = useCallback(async () => {
    setLoading(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.RESOURCE_TEXT_KEY_LIST,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
        resourceType: typeFilter,
        resourceKey: filters.resourceKey,
        text: filters.text,
        targetLanguageCode: filters.language,
        page,
        pageSize,
      });
      if (res.error_code !== constants.errorCode.Success) {
        await openOkModal(res.error_message, constants.messageCategory.Error);
        return;
      }
      setKeys(res.keys || []);
      setTotalCount(res.totalCount || 0);
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    } finally {
      setLoading(false);
    }
    // openOkModal 은 매 렌더 새로 만들어져 의존성에 넣으면 조회가 반복된다.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [languageCode, filters, typeFilter, page, pageSize]);

  const loadLanguages = useCallback(async () => {
    try {
      const res = await RequestServer({
        commandName: constants.commands.RESOURCE_TEXT_LANGUAGE_LIST,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
      });
      if (res.error_code !== constants.errorCode.Success) return;
      setSystemLanguages(res.languages || []);
    } catch {
      // 목록을 못 받아도 편집은 된다 — 새 리소스에서 언어를 직접 추가하면 된다.
    }
  }, [languageCode]);

  useEffect(() => {
    if (!ready || !isAdmin || !languageCode) return;
    loadKeys();
  }, [ready, isAdmin, languageCode, loadKeys]);

  useEffect(() => {
    if (!ready || !isAdmin || !languageCode) return;
    loadLanguages();
  }, [ready, isAdmin, languageCode, loadLanguages]);

  const loadDetail = async (resourceType, resourceKey) => {
    setDetailLoading(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.RESOURCE_TEXT_DETAIL,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
        resourceType,
        resourceKey,
      });
      if (res.error_code !== constants.errorCode.Success) {
        await openOkModal(res.error_message, constants.messageCategory.Error);
        return;
      }
      setDraftRows(
        sortRows(
          (res.rows || []).map((item) => ({
            languageCode: item.language_code,
            text: item.resource_text ?? "",
            updateUserId: item.update_user_id,
            updateTime: item.update_time,
            isNew: false,
          })),
        ),
      );
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    } finally {
      setDetailLoading(false);
    }
  };

  const openKey = async (row) => {
    setIsNew(false);
    setNewLanguage("");
    setSelected({ resourceType: row.resource_type, resourceKey: row.resource_key });
    setDraftType(row.resource_type);
    setDraftKey(row.resource_key);
    await loadDetail(row.resource_type, row.resource_key);
  };

  const startNew = () => {
    setIsNew(true);
    setSelected(null);
    setDraftType(constants.resourceType.label);
    setDraftKey("");
    setNewLanguage("");
    // 새 리소스는 이 시스템이 이미 쓰는 언어를 그대로 깔아준다. 하나도 없으면 빈 채로
    // 시작하고 관리자가 언어를 추가한다.
    setDraftRows(
      sortRows(
        systemLanguages.map((code) => ({
          languageCode: code,
          text: "",
          updateUserId: null,
          updateTime: null,
          isNew: true,
        })),
      ),
    );
  };

  const closeEditor = () => {
    setIsNew(false);
    setSelected(null);
    setDraftKey("");
    setDraftRows([]);
    setNewLanguage("");
  };

  const setRowText = (code, text) =>
    setDraftRows((prev) => prev.map((row) => (row.languageCode === code ? { ...row, text } : row)));

  const addLanguageRow = async () => {
    const code = newLanguage.trim();
    if (!LANGUAGE_FORMAT.test(code)) {
      await openOkModal(tm("RESOURCE_TEXT_LANGUAGE_INVALID"), constants.messageCategory.Warning);
      return;
    }
    if (draftRows.some((row) => row.languageCode === code)) {
      await openOkModal(tm("RESOURCE_TEXT_LANGUAGE_EXISTS"), constants.messageCategory.Warning);
      return;
    }
    setDraftRows((prev) =>
      sortRows([
        ...prev,
        { languageCode: code, text: "", updateUserId: null, updateTime: null, isNew: true },
      ]),
    );
    setNewLanguage("");
  };

  // 아직 저장된 적 없는 줄은 화면에서만 빼면 된다. 이미 저장된 줄은 DB 에서 지운다.
  const removeLanguageRow = async (row) => {
    if (row.isNew || isNew) {
      setDraftRows((prev) => prev.filter((item) => item.languageCode !== row.languageCode));
      return;
    }
    const confirmed = await openOkCancelModal(
      `${tm("RESOURCE_TEXT_LANGUAGE_DELETE_CONFIRM")}\n\n${selected.resourceKey} · ${row.languageCode}`,
      constants.messageCategory.Warning,
    );
    if (!confirmed) return;

    setSaving(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.RESOURCE_TEXT_DELETE,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
        resourceType: selected.resourceType,
        resourceKey: selected.resourceKey,
        targetLanguageCode: row.languageCode,
      });
      if (res.error_code !== constants.errorCode.Success) {
        await openOkModal(res.error_message, constants.messageCategory.Error);
        return;
      }
      await commonFunctions.reloadResourceTextCache();
      await loadDetail(selected.resourceType, selected.resourceKey);
      await loadKeys();
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    } finally {
      setSaving(false);
    }
  };

  const save = async () => {
    const key = draftKey.trim();
    if (!key) {
      await openOkModal(tm("RESOURCE_TEXT_KEY_REQUIRED"), constants.messageCategory.Warning);
      return;
    }
    // 내용이 있는 줄만 저장한다. 빈 줄까지 넣으면 화면에 아무것도 안 그려지는
    // 빈 라벨이 생기는데, 그건 아예 없는 것보다 찾기 어렵다.
    const filled = draftRows.filter((row) => String(row.text ?? "").trim() !== "");
    if (filled.length === 0) {
      await openOkModal(tm("RESOURCE_TEXT_EMPTY"), constants.messageCategory.Warning);
      return;
    }

    setSaving(true);
    try {
      const texts = filled.reduce((acc, row) => {
        acc[row.languageCode] = row.text;
        return acc;
      }, {});
      const res = await RequestServer({
        commandName: constants.commands.RESOURCE_TEXT_SAVE,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
        resourceType: draftType,
        resourceKey: key,
        texts,
      });
      if (res.error_code !== constants.errorCode.Success) {
        await openOkModal(res.error_message, constants.messageCategory.Error);
        return;
      }
      // 고친 문구가 이 화면에도 바로 보여야 한다 — 캐시를 비우고 다시 받는다.
      await commonFunctions.reloadResourceTextCache();
      await openOkModal(tm("RESOURCE_TEXT_SAVED"), constants.messageCategory.Info);
      setIsNew(false);
      setSelected({ resourceType: draftType, resourceKey: key });
      await loadDetail(draftType, key);
      await Promise.all([loadKeys(), loadLanguages()]);
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    } finally {
      setSaving(false);
    }
  };

  const removeKey = async () => {
    if (!selected) return;
    const confirmed = await openOkCancelModal(
      `${tm("RESOURCE_TEXT_DELETE_CONFIRM")}\n\n${selected.resourceType} / ${selected.resourceKey}`,
      constants.messageCategory.Warning,
    );
    if (!confirmed) return;

    setSaving(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.RESOURCE_TEXT_DELETE,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
        resourceType: selected.resourceType,
        resourceKey: selected.resourceKey,
      });
      if (res.error_code !== constants.errorCode.Success) {
        await openOkModal(res.error_message, constants.messageCategory.Error);
        return;
      }
      await commonFunctions.reloadResourceTextCache();
      await openOkModal(tm("RESOURCE_TEXT_DELETED"), constants.messageCategory.Info);
      closeEditor();
      await Promise.all([loadKeys(), loadLanguages()]);
    } catch (e) {
      await openOkModal(e.message, constants.messageCategory.Exception);
    } finally {
      setSaving(false);
    }
  };

  const runSearch = () => {
    setPage(1);
    setFilters({
      resourceKey: filterInput.resourceKey.trim(),
      text: filterInput.text.trim(),
      language: filterInput.language.trim(),
    });
  };

  const setFilterField = (field, value) =>
    setFilterInput((prev) => ({ ...prev, [field]: value }));

  const onFilterEnter = (e) => {
    if (e.key === "Enter") runSearch();
  };

  if (!ready) return null;

  if (!isAdmin) {
    return (
      <div className="mx-auto w-full max-w-4xl px-4 py-8">
        <Card className="p-6 text-center">
          <p className="text-sm font-semibold text-[var(--text)]">{tl("adminOnlyNoPermission")}</p>
        </Card>
      </div>
    );
  }

  const editorOpen = isNew || !!selected;

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-6">
      <BrunnerMessageBox />
      {(loading || saving) && <Loading />}

      <div className="mb-4">
        <h1 className="text-2xl font-extrabold text-[var(--text)]">{tl("adminResourceTextTitle")}</h1>
        <p className="mt-1 text-sm text-[var(--text-muted)]">{tl("resourceTextDesc")}</p>
      </div>

      <Card className="p-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <label className="mb-1 block text-xs font-bold text-[var(--text-muted)]">
              {tl("resourceTextKeyField")}
            </label>
            <input
              value={filterInput.resourceKey}
              onChange={(e) => setFilterField("resourceKey", e.target.value)}
              onKeyDown={onFilterEnter}
              placeholder={tl("resourceTextFilterKeyPlaceholder")}
              className="w-full rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 font-mono-data text-sm text-[var(--text)] outline-none placeholder:text-[var(--text-muted)]"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-[var(--text-muted)]">
              {tl("resourceTextFilterText")}
            </label>
            <input
              value={filterInput.text}
              onChange={(e) => setFilterField("text", e.target.value)}
              onKeyDown={onFilterEnter}
              placeholder={tl("resourceTextFilterTextPlaceholder")}
              className="w-full rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--text)] outline-none placeholder:text-[var(--text-muted)]"
            />
          </div>

          <div>
            <label className="mb-1 block text-xs font-bold text-[var(--text-muted)]">
              {tl("resourceTextLanguageCode")}
            </label>
            <input
              value={filterInput.language}
              onChange={(e) => setFilterField("language", e.target.value)}
              onKeyDown={onFilterEnter}
              placeholder={tl("resourceTextLanguagePlaceholder")}
              list="resource-text-language-options"
              className="w-full rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 font-mono-data text-sm text-[var(--text)] outline-none placeholder:text-[var(--text-muted)]"
            />
            <datalist id="resource-text-language-options">
              {systemLanguages.map((code) => (
                <option key={code} value={code} />
              ))}
            </datalist>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <select
            value={typeFilter}
            onChange={(e) => {
              setPage(1);
              setTypeFilter(e.target.value);
            }}
            className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--text)]"
          >
            {TYPE_FILTERS.map((item) => (
              <option key={item.value || "all"} value={item.value}>
                {tl(item.labelKey)}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={runSearch}
            className="flex items-center gap-1 rounded-[var(--radius-md)] bg-[var(--brand-blue,#2563eb)] px-4 py-2 text-sm font-bold text-white"
          >
            <Search size={14} />
            {tl("resourceTextSearch")}
          </button>

          <button
            type="button"
            onClick={loadKeys}
            className="flex items-center gap-1 rounded-[var(--radius-md)] border border-[var(--border)] px-3 py-2 text-sm font-semibold text-[var(--text)]"
          >
            <RefreshCw size={14} />
            {tl("resourceTextRefresh")}
          </button>

          <button
            type="button"
            onClick={startNew}
            className="flex items-center gap-1 rounded-[var(--radius-md)] border border-[var(--border)] px-3 py-2 text-sm font-semibold text-[var(--text)]"
          >
            <Plus size={14} />
            {tl("resourceTextNew")}
          </button>
        </div>

        <div className="mt-2 text-xs text-[var(--text-muted)]">
          {tl("resourceTextTotalCount")}: {totalCount}
        </div>
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
        <Card className="p-0">
          <div className="max-h-[60vh] overflow-y-auto">
            {keys.length === 0 ? (
              <div className="p-6 text-center text-sm text-[var(--text-muted)]">
                {tl("resourceTextNoResult")}
              </div>
            ) : (
              <ul className="divide-y divide-[var(--border)]">
                {keys.map((row) => {
                  const active =
                    selected?.resourceKey === row.resource_key &&
                    selected?.resourceType === row.resource_type;
                  return (
                    <li key={`${row.resource_type}:${row.resource_key}`}>
                      <button
                        type="button"
                        onClick={() => openKey(row)}
                        className={`flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition ${
                          active ? "bg-[var(--surface-alt)]" : "hover:bg-[var(--surface-alt)]"
                        }`}
                      >
                        <span className="min-w-0">
                          <span className="block truncate font-mono-data text-sm font-semibold text-[var(--text)]">
                            {row.resource_key}
                          </span>
                          <span className="mt-0.5 block text-xs text-[var(--text-muted)]">
                            {row.resource_type} · {row.language_count} {tl("resourceTextLanguageUnit")}
                          </span>
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <div className="flex items-center justify-between border-t border-[var(--border)] px-4 py-3">
            <button
              type="button"
              disabled={page <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="rounded-[var(--radius-md)] border border-[var(--border)] px-3 py-1.5 text-sm font-semibold text-[var(--text)] disabled:opacity-40"
            >
              {tl("resourceTextPrevPage")}
            </button>
            <span className="text-xs text-[var(--text-muted)]">
              {page} / {totalPages}
            </span>
            <button
              type="button"
              disabled={page >= totalPages}
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              className="rounded-[var(--radius-md)] border border-[var(--border)] px-3 py-1.5 text-sm font-semibold text-[var(--text)] disabled:opacity-40"
            >
              {tl("resourceTextNextPage")}
            </button>
          </div>
        </Card>

        <Card className="p-5">
          {!editorOpen ? (
            <div className="py-10 text-center text-sm text-[var(--text-muted)]">
              {tl("resourceTextSelectHint")}
            </div>
          ) : (
            <>
              <div className="flex items-start justify-between gap-3">
                <h2 className="font-extrabold text-[var(--text)]">
                  {isNew ? tl("resourceTextNew") : tl("resourceTextEdit")}
                </h2>
                <button
                  type="button"
                  onClick={closeEditor}
                  aria-label={tl("resourceTextClose")}
                  className="rounded-[var(--radius-md)] p-1 text-[var(--text-muted)] hover:text-[var(--text)]"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-[140px_minmax(0,1fr)]">
                <label className="text-xs font-bold text-[var(--text-muted)] sm:pt-2">
                  {tl("resourceTextTypeField")}
                </label>
                <select
                  value={draftType}
                  disabled={!isNew}
                  onChange={(e) => setDraftType(e.target.value)}
                  className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--text)] disabled:opacity-60"
                >
                  <option value={constants.resourceType.label}>{tl("resourceTextTypeLabel")}</option>
                  <option value={constants.resourceType.message}>{tl("resourceTextTypeMessage")}</option>
                </select>

                <label className="text-xs font-bold text-[var(--text-muted)] sm:pt-2">
                  {tl("resourceTextKeyField")}
                </label>
                <input
                  value={draftKey}
                  disabled={!isNew}
                  onChange={(e) => setDraftKey(e.target.value)}
                  placeholder={tl("resourceTextKeyPlaceholder")}
                  className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 font-mono-data text-sm text-[var(--text)] outline-none disabled:opacity-60 placeholder:text-[var(--text-muted)]"
                />
              </div>

              <div className="mt-5 space-y-4">
                {detailLoading ? (
                  <div className="py-6 text-center text-sm text-[var(--text-muted)]">
                    {tl("resourceTextLoading")}
                  </div>
                ) : draftRows.length === 0 ? (
                  <div className="rounded-[var(--radius-md)] border border-dashed border-[var(--border)] p-4 text-center text-sm text-[var(--text-muted)]">
                    {tl("resourceTextNoLanguage")}
                  </div>
                ) : (
                  draftRows.map((row) => (
                    <div key={row.languageCode}>
                      <div className="mb-1 flex items-center justify-between gap-2">
                        <span className="font-mono-data text-xs font-bold text-[var(--text)]">
                          {row.languageCode}
                        </span>
                        <span className="flex items-center gap-2">
                          <span className="text-[11px] text-[var(--text-muted)]">
                            {row.isNew
                              ? tl("resourceTextNotSetYet")
                              : `${row.updateUserId || "-"} · ${toDateTime(row.updateTime)}`}
                          </span>
                          <button
                            type="button"
                            onClick={() => removeLanguageRow(row)}
                            aria-label={tl("resourceTextRemoveLanguage")}
                            title={tl("resourceTextRemoveLanguage")}
                            className="rounded-[var(--radius-md)] p-1 text-[var(--text-muted)] hover:text-[var(--danger,#dc2626)]"
                          >
                            <Trash2 size={13} />
                          </button>
                        </span>
                      </div>
                      <textarea
                        rows={3}
                        value={row.text ?? ""}
                        onChange={(e) => setRowText(row.languageCode, e.target.value)}
                        className="w-full resize-y rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm text-[var(--text)] outline-none"
                      />
                    </div>
                  ))
                )}
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-[var(--border)] pt-4">
                <label className="text-xs font-bold text-[var(--text-muted)]">
                  {tl("resourceTextLanguageCode")}
                </label>
                <input
                  value={newLanguage}
                  onChange={(e) => setNewLanguage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") addLanguageRow();
                  }}
                  placeholder={tl("resourceTextLanguagePlaceholder")}
                  className="w-32 rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-1.5 font-mono-data text-sm text-[var(--text)] outline-none placeholder:text-[var(--text-muted)]"
                />
                <button
                  type="button"
                  onClick={addLanguageRow}
                  className="flex items-center gap-1 rounded-[var(--radius-md)] border border-[var(--border)] px-3 py-1.5 text-sm font-semibold text-[var(--text)]"
                >
                  <Plus size={14} />
                  {tl("resourceTextAddLanguage")}
                </button>
              </div>

              <div className="mt-5 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={save}
                  disabled={saving}
                  className="flex items-center gap-1 rounded-[var(--radius-md)] bg-[var(--brand-blue,#2563eb)] px-4 py-2 text-sm font-bold text-white disabled:opacity-60"
                >
                  <Save size={14} />
                  {tl("resourceTextSave")}
                </button>
                {!isNew && (
                  <button
                    type="button"
                    onClick={removeKey}
                    disabled={saving}
                    className="flex items-center gap-1 rounded-[var(--radius-md)] border border-[var(--border)] px-4 py-2 text-sm font-bold text-[var(--danger,#dc2626)] disabled:opacity-60"
                  >
                    <Trash2 size={14} />
                    {tl("resourceTextDelete")}
                  </button>
                )}
              </div>

              <p className="mt-3 text-xs leading-5 text-[var(--text-muted)]">
                {tl("resourceTextApplyNotice")}
              </p>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
