"use client";

import { useEffect, useMemo, useState } from "react";
import { RefreshCw, Save, Trash2 } from "lucide-react";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { RequestServer } from "@/components/core/client/requestServer";
import Card from "@/components/core/client/ui/Card";
import Loading from "@/components/core/client/loading";

const emptyScreen = {
  screenId: "",
  screenNameKey: "",
  routePath: "",
  screenScope: "app",
  adminOnly: false,
  loginRequired: true,
  allowedUserTypes: "",
  isActive: true,
};

const emptyMenu = {
  menuId: "",
  menuType: "item",
  parentMenuId: "",
  screenId: "",
  href: "",
  labelResourceKey: "",
  iconName: "",
  adminOnly: false,
  loginRequired: true,
  hideWhenLoggedIn: false,
  initiallyOpen: false,
  sortOrder: 1000,
  isVisible: true,
  menuScope: "app",
};

const boolValue = (value) => value === true || String(value).toUpperCase() === "Y";
const isMobileTabMenu = (menu) =>
  menu.parentMenuId === "section.mobileTabBar" || menu.menuScope === "mobileTabBar";

export default function AdminMenuContent() {
  const [languageCode, setLanguageCode] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [screens, setScreens] = useState([]);
  const [menus, setMenus] = useState([]);
  const [screenDraft, setScreenDraft] = useState(emptyScreen);
  const [menuDraft, setMenuDraft] = useState(emptyMenu);

  const tl = (key, fallback = key) =>
    commonFunctions.getResourceByLanguage(key, constants.resourceType.label, languageCode) || fallback;

  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode?.() || constants.languageCode.ko_KR);
    setIsAdmin(userInfo.isAdminUser?.() === true);
    setReady(true);
  }, []);

  const menuOptions = useMemo(
    () => menus.filter((m) => m.menu_type === "section").sort((a, b) => a.sort_order - b.sort_order),
    [menus],
  );
  const routePathByScreenId = useMemo(
    () => new Map(screens.map((screen) => [screen.screen_id, screen.route_path])),
    [screens],
  );

  const load = async () => {
    setBusy(true);
    setMessage("");
    try {
      const res = await RequestServer({
        commandName: constants.commands.MENU_ADMIN_SELECT,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
      });
      if (res.error_code !== constants.errorCode.Success) {
        setMessage(res.error_message || "Load failed.");
        return;
      }
      setScreens(res.data?.screens || []);
      setMenus(res.data?.menus || []);
    } catch (e) {
      setMessage(e.message);
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (ready && isAdmin && languageCode) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, isAdmin, languageCode]);

  const saveScreen = async () => {
    setBusy(true);
    setMessage("");
    try {
      const res = await RequestServer({
        commandName: constants.commands.MENU_SCREEN_SAVE,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
        ...screenDraft,
      });
      setMessage(res.error_message || (res.error_code === constants.errorCode.Success ? "Saved." : "Save failed."));
      if (res.error_code === constants.errorCode.Success) await load();
    } finally {
      setBusy(false);
    }
  };

  const saveMenu = async () => {
    setBusy(true);
    setMessage("");
    try {
      const href = menuDraft.href || routePathByScreenId.get(menuDraft.screenId) || "";
      const showInMobileTabBar = isMobileTabMenu(menuDraft);
      const res = await RequestServer({
        commandName: constants.commands.MENU_ITEM_SAVE,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
        ...menuDraft,
        parentMenuId: showInMobileTabBar ? "section.mobileTabBar" : menuDraft.parentMenuId,
        menuScope: showInMobileTabBar ? "mobileTabBar" : menuDraft.menuScope,
        href,
      });
      setMessage(res.error_message || (res.error_code === constants.errorCode.Success ? "Saved." : "Save failed."));
      if (res.error_code === constants.errorCode.Success) {
        window.dispatchEvent(new CustomEvent("menuChanged"));
        await load();
      }
    } finally {
      setBusy(false);
    }
  };

  const deleteScreen = async (screenId) => {
    setBusy(true);
    try {
      await RequestServer({
        commandName: constants.commands.MENU_SCREEN_DELETE,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
        screenId,
      });
      await load();
    } finally {
      setBusy(false);
    }
  };

  const deleteMenu = async (menuId) => {
    setBusy(true);
    try {
      const res = await RequestServer({
        commandName: constants.commands.MENU_ITEM_DELETE,
        userId: userInfo.getLoginUserId?.() || "",
        languageCode,
        menuId,
      });
      setMessage(res.error_message || "");
      if (res.error_code === constants.errorCode.Success) {
        window.dispatchEvent(new CustomEvent("menuChanged"));
        await load();
      }
    } finally {
      setBusy(false);
    }
  };

  const setShowInMobileTabBar = (checked) => {
    setMenuDraft((draft) => ({
      ...draft,
      menuType: checked ? "item" : draft.menuType,
      parentMenuId: checked
        ? "section.mobileTabBar"
        : draft.parentMenuId === "section.mobileTabBar" ? "" : draft.parentMenuId,
      menuScope: checked
        ? "mobileTabBar"
        : draft.menuScope === "mobileTabBar" ? "app" : draft.menuScope,
      loginRequired: checked ? true : draft.loginRequired,
      hideWhenLoggedIn: checked ? false : draft.hideWhenLoggedIn,
    }));
  };

  if (!ready) return null;
  if (!isAdmin) {
    return (
      <div className="mx-auto w-full max-w-4xl px-4 py-8">
        <Card className="p-6 text-center text-sm font-semibold text-[var(--text)]">
          {tl("adminOnlyNoPermission", "Admin only")}
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-6 text-[var(--text)]">
      {busy && <Loading />}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">{tl("adminMenuManageTitle", "메뉴 관리")}</h1>
          {message && <p className="mt-1 text-sm text-[var(--text-muted)]">{message}</p>}
        </div>
        <button
          type="button"
          onClick={load}
          className="inline-flex items-center gap-1 rounded-[var(--radius-md)] border border-[var(--border)] px-3 py-2 text-sm font-semibold"
        >
          <RefreshCw size={14} />
          {tl("resourceTextRefresh", "새로고침")}
        </button>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-4">
          <h2 className="mb-3 text-base font-extrabold">{tl("adminMenuScreenTitle", "화면")}</h2>
          <div className="grid gap-2">
            <input className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" placeholder="screenId" value={screenDraft.screenId} onChange={(e) => setScreenDraft({ ...screenDraft, screenId: e.target.value })} />
            <input className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" placeholder="label resource key" value={screenDraft.screenNameKey} onChange={(e) => setScreenDraft({ ...screenDraft, screenNameKey: e.target.value })} />
            <input className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" placeholder="/route/path" value={screenDraft.routePath} onChange={(e) => setScreenDraft({ ...screenDraft, routePath: e.target.value })} />
            <input className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" placeholder="user types: Personal,Pharmacy" value={screenDraft.allowedUserTypes} onChange={(e) => setScreenDraft({ ...screenDraft, allowedUserTypes: e.target.value })} />
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <select className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2" value={screenDraft.screenScope} onChange={(e) => setScreenDraft({ ...screenDraft, screenScope: e.target.value })}>
                <option value="common">common</option>
                <option value="app">app</option>
              </select>
              <label className="inline-flex items-center gap-1">
                <input type="checkbox" checked={screenDraft.adminOnly} onChange={(e) => setScreenDraft({ ...screenDraft, adminOnly: e.target.checked })} />
                admin
              </label>
              <label className="inline-flex items-center gap-1">
                <input type="checkbox" checked={screenDraft.loginRequired} onChange={(e) => setScreenDraft({ ...screenDraft, loginRequired: e.target.checked })} />
                login
              </label>
              <label className="inline-flex items-center gap-1">
                <input type="checkbox" checked={screenDraft.isActive} onChange={(e) => setScreenDraft({ ...screenDraft, isActive: e.target.checked })} />
                active
              </label>
              <button type="button" onClick={saveScreen} className="inline-flex items-center gap-1 rounded-[var(--radius-md)] bg-[var(--brand-blue,#2563eb)] px-3 py-2 font-bold text-white">
                <Save size={14} />
                {tl("resourceTextSave", "저장")}
              </button>
            </div>
          </div>
          <div className="mt-4 max-h-[45vh] overflow-auto divide-y divide-[var(--border)]">
            {screens.map((screen) => (
              <div key={screen.screen_id} className="flex items-center justify-between gap-2 py-2 text-sm">
                <button type="button" className="min-w-0 text-left" onClick={() => setScreenDraft({
                  screenId: screen.screen_id,
                  screenNameKey: screen.screen_name_key,
                  routePath: screen.route_path,
                  screenScope: screen.screen_scope,
                  adminOnly: boolValue(screen.admin_only),
                  loginRequired: boolValue(screen.login_required),
                  allowedUserTypes: screen.allowed_user_types || "",
                  isActive: boolValue(screen.is_active),
                })}>
                  <span className="block truncate font-mono-data font-bold">{screen.screen_id}</span>
                  <span className="block truncate text-xs text-[var(--text-muted)]">{screen.route_path}</span>
                </button>
                <button type="button" onClick={() => deleteScreen(screen.screen_id)} className="p-1 text-[var(--danger,#dc2626)]">
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-4">
          <h2 className="mb-3 text-base font-extrabold">{tl("adminMenuItemTitle", "메뉴")}</h2>
          <div className="grid gap-2">
            <input className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" placeholder="menuId" value={menuDraft.menuId} onChange={(e) => setMenuDraft({ ...menuDraft, menuId: e.target.value })} />
            <input className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" placeholder="label resource key" value={menuDraft.labelResourceKey} onChange={(e) => setMenuDraft({ ...menuDraft, labelResourceKey: e.target.value })} />
            <input className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" placeholder="icon name (chat, friends, stock, schedule, work, mypage)" value={menuDraft.iconName} onChange={(e) => setMenuDraft({ ...menuDraft, iconName: e.target.value })} />
            <div className="grid gap-2 sm:grid-cols-2">
              <select className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" value={menuDraft.menuType} onChange={(e) => setMenuDraft({ ...menuDraft, menuType: e.target.value })}>
                <option value="section">section</option>
                <option value="item">item</option>
              </select>
              <select className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" value={menuDraft.parentMenuId} onChange={(e) => setMenuDraft({ ...menuDraft, parentMenuId: e.target.value })}>
                <option value="">parent none</option>
                {menuOptions.map((menu) => <option key={menu.menu_id} value={menu.menu_id}>{menu.menu_id}</option>)}
              </select>
              <select className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" value={menuDraft.screenId} onChange={(e) => {
                const screenId = e.target.value;
                setMenuDraft({ ...menuDraft, screenId, href: routePathByScreenId.get(screenId) || menuDraft.href });
              }}>
                <option value="">screen none</option>
                {screens.map((screen) => <option key={screen.screen_id} value={screen.screen_id}>{screen.screen_id}</option>)}
              </select>
              <input className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" placeholder="href" value={menuDraft.href} onChange={(e) => setMenuDraft({ ...menuDraft, href: e.target.value })} />
              <input type="number" className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" value={menuDraft.sortOrder} onChange={(e) => setMenuDraft({ ...menuDraft, sortOrder: Number(e.target.value) })} />
              <select className="rounded-[var(--radius-md)] border border-[var(--border)] bg-[var(--surface)] px-3 py-2 text-sm" value={menuDraft.menuScope} onChange={(e) => setMenuDraft({ ...menuDraft, menuScope: e.target.value })}>
                <option value="common">common</option>
                <option value="app">app</option>
                <option value="mobileTabBar">mobileTabBar</option>
              </select>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-sm">
              <label><input type="checkbox" checked={menuDraft.adminOnly} onChange={(e) => setMenuDraft({ ...menuDraft, adminOnly: e.target.checked })} /> admin</label>
              <label><input type="checkbox" checked={menuDraft.loginRequired} onChange={(e) => setMenuDraft({ ...menuDraft, loginRequired: e.target.checked })} /> login</label>
              <label><input type="checkbox" checked={menuDraft.hideWhenLoggedIn} onChange={(e) => setMenuDraft({ ...menuDraft, hideWhenLoggedIn: e.target.checked })} /> hide after login</label>
              <label><input type="checkbox" checked={menuDraft.initiallyOpen} onChange={(e) => setMenuDraft({ ...menuDraft, initiallyOpen: e.target.checked })} /> initially open</label>
              <label><input type="checkbox" checked={menuDraft.isVisible} onChange={(e) => setMenuDraft({ ...menuDraft, isVisible: e.target.checked })} /> visible</label>
              <label><input type="checkbox" checked={isMobileTabMenu(menuDraft)} onChange={(e) => setShowInMobileTabBar(e.target.checked)} /> {tl("adminMenuMobileTabBar", "하단 상태바")}</label>
              <button type="button" onClick={saveMenu} className="inline-flex items-center gap-1 rounded-[var(--radius-md)] bg-[var(--brand-blue,#2563eb)] px-3 py-2 font-bold text-white">
                <Save size={14} />
                {tl("resourceTextSave", "저장")}
              </button>
            </div>
          </div>
          <div className="mt-4 max-h-[45vh] overflow-auto divide-y divide-[var(--border)]">
            {menus.map((menu) => (
              <div key={menu.menu_id} className="flex items-center justify-between gap-2 py-2 text-sm">
                <button type="button" className="min-w-0 text-left" onClick={() => setMenuDraft({
                  menuId: menu.menu_id,
                  menuType: menu.menu_type,
                  parentMenuId: menu.parent_menu_id || "",
                  screenId: menu.screen_id || "",
                  href: menu.href || "",
                  labelResourceKey: menu.label_resource_key,
                  iconName: menu.icon_name || "",
                  adminOnly: boolValue(menu.admin_only),
                  loginRequired: boolValue(menu.login_required),
                  hideWhenLoggedIn: boolValue(menu.hide_when_logged_in),
                  initiallyOpen: boolValue(menu.initially_open),
                  sortOrder: Number(menu.sort_order || 1000),
                  isVisible: boolValue(menu.is_visible),
                  menuScope: menu.menu_scope || "app",
                })}>
                  <span className="block truncate font-mono-data font-bold">{menu.menu_id}</span>
                  <span className="block truncate text-xs text-[var(--text-muted)]">{menu.parent_menu_id || "-"} / {menu.screen_id || "-"} / {menu.href || "-"}</span>
                </button>
                <button type="button" onClick={() => deleteMenu(menu.menu_id)} className="p-1 text-[var(--danger,#dc2626)]">
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
