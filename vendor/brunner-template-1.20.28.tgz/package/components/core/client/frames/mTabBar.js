"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
import * as commonFunctions from "@/lib/commonFunctions";
import * as constants from "@/lib/constants";
import * as userInfo from "@/components/core/client/frames/userInfo";
import {
  isMobileStatusBarVisible,
  loadMobileStatusBarItems,
  MOBILE_STATUS_BAR_VISIBLE_EVENT,
} from "@/lib/mobileStatusBar";

function Icon({ name, active }) {
  const commonProps = {
    width: 22,
    height: 22,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
  };

  const paths = {
    chat: (
      <>
        <path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 17 0Z" />
        {active && <path d="M8 10h8M8 14h5" />}
      </>
    ),
    friends: (
      <>
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
      </>
    ),
    stock: (
      <>
        <path d="M3 3v18h18" />
        <path d="M7 14l4-4 4 4 5-6" />
      </>
    ),
    work: (
      <>
        <rect x="4" y="4" width="16" height="16" rx="2" />
        <path d="M8 9h8M8 13h5M8 17h7" />
      </>
    ),
    schedule: (
      <>
        <rect x="3" y="4" width="18" height="18" rx="2" />
        <path d="M16 2v4M8 2v4M3 10h18" />
        {active && <path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01" />}
      </>
    ),
    mypage: (
      <>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21a8 8 0 0 1 16 0" />
      </>
    ),
  };

  return <svg {...commonProps}>{paths[name]}</svg>;
}

export default function MTabBar() {
  const router = useRouter();
  const [languageCode, setLanguageCode] = useState("ko-KR");
  const [tabs, setTabs] = useState([]);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    setLanguageCode(userInfo.getCurrentLanguageCode() || "ko-KR");
    setVisible(isMobileStatusBarVisible());

    const load = () => loadMobileStatusBarItems().then(setTabs).catch(() => setTabs([]));
    load();

    const syncPreference = () => setVisible(isMobileStatusBarVisible());
    const syncAll = () => {
      syncPreference();
      load();
    };
    window.addEventListener("userChanged", syncAll);
    window.addEventListener("menuChanged", syncAll);
    window.addEventListener(MOBILE_STATUS_BAR_VISIBLE_EVENT, syncPreference);
    return () => {
      window.removeEventListener("userChanged", syncAll);
      window.removeEventListener("menuChanged", syncAll);
      window.removeEventListener(MOBILE_STATUS_BAR_VISIBLE_EVENT, syncPreference);
    };
  }, []);

  useEffect(() => {
    if (typeof document === "undefined") return undefined;
    const active = visible && tabs.length > 0;
    document.documentElement.classList.toggle("has-mobile-tab-bar", active);
    return () => document.documentElement.classList.remove("has-mobile-tab-bar");
  }, [visible, tabs.length]);

  const getLabel = (labelKey) =>
    commonFunctions.getResourceByLanguage(labelKey, constants.resourceType.label, languageCode);

  const isActive = (href) => router.asPath === href || router.asPath?.startsWith(`${href}&`) || router.pathname === href.split("?")[0];

  if (!visible || tabs.length === 0) return null;

  return (
    // 칸 수를 탭 수에서 만든다 — grid-cols-4 로 고정해 두면 탭 수가 달라질 때
    // 빈 칸이 생겨 버튼들이 한쪽으로 쏠린다.
    <nav data-mobile-tab-bar className="fixed bottom-0 left-0 right-0 z-50 grid border-t bg-[var(--surface)] px-1 pt-2 md:hidden" style={{ gridTemplateColumns: `repeat(${tabs.length}, minmax(0, 1fr))`, paddingBottom: "env(safe-area-inset-bottom, 22px)", minHeight: "calc(78px + env(safe-area-inset-bottom, 22px))", borderColor: "var(--border)" }} aria-label={getLabel("mobileBottomNav")}>
      {tabs.map((tab) => {
        const active = isActive(tab.href);
        return (
          <Link
            key={tab.href}
            href={tab.href}
            aria-current={active ? "page" : undefined}
            className={`flex min-w-0 flex-col items-center justify-start gap-1 rounded-[var(--radius-md)] px-1 py-1 text-[11px] transition hover:opacity-80 ${
              active ? "font-bold text-[var(--brand-blue)]" : "font-medium text-[var(--text-subtle)]"
            }`}
          >
            <Icon name={tab.icon} active={active} />
            <span className="truncate">{getLabel(tab.labelKey)}</span>
          </Link>
        );
      })}
    </nav>
  );
}
