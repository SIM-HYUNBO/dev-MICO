"use client";

import { useEffect, useState, useRef } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import * as constants from "@/lib/constants";
import * as commonFunctions from "@/lib/commonFunctions";
import UserInfo from "@/components/core/client/frames/userInfo";
import * as userInfo from "@/components/core/client/frames/userInfo";
import { getDropdownMenuItems } from "@/components/core/client/frames/dropdownMenuitem";
import ComplaintContent from "@/components/core/client/contents/complaintContent";
import BrandWordmark from "@/components/core/client/ui/BrandWordmark";

const L = (key) =>
  commonFunctions.getResourceByLanguage(key, constants.resourceType.label, userInfo.getCurrentLanguageCode());

export const loadMenu = async ({ forceRefresh = false } = {}) => {
  // 메뉴는 항상 현재 코드 기준으로 생성한다. 로그인 시 localStorage(userInfo.menuItems)에
  // 저장된 옛 메뉴를 쓰면 배포로 메뉴 구성이 바뀌어도 낡은/깨진 메뉴가 계속 남는다.
  const items = await getDropdownMenuItems();

  // 섹션은 접힌 채로 시작한다 — 처음에는 1레벨(서비스·자료실·관리)만 보인다.
  //
  // 한때 전부 펼친 채로 열었다. 접혀 있으면 "메뉴가 비었다" 로 읽힌다는 이유였는데,
  // 항목이 늘면서 반대 문제가 커졌다. 메뉴를 열자마자 긴 목록이 통째로 쏟아져
  // 어디를 봐야 할지 알 수 없고, 원하는 항목까지 스크롤해야 한다.
  //
  // 비어 보이던 문제는 섹션 제목 옆 화살표가 접힘을 알려주는 것으로 해결한다.
  const sections = items
    .filter((item) => item.type === "section")
    .reduce((acc, cur) => {
      acc[cur.label] = cur.initiallyOpen === true;
      return acc;
    }, {});

  return { items, sections };
};

/* -----------------------------------------------------------
   🔹 DropdownMenu 컴포넌트
   ----------------------------------------------------------- */
export default function DropdownMenu() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [menuItems, setMenuItems] = useState([]);
  const [openSections, setOpenSections] = useState({});
  const [showComplaint, setShowComplaint] = useState(false);
  const menuRef = useRef(null);
  const panelRef = useRef(null);
  const buttonRef = useRef(null);
  const [panelPosition, setPanelPosition] = useState({ left: 12, top: 56, width: 340 });

  const placePanel = () => {
    if (typeof window === "undefined" || !buttonRef.current) return;
    const rect = buttonRef.current.getBoundingClientRect();
    const width = Math.min(340, window.innerWidth - 24);
    const left = Math.max(12, Math.min(rect.left, window.innerWidth - width - 12));
    setPanelPosition({ left, top: rect.bottom + 8, width });
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      // 메뉴 안에서 연 모달은 포털로 body에 붙어 menuRef 바깥이다.
      // 그걸 '바깥 클릭'으로 보면 모달을 누르는 순간 메뉴가 닫히고,
      // 모달을 그린 컴포넌트까지 함께 사라져 버튼이 눌리지 않는다.
      if (event.target?.closest?.("[data-brunner-modal]")) return;
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target) &&
        !panelRef.current?.contains(event.target)
      ) {
        setMobileMenuOpen(false);
      }
    };
    const handleEsc = (e) => { if (e.key === "Escape") setMobileMenuOpen(false); };
    if (mobileMenuOpen) {
      placePanel();
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleEsc);
      window.addEventListener("resize", placePanel);
      window.addEventListener("scroll", placePanel, true);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
      window.removeEventListener("resize", placePanel);
      window.removeEventListener("scroll", placePanel, true);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
      window.removeEventListener("resize", placePanel);
      window.removeEventListener("scroll", placePanel, true);
    };
  }, [mobileMenuOpen]);

  const toggleSection = (label) => {
    setOpenSections((prev) => ({
      ...prev,
      [label]: !prev[label],
    }));
  };

  const refreshMenu = async ({ forceRefresh = false } = {}) => {
    const { items, sections } = await loadMenu({ forceRefresh });
    setMenuItems(items);
    setOpenSections(sections);
  };

  const openMenu = async () => {
    // 항목을 다 불러온 뒤에야 패널을 열면, 그 로딩이 한 번 실패했을 때
    // 햄버거를 눌러도 아무 일도 일어나지 않는다(고장으로 보인다).
    // 패널은 먼저 열고 항목은 뒤이어 채운다.
    try {
      await refreshMenu({ forceRefresh: true });
    } catch (e) {
      console.warn("[menu] 항목을 불러오지 못했어요:", e?.message || e);
    }
  };

  // 로그인/로그아웃, 문서 저장/삭제 시 메뉴 자동 갱신
  useEffect(() => {
    const handleRefresh = () => refreshMenu({ forceRefresh: true });
    window.addEventListener("userChanged", handleRefresh);
    window.addEventListener("menuChanged", handleRefresh);
    return () => {
      window.removeEventListener("userChanged", handleRefresh);
      window.removeEventListener("menuChanged", handleRefresh);
    };
  }, []);

  const getSectionLabel = (item) => item.parent || constants.emptyString;

  const getItemDepth = (item, items) => {
    let depth = 0;
    let current = item;
    while (current.parent) {
      depth++;
      const parentItem = items.find((i) => i.label === current.parent);
      if (!parentItem) break;
      current = parentItem;
    }
    return depth;
  };

  const handleLogout = async () => {
    await refreshMenu({ forceRefresh: true });
  };

  return (
    <div ref={menuRef} className="relative inline-flex">
      {/* 햄버거 버튼 */}
      <button
        type="button"
        ref={buttonRef}
        className="theme-icon-button inline-flex h-10 w-10 items-center justify-center rounded-[var(--radius-md)] border shadow-sm transition"
        onClick={() => {
          // 패널을 먼저 열고 항목은 뒤이어 채운다. 예전에는 await openMenu() 로
          // 항목 로딩이 끝난 뒤에야 토글했는데, 문서목록 조회는 로그인 상태에서만
          // 일어나므로 "로그인하면 햄버거를 눌러도 아무 반응이 없다"로 나타났다.
          // (모바일에서 응답이 늦으면 그 시간 내내 메뉴가 안 열린다.)
          const next = !mobileMenuOpen;
          if (next) placePanel();
          setMobileMenuOpen(next);
          if (next) openMenu();
        }}
        aria-label={L("menuOpen")}
        aria-haspopup="menu"
        aria-expanded={mobileMenuOpen}
      >
        <svg
          width="22"
          height="22"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <line x1="4" y1="6" x2="20" y2="6" />
          <line x1="4" y1="12" x2="20" y2="12" />
          <line x1="4" y1="18" x2="20" y2="18" />
        </svg>
      </button>

      {mobileMenuOpen && typeof document !== "undefined" && createPortal(
        <div
          ref={panelRef}
          onMouseDown={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
          className="dropdown-menu-panel fixed z-[10020] flex flex-col overflow-hidden rounded-[var(--radius-xl)] border border-[var(--border)] bg-[var(--surface)] text-sm text-[var(--text)] shadow-[var(--shadow-card-strong)]"
          style={{ left: panelPosition.left, top: panelPosition.top, width: panelPosition.width }}
        >
          <div className="shrink-0 border-b border-[var(--border)] bg-[image:var(--brand-gradient-soft)] px-4 py-3">
            <BrandWordmark className="text-base font-extrabold" />
          </div>

          <ul className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-2" role="menu" aria-label={L("menu")}>
            {/* 항목이 없으면 빈 상자만 뜬다. 고장인지 원래 그런지 알 수 없으므로 그렇다고 적는다. */}
            {menuItems.length === 0 && (
              <li role="none" className="px-3 py-6 text-center text-sm text-[var(--text-muted)]">
                {L("menuEmpty")}
              </li>
            )}
            {menuItems.map((item, idx) => {
              if (item.type === "divider")
                return <li key={idx} role="separator" className="my-2 border-t border-[var(--border)]" />;

              if (item.type === "section") {
                if (item.parent && !openSections[item.parent]) return null;
                return (
                  <li key={idx} role="none" className="mt-1">
                    <button
                      type="button"
                      aria-expanded={!!openSections[item.label]}
                      className="flex w-full select-none items-center justify-between rounded-[var(--radius-md)] py-2.5 pr-3 text-left text-sm font-bold uppercase tracking-wide text-[var(--text-muted)] transition hover:bg-[var(--surface-alt)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-blue)]"
                      style={{ paddingLeft: `${12 + 16 * getItemDepth(item, menuItems)}px` }}
                      onClick={() => toggleSection(item.label)}
                    >
                      <span className="truncate">{item.label}</span>
                      <svg className={`h-4 w-4 shrink-0 transition ${openSections[item.label] ? "rotate-90" : ""}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="m9 18 6-6-6-6" />
                      </svg>
                    </button>
                  </li>
                );
              }

              // 조상 섹션이 모두 열려있어야 노출
              let ancestor = item;
              let hidden = false;
              while (ancestor.parent) {
                if (!openSections[ancestor.parent]) { hidden = true; break; }
                ancestor = menuItems.find((i) => i.label === ancestor.parent) || {};
              }
              if (hidden) return null;

              const depth = getItemDepth(item, menuItems);

              return (
                <li key={item.href + idx} role="none">
                  <Link
                    href={item.href}
                    role="menuitem"
                    onClick={() => setMobileMenuOpen(false)}
                    className="block rounded-[var(--radius-md)] px-3 py-2.5 text-base font-semibold text-[var(--text)] transition hover:bg-[var(--surface-alt)] hover:text-[var(--brand-blue)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-blue)]"
                    style={{ paddingLeft: `${16 * (depth + 1)}px` }}
                  >
                    <span className="line-clamp-2">{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>

          {/* 설정·문의 줄은 어떤 경우에도 남아야 한다. 화면이 짧으면 위의 목록이
              줄어들 뿐, 이 줄이 밀려 사라지지 않도록 h-14 를 최소 높이로도 건다. */}
          <div className="relative flex h-14 min-h-[3.5rem] shrink-0 items-center border-t border-[var(--border)] bg-[var(--surface-alt)] px-2">
            {/* 전체 너비: 사용자 이름 가운데 */}
            <div className="absolute inset-0">
              <UserInfo handleLogout={handleLogout} />
            </div>
            {/* 왼쪽: 설정 버튼 + 문의 버튼 */}
            {/* inset-y-0 로 세로를 명시한다. top 을 주지 않으면 위치가 static
                position 규칙에 맡겨지는데, 플렉스 컨테이너 안에서 그 값이 브라우저
                마다 달라 아이콘이 줄 바깥으로 걸치고 잘려 보인다. */}
            <div className="absolute inset-y-0 left-2 z-20 flex items-center gap-1">
              <Link
                href="/mainPages/settings"
                onClick={() => setMobileMenuOpen(false)}
                className="theme-icon-button inline-flex h-9 w-9 items-center justify-center rounded-full border transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-blue)]"
                title={L("settings")}
                aria-label={L("settings")}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3" />
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                </svg>
              </Link>
              <button
                onClick={() => { setShowComplaint(true); setMobileMenuOpen(false); }}
                className="theme-icon-button inline-flex h-9 w-9 items-center justify-center rounded-full border text-base font-bold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-blue)]"
                title={L("complaintTitle")}
                aria-label={L("complaintTitle")}
              ><span aria-hidden="true">?</span></button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {showComplaint && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 p-4" onClick={(e) => { if (e.target === e.currentTarget) setShowComplaint(false); }} role="dialog" aria-modal="true" aria-label={L("complaintTitle")}>
          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[var(--surface)] shadow-2xl">
            <button onClick={() => setShowComplaint(false)} aria-label={L("close")} className="absolute right-3 top-3 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-[var(--surface-alt)] text-[var(--text-muted)] hover:text-[var(--text)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand-blue)]"><span aria-hidden="true">✕</span></button>
            <ComplaintContent />
          </div>
        </div>
      )}
    </div>
  );
}
