import * as constants from "@/lib/constants";
import * as userInfo from "@/components/core/client/frames/userInfo";
import * as commonFunctions from "@/lib/commonFunctions";
import { RequestServer } from "@/components/core/client/requestServer";
import * as menuManifest from "@/lib/menuManifest";

const isAiContentDocument = (doc) => {
  const runtimeData = doc?.runtime_data || {};
  return (
    runtimeData.source === "AI_STUDIO" ||
    runtimeData.aiContent === true ||
    Boolean(runtimeData.aiContentEpisodeId) ||
    Boolean(runtimeData.aiContentSpaceId)
  );
};

const L = (key) =>
  commonFunctions.getResourceByLanguage(
    key,
    constants.resourceType.label,
    userInfo.getCurrentLanguageCode(),
  );

const menuRowsToItems = (rows) => {
  const dropdownRows = rows.filter((row) => row.menu_scope !== "mobileTabBar");
  const labelByMenuId = new Map(dropdownRows.map((row) => [row.menu_id, L(row.label_resource_key)]));
  return dropdownRows
    .map((row) => {
      const parent = row.parent_menu_id
        ? labelByMenuId.get(row.parent_menu_id) || L(row.parent_label_resource_key)
        : undefined;
      if (row.menu_type === "section") {
        return {
          label: L(row.label_resource_key),
          type: "section",
          parent,
          initiallyOpen: row.initially_open === true || String(row.initially_open).toUpperCase() === "Y",
        };
      }
      return {
        label: L(row.label_resource_key),
        href: row.href,
        type: "item",
        parent,
      };
    })
    .filter((item) => item.type === "section" || item.href);
};

const appendManifestSection = (items, sectionKey, sectionItems = []) => {
  if (!sectionKey || !Array.isArray(sectionItems) || sectionItems.length === 0) return;
  const parent = L(sectionKey);
  if (items.some((item) => item.type === "section" && item.label === parent)) return;
  items.push({ label: parent, type: "section" });
  sectionItems.forEach((item) => {
    if (!item?.href) return;
    if (items.some((existing) => existing.href === item.href)) return;
    items.push({
      label: L(item.key || item.labelResourceKey || item.label),
      href: item.href,
      type: "item",
      parent,
    });
  });
};

const loadMenuItemsFromManifest = () => {
  const items = [];

  if (Array.isArray(menuManifest.serviceMenuSections)) {
    menuManifest.serviceMenuSections.forEach((section) => {
      appendManifestSection(items, section.key, section.items);
    });
  } else {
    appendManifestSection(items, menuManifest.zicpMenuSectionKey, menuManifest.zicpMenu);
    appendManifestSection(items, "publicMenuSection", menuManifest.serviceMenu);
  }

  if (userInfo.isAdminUser?.()) {
    appendManifestSection(items, "adminMenuSection", menuManifest.adminMenu);
  }

  if (!userInfo.isLogin?.()) {
    appendManifestSection(items, "accountMenuSection", [
      { key: "homeSignin", href: "/mainPages/signin" },
      { key: "homeSignup", href: "/mainPages/signup" },
    ]);
  }

  return items;
};

const loadMenuItemsFromDb = async () => {
  const res = await RequestServer({
    commandName: constants.commands.MENU_SELECT,
    userId: userInfo.getLoginUserId?.() || "",
    languageCode: userInfo.getCurrentLanguageCode(),
  });
  if (res.error_code !== constants.errorCode.Success) {
    console.warn("[menu] DB menu load failed:", res.error_message);
    return loadMenuItemsFromManifest();
  }
  const items = menuRowsToItems(res.data?.menus || []);
  if (items.length === 0) {
    console.warn("[menu] DB menu is empty; using manifest fallback.");
    return loadMenuItemsFromManifest();
  }
  if (userInfo.isAdminUser?.()) {
    appendManifestSection(items, "adminMenuSection", menuManifest.adminMenu);
  }
  return items;
};

const appendDocumentItems = async (items) => {
  if (!userInfo.getCurrentSystemCode()) return;

  const publicDocumentSectionLabel = L("publicDocumentSection");
  items.push({ label: publicDocumentSectionLabel, type: "section" });

  let documentList = null;
  try {
    documentList = await commonFunctions.getAdminDocumentList(userInfo.getCurrentSystemCode());
  } catch (e) {
    console.warn("[menu] document menu load failed:", e?.message || e);
  }
  if (!documentList) return;

  try {
    const helpDocs = documentList.filter((d) => !isAiContentDocument(d));
    const pathOf = (d) => d.runtime_data?.menu_path || d.menu_path || "";
    const adminVersions = new Map(
      helpDocs
        .filter((d) => pathOf(d).endsWith("-admin"))
        .map((d) => [pathOf(d).replace(/-admin$/, ""), d]),
    );

    helpDocs.forEach((doc) => {
      const path = pathOf(doc);
      if (path.endsWith("-admin") && adminVersions.has(path.replace(/-admin$/, ""))) {
        const hasNormal = helpDocs.some((x) => pathOf(x) === path.replace(/-admin$/, ""));
        if (hasNormal) return;
      }
      const target = adminVersions.get(path) || doc;
      items.push({
        label: doc.runtime_data?.title || L("menuUntitledDocument"),
        href: `/${target.id}`,
        type: "item",
        parent: publicDocumentSectionLabel,
      });
    });
  } catch (e) {
    console.warn("[menu] document menu build failed:", e?.message || e);
  }
};

export async function getDropdownMenuItems() {
  const items = await loadMenuItemsFromDb();
  await appendDocumentItems(items);
  return items;
}
