// 앱의 SQL 사본이 템플릿 판을 가리는 것을 잡는 게이트.
//
// 왜 필요한가
//   run_sql 은 SQL 파일을 찾을 때 앱의 scripts 를 먼저 본다. 파생 서비스가 자기
//   판을 쓸 수 있게 하려는 규칙인데, 실제로는 반대로 쓰였다 — 오래 전 복사해 둔
//   사본이 그대로 남아, 템플릿이 고친 판을 조용히 가린다. 사본은 만든 순간부터
//   밀리기 시작하는데 밀린 것을 알려주는 장치가 없었다.
//
//   실제로 이렇게 터졌다. insert_dynamic_sql_mark_all_read.sql 의 앱 사본에는
//   바깥 INSERT 에 ON CONFLICT 가 없었다. 템플릿 판은 이미 재실행 안전했는데
//   사본이 그것을 가려, 이미 등록된 이름을 다시 넣다가 PK 중복으로 죽었고
//   운영 사이트가 502 로 내려갔다. 그 파일은 그때까지 한 번도 돈 적이 없어
//   아무도 몰랐다.
//
// 무엇을 막고 무엇을 알리나
//   막는다(exit 1) — 앱 사본이 TB_COR_SQL_INFO 에 ON CONFLICT 없이 INSERT 하는 경우.
//     두 번 돌면 반드시 죽는다. 배포를 멈추는 편이 낫다.
//   알린다(경고) — 앱 사본이 템플릿 판의 부분집합인 경우(고유 내용이 없음).
//     지우면 템플릿 수정을 그냥 받는다.
//   알린다(참고) — 앱 사본에 고유 내용이 있는 경우. 의도한 재정의일 수 있으니
//     막지 않는다. 다만 템플릿이 그 파일을 고쳤다면 못 받고 있다는 뜻이다.

const fs = require("fs");
const path = require("path");

const appDir = process.env.BRUNNER_APP_DIR || process.cwd();
const packageScripts = __dirname;

const readList = () => {
  const candidates = [
    path.join(appDir, "scripts", "install_sql_files.json"),
    path.join(packageScripts, "install_sql_files.json"),
  ];
  const file = candidates.find((c) => fs.existsSync(c));
  if (!file) return [];
  const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
  const list = Array.isArray(parsed) ? parsed : parsed.files || [];
  return list
    .map((e) => String(typeof e === "string" ? e : e?.file || "").trim())
    .filter(Boolean);
};

// 스키마 이름 차이는 무시한다 — run_sql 이 적용 시점에 바꾼다.
// 접두어(brunner_template.)와 따옴표 안 이름('brunner_template') 둘 다 run_sql 이
// 적용 시점에 바꾼다. 그것 때문에 다르다고 보면 지워도 되는 사본을 계속 남기게 된다.
const normalize = (text) =>
  text
    .replace(/\r\n/g, "\n")
    .replace(/\bbrunner_template\./g, "brunner.")
    .replace(/'brunner_template'/g, "'brunner'")
    .trim();

// 작은따옴표 안은 등록되는 SQL 본문이라 바깥 문장과 무관하다. 지우고 본다.
const unguardedInserts = (sql) =>
  sql
    .replace(/'(?:[^']|'')*'/g, "''")
    .split(";")
    .filter(
      (stmt) =>
        /INSERT\s+INTO\s+[\w".]*TB_COR_SQL_INFO/i.test(stmt) && !/ON\s+CONFLICT/i.test(stmt),
    ).length;

const codeLines = (text) =>
  normalize(text)
    .split("\n")
    .filter((line) => line.trim() && !line.trim().startsWith("--"));

const main = () => {
  // 이 저장소 자신에서 돌면 앱과 패키지가 같은 곳이라 검사할 것이 없다.
  if (path.resolve(appDir, "scripts") === path.resolve(packageScripts)) {
    console.log("[shadow-sql-gate] 템플릿 저장소 자신 — 건너뛴다.");
    return 0;
  }

  const blocking = [];
  const stale = [];
  const overridden = [];

  for (const file of readList()) {
    const local = path.join(appDir, "scripts", file);
    const pkg = path.join(packageScripts, file);
    if (!fs.existsSync(local) || !fs.existsSync(pkg)) continue;

    const localText = fs.readFileSync(local, "utf8");
    const pkgText = fs.readFileSync(pkg, "utf8");
    if (normalize(localText) === normalize(pkgText)) {
      stale.push({ file, reason: "템플릿 판과 같음 — 사본을 둘 이유가 없다" });
      continue;
    }

    // 옛 run_sql 만 치환하던 자리표시자. 패키지 run_sql 은 brunner_template. 접두어를
    // 바꿀 뿐 ${...} 를 모른다. 그대로 Postgres 로 가서 $ 문법 오류로 죽는다.
    // zicp 가 실제로 이것 때문에 배포에 실패했다.
    const placeholders = (localText.match(/\$\{[A-Z_]+\}/g) || []).length;
    if (placeholders > 0) {
      blocking.push({ file, placeholders });
      continue;
    }

    const bad = unguardedInserts(localText);
    if (bad > 0) {
      blocking.push({ file, bad });
      continue;
    }

    const pkgSet = new Set(codeLines(pkgText));
    const ownLines = codeLines(localText).filter((l) => !pkgSet.has(l));
    if (ownLines.length === 0) stale.push({ file, reason: "템플릿 판의 부분집합 — 밀려 있다" });
    else overridden.push({ file, own: ownLines.length });
  }

  console.log("=== 앱 SQL 사본 게이트 ===");

  if (overridden.length) {
    console.log(`\n[참고] 고유 내용이 있는 사본 ${overridden.length}건 — 의도한 재정의로 본다.`);
    for (const o of overridden) console.log(`  ${o.file} (고유 ${o.own}줄)`);
  }

  if (stale.length) {
    console.warn(`\n[경고] 지워도 되는 사본 ${stale.length}건 — 지우면 템플릿 수정을 그대로 받는다.`);
    for (const s of stale) console.warn(`  ${s.file} — ${s.reason}`);
  }

  if (blocking.length) {
    console.error(`\n[차단] 재실행하면 죽는 사본 ${blocking.length}건`);
    for (const b of blocking) {
      if (b.placeholders) {
        console.error(`  ${b.file} — 옛 치환 자리표시자 \${...} ${b.placeholders}곳 (패키지 run_sql 은 치환하지 않는다)`);
      } else {
        console.error(`  ${b.file} — TB_COR_SQL_INFO 에 ON CONFLICT 없는 INSERT ${b.bad}곳`);
      }
    }
    console.error(
      "\n  이 사본을 지우면 템플릿의 재실행 안전한 판이 쓰인다. 사본을 꼭 남겨야 하면\n" +
        "  바깥 INSERT 에 ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ) 를 붙여라.",
    );
    return 1;
  }

  console.log("\n[shadow-sql-gate] OK — 배포를 막을 사본은 없다.");
  return 0;
};

process.exit(main());
