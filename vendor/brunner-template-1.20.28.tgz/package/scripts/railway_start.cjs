// Railway production entrypoint.
// Applies required DB SQL before starting the web server, then syncs repo docs best-effort.

const { spawn, spawnSync } = require("child_process");
const fs = require("fs");
const path = require("path");

// 이 스크립트는 두 자리에서 실행된다 — 이 저장소 자신, 그리고 파생 서비스의
// node_modules/brunner-template. 스크립트는 패키지 안에서 찾고, 서버는 앱 루트에서
// 띄워야 한다. 둘을 구분하지 않으면 파생 서비스에서 패키지의 pages 를 서빙하게 된다.
// 이 저장소에서 실행하면 두 값이 같으므로 동작이 달라지지 않는다.
const packageRoot = path.join(__dirname, "..");
const appDir = process.env.BRUNNER_APP_DIR || process.cwd();
const packageScript = (name) => path.join(__dirname, name);

const runRequired = (label, args) => {
  console.log(`[railway_start] ${label}`);
  const result = spawnSync(process.execPath, args, {
    cwd: appDir,
    stdio: "inherit",
    env: process.env,
  });

  if (result.status !== 0) {
    const code = result.status ?? 1;
    console.error(`[railway_start] ${label} failed with exit code ${code}.`);
    process.exit(code);
  }
};

const runOptional = (label, args) => {
  console.log(`[railway_start] ${label}`);
  const result = spawnSync(process.execPath, args, {
    cwd: appDir,
    stdio: "inherit",
    env: process.env,
  });

  if (result.status !== 0) {
    const code = result.status ?? 1;
    console.warn(`[railway_start] ${label} failed with exit code ${code}; continuing.`);
  }
};

runRequired("Apply DB SQL scripts", [packageScript("run_sql.cjs")]);

// 리소스 시드는 실패해도 서버를 띄운다.
//
// 왜
//   이건 초기 데이터를 넣는 단계이고 ON CONFLICT DO NOTHING 이라 이미 깔린 시스템
//   에서는 사실상 할 일이 없다. 그런데 필수 단계로 두었더니, 이 단계가 실패하는
//   순간 사이트 전체가 502 로 죽었다. 문구 몇 줄을 못 넣은 대가로 서비스를 내리는
//   것은 어떤 경우에도 맞지 않는다.
//
//   실패하면 화면에 [리소스 없음:...] 이 보이므로 조용히 묻히지도 않는다.
runOptional("Apply resource text table and seed", [packageScript("apply_resource_text_seed.cjs")]);

// 시드가 하나 빠지거나 SQL_NAME 이 어긋나면 배포는 그대로 성공하고 그 기능만 조용히 죽는다.
// (select_BRUNNER_DB_SIZE 는 개명 때 코드가 안 따라와 매 배포마다 지워지고 있었는데,
//  배포 로그에는 아무 표시도 없었다.) 검증은 소스의 getSQL 이름을 DB 와 대조한다.
// 실패해도 서버는 띄운다 — 미등록 하나로 전체를 못 뜨게 만드는 쪽이 더 위험하다.
if (process.env.VERIFY_DYNAMIC_SQL_ON_START !== "false") {
  runOptional("Verify dynamic SQL registrations", [packageScript("verify_dynamic_sql.cjs")]);
}

// 문서 동기화는 실패해도 되는 단계인데, 재시도를 반복하는 동안 서버가 뜨지
// 않아 헬스체크가 컨테이너를 죽였다(신규 설치본에는 PLAN.md 가 없어 매번 걸렸다).
// 기동을 막지 않도록 서버를 띄운 뒤 뒤에서 돌린다.
const syncRepoDocsInBackground = () => {
  if (process.env.SYNC_REPO_DOCS_ON_START === "false") return;
  console.log("[railway_start] Sync repository docs to eDoc (background)");
  const child = spawn(process.execPath, [packageScript("sync_repo_docs_to_edoc.cjs")], {
    cwd: appDir,
    stdio: "inherit",
    env: process.env,
  });
  child.on("exit", (code) => {
    if (code !== 0) console.warn(`[railway_start] Repository doc sync exited with ${code}; ignored.`);
  });
};

// 앱이 자기 server.js 를 갖고 있으면 그것을 띄운다.
//
// 왜
//   설치 마법사가 만든 새 시스템은 server.js 가 없으므로 패키지 것을 띄우는 게 맞다.
//   하지만 오래된 파생 서비스는 자기 server.js 에 그 서비스에만 있는 것들을 담고
//   있다 — 주식 크론, 자동매매, 뉴스 수집 같은 것이 거기서 뜬다. 패키지 것으로
//   갈아치우면 그 기능이 통째로 사라지고, 실제로 기동에 실패해 사이트가 502 로
//   죽었다. 무엇을 띄울지는 앱이 정하고, 패키지는 없을 때만 대신한다.
const appServerEntry = path.join(appDir, "server.js");
const serverEntry = fs.existsSync(appServerEntry) ? appServerEntry : path.join(packageRoot, "server.js");

console.log(`[railway_start] Start web server (${serverEntry === appServerEntry ? "app" : "package"})`);
const server = spawn(process.execPath, [serverEntry], {
  cwd: appDir,
  stdio: "inherit",
  env: process.env,
});

// 서버가 뜨기 시작한 뒤에 돌린다. 실패해도 기동에는 영향이 없다.
syncRepoDocsInBackground();

const forwardSignal = (signal) => {
  if (!server.killed) server.kill(signal);
};

process.on("SIGTERM", () => forwardSignal("SIGTERM"));
process.on("SIGINT", () => forwardSignal("SIGINT"));

server.on("exit", (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }
  process.exit(code ?? 0);
});
