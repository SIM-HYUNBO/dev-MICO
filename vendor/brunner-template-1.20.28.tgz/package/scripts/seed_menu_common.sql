DO $seed_menu_common$
DECLARE
  t text;
BEGIN
  IF to_regclass('brunner_template.tb_cor_menu') IS NULL
     OR to_regclass('brunner_template.tb_cor_screen') IS NULL THEN
    RAISE NOTICE 'skip seed_menu_common: menu tables do not exist';
    RETURN;
  END IF;

  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.tb_cor_sql_info
      UNION SELECT DISTINCT system_code AS code FROM brunner_template.tb_cor_resource_text
      UNION SELECT '00'
      UNION SELECT '01'
      UNION SELECT '02'
    ) x
    WHERE code IS NOT NULL AND code <> ''
    ORDER BY code
  LOOP
    INSERT INTO brunner_template.tb_cor_resource_text
      (system_code, resource_type, resource_key, language_code, resource_text, create_user_id, update_user_id, update_time)
    VALUES
      (t, 'label', 'adminMenuManageTitle', 'ko-KR', '메뉴 관리', 'system', 'system', NOW()),
      (t, 'label', 'adminMenuManageTitle', 'en-US', 'Menu management', 'system', 'system', NOW()),
      (t, 'label', 'adminMenuManageTitle', 'ja-JP', 'メニュー管理', 'system', 'system', NOW()),
      (t, 'label', 'adminMenuScreenTitle', 'ko-KR', '화면', 'system', 'system', NOW()),
      (t, 'label', 'adminMenuScreenTitle', 'en-US', 'Screens', 'system', 'system', NOW()),
      (t, 'label', 'adminMenuScreenTitle', 'ja-JP', '画面', 'system', 'system', NOW()),
      (t, 'label', 'adminMenuItemTitle', 'ko-KR', '메뉴', 'system', 'system', NOW()),
      (t, 'label', 'adminMenuItemTitle', 'en-US', 'Menus', 'system', 'system', NOW()),
      (t, 'label', 'adminMenuItemTitle', 'ja-JP', 'メニュー', 'system', 'system', NOW())
    ON CONFLICT (system_code, resource_type, resource_key, language_code)
    DO UPDATE SET resource_text = EXCLUDED.resource_text,
                  update_user_id = EXCLUDED.update_user_id,
                  update_time = NOW();

    INSERT INTO brunner_template.tb_cor_screen AS target_screen
      (system_code, screen_id, screen_name_key, route_path, screen_scope,
       admin_only, login_required, allowed_user_types, create_user_id, update_user_id, update_time)
    VALUES
      (t, 'main.directChat', 'directChat', '/mainPages/chatRoom?roomType=DIRECT', 'common', FALSE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'main.groupChat', 'groupChat', '/mainPages/chatRoom?roomType=GROUP', 'common', FALSE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'main.openChat', 'openChat', '/mainPages/openChat', 'common', FALSE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'main.friends', 'userFriendManagement', '/mainPages/userFriendManagement', 'common', FALSE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'main.eDocDesigner', 'eDocDesigner', '/mainPages/eDocDesigner', 'common', FALSE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'main.schedule', 'schedule', '/mainPages/schedule', 'common', FALSE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'main.calculator', 'calculator', '/mainPages/calculator', 'common', FALSE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'main.complaint', 'complaint', '/mainPages/complaint', 'common', FALSE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'account.signin', 'homeSignin', '/mainPages/signin', 'common', FALSE, FALSE, NULL, 'system', 'system', NOW()),
      (t, 'account.signup', 'homeSignup', '/mainPages/signup', 'common', FALSE, FALSE, NULL, 'system', 'system', NOW()),
      (t, 'admin.transactionHistory', 'transactionHistory', '/mainPages/transactionHistory', 'common', TRUE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'admin.userActivityDashboard', 'userActivityDashboard', '/mainPages/userActivityDashboard', 'common', TRUE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'admin.dbUsage', 'adminDbUsageTitle', '/mainPages/adminDbUsage', 'common', TRUE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'admin.railwayDeploy', 'adminRailwayDeployTitle', '/admin/railway-deploy', 'common', TRUE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'admin.resourceText', 'adminResourceTextTitle', '/admin/resource-text', 'common', TRUE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'admin.menu', 'adminMenuManageTitle', '/admin/menu', 'common', TRUE, TRUE, NULL, 'system', 'system', NOW()),
      (t, 'admin.dynamicSql', 'dynamicSql', '/mainPages/dynamicSql', 'common', TRUE, TRUE, NULL, 'system', 'system', NOW())
    ON CONFLICT (system_code, screen_id) DO UPDATE SET
      screen_name_key = EXCLUDED.screen_name_key,
      route_path = EXCLUDED.route_path,
      screen_scope = EXCLUDED.screen_scope,
      admin_only = EXCLUDED.admin_only,
      login_required = EXCLUDED.login_required,
      allowed_user_types = EXCLUDED.allowed_user_types,
      update_user_id = EXCLUDED.update_user_id,
      update_time = NOW()
    WHERE target_screen.create_user_id = 'system';

    INSERT INTO brunner_template.tb_cor_menu AS target_menu
      (system_code, menu_id, menu_type, parent_menu_id, screen_id, href, label_resource_key,
       admin_only, login_required, hide_when_logged_in, initially_open, sort_order,
       menu_scope, create_user_id, update_user_id, update_time)
    VALUES
      (t, 'section.public', 'section', NULL, NULL, NULL, 'publicMenuSection', FALSE, TRUE, FALSE, FALSE, 100, 'common', 'system', 'system', NOW()),
      (t, 'main.directChat', 'item', 'section.public', 'main.directChat', '/mainPages/chatRoom?roomType=DIRECT', 'directChat', FALSE, TRUE, FALSE, FALSE, 110, 'common', 'system', 'system', NOW()),
      (t, 'main.groupChat', 'item', 'section.public', 'main.groupChat', '/mainPages/chatRoom?roomType=GROUP', 'groupChat', FALSE, TRUE, FALSE, FALSE, 120, 'common', 'system', 'system', NOW()),
      (t, 'main.openChat', 'item', 'section.public', 'main.openChat', '/mainPages/openChat', 'openChat', FALSE, TRUE, FALSE, FALSE, 130, 'common', 'system', 'system', NOW()),
      (t, 'main.eDocDesigner', 'item', 'section.public', 'main.eDocDesigner', '/mainPages/eDocDesigner', 'eDocDesigner', FALSE, TRUE, FALSE, FALSE, 140, 'common', 'system', 'system', NOW()),
      (t, 'main.schedule', 'item', 'section.public', 'main.schedule', '/mainPages/schedule', 'schedule', FALSE, TRUE, FALSE, FALSE, 150, 'common', 'system', 'system', NOW()),
      (t, 'main.calculator', 'item', 'section.public', 'main.calculator', '/mainPages/calculator', 'calculator', FALSE, TRUE, FALSE, FALSE, 160, 'common', 'system', 'system', NOW()),
      (t, 'main.complaint', 'item', 'section.public', 'main.complaint', '/mainPages/complaint', 'complaint', FALSE, TRUE, FALSE, FALSE, 170, 'common', 'system', 'system', NOW()),
      (t, 'section.account', 'section', NULL, NULL, NULL, 'accountMenuSection', FALSE, FALSE, TRUE, FALSE, 200, 'common', 'system', 'system', NOW()),
      (t, 'account.signin', 'item', 'section.account', 'account.signin', '/mainPages/signin', 'homeSignin', FALSE, FALSE, TRUE, FALSE, 210, 'common', 'system', 'system', NOW()),
      (t, 'account.signup', 'item', 'section.account', 'account.signup', '/mainPages/signup', 'homeSignup', FALSE, FALSE, TRUE, FALSE, 220, 'common', 'system', 'system', NOW()),
      (t, 'section.admin', 'section', NULL, NULL, NULL, 'adminMenuSection', TRUE, TRUE, FALSE, TRUE, 900, 'common', 'system', 'system', NOW()),
      (t, 'admin.transactionHistory', 'item', 'section.admin', 'admin.transactionHistory', '/mainPages/transactionHistory', 'transactionHistory', TRUE, TRUE, FALSE, FALSE, 910, 'common', 'system', 'system', NOW()),
      (t, 'admin.userActivityDashboard', 'item', 'section.admin', 'admin.userActivityDashboard', '/mainPages/userActivityDashboard', 'userActivityDashboard', TRUE, TRUE, FALSE, FALSE, 920, 'common', 'system', 'system', NOW()),
      (t, 'admin.dbUsage', 'item', 'section.admin', 'admin.dbUsage', '/mainPages/adminDbUsage', 'adminDbUsageTitle', TRUE, TRUE, FALSE, FALSE, 930, 'common', 'system', 'system', NOW()),
      (t, 'admin.railwayDeploy', 'item', 'section.admin', 'admin.railwayDeploy', '/admin/railway-deploy', 'adminRailwayDeployTitle', TRUE, TRUE, FALSE, FALSE, 940, 'common', 'system', 'system', NOW()),
      (t, 'admin.resourceText', 'item', 'section.admin', 'admin.resourceText', '/admin/resource-text', 'adminResourceTextTitle', TRUE, TRUE, FALSE, FALSE, 950, 'common', 'system', 'system', NOW()),
      (t, 'admin.menu', 'item', 'section.admin', 'admin.menu', '/admin/menu', 'adminMenuManageTitle', TRUE, TRUE, FALSE, FALSE, 960, 'common', 'system', 'system', NOW()),
      (t, 'admin.dynamicSql', 'item', 'section.admin', 'admin.dynamicSql', '/mainPages/dynamicSql', 'dynamicSql', TRUE, TRUE, FALSE, FALSE, 970, 'common', 'system', 'system', NOW()),
      (t, 'section.mobileTabBar', 'section', NULL, NULL, NULL, 'mobileBottomNav', FALSE, TRUE, FALSE, FALSE, 1000, 'mobileTabBar', 'system', 'system', NOW()),
      (t, 'tab.chat', 'item', 'section.mobileTabBar', 'main.directChat', '/mainPages/chatRoom?roomType=DIRECT', 'TAB_CHAT', FALSE, TRUE, FALSE, FALSE, 1010, 'mobileTabBar', 'system', 'system', NOW()),
      (t, 'tab.friends', 'item', 'section.mobileTabBar', 'main.friends', '/mainPages/userFriendManagement', 'TAB_FRIENDS', FALSE, TRUE, FALSE, FALSE, 1020, 'mobileTabBar', 'system', 'system', NOW()),
      (t, 'tab.schedule', 'item', 'section.mobileTabBar', 'main.schedule', '/mainPages/schedule', 'TAB_SCHEDULE', FALSE, TRUE, FALSE, FALSE, 1030, 'mobileTabBar', 'system', 'system', NOW())
    ON CONFLICT (system_code, menu_id) DO UPDATE SET
      menu_type = EXCLUDED.menu_type,
      parent_menu_id = EXCLUDED.parent_menu_id,
      screen_id = EXCLUDED.screen_id,
      href = EXCLUDED.href,
      label_resource_key = EXCLUDED.label_resource_key,
      admin_only = EXCLUDED.admin_only,
      login_required = EXCLUDED.login_required,
      hide_when_logged_in = EXCLUDED.hide_when_logged_in,
      initially_open = EXCLUDED.initially_open,
      sort_order = EXCLUDED.sort_order,
      menu_scope = EXCLUDED.menu_scope,
      update_user_id = EXCLUDED.update_user_id,
      update_time = NOW()
    WHERE target_menu.create_user_id = 'system';

    UPDATE brunner_template.tb_cor_menu
    SET icon_name = CASE menu_id
      WHEN 'tab.chat' THEN 'chat'
      WHEN 'tab.friends' THEN 'friends'
      WHEN 'tab.schedule' THEN 'schedule'
      ELSE icon_name
    END,
    update_user_id = 'system',
    update_time = NOW()
    WHERE system_code = t
      AND menu_id IN ('tab.chat', 'tab.friends', 'tab.schedule')
      AND create_user_id = 'system';
  END LOOP;
END
$seed_menu_common$;
