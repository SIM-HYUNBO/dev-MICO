const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const listPath = path.join(root, "scripts", "install_sql_files.json");
const raw = JSON.parse(fs.readFileSync(listPath, "utf8"));
const files = (Array.isArray(raw) ? raw : raw.files || []).map((entry) =>
  String(typeof entry === "string" ? entry : entry?.file || "").trim(),
);

const required = ["create_menu_tables.sql", "seed_menu_common.sql"];
const missing = required.filter((file) => !files.includes(file));

if (missing.length > 0) {
  console.error(`[menu-sql-gate] install_sql_files.json missing: ${missing.join(", ")}`);
  process.exit(1);
}

const createIndex = files.indexOf("create_menu_tables.sql");
const seedIndex = files.indexOf("seed_menu_common.sql");

if (createIndex > seedIndex) {
  console.error("[menu-sql-gate] create_menu_tables.sql must run before seed_menu_common.sql.");
  process.exit(1);
}

console.log("[menu-sql-gate] OK - menu tables and seed are in the install list.");
