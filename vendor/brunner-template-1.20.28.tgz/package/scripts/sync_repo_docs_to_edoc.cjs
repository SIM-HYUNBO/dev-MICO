// scripts/sync_repo_docs_to_edoc.cjs
// Sync repository Markdown files into public eDoc documents.

const { Client } = require("pg");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

require("dotenv").config({ path: path.join(__dirname, "../.env") });

// 이 배포가 바라볼 스키마. 테넌트로 합류하면 brunner 를 본다.
// 소문자로 접는다 — lib/dbSchema.js 와 같은 규칙.
const SCHEMA = (process.env.DB_SCHEMA || "").trim().toLowerCase() || "brunner_template";
// 스키마 형식을 검사한 뒤 따옴표 없이 쓴다.
//
// 왜
//   테이블은 따옴표 없이 만들어져 소문자로 존재한다. 여기서 대문자 이름을
//   따옴표로 감싸면 "brunner"."TB_COR_SQL_INFO" 가 되어 42P01 로 죽는다.
//   실제로 이 두 스크립트만 그렇게 죽어 있었고, || true 로 감싸여 있어
//   배포는 성공하고 문서 동기화와 SQL 검증만 조용히 멈춰 있었다.
//   lib/dbSchema.js 의 qualifiedTable 과 같은 규칙으로 맞춘다.
if (!/^[a-z_][a-z0-9_]*$/.test(SCHEMA)) {
  console.error(`[${require("path").basename(__filename)}] DB_SCHEMA 형식이 올바르지 않다: ${SCHEMA}`);
  process.exit(1);
}
const qualifiedTable = (tableName) => `${SCHEMA}.${tableName}`;


// 누락이면 '00' 으로 떨어지지 않고 멈춘다. 설정을 빠뜨린 배포가 조용히
// 남의 테넌트 문서를 덮어쓰는 쪽이 훨씬 위험하다. 두 자리 영숫자여야 한다.
const SYSTEM_CODE = (process.env.SYSTEM_CODE || "").trim();
if (!/^[A-Za-z0-9]{2}$/.test(SYSTEM_CODE)) {
  console.error(
    `[repo-doc-sync] SYSTEM_CODE 는 두 자리 영숫자여야 한다: ${JSON.stringify(SYSTEM_CODE)}`,
  );
  process.exit(1);
}
const SYNC_USER_ID = process.env.REPO_DOC_SYNC_USER_ID || process.env.ADMIN_USER_ID || "admin";
const MAX_SYNC_ATTEMPTS = Number(process.env.REPO_DOC_SYNC_ATTEMPTS || 4);
const SYNC_RETRY_DELAY_MS = Number(process.env.REPO_DOC_SYNC_RETRY_DELAY_MS || 10000);

const DOCS = [
  {
    key: "repo-readme",
    file: "README.md",
    title: "README",
    description: "Repository README synchronized from README.md",
    menuPath: "Repository/README",
    // 공개 여부는 서버가 실제로 보는 값이다(목록·단건 조회 모두). 사용자 매뉴얼만 공개.
    isPublic: true,
  },
  {
    key: "repo-readme-admin",
    file: "README-admin.md",
    title: "README (관리자)",
    description: "Repository admin guide synchronized from README-admin.md",
    menuPath: "Repository/README-admin",
    // 관리자·내부 문서. isPublic=false 면 목록에서 빠지고 단건 조회도 소유자/관리자만 된다.
    isPublic: false,
  },
  {
    key: "repo-plan",
    file: "PLAN.md",
    title: "PLAN",
    description: "Repository plan synchronized from PLAN.md",
    menuPath: "Repository/PLAN",
    // 관리자·내부 문서. isPublic=false 면 목록에서 빠지고 단건 조회도 소유자/관리자만 된다.
    isPublic: false,
  },
  {
    key: "repo-offering",
    file: "Offering.md",
    title: "Offering",
    description: "Business offering synchronized from Offering.md",
    menuPath: "Repository/Offering",
    // 관리자·내부 문서. isPublic=false 면 목록에서 빠지고 단건 조회도 소유자/관리자만 된다.
    isPublic: false,
  },
  {
    key: "repo-contract",
    file: "Contract.md",
    title: "Contract",
    description: "Development contract template synchronized from Contract.md",
    menuPath: "Repository/Contract",
    // 관리자·내부 문서. isPublic=false 면 목록에서 빠지고 단건 조회도 소유자/관리자만 된다.
    isPublic: false,
  },
].map((doc) => ({ ...doc, id: stableUUID(doc.key) }));

const componentType = {
  text: "Text",
  table: "Table",
  image: "Image",
  checklist: "Checklist",
  linkText: "LinkText",
  button: "Button",
};

function stableId(prefix, seed) {
  const hash = crypto.createHash("sha1").update(seed).digest("hex").slice(0, 10);
  return `${prefix}-${hash}`;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// UUID v4 포맷의 고정 ID 생성 (seed 기반 결정론적)
function stableUUID(seed) {
  const hash = crypto.createHash("sha1").update(seed).digest("hex");
  return [
    hash.slice(0, 8),
    hash.slice(8, 12),
    "4" + hash.slice(13, 16),
    ((parseInt(hash[16], 16) & 0x3) | 0x8).toString(16) + hash.slice(17, 20),
    hash.slice(20, 32),
  ].join("-");
}

function makeComponent(type, runtimeData, seed) {
  return {
    id: stableId("comp", `${type}:${seed}`),
    type,
    runtime_data: runtimeData,
  };
}

// 인용문(">") 안에 들어간 코드펜스도 코드펜스다.
// "> ```json" 은 trimmed.startsWith("```") 에 걸리지 않아, 인용 블록 안의 코드가
// 그대로 사용자 문서 본문에 실렸다. 인용 표시를 걷어낸 뒤 판단한다.
const isFence = (line) => /^>*\s*```/.test(String(line).trim());

function parseTableRow(line) {
  // 셀 안의 "\|" 는 파이프 문자 자체다. 그대로 split 하면 열이 하나 늘어
  // 헤더와 개수가 어긋나고, 표가 통째로 밀려 렌더된다. (표 문법을 설명하는
  // 행에서 실제로 그렇게 깨졌다.) 이스케이프되지 않은 파이프에서만 자른다.
  return line
    .split(/(?<!\\)\|/)
    .map((cell) => cell.trim().replace(/\\\|/g, "|"))
    .filter((_, index, items) => index > 0 && index < items.length - 1);
}

function markdownToComponents(markdown, docId) {
  const lines = markdown.split("\n");
  const components = [];
  let index = 0;

  while (index < lines.length) {
    const line = lines[index];
    const trimmed = line.trim();

    if (!trimmed) {
      index += 1;
      continue;
    }

    // 코드블록(``` ... ```)은 문서 컴포넌트로 옮길 자리가 없다.
    //
    // 처리하지 않으면 펜스 안 내용이 한 줄씩 본문 텍스트가 되어, 사용자에게 보이는
    // 문서에 "sequenceDiagram", "User->>Home: ..." 같은 mermaid 소스가 그대로
    // 쏟아진다. GitHub 에서는 그림으로 보이는 편이 좋으므로 원본은 두고,
    // 문서로 옮길 때만 건너뛴다.
    if (isFence(trimmed)) {
      index += 1;
      while (index < lines.length && !isFence(lines[index])) {
        index += 1;
      }
      index += 1; // 닫는 펜스
      continue;
    }

    if (trimmed === "---") {
      components.push(makeComponent(componentType.text, {
        content: "─────────────────────────────",
        fontSize: 10,
        fontFamily: "Arial",
        textAlign: "center",
      }, `${docId}:${index}:${line}`));
      index += 1;
      continue;
    }

    if (/^<!--.*-->$/.test(trimmed)) {
      index += 1;
      continue;
    }

    const heading = line.match(/^(#{1,6})\s+(.*)/);
    if (heading) {
      const level = heading[1].length;
      components.push(makeComponent(componentType.text, {
        content: heading[2],
        fontSize: Math.max(10, 24 - (level - 1) * 4),
        fontFamily: "Arial",
        fontWeight: level <= 2 ? "bold" : "normal",
        textAlign: "left",
      }, `${docId}:${index}:${line}`));
      index += 1;
      continue;
    }

    const image = line.match(/^!\[([^\]]*)\]\(([^)]+)\)/);
    if (image) {
      components.push(makeComponent(componentType.image, {
        src: image[2],
        alt: image[1],
        height: "auto",
        positionAlign: "center",
      }, `${docId}:${index}:${line}`));
      index += 1;
      continue;
    }

    const link = line.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
    if (link) {
      components.push(makeComponent(componentType.linkText, {
        content: link[1],
        url: link[2],
        textAlign: "left",
      }, `${docId}:${index}:${line}`));
      index += 1;
      continue;
    }

    const button = line.match(/^\*\*\[(.+)\]\*\*$/);
    if (button) {
      components.push(makeComponent(componentType.button, {
        buttonText: button[1],
        buttonColor: "#4F46E5",
        textColor: "#FFFFFF",
        padding: "10px 20px",
        borderRadius: "6px",
      }, `${docId}:${index}:${line}`));
      index += 1;
      continue;
    }

    if (/^-\s*\[[ x]\]/.test(line)) {
      const items = [];
      const start = index;
      while (index < lines.length && /^-\s*\[[ x]\]/.test(lines[index])) {
        const item = lines[index].match(/^-\s*\[([ x])\]\s*(.*)/);
        if (item) items.push({ label: item[2], checked: item[1] === "x" });
        index += 1;
      }
      components.push(makeComponent(componentType.checklist, { items }, `${docId}:${start}:${items.length}`));
      continue;
    }

    if (trimmed.startsWith("|")) {
      const tableLines = [];
      const start = index;
      while (index < lines.length && lines[index].trim().startsWith("|")) {
        tableLines.push(lines[index]);
        index += 1;
      }

      const headers = parseTableRow(tableLines[0] || "");
      // 열 폭을 150px 로 박으면 내용이 긴 열이 잘려 읽을 수 없다. 표 컴포넌트의
      // 기본값("auto")에 맡겨 내용에 맞춰 늘어나게 둔다.
      const columns = headers.map((header) => ({ header, width: "auto", align: "left" }));
      const rows = tableLines.slice(2).map(parseTableRow);
      // 문서의 표는 읽는 것이지 채우는 것이 아니다. editable 을 켜두면 뷰어에서 셀이
      // 한 줄짜리 input 으로 그려져 내용이 길면 그냥 잘린다.
      components.push(makeComponent(componentType.table, { columns, rows, editable: false }, `${docId}:${start}:${tableLines.join("\n")}`));
      continue;
    }

    const textLines = [];
    const start = index;
    while (
      index < lines.length &&
      lines[index].trim() &&
      lines[index].trim() !== "---" &&
      !lines[index].match(/^#{1,6}\s/) &&
      !lines[index].match(/^!\[/) &&
      !lines[index].trim().startsWith("|") &&
      !lines[index].match(/^-\s*\[[ x]\]/) &&
      // 코드펜스는 위에서 건너뛰지만, 텍스트를 모으기 시작한 뒤에 펜스를 만나면
      // 여기서 멈추지 않는 한 그대로 본문에 딸려 들어간다. 실제로 목록 항목
      // 안에 들여쓴 ``` 블록이 사용자 문서에 소스째 실리고 있었다.
      !isFence(lines[index]) &&
      !/^<!--.*-->$/.test(lines[index].trim())
    ) {
      textLines.push(lines[index]);
      index += 1;
    }

    if (textLines.length > 0) {
      components.push(makeComponent(componentType.text, {
        content: textLines.join("\n"),
        fontSize: 12,
        fontFamily: "Arial",
        textAlign: "left",
      }, `${docId}:${start}:${textLines.join("\n")}`));
    }
  }

  return components;
}

function markdownToEDoc(markdown, doc) {
  const titleMatch = markdown.match(/^#\s+(.+)/m);
  const title = doc.title || (titleMatch ? titleMatch[1] : doc.file);

  return {
    id: doc.id,
    runtime_data: {
      title,
      description: doc.description,
      isPublic: doc.isPublic !== false,
      adminOnly: doc.adminOnly === true,
      backgroundColor: "#ffffff",
      padding: 1,
      menu_path: doc.menuPath,
      source_file: doc.file,
      source_sync: "repository",
      synced_at: new Date().toISOString(),
    },
    pages: [
      {
        id: stableId("page", doc.id),
        components: markdownToComponents(markdown, doc.id),
        runtime_data: {
          padding: 24,
          alignment: "left",
          backgroundColor: "#ffffff",
          pageSize: "Auto",
        },
      },
    ],
  };
}

async function getDynamicSQL(client, sqlName, sqlSeq) {
  const result = await client.query(
    `
      SELECT sql_content
        FROM ${qualifiedTable("TB_COR_SQL_INFO")}
       WHERE system_code = $1
         AND sql_name = $2
         AND sql_seq = $3
    `,
    [SYSTEM_CODE, sqlName, sqlSeq],
  );

  if (result.rowCount !== 1) {
    throw new Error(`Dynamic SQL not found: ${sqlName} #${sqlSeq}`);
  }

  return result.rows[0].sql_content;
}

async function syncDocument(client, sqls, doc) {
  const filePath = path.join(__dirname, "..", doc.file);
  if (!fs.existsSync(filePath)) {
    throw new Error(`Document source not found: ${doc.file}`);
  }

  const markdown = fs.readFileSync(filePath, "utf8");
  const documentData = markdownToEDoc(markdown, doc);

  // menu_path로 기존 문서 먼저 조회 — 수동 생성 문서 ID를 그대로 유지
  const byPathResult = await client.query(
    `SELECT id FROM ${qualifiedTable("TB_COR_EDOC_DOCUMENT")}
      WHERE system_code = $1
        AND menu_path = $2
      LIMIT 1`,
    [SYSTEM_CODE, doc.menuPath],
  );

  const existingId = byPathResult.rowCount > 0 ? byPathResult.rows[0].id : null;
  const targetId = existingId || doc.id;

  // stableUUID로 만든 별도 문서가 이미 있으면 삭제 (중복 제거)
  if (existingId && existingId !== doc.id) {
    await client.query(
      `DELETE FROM ${qualifiedTable("TB_COR_EDOC_DOCUMENT")} WHERE system_code = $1 AND id = $2`,
      [SYSTEM_CODE, doc.id],
    );
  }

  const selectResult = await client.query(sqls.selectOne, [SYSTEM_CODE, targetId]);

  if (selectResult.rowCount > 0) {
    const updateResult = await client.query(sqls.updateOne, [
      SYSTEM_CODE,
      targetId,
      documentData.runtime_data.title,
      documentData.runtime_data.description,
      SYNC_USER_ID,
      JSON.stringify(documentData.runtime_data),
      JSON.stringify(documentData.pages),
      documentData.runtime_data.menu_path,
    ]);

    if (updateResult.rowCount !== 1) {
      throw new Error(`Failed to update synced document: ${targetId}`);
    }

    console.log(`Updated ${doc.file} -> ${targetId}`);
    return;
  }

  const insertResult = await client.query(sqls.insertOne, [
    SYSTEM_CODE,
    targetId,
    documentData.runtime_data.title,
    documentData.runtime_data.description,
    1,
    SYNC_USER_ID,
    JSON.stringify(documentData.runtime_data),
    JSON.stringify(documentData.pages),
    documentData.runtime_data.menu_path,
  ]);

  if (insertResult.rowCount !== 1) {
    throw new Error(`Failed to insert synced document: ${targetId}`);
  }

  console.log(`Inserted ${doc.file} -> ${targetId}`);
}

async function syncAllDocuments() {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.SSL_MODE === "require" ? { rejectUnauthorized: false } : false,
    connectionTimeoutMillis: Number(process.env.REPO_DOC_SYNC_CONNECT_TIMEOUT_MS || 30000),
    query_timeout: Number(process.env.REPO_DOC_SYNC_QUERY_TIMEOUT_MS || 60000),
  });

  await client.connect();
  console.log("DB connected.");

  try {
    const sqls = {
      selectOne: await getDynamicSQL(client, "select_TB_COR_EDOC_DOCUMENT", 1),
      insertOne: await getDynamicSQL(client, "insert_TB_COR_EDOC_DOCUMENT", 1),
      updateOne: await getDynamicSQL(client, "update_TB_COR_EDOC_DOCUMENT", 1),
    };

    for (const doc of DOCS) {
      await syncDocument(client, sqls, doc);
    }
  } finally {
    await client.end();
  }

  console.log("Repository docs synchronized.");
}

async function main() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is required.");
  }

  let lastError = null;

  for (let attempt = 1; attempt <= MAX_SYNC_ATTEMPTS; attempt += 1) {
    try {
      console.log(`Repository doc sync attempt ${attempt}/${MAX_SYNC_ATTEMPTS}`);
      await syncAllDocuments();
      return;
    } catch (err) {
      lastError = err;
      console.warn(`Repository doc sync attempt ${attempt} failed: ${err.message}`);

      if (attempt < MAX_SYNC_ATTEMPTS) {
        await sleep(SYNC_RETRY_DELAY_MS);
      }
    }
  }

  throw lastError;
}

main().catch((err) => {
  console.error("Repository doc sync failed:", err.message);
  process.exit(1);
});
