-- 화면 문구 관리(/admin/resource-text) 동적 SQL.
--
-- pages/api/biz/resourceText.js 가 아래 네 이름을 요구한다. 하나라도 없으면
-- 그 화면만 조용히 죽는다.
--
-- 키 목록과 본문을 나눠 조회한다
--   한 테넌트의 리소스 행은 7천 줄이 넘는다. 화면이 열릴 때마다 전부 내려보내면
--   목록이 뜨기 전에 수백 KB 를 기다려야 한다. 목록은 키 단위로 페이지를 끊어
--   가져오고, 언어별 본문은 키를 고른 뒤에 가져온다.
--
-- 테넌트마다 심는다
--   스키마를 하나로 통합해 SYSTEM_CODE 로 테넌트를 가르는 구조다. '00' 으로만
--   박아두면 다른 테넌트에서 이 화면이 죽는다. 스키마를 소유한 배포가 그 안의
--   모든 테넌트에 심는다.
DO $seed$
DECLARE
  t    text;
  defs constant text[][] := ARRAY[
    -- 1) 키 목록: 조건으로 좁히고 키 단위로 묶어 페이지를 끊는다.
    --    $2 유형, $3 리소스 키, $4 문구 값, $5 언어 코드 (각각 널이면 조건 없음)
    --    $6 limit, $7 offset
    --    셋을 한 검색어로 합치지 않는다 — 키로 찾을 때와 문구로 찾을 때 원하는
    --    결과가 다르고, 합쳐두면 한쪽만 좁히려 해도 다른 쪽이 딸려 온다.
    ['select_TB_COR_RESOURCE_TEXT_KEY_LIST',
     'SELECT RESOURCE_TYPE, RESOURCE_KEY, COUNT(*)::int AS LANGUAGE_COUNT, MAX(UPDATE_TIME) AS LAST_UPDATE_TIME '
     || 'FROM brunner_template.TB_COR_RESOURCE_TEXT '
     || 'WHERE SYSTEM_CODE = $1 '
     || 'AND ($2::text IS NULL OR RESOURCE_TYPE = $2::text) '
     || 'AND ($3::text IS NULL OR RESOURCE_KEY ILIKE ''%'' || $3::text || ''%'') '
     || 'AND ($4::text IS NULL OR RESOURCE_TEXT ILIKE ''%'' || $4::text || ''%'') '
     || 'AND ($5::text IS NULL OR LANGUAGE_CODE ILIKE ''%'' || $5::text || ''%'') '
     || 'GROUP BY RESOURCE_TYPE, RESOURCE_KEY '
     || 'ORDER BY RESOURCE_TYPE, RESOURCE_KEY '
     || 'LIMIT $6 OFFSET $7'],

    -- 2) 검색 결과의 전체 키 수. 페이지 이동을 위해 목록과 같은 조건으로 센다.
    ['select_TB_COR_RESOURCE_TEXT_KEY_COUNT',
     'SELECT COUNT(*)::int AS TOTAL_COUNT FROM ( '
     || 'SELECT 1 FROM brunner_template.TB_COR_RESOURCE_TEXT '
     || 'WHERE SYSTEM_CODE = $1 '
     || 'AND ($2::text IS NULL OR RESOURCE_TYPE = $2::text) '
     || 'AND ($3::text IS NULL OR RESOURCE_KEY ILIKE ''%'' || $3::text || ''%'') '
     || 'AND ($4::text IS NULL OR RESOURCE_TEXT ILIKE ''%'' || $4::text || ''%'') '
     || 'AND ($5::text IS NULL OR LANGUAGE_CODE ILIKE ''%'' || $5::text || ''%'') '
     || 'GROUP BY RESOURCE_TYPE, RESOURCE_KEY) x'],

    -- 3) 고른 키의 언어별 본문.
    ['select_TB_COR_RESOURCE_TEXT_DETAIL',
     'SELECT LANGUAGE_CODE, RESOURCE_TEXT, IS_ACTIVE, UPDATE_USER_ID, UPDATE_TIME '
     || 'FROM brunner_template.TB_COR_RESOURCE_TEXT '
     || 'WHERE SYSTEM_CODE = $1 AND RESOURCE_TYPE = $2 AND RESOURCE_KEY = $3 '
     || 'ORDER BY LANGUAGE_CODE'],

    -- 4) 한 언어 저장. 없던 언어를 채울 수 있어야 하므로 upsert 다.
    --    UPDATE_USER_ID 에 고친 사람을 남긴다 — seed 가 심은 행은 'system' 이다.
    ['upsert_TB_COR_RESOURCE_TEXT',
     'INSERT INTO brunner_template.TB_COR_RESOURCE_TEXT '
     || '(SYSTEM_CODE, RESOURCE_TYPE, RESOURCE_KEY, LANGUAGE_CODE, RESOURCE_TEXT, IS_ACTIVE, CREATE_USER_ID, UPDATE_USER_ID, UPDATE_TIME) '
     || 'VALUES ($1, $2, $3, $4, $5, TRUE, $6, $6, NOW()) '
     || 'ON CONFLICT (SYSTEM_CODE, RESOURCE_TYPE, RESOURCE_KEY, LANGUAGE_CODE) '
     || 'DO UPDATE SET RESOURCE_TEXT = EXCLUDED.RESOURCE_TEXT, IS_ACTIVE = TRUE, '
     || 'UPDATE_USER_ID = EXCLUDED.UPDATE_USER_ID, UPDATE_TIME = NOW()'],

    -- 5) 이 시스템에 실제로 쓰이는 언어 목록.
    --    화면이 언어를 ko/en/ja 로 박아두면 언어가 늘어도 그 화면에서는 안 보인다.
    --    무엇을 보여줄지는 코드가 아니라 데이터가 정한다.
    ['select_TB_COR_RESOURCE_TEXT_LANGUAGE_LIST',
     'SELECT DISTINCT LANGUAGE_CODE FROM brunner_template.TB_COR_RESOURCE_TEXT '
     || 'WHERE SYSTEM_CODE = $1 ORDER BY LANGUAGE_CODE'],

    -- 6) 삭제. $4 가 널이면 그 키의 모든 언어를, 언어를 주면 그 한 줄만 지운다.
    ['delete_TB_COR_RESOURCE_TEXT',
     'DELETE FROM brunner_template.TB_COR_RESOURCE_TEXT '
     || 'WHERE SYSTEM_CODE = $1 AND RESOURCE_TYPE = $2 AND RESOURCE_KEY = $3 '
     || 'AND ($4::text IS NULL OR LANGUAGE_CODE = $4::text)']
  ];
  i int;
BEGIN
  IF to_regclass('brunner_template.tb_cor_resource_text') IS NULL THEN
    RAISE NOTICE 'skip insert_dynamic_sql_resource_text: TB_COR_RESOURCE_TEXT does not exist';
    RETURN;
  END IF;

  FOR t IN
    SELECT code FROM (
      SELECT DISTINCT system_code AS code FROM brunner_template.TB_COR_SQL_INFO
      UNION SELECT '00'
    ) x ORDER BY code
  LOOP
    FOR i IN 1 .. array_length(defs, 1) LOOP
      INSERT INTO brunner_template.TB_COR_SQL_INFO
        (SYSTEM_CODE, SQL_NAME, SQL_SEQ, SQL_CONTENT, CREATE_USER_ID, CREATE_TIME)
      VALUES (t, defs[i][1], 1, defs[i][2], 'claude', NOW())
      ON CONFLICT (SYSTEM_CODE, SQL_NAME, SQL_SEQ)
      DO UPDATE SET SQL_CONTENT = EXCLUDED.SQL_CONTENT, CREATE_TIME = NOW();
    END LOOP;
  END LOOP;
END
$seed$;
